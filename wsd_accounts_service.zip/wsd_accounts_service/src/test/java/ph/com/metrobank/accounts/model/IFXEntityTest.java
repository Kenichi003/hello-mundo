package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.ifx.AcctBal;
import ph.com.metrobank.accounts.model.ifx.AcctInfo;
import ph.com.metrobank.accounts.model.ifx.AcctInqRs;
import ph.com.metrobank.accounts.model.ifx.AcctRec;
import ph.com.metrobank.accounts.model.ifx.BalType;
import ph.com.metrobank.accounts.model.ifx.CurAmt;
import ph.com.metrobank.accounts.model.ifx.Status;

@RunWith(SpringJUnit4ClassRunner.class)
public class IFXEntityTest {

	private AcctBal acctBal = new AcctBal();
	private AcctInqRs acctInqRs = new AcctInqRs();
	private Status status = new Status();
	private AcctInfo acctInfo = new AcctInfo();
	private AcctRec acctRec = new AcctRec();
	private BalType balType = new BalType();
	private CurAmt curAmt = new CurAmt();

	@Before
	public void setUp() {
		acctBal.getBalType();
		acctBal.getCurAmt();
		acctInqRs.getAcctRec();
		acctInqRs.getStatus();
		status.getStatusCode();
		status.getStatusDesc();
		acctInfo.getAcctBal();
		acctRec.getAcctInfo();
		balType.getBalTypeValues();
		curAmt.getAmt();
	}

	@Test
	public void testIFXValue1() {
		acctRec.setAcctInfo(new AcctInfo());
		acctRec.getAcctInfo();
		acctInfo.setAcctBal(new ArrayList<>());
		acctInfo.getAcctBal();
		acctInqRs.setAcctRec(new AcctRec());
		acctInqRs.setStatus(new Status());
		acctInqRs.getAcctRec();
		acctInqRs.getStatus();
		acctBal.setBalType(new BalType());
		acctBal.setCurAmt(new CurAmt());
		acctBal.getBalType();
		acctBal.getCurAmt();
		assertThat(acctBal).isNotNull();
		assertThat(acctInqRs).isNotNull();
		assertThat(status).isNotNull();
		assertThat(acctInfo).isNotNull();
		assertThat(acctRec).isNotNull();
		assertThat(balType).isNotNull();
		assertThat(curAmt).isNotNull();
	}

}
