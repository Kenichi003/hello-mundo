package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.Account;
import ph.com.metrobank.accounts.model.AccountAlias;

@RunWith(SpringJUnit4ClassRunner.class)
public class AccountAliasEntityTest {

	private AccountAlias accountAlias;
	private AccountAlias accountAlias2;
	private Account account;
	
	@Before
	public void setUp() {
		account = new Account();
		account = new Account("type","value");
		accountAlias = new AccountAlias();
		accountAlias = new AccountAlias("id",account);
		
		accountAlias2 = new AccountAlias();
		accountAlias2.getAccountName();
	}
	
	@Test
	public void testAccountAliasValue() {	
		assertThat(accountAlias.getId()).isEqualTo("id");
		assertThat(accountAlias.getAccountName()).isEqualToComparingFieldByField(account);
	}

}
