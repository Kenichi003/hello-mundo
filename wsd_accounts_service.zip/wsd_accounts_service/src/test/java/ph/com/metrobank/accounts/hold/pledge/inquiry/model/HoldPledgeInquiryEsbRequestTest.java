package ph.com.metrobank.accounts.hold.pledge.inquiry.model;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;

import ph.com.metrobank.accounts.hold.pledge.release.models.Credentials;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryEsbRequest;
import ph.com.metrobank.accounts.hold.pledge.release.models.TransInfo;

public class HoldPledgeInquiryEsbRequestTest {

private HoldPledgeInquiryEsbRequest holdPledgeInquiryEsbRequest;
	
	@Before
	public void setUp() throws Exception {
		holdPledgeInquiryEsbRequest = generateHoldInquiryRequest();
	}

	@Test
	public void testHoldInquiryRequest() {
		assertEquals("3123456789", holdPledgeInquiryEsbRequest.getAccountNumber().toString());
		assertEquals("123", holdPledgeInquiryEsbRequest.getBranchCode());
		assertEquals("password", holdPledgeInquiryEsbRequest.getCredentials().getPassword());
		assertEquals("systemID", holdPledgeInquiryEsbRequest.getCredentials().getSystemID());
		assertEquals("608", holdPledgeInquiryEsbRequest.getCurrencyCode());
		assertEquals("keyoflastrecord", holdPledgeInquiryEsbRequest.getKeyOfLastRecord());
		assertEquals("123", holdPledgeInquiryEsbRequest.getOriginatingBranchCode());
		assertEquals("testsearchdescription", holdPledgeInquiryEsbRequest.getSearchDescription());
		assertEquals("testsearch", holdPledgeInquiryEsbRequest.getSearchString());
		assertEquals("test", holdPledgeInquiryEsbRequest.getTransactionInformation().getChannelTransaction());
		assertEquals("2019-10-29", holdPledgeInquiryEsbRequest.getTransactionInformation().getDateStamp());
		assertEquals("123", holdPledgeInquiryEsbRequest.getTransactionInformation().getProcessingBranch());
		assertEquals("1234567", holdPledgeInquiryEsbRequest.getTransactionInformation().getSequenceNumber().toString());
		assertEquals("123", holdPledgeInquiryEsbRequest.getTransactionInformation().getServicingBranch());
		assertEquals("P", holdPledgeInquiryEsbRequest.getTransactionInformation().getSourceProductCode());
		assertEquals("09:58:01", holdPledgeInquiryEsbRequest.getTransactionInformation().getTimeStamp());
		
	}

	private HoldPledgeInquiryEsbRequest generateHoldInquiryRequest() {
		HoldPledgeInquiryEsbRequest holdInquiryRequest = new HoldPledgeInquiryEsbRequest();
		
		Credentials credentials = new Credentials();
		credentials.setPassword("password");
		credentials.setSystemID("systemID");
		
		TransInfo transactionInformation = new TransInfo();
		transactionInformation.setChannelTransaction("test");
		transactionInformation.setDateStamp("2019-10-29");
		transactionInformation.setProcessingBranch("123");
		transactionInformation.setSequenceNumber(new BigInteger("1234567"));
		transactionInformation.setServicingBranch("123");
		transactionInformation.setSourceProductCode("P");
		transactionInformation.setTimeStamp("09:58:01");
		
		holdInquiryRequest.setAccountNumber("3123456789");
		holdInquiryRequest.setBranchCode("123");
		holdInquiryRequest.setCredentials(credentials);
		holdInquiryRequest.setCurrencyCode("608");
		holdInquiryRequest.setKeyOfLastRecord("keyoflastrecord");
		holdInquiryRequest.setOriginatingBranchCode("123");
		holdInquiryRequest.setSearchDescription("testsearchdescription");
		holdInquiryRequest.setSearchString("testsearch");
		holdInquiryRequest.setTransactionInformation(transactionInformation);
		
		return holdInquiryRequest;
	}

}
