package ph.com.metrobank.accounts;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.pgw.osb.account.status.detail.AccountDetailsInquiryResponse;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeResponse;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryResponse;
import ph.com.metrobank.accounts.hold.pledge.release.services.AddHoldPledgeService;
import ph.com.metrobank.accounts.hold.pledge.release.services.HoldPledgeInquiryService;
import ph.com.metrobank.accounts.hold.pledge.release.services.ReleaseHoldPledgeService;
import ph.com.metrobank.accounts.model.CasaModel;
import ph.com.metrobank.accounts.model.CasaResponse;
import ph.com.metrobank.accounts.model.ifx.AcctInqRs;
import ph.com.metrobank.accounts.services.AccountStatusService;
import ph.com.metrobank.accounts.services.GenerateUUIDService;
import ph.com.metrobank.accounts.services.LoggingService;
import ph.com.metrobank.accounts.services.OrchestrationService;

@RunWith(SpringJUnit4ClassRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(properties = "spring.profiles.active=dev")
@ContextConfiguration(classes = { AccountsApplication.class })
public class AccountsControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private LoggingService loggingService;

	@MockBean
	private GenerateUUIDService generateUUIDService;

	@MockBean
	private OrchestrationService orchestrationService;
	
	@MockBean
	private AccountStatusService accountStatusService;
	
	@MockBean
	private HoldPledgeInquiryService holdPledgeInquiryService;
	
	@MockBean
	private ReleaseHoldPledgeService releaseHoldPledgeService;
	
	@MockBean
	private AddHoldPledgeService addHoldPledgeService;

	private CasaModel casaModel;
	private List<CasaModel> casaModelList;
	private List<CasaResponse> casaResponse;
	
	private AccountDetailsInquiryResponse accountDetailsInquiryResponse;

	@Before
	public void setUp() {
		casaModelList = new ArrayList<>();
		casaResponse = new ArrayList<>();

		casaModel = new CasaModel();
		casaModel.setId("1024");
		casaModel.setAccountNo("123456789");
		casaModel.setCreated(null);
		casaModel.setCurrencyCode("001");
		casaModel.setDocumentId("123");
		casaModel.setProductType("AA");
		casaModel.setOwner("reagan1215");
		casaModelList.add(casaModel);
		
		accountDetailsInquiryResponse = new AccountDetailsInquiryResponse();
		accountDetailsInquiryResponse.setAccountName("Test Name");
		accountDetailsInquiryResponse.setAccountNumber("1234567890");
		accountDetailsInquiryResponse.setAccountStatus("teststatus");
		accountDetailsInquiryResponse.setAvailableBalance("1000");
		accountDetailsInquiryResponse.setAvailableBalanceAsOfATA("1000");
		accountDetailsInquiryResponse.setCurrentBalance("1000");
		accountDetailsInquiryResponse.setProductDescription("Test description");
	}

	@Test
	public void testGetCasa() throws Exception {
		when(orchestrationService.getCasa("reagan1215", "1")).thenReturn(casaResponse);
		mockMvc.perform(get("/wsd/getCasa/{owner}", "mark").contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetCasa2() throws Exception {
		when(orchestrationService.getCasa(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(new RuntimeException("Unexpected Exception"));
		mockMvc.perform(get("/wsd/getCasa/{owner}", "mark").contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetAccountNo() throws Exception {
		when(orchestrationService.getAccountNo("1")).thenReturn("1234567891234");
		mockMvc.perform(get("/wsd/getAccountNo/{id}", "1")).andExpect(status().isOk());
	}

	@Test
	public void testGetAccountNickname() throws Exception {
		when(orchestrationService.getAccountNickname("1")).thenReturn("1234567891234");
		mockMvc.perform(get("/wsd/getAccountNickname/{accountNo}", "1")).andExpect(status().isOk());
	}

	@Test
	public void testHealthCheck() throws Exception {
		mockMvc.perform(get("/wsd/healthCheck")).andExpect(status().isOk());
	}

	@Test
	public void testInquiryAcctBalance() throws Exception {
		when(orchestrationService.inquireCasa(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(new AcctInqRs());
		mockMvc.perform(get("/wsd/inquiry/acctBalance/{accountNo}", "1")).andExpect(status().isOk());
	}
	
	@Test
	public void testInquireAccountStatus() throws Exception {
		when(accountStatusService.getAccountStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Optional.of(accountDetailsInquiryResponse));
		mockMvc.perform(get("/wsd/inquiry/acctStatus/{accountNo}/{currencyCode}", "1234567890", "608"))
				.andExpect(status().isOk());
	}
	
	@Test
	public void testGetHoldPledge() throws Exception {
		HoldPledgeInquiryResponse holdPledgeInquiryResponse = new HoldPledgeInquiryResponse();
		when(holdPledgeInquiryService.holdPledgeInquireBalance(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(holdPledgeInquiryResponse);
		mockMvc.perform(get("/wsd/inquiry/holdPledgeInquiry")
				.content("test mesage"))
		.andExpect(status().isOk());
	}
	
	@Test
	public void testReleaseHoldPledge() throws Exception {
		AddReleaseHoldPledgeResponse addReleaseHoldPledgeESBResponse = new AddReleaseHoldPledgeResponse();
		when(releaseHoldPledgeService.releaseHoldPledge(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(addReleaseHoldPledgeESBResponse);
		mockMvc.perform(post("/wsd/releaseHoldPledge")
				.content("test message"))
		.andExpect(status().isOk());
	}
	
	
	@Test
	public void testAddHoldPledge() throws Exception {
		AddReleaseHoldPledgeResponse addReleaseHoldPledgeESBResponse = new AddReleaseHoldPledgeResponse();
		when(addHoldPledgeService.addHoldPledge(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(addReleaseHoldPledgeESBResponse);
		mockMvc.perform(post("/wsd/addHoldPledge")
				.content("test message"))
		.andExpect(status().isOk());
	}
	
	@Test
	public void testAccountBalance() throws Exception {
		AcctInqRs acctInqRs = new AcctInqRs();
		when(orchestrationService.orchestrateCasaBalanceInquiry(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(acctInqRs);
		mockMvc.perform(get("/wsd/inquiry/acctBalance")
				.content("test message"))
		.andExpect(status().isOk());
	}

}