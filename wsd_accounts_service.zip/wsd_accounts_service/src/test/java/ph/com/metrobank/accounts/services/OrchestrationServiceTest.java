package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pgw.osb.adb.AccountDetailedBalanceResponse;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.model.CasaModel;
import ph.com.metrobank.accounts.model.CasaResponse;
import ph.com.metrobank.accounts.model.FrontEndTransaction;
import ph.com.metrobank.accounts.model.ifx.AcctInqRs;
import ph.com.metrobank.accounts.services.AccountBalanceOSBService;
import ph.com.metrobank.accounts.services.CasaService;
import ph.com.metrobank.accounts.services.EADocumentService;
import ph.com.metrobank.accounts.services.FrontEndTransactionService;
import ph.com.metrobank.accounts.services.LoggingService;
import ph.com.metrobank.accounts.services.OrchestrationService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
public class OrchestrationServiceTest {

	@Autowired
	private OrchestrationService orchestrationService;

	@MockBean
	private LoggingService loggingService;

	@MockBean
	private CasaService casaService;

	@MockBean
	private FrontEndTransactionService frontEndTransactionService;

	@MockBean
	private EADocumentService eaDocumentService;

	@MockBean
	private AccountBalanceOSBService accountBalanceOSBService;

	private FrontEndTransaction frontEndTransaction;
	private CasaModel casaModel;
	private CasaResponse casaResponse;
	private AccountDetailedBalanceResponse accountDetailedBalanceResponse;

	@Before
	public void setUp() {
		accountDetailedBalanceResponse = new AccountDetailedBalanceResponse();
		accountDetailedBalanceResponse.setAvailableAmount("1000");
		accountDetailedBalanceResponse.setCurrentBalance("1000");

		casaResponse = new CasaResponse("1", "123", "alias", "1000", "NA");
		casaResponse.setId("1");
		casaResponse.setAccountNo("123");
		casaResponse.setAccountAlias("alias");
		casaResponse.setBalance("1000");
		casaResponse.setRemarks("NA");

		frontEndTransaction = new FrontEndTransaction();
		frontEndTransaction.setId("1");
		frontEndTransaction.setCode("123");
		frontEndTransaction.setCreated(null);
		frontEndTransaction.setDescription("desc");
		frontEndTransaction.setEnabled("1");
		frontEndTransaction.setName("name");
		frontEndTransaction.setOtpAmount("123");
		frontEndTransaction.setProductTypes("702,123,456");
		frontEndTransaction.setTransactionLimit("1000");

		casaModel = new CasaModel();
		casaModel.setId("1024");
		casaModel.setAccountNo("123456789");
		casaModel.setCreated("09/22/2016 07:16:08.901000000 PM");
		casaModel.setCurrencyCode("001");
		casaModel.setDocumentId("123");
		casaModel.setProductType("AA");
		casaModel.setOwner("reagan1215");
	}

	@Test
	public void testGetAccountNo() throws Exception {
		when(casaService.getAccountNo(Mockito.anyString())).thenReturn("1234567891234");
		String res = orchestrationService.getAccountNo("1");
		assertThat(res).isEqualTo("1234567891234");
	}

	@Test
	public void testGetCasa1() throws Exception {
		List<CasaModel> casaList = new ArrayList<>();
		casaList.add(casaModel);
		when(frontEndTransactionService.getFrontEndTransaction()).thenReturn(frontEndTransaction);
		when(casaService.getCasaModelByOwner(Mockito.anyString(), Mockito.any())).thenReturn(casaList);
		when(accountBalanceOSBService.getBalance(Mockito.any(), Mockito.anyString()))
				.thenReturn(accountDetailedBalanceResponse);
		List<CasaResponse> res = orchestrationService.getCasa("owner", "1");
		assertThat(res).isNotEmpty();
	}

	@Test
	public void testGetCasa2() throws Exception {
		List<CasaModel> casaList = new ArrayList<>();
		casaList.add(casaModel);
		when(frontEndTransactionService.getFrontEndTransaction()).thenReturn(frontEndTransaction);
		when(casaService.getCasaModelByOwner(Mockito.anyString(), Mockito.any())).thenReturn(casaList);
		when(accountBalanceOSBService.getBalance(Mockito.any(), Mockito.anyString())).thenReturn(null);
		List<CasaResponse> res = orchestrationService.getCasa("owner", "1");
		assertThat(res).isNotEmpty();
	}

	@Test
	public void testGetAccountNickname() throws Exception {
		when(casaService.getAccountNickname(Mockito.anyString())).thenReturn(casaModel);
		when(eaDocumentService.getAccountAlias(Mockito.anyString())).thenReturn("alias");
		String res = orchestrationService.getAccountNickname("1");
		assertThat(res).isEqualTo("alias");
	}

	@Test
	public void testInquireCasa1() throws Exception {
		when(accountBalanceOSBService.getBalance(Mockito.any(), Mockito.anyString()))
				.thenReturn(accountDetailedBalanceResponse);
		AcctInqRs res = orchestrationService.inquireCasa("1234567891234", "1");
		assertThat(res).isNotNull();
	}

	@Test
	public void testInquireCasa2() throws Exception {
		when(accountBalanceOSBService.getBalance(Mockito.any(), Mockito.anyString())).thenReturn(null);
		AcctInqRs res = orchestrationService.inquireCasa("1234567891234", "1");
		assertThat(res).isNotNull();
	}
}
