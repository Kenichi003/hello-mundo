/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email emmanuel.ombrose@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import javax.xml.ws.WebServiceException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.core.env.Environment;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pgw.osb.account.status.detail.AccountDetailsInquiryResponse;
import com.pgw.osb.account.status.detail.CASAInformationInquiryStatusDetails;
import com.pgw.osb.account.status.detail.TransInfo;
import com.pgw.osb.account.status.detail.WsStatus;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.services.AccountStatusService;
import ph.com.metrobank.accounts.services.EncryptionService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
public class AccountStatusServiceTest {

	@SpyBean
	private AccountStatusService accountStatusService;

	@Mock
	private EncryptionService encSvc;

	@Mock
	private Environment env;

	@MockBean
	private LoggingService loggingService;

	private CASAInformationInquiryStatusDetails mockRequest;

	@Before
	public void setUp() {
		mockRequest = Mockito.mock(CASAInformationInquiryStatusDetails.class);
	}

	@Test
	public void testGetAccountStatusActive() throws Exception {
		Mockito.doReturn(mockRequest).when(accountStatusService)
				.createCASAInformationInquiryBalanceAndDetailsServiceStub();
		Mockito.doReturn(generateResponse()).when(mockRequest).getStatusDetails(Mockito.any(), Mockito.any(),
				Mockito.any());

		Optional<AccountDetailsInquiryResponse> res = accountStatusService.getAccountStatus("1413141442742", "608",
				"1");

		assertThat(res.get().getAccountName()).isNotEmpty();
	}

	@Test
	public void testGetAccountStatusNotActive() throws Exception {
		Optional<AccountDetailsInquiryResponse> res = accountStatusService.getAccountStatus("14131414427421", "608",
				"1");

		assertThat(res.get().getAccountName()).isNull();
	}

	@Test
	public void testGetAccountStatusException() throws Exception {
		Mockito.doReturn(mockRequest).when(accountStatusService)
				.createCASAInformationInquiryBalanceAndDetailsServiceStub();
		Mockito.doThrow(new WebServiceException()).when(mockRequest).getStatusDetails(Mockito.any(), Mockito.any(),
				Mockito.any());

		try {
			Optional<AccountDetailsInquiryResponse> res = accountStatusService.getAccountStatus("14131414427421", "608",
					"1");

			assertThat(res).isEmpty();	
		} catch (WebServiceException w) {
			
		}

	}

	private AccountDetailsInquiryResponse generateResponse() {
		AccountDetailsInquiryResponse response = new AccountDetailsInquiryResponse();
		response.setAccountName("Test Name");
		response.setAccountNumber("0000000000");
		response.setAccountStatus("Active");
		response.setAvailableBalance("0");
		response.setAvailableBalanceAsOfATA("0");
		response.setCurrentBalance("1000");
		response.setProductDescription("test description");
		response.setProductType("CIF");
		response.setTransactionInformation(new TransInfo());
		response.setWSS(new WsStatus());
		return response;
	}
}
