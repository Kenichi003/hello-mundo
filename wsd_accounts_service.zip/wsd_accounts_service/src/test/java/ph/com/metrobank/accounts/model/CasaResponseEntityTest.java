package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.CasaResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class CasaResponseEntityTest {

	private CasaResponse casaResponse;
	
	@Before
	public void setUp() {
		casaResponse = new CasaResponse("1", "123", "alias", "1000", "NA");
		casaResponse.setId("1");
		casaResponse.setAccountNo("123");
		casaResponse.setAccountAlias("alias");
		casaResponse.setBalance("1000");
		casaResponse.setRemarks("NA");
	}
	
	@Test
	public void testCasaResponseValue() {	
		assertThat(casaResponse.getId()).isEqualTo("1");
		assertThat(casaResponse.getAccountNo()).isEqualTo("123");
		assertThat(casaResponse.getAccountAlias()).isEqualTo("alias");
		assertThat(casaResponse.getBalance()).isEqualTo("1000");
		assertThat(casaResponse.getRemarks()).isEqualTo("NA");
		assertThat(casaResponse.toString()).isEqualTo(casaResponse.toString());
	}

}
