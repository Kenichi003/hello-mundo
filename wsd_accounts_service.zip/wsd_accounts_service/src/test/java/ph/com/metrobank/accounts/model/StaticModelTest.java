package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.ErrorMessage;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.model.TransactionDesc;

@RunWith(SpringJUnit4ClassRunner.class)
public class StaticModelTest {

	@Test
	public void testStaticValue() throws NoSuchFieldException, SecurityException {
		assertThat(TraceLog.MBL_CONTROLLER_GET_CASA).isEqualTo("ACCOUNT_SERVICE_CONTROLLER_GET_CASA: ");
		assertThat(ErrorMessage.MESSAGE_FORMAT_ERROR).isEqualTo("MESSAGE_FORMAT_ERROR ");
	}

	@Test(expected = IllegalStateException.class)
	public void testTraceLog() throws IllegalAccessException {
		new TraceLog();
	}

	@Test(expected = IllegalStateException.class)
	public void testErrorMessage() throws IllegalAccessException {
		new ErrorMessage();
	}

	@Test(expected = IllegalStateException.class)
	public void testTransactionDesc() throws IllegalAccessException {
		new TransactionDesc();
	}

}
