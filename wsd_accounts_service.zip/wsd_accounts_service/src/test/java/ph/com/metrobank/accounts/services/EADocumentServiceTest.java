package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.repository.EaDocumentRepository;
import ph.com.metrobank.accounts.services.EADocumentService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class EADocumentServiceTest {
	
	@Autowired
	private EADocumentService eaDocumentService;
	
	@MockBean
	private LoggingService loggingService;
	
	@MockBean
	private EaDocumentRepository eaDocumentRepository;
	
	@Test
	public void testGetJsonDataByDocumentId1() throws Exception {
		when(eaDocumentRepository.getJsonDataByDocumentId("1")).thenReturn("{\"id\":\"id\",\"accountName\":{\"type\":\"type\",\"value\":\"value\"}}");
		String result = eaDocumentService.getAccountAlias("1");
		assertThat(result).isEqualTo("value");
	}
	
	@Test
	public void testGetJsonDataByDocumentId2() throws Exception {
		when(eaDocumentRepository.getJsonDataByDocumentId("1")).thenReturn(null);
		String result = eaDocumentService.getAccountAlias("1");
		assertThat(result).isEqualTo("");
	}
}