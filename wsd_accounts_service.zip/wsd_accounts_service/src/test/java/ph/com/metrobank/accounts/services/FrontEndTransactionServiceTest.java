package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.model.FrontEndTransaction;
import ph.com.metrobank.accounts.repository.FrontEndTransactionRepository;
import ph.com.metrobank.accounts.services.FrontEndTransactionService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class FrontEndTransactionServiceTest {
	
	@Autowired
	private FrontEndTransactionService frontEndTransactionService;
	
	@MockBean
	private LoggingService loggingService;
	
	@MockBean
	private FrontEndTransactionRepository frontEndTransactionRepository;
	
	private FrontEndTransaction frontEndTransaction;
	
	@Before
	public void setUp() {
		frontEndTransaction = new FrontEndTransaction();
		frontEndTransaction.setId("1");
		frontEndTransaction.setCode("123");
		frontEndTransaction.setCreated(null);
		frontEndTransaction.setDescription("desc");
		frontEndTransaction.setEnabled("1");
		frontEndTransaction.setName("name");
		frontEndTransaction.setOtpAmount("123");
		frontEndTransaction.setProductTypes("702");
		frontEndTransaction.setTransactionLimit("1000");
	}
	
	@Test
	public void testGetFrontEndTransaction() throws Exception {
		when(frontEndTransactionRepository.getFrontEndTransaction(Mockito.anyString())).thenReturn(frontEndTransaction);
		FrontEndTransaction res = frontEndTransactionService.getFrontEndTransaction();
		assertThat(res.getTransactionLimit()).isEqualTo("1000");
	}
	
}
