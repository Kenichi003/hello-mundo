package ph.com.metrobank.accounts;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.WebRequest;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.config.CustomResponseEntityExceptionHandler;
import ph.com.metrobank.accounts.model.ErrorDetails;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class ExceptionHandlerTest {
	
	@Autowired
	private CustomResponseEntityExceptionHandler handler;
	
	@Mock
    private WebRequest webRequest;

	@Test
	public void testHandleException() {
		ResponseEntity<ErrorDetails> res = handler.handleExceptions(new Exception("error"), webRequest);
		assertThat(res.getBody().getStatus()).isEqualTo(HttpStatus.BAD_REQUEST.value());
	}

}
