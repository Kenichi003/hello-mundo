package ph.com.metrobank.accounts.util;

import static org.assertj.core.api.Assertions.assertThat;
import java.io.IOException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.model.CasaResponse;
import ph.com.metrobank.accounts.util.JsonUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class JsonUtilTest {
	
	private CasaResponse casaResponse;
	
	@Before
	public void setUp() {
		casaResponse = new CasaResponse("1", "123", "alias", "1000", "NA");
		casaResponse.setId("1");
		casaResponse.setAccountNo("123");
		casaResponse.setAccountAlias("alias");
		casaResponse.setBalance("1000");
		casaResponse.setRemarks("NA");
	}
	
	@Test
	public void testJsonUtil() throws IOException {
		CasaResponse result = JsonUtil.mapFromJson(casaResponse.toString(), CasaResponse.class);
		assertThat(result).isNotNull();
	}
}
