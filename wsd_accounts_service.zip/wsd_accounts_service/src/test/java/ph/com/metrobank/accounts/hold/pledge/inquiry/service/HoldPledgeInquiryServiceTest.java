package ph.com.metrobank.accounts.hold.pledge.inquiry.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.ConfigurationModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeDetails;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryRequest;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryResponse;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.WsStatus;
import ph.com.metrobank.accounts.hold.pledge.release.services.HoldPledgeInquiryService;
import ph.com.metrobank.accounts.model.TransactionStatus;
import ph.com.metrobank.accounts.services.BuildModelService;
import ph.com.metrobank.accounts.services.EncryptionService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
public class HoldPledgeInquiryServiceTest {

	@Autowired
	@InjectMocks
	private HoldPledgeInquiryService holdPledgeInquiryService;
	
	@Mock
    private LoggingService loggingService;
	
	@Mock
	private EncryptionService encryptionService;
	
	@Mock
    private BuildModelService buildModelService;
	
	@Mock
	private RestTemplate restTemplate;
	
	private ResponseEntity<HoldPledgeInquiryResponse> responseEntity;
	
	private RequestCommonModel requestCommonModel;
	
	private ConfigurationModel configurationModel;
	
	private HoldPledgeInquiryRequest holdPledgeInquiryRequest;
	
	private AccountsModel accountsModel;
	
	@Value("${directlink.account.inquiry}")
	private String getAccountByTokenAndMerchantIdEndpoint;
	
	@Value("${directlink.configuration.settings}")
	private String getConfigurationSettingsEndpoint;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		
		requestCommonModel = generateRequestCommonModel();
		configurationModel = generateConfigurationModel();
		holdPledgeInquiryRequest = generateHoldPledgeInquiryRequest();
		accountsModel = generateAccountsModel();
		responseEntity = generateResponseEntity();
			
		when(encryptionService.buildSignedModel(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(requestCommonModel);
		when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(configurationModel);
		when(encryptionService.verifyModel(Mockito.any(), Mockito.any(), Mockito.anyString())).thenReturn(requestCommonModel);
		when(buildModelService.jsonToObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenReturn(holdPledgeInquiryRequest);
		when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(AccountsModel.class))).thenReturn(accountsModel);
		doReturn(responseEntity).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<?>)Mockito.any());
	}

	@Test
	public void testHoldPledgeInquirySuccess() throws IOException {
		holdPledgeInquiryRequest.setKeyOfLastRecord("");
		holdPledgeInquiryRequest.setSearchDescription("");
		doReturn(holdPledgeInquiryRequest).when(buildModelService).jsonToObject(Mockito.anyString(), Mockito.any(), Mockito.anyString());
		HoldPledgeInquiryResponse holdPledgeInquiryResponse = holdPledgeInquiryService.holdPledgeInquireBalance("test", "1");
		
		assertEquals(TransactionStatus.SUCCESS.getCode(), holdPledgeInquiryResponse.getTransactionCode());
	}
	
	@Test
	public void testHoldPledgeInquiryNullAccounstModel() {
		when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(AccountsModel.class))).thenReturn(null);
		
		HoldPledgeInquiryResponse holdPledgeInquiryResponse = holdPledgeInquiryService.holdPledgeInquireBalance("test", "1");
		
		assertEquals(TransactionStatus.INVALID_ACCOUNT.getCode(), holdPledgeInquiryResponse.getTransactionCode());
	}
	
	@Test
	public void testHoldPledgeInquiryDifferentExternalUserId() throws Exception {
		holdPledgeInquiryRequest.setExternalUserId("differentexternaluserid");
		doReturn(holdPledgeInquiryRequest).when(buildModelService).jsonToObject(Mockito.anyString(), Mockito.any(), Mockito.anyString());
		
		HoldPledgeInquiryResponse holdPledgeInquiryResponse = holdPledgeInquiryService.holdPledgeInquireBalance("test", "1");
		
		assertEquals(TransactionStatus.INVALID_REQUEST.getCode(), holdPledgeInquiryResponse.getTransactionCode());
	}
	
	@Test
	public void testHoldPledgeInquiryNoRecordFound() throws Exception {
		responseEntity = generateNoRecordFoundResponseEntity();
		doReturn(responseEntity).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<?>)Mockito.any());
		
		HoldPledgeInquiryResponse holdPledgeInquiryResponse = holdPledgeInquiryService.holdPledgeInquireBalance("test", "1");
		
		assertEquals(TransactionStatus.NO_RECORD_FOUND.getCode(), holdPledgeInquiryResponse.getTransactionCode());
	}
	
	@Test
	public void testHoldPledgeInquiryRestClientException() throws Exception {
		doThrow(RestClientException.class).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<?>)Mockito.any());
		
		HoldPledgeInquiryResponse holdPledgeInquiryResponse = holdPledgeInquiryService.holdPledgeInquireBalance("test", "1");
		
		assertEquals(TransactionStatus.INTERNAL_SERVER_ERROR.getCode(), holdPledgeInquiryResponse.getTransactionCode());
	}
	
	@Test
	public void testHoldPledgeInquiryException() throws Exception {
		doReturn(null).when(buildModelService).jsonToObject(Mockito.anyString(), Mockito.any(), Mockito.anyString());
		
		HoldPledgeInquiryResponse holdInquiryResponse = holdPledgeInquiryService.holdPledgeInquireBalance("test", "1");
		
		assertEquals(TransactionStatus.INVALID_REQUEST.getCode(), holdInquiryResponse.getTransactionCode());
	}
	
	private RequestCommonModel generateRequestCommonModel() {
		RequestCommonModel requestCommonModel = new RequestCommonModel();
		requestCommonModel.setChannelId("JVZ");
		requestCommonModel.setData("testdata");
		requestCommonModel.setSignature("testsignature");
		
		return requestCommonModel;
	}
	
	private ConfigurationModel generateConfigurationModel() {
		ConfigurationModel configurationModel = new ConfigurationModel();
		configurationModel.setAggregateLimitAccount(1);
		configurationModel.setAggregateLimitUser(1);
		configurationModel.setBankPrivateKey("testbankprivatekey");
		configurationModel.setBankPublicKey("testbankpublickey");
		configurationModel.setExpiryDays(1);
		configurationModel.setMaxLinkedAccounts(1);
		configurationModel.setMerchantAlias("Jarvis");
		configurationModel.setMerchantId("JVZ");
		configurationModel.setMerchantName("Jarvis");
		configurationModel.setMerchantPublicKey("testmerchatnpublickey");
		configurationModel.setTxnRenewalCriteria(1);
		
		return configurationModel;
	}
	
	private HoldPledgeInquiryRequest generateHoldPledgeInquiryRequest() {
		HoldPledgeInquiryRequest holdPledgeInquiryRequest = new HoldPledgeInquiryRequest();
		holdPledgeInquiryRequest.setExternalUserId("testexternaluserid");
		holdPledgeInquiryRequest.setKeyOfLastRecord("keyoflastrecord");
		holdPledgeInquiryRequest.setSearchDescription("testsearchdescription");
		holdPledgeInquiryRequest.setSearchString("testsearchstring");
		holdPledgeInquiryRequest.setToken("testtoken");
		
		return holdPledgeInquiryRequest;
	}
	
	private AccountsModel generateAccountsModel() {
		AccountsModel accountsModel = new AccountsModel();
		accountsModel.setAccountNo("1111111111111");
		accountsModel.setAccountRef("1111");
		accountsModel.setDateCreated(new Date());
		accountsModel.setDateExpired(new Date());
		accountsModel.setDateModified(new Date());
		accountsModel.setDeleteFlag(false);
		accountsModel.setDlId("1");
		accountsModel.setExternalUserId("testexternaluserid");
		accountsModel.setMerchantId("JVZ");
		accountsModel.setOwner("testowner");
		accountsModel.setToken("testtoken");
		
		return accountsModel;
	}
	
	private ResponseEntity<HoldPledgeInquiryResponse> generateResponseEntity() {
		HoldPledgeInquiryResponse holdInquiryResponse = new HoldPledgeInquiryResponse();
		
		List<HoldPledgeDetails> holdPledgeDetailsList = new ArrayList<>();
		HoldPledgeDetails holdPledgeDetails = new HoldPledgeDetails();
		holdPledgeDetails.setAmount(new BigDecimal("999999"));
		holdPledgeDetails.setDescription("test description");
		holdPledgeDetails.setExpirationDate("2019-12-31");
		holdPledgeDetails.setHighSerialNumber("highserialnumber");
		holdPledgeDetails.setHoldPledgeType("H");
		holdPledgeDetails.setLowSerialNumber("lowserialnumber");
		holdPledgeDetails.setMaintenanceDate("2019-12-30");
		holdPledgeDetails.setSequenceNumber("1234567");
		holdPledgeDetails.setUserId("testuserid");	
		holdPledgeDetailsList.add(holdPledgeDetails);
		
		holdInquiryResponse.setMaskedAccountNumber("6789");
		holdInquiryResponse.setAvailableBalance(new BigDecimal("999999"));
		holdInquiryResponse.setBranchCode("123");
		holdInquiryResponse.setCurrencyCode("608");
		holdInquiryResponse.setCurrentBalance(new BigDecimal("999999"));
		holdInquiryResponse.setFullHoldIndicator("N");
		holdInquiryResponse.setFullPledgeIndicator("N");
		holdInquiryResponse.setHoldPledgeDetails(holdPledgeDetailsList);
		holdInquiryResponse.setKeyOfLastRecord("keyoflastrecord");
		holdInquiryResponse.setLastPageIndicator("lastpageindicator");
		holdInquiryResponse.setOriginatingBranchCode("123");
		holdInquiryResponse.setTotalFloatBalance(new BigDecimal("999999"));
		holdInquiryResponse.setTotalHoldBalance(new BigDecimal("999999"));
		holdInquiryResponse.setTotalPledgeBalance(new BigDecimal("999999"));
		holdInquiryResponse.setTransactionCode(TransactionStatus.SUCCESS.getCode());
		holdInquiryResponse.setTransactionDesc(TransactionStatus.SUCCESS.getDescription());
		holdInquiryResponse.setWsStatus(new WsStatus());
		
		return new ResponseEntity<>(holdInquiryResponse, HttpStatus.OK);
	}
	
	private ResponseEntity<HoldPledgeInquiryResponse> generateNoRecordFoundResponseEntity() {
		HoldPledgeInquiryResponse holdInquiryResponse = new HoldPledgeInquiryResponse();
		WsStatus wss = new WsStatus();
		wss.setErrorMessage("No record found");
		wss.setSoaResponseCode("SOA-001");
		wss.setTransactionStatus(1);
		
		holdInquiryResponse.setWsStatus(wss);
		
		return new ResponseEntity<>(holdInquiryResponse, HttpStatus.OK);
	}
}
