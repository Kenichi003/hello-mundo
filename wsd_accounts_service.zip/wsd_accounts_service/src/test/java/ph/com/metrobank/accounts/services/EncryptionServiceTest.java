package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.hold.pledge.release.models.ConfigurationModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.services.BuildModelService;
import ph.com.metrobank.accounts.services.EncryptionService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class EncryptionServiceTest {
	
	@MockBean
	private LoggingService loggingService;
	
	@Autowired
	private EncryptionService encryptSvc;
	
	@MockBean
	private BuildModelService buildModelService;
	
	private KeyPair kp;
	private RequestCommonModel requestCommonModel;
	private ConfigurationModel configurationModel;
	
	private String password = "";
	
	@Before
	public void setUp() throws NoSuchAlgorithmException {
		password = "testPassword";
		
		configurationModel = new ConfigurationModel();
		configurationModel.setExpiryDays(182);
		configurationModel.setAggregateLimitAccount(30000);
		configurationModel.setAggregateLimitUser(50000);
		configurationModel.setMaxLinkedAccounts(1);
		configurationModel.setMerchantId("JVZ");
		configurationModel.setTxnRenewalCriteria(3);
		configurationModel.setMerchantName("JARVIS");
		configurationModel.setMerchantAlias("JARVIS");
		configurationModel.setBankPrivateKey(
				"MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCpJ+7g7SqRwfcuqk2k0a0f7x6EaQRwIMEiNx1eEBZKKjN9/BrVG7z+NmhwZKwFp/qTLMlt9wJAzrtpxsBq/40ZX0bEJp4Ctps5yidN3Y73OyH8UzvFKFRFM4AWLdkOBIb/4/rhfJDE34IwoCJKPmW9Peuz8PpRUXiGi1foRrtyvKYG16mP4A9VOT7LbtOYjFJI4kcnHWnB9O7E27A8Mwdpb1PpnR08w1WMWl5v4/jf/aLNoIZdYJyNxZTQ3/OeAyDRJseP4XKx6OowS1n7W9iqYU55p3PEGc8UPtKJVCNIHTHZDxu15H0n/Z+U9lj8IyBCorDaHU0isIkTDuDAvpKBAgMBAAECggEBAIoRyzySuP1yGgVgArI2Zx46umkPowy2343C+NiPPvJYUeFShsBNvMyusj6THYocWz4H/34fcRpe48Bp9yMe5hfAme1/K9hBHqBj7gLzhj8saAgiFBZQXcCCUdlIoPN9JIf3mQ618yCO4yA3hOWe2sJFqX8dgeQgIMWJNT6lhVkXYnjrgln8fDSa4pUVau416rq7xbrFa5dm+UrGeiu5T9AWehSQm4scznDb7wfRUw5qxpx68kTKQ5keUYxzqWvu4KrfA/PNudySlFigLH2RirB/6DC2uZvCLzeSeHmc2n3yXOA1Zd+J6eM28f1e4oi/fGyBC/XyqOcYEjAE+iNobfECgYEA+7EutvU6e6GP/yUfSRSPiEpwMYhI3CuMCODrQizISnw1XpMH7SzttdFqEJDe+iVp62wnFrlffZkp2XTkU5mfIwgBROkjuZw0fcJBoQs0SSwSzkOoi5LcYCudAn0bS432rGH/YL2BYsckBt24TuJn76FZthgqPswP7k2jNhmrKe0CgYEArA0b9xmqAyobKT5Hna3fVWDZ3UV1Bkc817KBGKY8MKH8EvJsxumSQ1DRwzZXjGoozKqMhcaQX5bGqm2/DuX56MSsZnIIgqMCXQiJQVhqQJ7Z5QSlcmZ3m6V3dstnP7TYBxArDSZvljnj/+coN50wUsG3H9UOP7kRm3lndssSKGUCgYEA29+5U5N/d6l4RgiEAC+6A/IjeOH55H0WZFs4qiK9BnTjmq8PaZ6qOv+qjLZCVHyCv2tH6o4eYXaAHLwFCxNU9iF0GmMhFnDjWkltU+aZ0qJx+0cX4nZ1ln4DN71bLvHh4E3r7vMeKNCXJHhlHmSjL6/g0zbhEOLrt96TChv6bzECgYASaojOx1F6azxjCsaRqzXXprlLRQ8EsAVkNTg6UjjpH72irY5VMFU2nWUGlz+ByS860RqfiySTBsmXHo4v4xAACWVGxfgBO7+aA7rlYrhk2FwMdpXbC/rLj0edUKJpoErrXqCtFKsnEmVEVBLq+QleIlwerSiMS5wF31Xi0lPMPQKBgQDfkLymo+uRm3JXDIccc1qEIVgU6iTa1rfpF6bSP55QsiF5S35IT/ZIRr90AQ9z5zYlO2TZPT6NoQnI8eBaRaGIeHwLQT4P54Hr9Prqdxn5mvaeFvkE2rwxIJGMG6m1o+r7WyDcLkQkBuoaVoHnn5Q+eD8KxcKodbss0IR5L7Z8Gg==");
		configurationModel.setBankPublicKey(
				"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSfu4O0qkcH3LqpNpNGtH+8ehGkEcCDBIjcdXhAWSiozffwa1Ru8/jZocGSsBaf6kyzJbfcCQM67acbAav+NGV9GxCaeArabOconTd2O9zsh/FM7xShURTOAFi3ZDgSG/+P64XyQxN+CMKAiSj5lvT3rs/D6UVF4hotX6Ea7crymBtepj+APVTk+y27TmIxSSOJHJx1pwfTuxNuwPDMHaW9T6Z0dPMNVjFpeb+P43/2izaCGXWCcjcWU0N/zngMg0SbHj+FysejqMEtZ+1vYqmFOeadzxBnPFD7SiVQjSB0x2Q8bteR9J/2flPZY/CMgQqKw2h1NIrCJEw7gwL6SgQIDAQAB");
		configurationModel.setMerchantPublicKey(
				"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSfu4O0qkcH3LqpNpNGtH+8ehGkEcCDBIjcdXhAWSiozffwa1Ru8/jZocGSsBaf6kyzJbfcCQM67acbAav+NGV9GxCaeArabOconTd2O9zsh/FM7xShURTOAFi3ZDgSG/+P64XyQxN+CMKAiSj5lvT3rs/D6UVF4hotX6Ea7crymBtepj+APVTk+y27TmIxSSOJHJx1pwfTuxNuwPDMHaW9T6Z0dPMNVjFpeb+P43/2izaCGXWCcjcWU0N/zngMg0SbHj+FysejqMEtZ+1vYqmFOeadzxBnPFD7SiVQjSB0x2Q8bteR9J/2flPZY/CMgQqKw2h1NIrCJEw7gwL6SgQIDAQAB");

		requestCommonModel = new RequestCommonModel();
		requestCommonModel.setData("test message");
		requestCommonModel.setChannelId("JVZ");
		requestCommonModel.setSignature("asdghrtsdfgsfbv");

		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator.initialize(2048);
		kp = keyPairGenerator.genKeyPair();
	}
	
	@Test
	public void testEncryption() throws NoSuchAlgorithmException {
		String encrPassword = encryptSvc.sha256("1", password);
		assertThat(encryptSvc.sha256("1", password)).isEqualTo(encrPassword);
	}
	
	@Test
	public void testEncryptionMD5() throws NoSuchAlgorithmException {
		String encrPassword = encryptSvc.encryptMD5("payload");
		assertThat(encryptSvc.encryptMD5("payload")).isEqualTo(encrPassword);
	}
	
	@Test
	public void testEncrypt() throws Exception {
		String publicKeyString = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSfu4O0qkcH3LqpNpNGtH+8ehGkEcCDBIjcdXhAWSiozffwa1Ru8/jZocGSsBaf6kyzJbfcCQM67acbAav+NGV9GxCaeArabOconTd2O9zsh/FM7xShURTOAFi3ZDgSG/+P64XyQxN+CMKAiSj5lvT3rs/D6UVF4hotX6Ea7crymBtepj+APVTk+y27TmIxSSOJHJx1pwfTuxNuwPDMHaW9T6Z0dPMNVjFpeb+P43/2izaCGXWCcjcWU0N/zngMg0SbHj+FysejqMEtZ+1vYqmFOeadzxBnPFD7SiVQjSB0x2Q8bteR9J/2flPZY/CMgQqKw2h1NIrCJEw7gwL6SgQIDAQAB";
		String result = encryptSvc.encrypt("test message", publicKeyString);
		assertThat(result).isNotBlank();
	}

	@Test
	public void testPrivateKey() throws Exception {
		String privateKeyString = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCpJ+7g7SqRwfcuqk2k0a0f7x6EaQRwIMEiNx1eEBZKKjN9/BrVG7z+NmhwZKwFp/qTLMlt9wJAzrtpxsBq/40ZX0bEJp4Ctps5yidN3Y73OyH8UzvFKFRFM4AWLdkOBIb/4/rhfJDE34IwoCJKPmW9Peuz8PpRUXiGi1foRrtyvKYG16mP4A9VOT7LbtOYjFJI4kcnHWnB9O7E27A8Mwdpb1PpnR08w1WMWl5v4/jf/aLNoIZdYJyNxZTQ3/OeAyDRJseP4XKx6OowS1n7W9iqYU55p3PEGc8UPtKJVCNIHTHZDxu15H0n/Z+U9lj8IyBCorDaHU0isIkTDuDAvpKBAgMBAAECggEBAIoRyzySuP1yGgVgArI2Zx46umkPowy2343C+NiPPvJYUeFShsBNvMyusj6THYocWz4H/34fcRpe48Bp9yMe5hfAme1/K9hBHqBj7gLzhj8saAgiFBZQXcCCUdlIoPN9JIf3mQ618yCO4yA3hOWe2sJFqX8dgeQgIMWJNT6lhVkXYnjrgln8fDSa4pUVau416rq7xbrFa5dm+UrGeiu5T9AWehSQm4scznDb7wfRUw5qxpx68kTKQ5keUYxzqWvu4KrfA/PNudySlFigLH2RirB/6DC2uZvCLzeSeHmc2n3yXOA1Zd+J6eM28f1e4oi/fGyBC/XyqOcYEjAE+iNobfECgYEA+7EutvU6e6GP/yUfSRSPiEpwMYhI3CuMCODrQizISnw1XpMH7SzttdFqEJDe+iVp62wnFrlffZkp2XTkU5mfIwgBROkjuZw0fcJBoQs0SSwSzkOoi5LcYCudAn0bS432rGH/YL2BYsckBt24TuJn76FZthgqPswP7k2jNhmrKe0CgYEArA0b9xmqAyobKT5Hna3fVWDZ3UV1Bkc817KBGKY8MKH8EvJsxumSQ1DRwzZXjGoozKqMhcaQX5bGqm2/DuX56MSsZnIIgqMCXQiJQVhqQJ7Z5QSlcmZ3m6V3dstnP7TYBxArDSZvljnj/+coN50wUsG3H9UOP7kRm3lndssSKGUCgYEA29+5U5N/d6l4RgiEAC+6A/IjeOH55H0WZFs4qiK9BnTjmq8PaZ6qOv+qjLZCVHyCv2tH6o4eYXaAHLwFCxNU9iF0GmMhFnDjWkltU+aZ0qJx+0cX4nZ1ln4DN71bLvHh4E3r7vMeKNCXJHhlHmSjL6/g0zbhEOLrt96TChv6bzECgYASaojOx1F6azxjCsaRqzXXprlLRQ8EsAVkNTg6UjjpH72irY5VMFU2nWUGlz+ByS860RqfiySTBsmXHo4v4xAACWVGxfgBO7+aA7rlYrhk2FwMdpXbC/rLj0edUKJpoErrXqCtFKsnEmVEVBLq+QleIlwerSiMS5wF31Xi0lPMPQKBgQDfkLymo+uRm3JXDIccc1qEIVgU6iTa1rfpF6bSP55QsiF5S35IT/ZIRr90AQ9z5zYlO2TZPT6NoQnI8eBaRaGIeHwLQT4P54Hr9Prqdxn5mvaeFvkE2rwxIJGMG6m1o+r7WyDcLkQkBuoaVoHnn5Q+eD8KxcKodbss0IR5L7Z8Gg==";
		PrivateKey result = encryptSvc.getPrivateKey(privateKeyString);
		String privateKeyString2 = encryptSvc.privatekeyToString(result);
		assertThat(privateKeyString).isEqualTo(privateKeyString2);
	}

	@Test
	public void testPublicKey() throws Exception {
		String publicKeyString = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSfu4O0qkcH3LqpNpNGtH+8ehGkEcCDBIjcdXhAWSiozffwa1Ru8/jZocGSsBaf6kyzJbfcCQM67acbAav+NGV9GxCaeArabOconTd2O9zsh/FM7xShURTOAFi3ZDgSG/+P64XyQxN+CMKAiSj5lvT3rs/D6UVF4hotX6Ea7crymBtepj+APVTk+y27TmIxSSOJHJx1pwfTuxNuwPDMHaW9T6Z0dPMNVjFpeb+P43/2izaCGXWCcjcWU0N/zngMg0SbHj+FysejqMEtZ+1vYqmFOeadzxBnPFD7SiVQjSB0x2Q8bteR9J/2flPZY/CMgQqKw2h1NIrCJEw7gwL6SgQIDAQAB";
		PublicKey result = encryptSvc.getPublicKey(publicKeyString);
		String publicKeyString2 = encryptSvc.publicKeyToString(result);
		assertThat(publicKeyString).isEqualTo(publicKeyString2);
	}

	@Test
	public void testDecryptByPrivateKey() throws Exception {
		String publicKeyString = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSfu4O0qkcH3LqpNpNGtH+8ehGkEcCDBIjcdXhAWSiozffwa1Ru8/jZocGSsBaf6kyzJbfcCQM67acbAav+NGV9GxCaeArabOconTd2O9zsh/FM7xShURTOAFi3ZDgSG/+P64XyQxN+CMKAiSj5lvT3rs/D6UVF4hotX6Ea7crymBtepj+APVTk+y27TmIxSSOJHJx1pwfTuxNuwPDMHaW9T6Z0dPMNVjFpeb+P43/2izaCGXWCcjcWU0N/zngMg0SbHj+FysejqMEtZ+1vYqmFOeadzxBnPFD7SiVQjSB0x2Q8bteR9J/2flPZY/CMgQqKw2h1NIrCJEw7gwL6SgQIDAQAB";
		String privateKeyString = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCpJ+7g7SqRwfcuqk2k0a0f7x6EaQRwIMEiNx1eEBZKKjN9/BrVG7z+NmhwZKwFp/qTLMlt9wJAzrtpxsBq/40ZX0bEJp4Ctps5yidN3Y73OyH8UzvFKFRFM4AWLdkOBIb/4/rhfJDE34IwoCJKPmW9Peuz8PpRUXiGi1foRrtyvKYG16mP4A9VOT7LbtOYjFJI4kcnHWnB9O7E27A8Mwdpb1PpnR08w1WMWl5v4/jf/aLNoIZdYJyNxZTQ3/OeAyDRJseP4XKx6OowS1n7W9iqYU55p3PEGc8UPtKJVCNIHTHZDxu15H0n/Z+U9lj8IyBCorDaHU0isIkTDuDAvpKBAgMBAAECggEBAIoRyzySuP1yGgVgArI2Zx46umkPowy2343C+NiPPvJYUeFShsBNvMyusj6THYocWz4H/34fcRpe48Bp9yMe5hfAme1/K9hBHqBj7gLzhj8saAgiFBZQXcCCUdlIoPN9JIf3mQ618yCO4yA3hOWe2sJFqX8dgeQgIMWJNT6lhVkXYnjrgln8fDSa4pUVau416rq7xbrFa5dm+UrGeiu5T9AWehSQm4scznDb7wfRUw5qxpx68kTKQ5keUYxzqWvu4KrfA/PNudySlFigLH2RirB/6DC2uZvCLzeSeHmc2n3yXOA1Zd+J6eM28f1e4oi/fGyBC/XyqOcYEjAE+iNobfECgYEA+7EutvU6e6GP/yUfSRSPiEpwMYhI3CuMCODrQizISnw1XpMH7SzttdFqEJDe+iVp62wnFrlffZkp2XTkU5mfIwgBROkjuZw0fcJBoQs0SSwSzkOoi5LcYCudAn0bS432rGH/YL2BYsckBt24TuJn76FZthgqPswP7k2jNhmrKe0CgYEArA0b9xmqAyobKT5Hna3fVWDZ3UV1Bkc817KBGKY8MKH8EvJsxumSQ1DRwzZXjGoozKqMhcaQX5bGqm2/DuX56MSsZnIIgqMCXQiJQVhqQJ7Z5QSlcmZ3m6V3dstnP7TYBxArDSZvljnj/+coN50wUsG3H9UOP7kRm3lndssSKGUCgYEA29+5U5N/d6l4RgiEAC+6A/IjeOH55H0WZFs4qiK9BnTjmq8PaZ6qOv+qjLZCVHyCv2tH6o4eYXaAHLwFCxNU9iF0GmMhFnDjWkltU+aZ0qJx+0cX4nZ1ln4DN71bLvHh4E3r7vMeKNCXJHhlHmSjL6/g0zbhEOLrt96TChv6bzECgYASaojOx1F6azxjCsaRqzXXprlLRQ8EsAVkNTg6UjjpH72irY5VMFU2nWUGlz+ByS860RqfiySTBsmXHo4v4xAACWVGxfgBO7+aA7rlYrhk2FwMdpXbC/rLj0edUKJpoErrXqCtFKsnEmVEVBLq+QleIlwerSiMS5wF31Xi0lPMPQKBgQDfkLymo+uRm3JXDIccc1qEIVgU6iTa1rfpF6bSP55QsiF5S35IT/ZIRr90AQ9z5zYlO2TZPT6NoQnI8eBaRaGIeHwLQT4P54Hr9Prqdxn5mvaeFvkE2rwxIJGMG6m1o+r7WyDcLkQkBuoaVoHnn5Q+eD8KxcKodbss0IR5L7Z8Gg==";
		String encryptedText = encryptSvc.encrypt("test message", publicKeyString);
		String decryptedText = encryptSvc.decryptByPrivateKey(encryptedText, privateKeyString);
		assertThat(decryptedText).isEqualTo("test message");
	}

	@Test
	public void testDecryptByPrivateKeyString() throws Exception {
		String publicKeyString = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSfu4O0qkcH3LqpNpNGtH+8ehGkEcCDBIjcdXhAWSiozffwa1Ru8/jZocGSsBaf6kyzJbfcCQM67acbAav+NGV9GxCaeArabOconTd2O9zsh/FM7xShURTOAFi3ZDgSG/+P64XyQxN+CMKAiSj5lvT3rs/D6UVF4hotX6Ea7crymBtepj+APVTk+y27TmIxSSOJHJx1pwfTuxNuwPDMHaW9T6Z0dPMNVjFpeb+P43/2izaCGXWCcjcWU0N/zngMg0SbHj+FysejqMEtZ+1vYqmFOeadzxBnPFD7SiVQjSB0x2Q8bteR9J/2flPZY/CMgQqKw2h1NIrCJEw7gwL6SgQIDAQAB";
		String privateKeyString = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCpJ+7g7SqRwfcuqk2k0a0f7x6EaQRwIMEiNx1eEBZKKjN9/BrVG7z+NmhwZKwFp/qTLMlt9wJAzrtpxsBq/40ZX0bEJp4Ctps5yidN3Y73OyH8UzvFKFRFM4AWLdkOBIb/4/rhfJDE34IwoCJKPmW9Peuz8PpRUXiGi1foRrtyvKYG16mP4A9VOT7LbtOYjFJI4kcnHWnB9O7E27A8Mwdpb1PpnR08w1WMWl5v4/jf/aLNoIZdYJyNxZTQ3/OeAyDRJseP4XKx6OowS1n7W9iqYU55p3PEGc8UPtKJVCNIHTHZDxu15H0n/Z+U9lj8IyBCorDaHU0isIkTDuDAvpKBAgMBAAECggEBAIoRyzySuP1yGgVgArI2Zx46umkPowy2343C+NiPPvJYUeFShsBNvMyusj6THYocWz4H/34fcRpe48Bp9yMe5hfAme1/K9hBHqBj7gLzhj8saAgiFBZQXcCCUdlIoPN9JIf3mQ618yCO4yA3hOWe2sJFqX8dgeQgIMWJNT6lhVkXYnjrgln8fDSa4pUVau416rq7xbrFa5dm+UrGeiu5T9AWehSQm4scznDb7wfRUw5qxpx68kTKQ5keUYxzqWvu4KrfA/PNudySlFigLH2RirB/6DC2uZvCLzeSeHmc2n3yXOA1Zd+J6eM28f1e4oi/fGyBC/XyqOcYEjAE+iNobfECgYEA+7EutvU6e6GP/yUfSRSPiEpwMYhI3CuMCODrQizISnw1XpMH7SzttdFqEJDe+iVp62wnFrlffZkp2XTkU5mfIwgBROkjuZw0fcJBoQs0SSwSzkOoi5LcYCudAn0bS432rGH/YL2BYsckBt24TuJn76FZthgqPswP7k2jNhmrKe0CgYEArA0b9xmqAyobKT5Hna3fVWDZ3UV1Bkc817KBGKY8MKH8EvJsxumSQ1DRwzZXjGoozKqMhcaQX5bGqm2/DuX56MSsZnIIgqMCXQiJQVhqQJ7Z5QSlcmZ3m6V3dstnP7TYBxArDSZvljnj/+coN50wUsG3H9UOP7kRm3lndssSKGUCgYEA29+5U5N/d6l4RgiEAC+6A/IjeOH55H0WZFs4qiK9BnTjmq8PaZ6qOv+qjLZCVHyCv2tH6o4eYXaAHLwFCxNU9iF0GmMhFnDjWkltU+aZ0qJx+0cX4nZ1ln4DN71bLvHh4E3r7vMeKNCXJHhlHmSjL6/g0zbhEOLrt96TChv6bzECgYASaojOx1F6azxjCsaRqzXXprlLRQ8EsAVkNTg6UjjpH72irY5VMFU2nWUGlz+ByS860RqfiySTBsmXHo4v4xAACWVGxfgBO7+aA7rlYrhk2FwMdpXbC/rLj0edUKJpoErrXqCtFKsnEmVEVBLq+QleIlwerSiMS5wF31Xi0lPMPQKBgQDfkLymo+uRm3JXDIccc1qEIVgU6iTa1rfpF6bSP55QsiF5S35IT/ZIRr90AQ9z5zYlO2TZPT6NoQnI8eBaRaGIeHwLQT4P54Hr9Prqdxn5mvaeFvkE2rwxIJGMG6m1o+r7WyDcLkQkBuoaVoHnn5Q+eD8KxcKodbss0IR5L7Z8Gg==";
		String encryptedText = encryptSvc.encrypt("test message", publicKeyString);
		String result = encryptSvc.decryptByPrivateKeyString(encryptedText, privateKeyString);
		assertThat(result).isEqualTo("test message");
	}

	@Test
	public void testGenerateKeys() throws Exception {
		KeyPair kp = encryptSvc.generateKeys("1");
		assertThat(kp).isNotNull();
	}

	@Test
	public void testVerifySignature() throws Exception {
		String publicKeyString = encryptSvc.publicKeyToString(kp.getPublic());
		boolean result = encryptSvc.verifySignature("test message",
				"JJdGR9ULoWKNXnV7EusvzvPeETiNinm7WSGuAtaqVEft4LC1B282iWstXyylPOhhP8BOW+VJVWyxnp56WloIZEkQtjYj2CXNkeqhUk1whNq0m3XglXXGjKoSYFNAygPUaqBvRA8o1plY9xfp0vGAlDetRU7w1tDUw848s/caBALuLiwaStIlV0yiVbzSfbqP8+7zZkABdNt6X+1HL02eCoQClPsGGncEHjsPuuac7R5s1pPB6M1tnBH+KHkNvmGl7s6ZS4p18gwe+a3YfrAMq0y6DJ+xqE/UAy4GJWoQb2+pLKz3g64AEUSzdovdkVLNbCVOUWbWLD8ROtEH3BORQQ==",
				publicKeyString);
		assertThat(result).isFalse();
	}

	@Test
	public void testBuildSignedModel() throws Exception {
		String privateKeyString = encryptSvc.privatekeyToString(kp.getPrivate());
		String publicKeyString = encryptSvc.publicKeyToString(kp.getPublic());
		String signature = encryptSvc.sign("test message", privateKeyString);
		String encryptedText = encryptSvc.encrypt("test message", publicKeyString);
		requestCommonModel.setSignature(signature);
		requestCommonModel.setData(encryptedText);

		when(buildModelService.jsonToObject(Mockito.anyString(), Mockito.any(), Mockito.anyString()))
				.thenReturn(requestCommonModel);
		RequestCommonModel result = encryptSvc.buildSignedModel("", "", RequestCommonModel.class);
		assertThat(result).isNotNull();
	}

	@Test
	public void testVerifyModel1() throws Exception {
		String publicKeyString = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSfu4O0qkcH3LqpNpNGtH+8ehGkEcCDBIjcdXhAWSiozffwa1Ru8/jZocGSsBaf6kyzJbfcCQM67acbAav+NGV9GxCaeArabOconTd2O9zsh/FM7xShURTOAFi3ZDgSG/+P64XyQxN+CMKAiSj5lvT3rs/D6UVF4hotX6Ea7crymBtepj+APVTk+y27TmIxSSOJHJx1pwfTuxNuwPDMHaW9T6Z0dPMNVjFpeb+P43/2izaCGXWCcjcWU0N/zngMg0SbHj+FysejqMEtZ+1vYqmFOeadzxBnPFD7SiVQjSB0x2Q8bteR9J/2flPZY/CMgQqKw2h1NIrCJEw7gwL6SgQIDAQAB";
		String encryptedText = encryptSvc.encrypt("test message", publicKeyString);
		requestCommonModel.setSignature(
				"JJdGR9ULoWKNXnV7EusvzvPeETiNinm7WSGuAtaqVEft4LC1B282iWstXyylPOhhP8BOW+VJVWyxnp56WloIZEkQtjYj2CXNkeqhUk1whNq0m3XglXXGjKoSYFNAygPUaqBvRA8o1plY9xfp0vGAlDetRU7w1tDUw848s/caBALuLiwaStIlV0yiVbzSfbqP8+7zZkABdNt6X+1HL02eCoQClPsGGncEHjsPuuac7R5s1pPB6M1tnBH+KHkNvmGl7s6ZS4p18gwe+a3YfrAMq0y6DJ+xqE/UAy4GJWoQb2+pLKz3g64AEUSzdovdkVLNbCVOUWbWLD8ROtEH3BORQQ==");
		requestCommonModel.setData(encryptedText);
		RequestCommonModel result = encryptSvc.verifyModel(requestCommonModel,
				configurationModel, "");
		assertThat(result).isNull();
	}
	
	@Test
	public void testVerifyModel2() throws Exception {
		String privateKeyString = encryptSvc.privatekeyToString(kp.getPrivate());
		String publicKeyString = encryptSvc.publicKeyToString(kp.getPublic());
		String signature = encryptSvc.sign("test message", privateKeyString);
		String encryptedText = encryptSvc.encrypt("test message", publicKeyString);
		requestCommonModel.setSignature(signature);
		requestCommonModel.setData(encryptedText);
		configurationModel.setBankPrivateKey(privateKeyString);
		configurationModel.setMerchantPublicKey(publicKeyString);
		RequestCommonModel result = encryptSvc.verifyModel(requestCommonModel,
				configurationModel, "");
		assertThat(result).isNotNull();
	}
}