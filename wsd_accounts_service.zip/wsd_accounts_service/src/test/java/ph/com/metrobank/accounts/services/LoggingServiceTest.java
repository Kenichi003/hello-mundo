package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class LoggingServiceTest {
	
	@Autowired
	private LoggingService loggingService;
	
	@Test
	public void testLoggingService1() {
		Map<String, String> map = new HashMap<>();
		map.put("COMPONENT", "COMPONENT");
		map.put("UUID", "UUID");
		map.put("ACCOUNT NUMBER", "123456789");
		map.put("INFO", "OTHER INFO");
		String log = loggingService.log("COMPONENT", "UUID", "123456789", "OTHER INFO");
		assertThat(map.toString()).isEqualTo(log);
	}
	
	@Test
	public void testLoggingService2() {
		Map<String, String> map = new HashMap<>();
		map.put("UUID", "UUID");
		map.put("ACCOUNT NUMBER", "123456789");
		map.put("INFO", "OTHER INFO");
		String log = loggingService.log("", "UUID", "123456789", "OTHER INFO");
		assertThat(map.toString()).isEqualTo(log);
	}
	
	@Test
	public void testLoggingService3() throws Exception {
		Map<String, String> map = new HashMap<>();
		map.put("COMPONENT", "COMPONENT");
		map.put("ACCOUNT NUMBER", "123456789");
		map.put("INFO", "OTHER INFO");
		String log = loggingService.log("COMPONENT", "", "123456789", "OTHER INFO");
		assertThat(map.toString()).isEqualTo(log);
	}
	
	@Test
	public void testLoggingService4() throws Exception {
		Map<String, String> map = new HashMap<>();
		map.put("COMPONENT", "COMPONENT");
		map.put("UUID", "UUID");
		map.put("INFO", "OTHER INFO");
		String log = loggingService.log("COMPONENT", "UUID", "", "OTHER INFO");
		assertThat(map.toString()).isEqualTo(log);
	}
	
	@Test
	public void testLoggingService5() throws Exception {
		Map<String, String> map = new HashMap<>();
		map.put("COMPONENT", "COMPONENT");
		map.put("UUID", "UUID");
		map.put("ACCOUNT NUMBER", "123456789");
		String log = loggingService.log("COMPONENT", "UUID", "123456789", "");
		assertThat(map.toString()).isEqualTo(log);
	}

}
