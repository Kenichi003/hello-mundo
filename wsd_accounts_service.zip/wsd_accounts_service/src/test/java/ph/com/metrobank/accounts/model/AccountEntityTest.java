package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.Account;

@RunWith(SpringJUnit4ClassRunner.class)
public class AccountEntityTest {

	private Account account;
	
	@Before
	public void setUp() {
		account = new Account();
		account = new Account("type","value");
	}
	
	@Test
	public void testAccountValue() {	
		assertThat(account.getType()).isEqualTo("type");
		assertThat(account.getValue()).isEqualTo("value");
	}

}
