package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.core.env.Environment;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.pgw.osb.adb.AccountDetailedBalanceResponse;
import com.pgw.osb.adb.CASAInformatInquiryBalanceAndDetails;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.services.AccountDetailsService;
import ph.com.metrobank.accounts.services.EncryptionService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
public class AccountDetailsService2Test {

	@SpyBean
	private AccountDetailsService accountDetailsService;

	@Mock
	private EncryptionService encSvc;

	@Mock
	private Environment env;

	@MockBean
	private LoggingService loggingService;

	private CASAInformatInquiryBalanceAndDetails mockRequest;

	@Before
	public void setUp() {
		mockRequest = Mockito.mock(CASAInformatInquiryBalanceAndDetails.class);
	}

	@Test
	public void testGetBalance1() throws Exception {
		Mockito.doReturn(mockRequest).when(accountDetailsService).createCASAInformatInquiryBalanceAndDetailsStub();
		AccountDetailedBalanceResponse res = accountDetailsService.getAccountBalance("1234567891234", "1");
		assertThat(res).isNull();
	}

	@Test
	public void testGetBalance2() throws Exception {
		try {
			AccountDetailedBalanceResponse res = accountDetailsService.getAccountBalance("1234567891234", "1");
			assertThat(res).isNull();
			fail("Exception expected");
		} catch (Exception e) {
			// fine, as expected
		}

	}

}
