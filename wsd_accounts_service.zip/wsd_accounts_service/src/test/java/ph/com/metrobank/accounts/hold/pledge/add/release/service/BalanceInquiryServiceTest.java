package ph.com.metrobank.accounts.hold.pledge.add.release.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.Date;

import javax.xml.ws.WebServiceException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.pgw.osb.adb.AccountDetailedBalanceResponse;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeDataRequest;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeResponse;
import ph.com.metrobank.accounts.hold.pledge.release.models.ConfigurationModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.Credentials;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.TransInfo;
import ph.com.metrobank.accounts.hold.pledge.release.models.WsStatus;
import ph.com.metrobank.accounts.model.TransactionStatus;
import ph.com.metrobank.accounts.model.ifx.AcctInqRs;
import ph.com.metrobank.accounts.services.AccountBalanceOSBService;
import ph.com.metrobank.accounts.services.BuildModelService;
import ph.com.metrobank.accounts.services.EncryptionService;
import ph.com.metrobank.accounts.services.OrchestrationService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
public class BalanceInquiryServiceTest {

	@InjectMocks
	@Autowired
	private OrchestrationService orchestrationService;

	@Mock
	private EncryptionService encryptionService;

	@Mock
	private BuildModelService buildModelService;

	@Mock
	private AccountBalanceOSBService accountBalanceOSBService;

	@Mock
	private RestTemplate restTemplate;

	private RequestCommonModel requestCommonModel;

	private AddReleaseHoldPledgeDataRequest addReleaseHoldPledgeDataRequest;

	private ConfigurationModel configurationModel;

	private AccountsModel accountsModel;

	private AccountDetailedBalanceResponse accountDetailedBalanceResponse;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		accountDetailedBalanceResponse = new AccountDetailedBalanceResponse();
		accountDetailedBalanceResponse.setAvailableAmount("1000");
		accountDetailedBalanceResponse.setCurrentBalance("1000");

		requestCommonModel = generateRequestCommonModel();
		addReleaseHoldPledgeDataRequest = generateAddReleaseHoldPledgeDataRequest();
		accountsModel = generateAccountsModel();
		configurationModel = generateConfigurationModel();

		when(encryptionService.buildSignedModel(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
				.thenReturn(requestCommonModel);
		when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class)))
				.thenReturn(configurationModel);
		when(encryptionService.verifyModel(Mockito.any(), Mockito.any(), Mockito.anyString()))
				.thenReturn(requestCommonModel);
		when(buildModelService.jsonToObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
				.thenReturn(addReleaseHoldPledgeDataRequest);
		when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(AccountsModel.class))).thenReturn(accountsModel);
	}

	@Test
	public void testOrchestrateCasaBalanceInquiry1() {
		when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(AccountsModel.class))).thenReturn(null);

		AcctInqRs accountInquiryResponse = orchestrationService.orchestrateCasaBalanceInquiry("testjson", "1");
		assertNotNull(accountInquiryResponse);
		assertEquals(TransactionStatus.INVALID_REQUEST.getCode(), accountInquiryResponse.getStatus().getStatusCode());
	}

	@Test
	public void testOrchestrateCasaBalanceInquiry2() throws Exception {
		accountsModel.setExternalUserId("testdifferentexternaluserid");
		when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(AccountsModel.class))).thenReturn(accountsModel);

		AcctInqRs accountInquiryResponse = orchestrationService.orchestrateCasaBalanceInquiry("testjson", "1");
		assertNotNull(accountInquiryResponse);
		assertEquals(TransactionStatus.INVALID_REQUEST.getCode(), accountInquiryResponse.getStatus().getStatusCode());
	}

	@Test
	public void testOrchestrateCasaBalanceInquiry3() throws Exception {
		ResponseEntity<AddReleaseHoldPledgeResponse> responseEntity = generateResponseEntity();
		doReturn(responseEntity).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(), Mockito.any(),
				(Class<?>) Mockito.any());
		when(accountBalanceOSBService.getBalance(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountDetailedBalanceResponse);

		AcctInqRs accountInquiryResponse = orchestrationService.orchestrateCasaBalanceInquiry("testjson", "1");
		assertNotNull(accountInquiryResponse);
		assertEquals(TransactionStatus.SUCCESS.getCode(), accountInquiryResponse.getStatus().getStatusCode());
	}

	@Test
	public void testOrchestrateCasaBalanceInquiry4() throws Exception {
		ResponseEntity<AddReleaseHoldPledgeResponse> responseEntity = generateResponseEntity();
		doReturn(responseEntity).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(), Mockito.any(),
				(Class<?>) Mockito.any());
		when(accountBalanceOSBService.getBalance(Mockito.anyString(), Mockito.anyString())).thenReturn(null);

		AcctInqRs accountInquiryResponse = orchestrationService.orchestrateCasaBalanceInquiry("testjson", "1");
		assertNotNull(accountInquiryResponse);
		assertEquals(TransactionStatus.NO_BALANCE_RETRIEVED.getCode(),
				accountInquiryResponse.getStatus().getStatusCode());
	}
	
	@Test
	public void testOrchestrateCasaBalanceInquiry5() throws Exception {
		ResponseEntity<AddReleaseHoldPledgeResponse> responseEntity = generateResponseEntity();
		doReturn(responseEntity).when(restTemplate).exchange(Mockito.anyString(), Mockito.any(), Mockito.any(),
				(Class<?>) Mockito.any());
		
		doThrow(WebServiceException.class).when(accountBalanceOSBService).getBalance(Mockito.anyString(), Mockito.anyString());
		
		AcctInqRs accountInquiryResponse = orchestrationService.orchestrateCasaBalanceInquiry("testjson", "1");
		assertNotNull(accountInquiryResponse);
		assertEquals(TransactionStatus.INTERNAL_SERVER_ERROR.getCode(), accountInquiryResponse.getStatus().getStatusCode());
	}
	
	@Test
	public void testOrchestrateCasaBalanceInquiry6() throws Exception {
		when(encryptionService.verifyModel(Mockito.any(), Mockito.any(), Mockito.anyString()))
		.thenReturn(null);
		AcctInqRs accountInquiryResponse = orchestrationService.orchestrateCasaBalanceInquiry("testjson", "1");
		assertNotNull(accountInquiryResponse);
		assertEquals(TransactionStatus.INVALID_REQUEST.getCode(), accountInquiryResponse.getStatus().getStatusCode());
	}
	
	private RequestCommonModel generateRequestCommonModel() {
		RequestCommonModel requestCommonModel = new RequestCommonModel();
		requestCommonModel.setChannelId("JVZ");
		requestCommonModel.setData("testdata");
		requestCommonModel.setSignature("testsignature");

		return requestCommonModel;
	}

	private AddReleaseHoldPledgeDataRequest generateAddReleaseHoldPledgeDataRequest() {
		AddReleaseHoldPledgeDataRequest addReleaseHoldPledgeJarvisRequest = new AddReleaseHoldPledgeDataRequest();

		Credentials credentials = new Credentials();
		credentials.setPassword("password");
		credentials.setSystemID("systemID");

		TransInfo transactionInformation = new TransInfo();
		transactionInformation.setChannelTransaction("test");
		transactionInformation.setDateStamp("2019-10-29");
		transactionInformation.setProcessingBranch("123");
		transactionInformation.setSequenceNumber(new BigInteger("1234567"));
		transactionInformation.setServicingBranch("123");
		transactionInformation.setSourceProductCode("P");
		transactionInformation.setTimeStamp("09:58:01");

		addReleaseHoldPledgeJarvisRequest.setAccountNumber("3123456789");
		addReleaseHoldPledgeJarvisRequest.setAllFunds("O");
		addReleaseHoldPledgeJarvisRequest.setAmount("100");
		addReleaseHoldPledgeJarvisRequest.setBranchCode("123");
		addReleaseHoldPledgeJarvisRequest.setCredentials(credentials);
		addReleaseHoldPledgeJarvisRequest.setCurrencyCode("608");
		addReleaseHoldPledgeJarvisRequest.setDays("1");
		addReleaseHoldPledgeJarvisRequest.setDescription("JARVIS TEST 1");
		addReleaseHoldPledgeJarvisRequest.setExternalUserId("testexternaluserid");
		addReleaseHoldPledgeJarvisRequest.setHighSerialNumber("highserialnumber");
		addReleaseHoldPledgeJarvisRequest.setLowSerialNumber("lowserialnumber");
		addReleaseHoldPledgeJarvisRequest.setMaintenanceType("O");
		addReleaseHoldPledgeJarvisRequest.setOriginatingBranchCode("123");
		addReleaseHoldPledgeJarvisRequest.setReferenceNo("1234567890");
		addReleaseHoldPledgeJarvisRequest.setToken("testtoken");
		addReleaseHoldPledgeJarvisRequest.setTransactionCodeType("30");
		addReleaseHoldPledgeJarvisRequest.setTransactionInformation(transactionInformation);

		return addReleaseHoldPledgeJarvisRequest;
	}

	private AccountsModel generateAccountsModel() {
		AccountsModel accountsModel = new AccountsModel();
		accountsModel.setAccountNo("1233123456789");
		accountsModel.setAccountRef("1111");
		accountsModel.setDateCreated(new Date());
		accountsModel.setDateExpired(new Date());
		accountsModel.setDateModified(new Date());
		accountsModel.setDeleteFlag(false);
		accountsModel.setDlId("1");
		accountsModel.setExternalUserId("testexternaluserid");
		accountsModel.setMerchantId("JVZ");
		accountsModel.setOwner("testowner");
		accountsModel.setToken("testtoken");

		return accountsModel;
	}

	private ConfigurationModel generateConfigurationModel() {
		ConfigurationModel configurationModel = new ConfigurationModel();
		configurationModel.setAggregateLimitAccount(1);
		configurationModel.setAggregateLimitUser(1);
		configurationModel.setBankPrivateKey("testbankprivatekey");
		configurationModel.setBankPublicKey("testbankpublickey");
		configurationModel.setExpiryDays(1);
		configurationModel.setMaxLinkedAccounts(1);
		configurationModel.setMerchantAlias("Jarvis");
		configurationModel.setMerchantId("JVZ");
		configurationModel.setMerchantName("Jarvis");
		configurationModel.setMerchantPublicKey("testmerchatnpublickey");
		configurationModel.setTxnRenewalCriteria(1);

		return configurationModel;
	}

	private ResponseEntity<AddReleaseHoldPledgeResponse> generateResponseEntity() {
		AddReleaseHoldPledgeResponse addReleaseHoldPledgeESBResponse = new AddReleaseHoldPledgeResponse();

		WsStatus wsStatus = new WsStatus();
		wsStatus.setErrorMessage("");
		wsStatus.setSoaResponseCode("SOA-000");
		wsStatus.setTransactionStatus(0);
		addReleaseHoldPledgeESBResponse.setWsStatus(wsStatus);

		addReleaseHoldPledgeESBResponse.setAccountNumber("3123456789");
		addReleaseHoldPledgeESBResponse.setAmount("100");
		addReleaseHoldPledgeESBResponse.setAvailableBalance("1000");
		addReleaseHoldPledgeESBResponse.setBranchCode("123");
		addReleaseHoldPledgeESBResponse.setCurrencyCode("608");
		addReleaseHoldPledgeESBResponse.setCurrentBalance("1000");
		addReleaseHoldPledgeESBResponse.setDescription("JARVIS TESTING");
		addReleaseHoldPledgeESBResponse.setHoldPledgeType("P");
		addReleaseHoldPledgeESBResponse.setOriginatingBranchCode("123");
		addReleaseHoldPledgeESBResponse.setTransactionCode(TransactionStatus.SUCCESS.getCode());
		addReleaseHoldPledgeESBResponse.setTransactionDesc(TransactionStatus.SUCCESS.getDescription());
		addReleaseHoldPledgeESBResponse.setWsStatus(wsStatus);

		return new ResponseEntity<>(addReleaseHoldPledgeESBResponse, HttpStatus.OK);
	}

}
