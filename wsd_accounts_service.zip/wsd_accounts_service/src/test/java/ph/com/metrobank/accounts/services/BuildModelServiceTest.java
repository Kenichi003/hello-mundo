package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryRequest;
import ph.com.metrobank.accounts.services.BuildModelService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class BuildModelServiceTest {

	@Autowired
	private BuildModelService buildModelService;
	
	@MockBean
	private LoggingService loggingService;

	@Test
	public void testBuildBind() throws Exception {
		String json = "{\n    \"externalUserId\": \"92c696d8-a89d-4cbc-b9ea-ac47d207e7a9\",\n    \"token\": \"0062283539237226176267683642864197825648\",\n    \"searchString\": \"Test search string\",\n    \"keyOfLastRecord\": \"1\"\n}\n";
		HoldPledgeInquiryRequest result = (HoldPledgeInquiryRequest) buildModelService.jsonToObject(json, HoldPledgeInquiryRequest.class, "1");
		assertThat(result.getExternalUserId()).isEqualTo("92c696d8-a89d-4cbc-b9ea-ac47d207e7a9");
	}

}
