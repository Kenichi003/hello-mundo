package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.UUID;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.services.GenerateUUIDService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class GenerateUUIDServiceTest {
	
	@Autowired
	private GenerateUUIDService uuid;
	
	@Test
	public void testGenerateUUID() {
		String uId = uuid.generateUUID();
		UUID uuid = UUID.fromString(uId);
		assertThat(uId).isEqualTo(uuid.toString());
	}
	
}
