package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pgw.osb.adb.AccountDetailedBalanceResponse;
import com.pgw.osb.adb.WsStatus;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.model.CasaResponse;
import ph.com.metrobank.accounts.services.AccountBalanceOSBService;
import ph.com.metrobank.accounts.services.AccountDetailsService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
public class AccountBalanceServiceTest {

	@Autowired
	private AccountBalanceOSBService accountBalanceOSBService;

	@MockBean
	private LoggingService loggingService;

	@MockBean
	private AccountDetailsService accountDetailsService;

	private CasaResponse casaResponse;
	private AccountDetailedBalanceResponse accountDetailedBalanceResponse;
	private WsStatus wss;

	@Before
	public void setUp() {
		wss = new WsStatus();
		wss.setSOAResponseCode("SOA-000");
		wss.setTransactionStatus("0");

		accountDetailedBalanceResponse = new AccountDetailedBalanceResponse();
		accountDetailedBalanceResponse.setObjWSS(wss);
		accountDetailedBalanceResponse.setAvailableAmount("1000");

		casaResponse = new CasaResponse("1", "123", "alias", "1000", "NA");
		casaResponse.setId("1");
		casaResponse.setAccountNo("1234567891234");
		casaResponse.setAccountAlias("alias");
		casaResponse.setBalance("1000");
		casaResponse.setRemarks("NA");
	}

	@Test
	public void testGetBalance() throws Exception {
		when(accountDetailsService.getAccountBalance(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountDetailedBalanceResponse);
		AccountDetailedBalanceResponse res = accountBalanceOSBService.getBalance("1", "1");
		assertThat(res).isNotNull();
	}

	@Test
	public void testGetBalance2() throws Exception {
		accountDetailedBalanceResponse.getObjWSS().setTransactionStatus("1");
		when(accountDetailsService.getAccountBalance(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountDetailedBalanceResponse);
		AccountDetailedBalanceResponse res = accountBalanceOSBService.getBalance("1", "1");
		assertThat(res).isNull();
	}

	@Test
	public void testGetBalance3() throws Exception {
		accountDetailedBalanceResponse.getObjWSS().setTransactionStatus("1");
		accountDetailedBalanceResponse.getObjWSS().setSOAResponseCode("SOA-001");
		when(accountDetailsService.getAccountBalance(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountDetailedBalanceResponse);
		AccountDetailedBalanceResponse res = accountBalanceOSBService.getBalance("1", "1");
		assertThat(res).isNull();
	}

	@Test
	public void testGetBalance4() throws Exception {
		accountDetailedBalanceResponse.getObjWSS().setTransactionStatus("0");
		accountDetailedBalanceResponse.getObjWSS().setSOAResponseCode("SOA-001");
		when(accountDetailsService.getAccountBalance(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(accountDetailedBalanceResponse);
		AccountDetailedBalanceResponse res = accountBalanceOSBService.getBalance("1", "1");
		assertThat(res).isNull();
	}

	@Test
	public void testGetBalance5() throws Exception {
		when(accountDetailsService.getAccountBalance(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(new DatatypeConfigurationException(""));
		AccountDetailedBalanceResponse res = accountBalanceOSBService.getBalance("1", "1");
		assertThat(res).isNull();
	}

}
