package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.CasaModel;
import ph.com.metrobank.accounts.model.Format;

@RunWith(SpringJUnit4ClassRunner.class)
public class CasaModelEntityTest {

	private CasaModel casaModel;
	
	@Before
	public void setUp() {
		casaModel = new CasaModel();
		casaModel.setId("1024");
		casaModel.setAccountNo("123456789");
		casaModel.setCreated("09/22/2016 07:16:08.901000000 PM");
		casaModel.setCurrencyCode("001");
		casaModel.setDocumentId("123");
		casaModel.setProductType("AA");
		casaModel.setOwner("reagan1215");
	}
	
	@Test
	public void testCasaModelValue() {	
		assertThat(casaModel.getAccountNo()).isEqualTo("123456789");
		assertThat(casaModel.getCreated()).isEqualTo("09/22/2016 07:16:08.901000000 PM");
		assertThat(casaModel.getId()).isEqualTo("1024");
		assertThat(casaModel.getCurrencyCode()).isEqualTo("001");
		assertThat(casaModel.getOwner()).isEqualTo("reagan1215");
		assertThat(casaModel.getDocumentId()).isEqualTo("123");
		assertThat(casaModel.getProductType()).isEqualTo("AA");
		assertThat(casaModel.toString()).isEqualTo(casaModel.toString());
		
		Format format = new Format();
		assertThat(format.toString()).isEqualTo("");
	}

}
