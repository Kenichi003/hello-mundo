package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.EaDocument;

@RunWith(SpringJUnit4ClassRunner.class)
public class EaDocumentEntityTest {

	private EaDocument ea;
	
	@Before
	public void setUp() {
		ea = new EaDocument();
		ea.setId("1024");
		ea.setJsonData("string");
	}
	
	@Test
	public void testEaDocumentValue() {	
		assertThat(ea.getId()).isEqualTo("1024");
		assertThat(ea.getJsonData()).isEqualTo("string");
	}

}
