package ph.com.metrobank.accounts.hold.pledge.common.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;

import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.model.Format;

public class AccountsModelTest {

private AccountsModel accountsModel;
	
	@Before
	public void setUp() {
		accountsModel = new AccountsModel();
		accountsModel.setDlId("1");
		accountsModel.setAccountNo("123456");
		accountsModel.setToken("654321");
		accountsModel.setOwner("drmarkryanto");
		accountsModel.setMerchantId("LZD");
		accountsModel.setReferenceNo("1111111");
		accountsModel.setDateCreated(null);
		accountsModel.setDateModified(null);
		accountsModel.setDeleteFlag(false);
		accountsModel.setRmNumber("1234567890");
	}
	
	@Test
	public void testAccountModelValue() {	
		assertThat(accountsModel.getDlId()).isEqualTo("1");
		assertThat(accountsModel.getAccountNo()).isEqualTo("123456");
		assertThat(accountsModel.getToken()).isEqualTo("654321");
		assertThat(accountsModel.getMerchantId()).isEqualTo("LZD");
		assertThat(accountsModel.getOwner()).isEqualTo("drmarkryanto");
		assertThat(accountsModel.getReferenceNo()).isEqualTo("1111111");
		assertThat(accountsModel.getDateCreated()).isNull();
		assertThat(accountsModel.getDateModified()).isNull();
		assertThat(accountsModel.isDeleteFlag()).isFalse();
		assertThat(accountsModel.toString()).isEqualTo(accountsModel.toString());
		assertThat(accountsModel.getRmNumber()).isEqualTo("1234567890");
		
		Format format = new Format();
		assertThat(format.toString()).isEqualTo("");
	}
}
