package ph.com.metrobank.accounts.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.model.CasaModel;
import ph.com.metrobank.accounts.repository.CasaRepository;
import ph.com.metrobank.accounts.services.CasaService;
import ph.com.metrobank.accounts.services.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration=RegistrationPolicy.REPLACE_EXISTING)
public class CasaServiceTest {
	
	@Autowired
	private CasaService casaService;
	
	@MockBean
	private LoggingService loggingService;
	
	@MockBean
	private CasaRepository casaRepository;
	
	private CasaModel casaModel;
	private List<CasaModel> casaModelList;
	
	@Before
	public void setUp() {
		casaModelList = new ArrayList<>();
		casaModel = new CasaModel();
		casaModel.setId("1024");
		casaModel.setAccountNo("123456789");
		casaModel.setCreated("09/22/2016 07:16:08.901000000 PM");
		casaModel.setCurrencyCode("001");
		casaModel.setDocumentId("123");
		casaModel.setProductType("AA");
		casaModel.setOwner("reagan1215");
		
		casaModelList.add(casaModel);
	}
	
	@Test
	public void testGetCasaModel() throws Exception {
		List<String> productLists = new ArrayList<>();
		productLists.add("702");
		when(casaRepository.getCasaModelByOwner("reagan1215", "001", productLists)).thenReturn(casaModelList);
		List<CasaModel> result = casaService.getCasaModelByOwner("reagan1215", productLists);
		assertThat(result).isNotEmpty();
	}
	
	@Test
	public void testGetAccountNo() throws Exception {
		when(casaRepository.getAccountNo(Mockito.anyString())).thenReturn("1234567891234");
		String result = casaService.getAccountNo("1");
		assertThat(result).isEqualTo("1234567891234");
	}
	
	@Test
	public void testGetAccountNickname() throws Exception {
		when(casaRepository.getCasaModelByAccountNo(Mockito.anyString())).thenReturn(casaModel);
		CasaModel result = casaService.getAccountNickname("1");
		assertThat(result.getAccountNo()).isEqualTo("123456789");
	}
	
}
