package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.TransactionStatus;

@RunWith(SpringJUnit4ClassRunner.class)
public class TransactionStatusEntityTest {

	@Test
	public void testInitialStatusValue() {
		assertThat(TransactionStatus.getDescription("000")).isEqualTo("SUCCESS");
		assertThat(TransactionStatus.getDescription("999")).isEqualTo("INTERNAL SERVER ERROR");
	}

}
