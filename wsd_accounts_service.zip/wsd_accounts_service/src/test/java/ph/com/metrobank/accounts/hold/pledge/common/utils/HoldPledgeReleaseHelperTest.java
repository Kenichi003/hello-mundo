package ph.com.metrobank.accounts.hold.pledge.common.utils;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.AccountsApplication;
import ph.com.metrobank.accounts.hold.pledge.release.models.AccountDetails;
import ph.com.metrobank.accounts.hold.pledge.release.utils.HoldPledgeReleaseHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ContextConfiguration(classes = AccountsApplication.class, initializers = ConfigFileApplicationContextInitializer.class)
@EnableMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
public class HoldPledgeReleaseHelperTest {

	private AccountDetails accountDetails;

	@Before
	public void setUp() throws Exception {
		accountDetails = generateAccountDetails();
	}

	@Test
	public void testCreateAccountDetails() {
		AccountDetails accountDetailsTest = HoldPledgeReleaseHelper.createAccountDetails("1233123456789", "608");

		assertEquals(accountDetails.getAccountNumber(), accountDetailsTest.getAccountNumber());
		assertEquals(accountDetails.getBranchCode(), accountDetailsTest.getBranchCode());
		assertEquals(accountDetails.getCurrencyCode(), accountDetailsTest.getCurrencyCode());
		assertEquals(accountDetails.getOriginatingBranchCode(), accountDetailsTest.getOriginatingBranchCode());
	}

	private AccountDetails generateAccountDetails() {
		AccountDetails accountDetails = new AccountDetails();
		accountDetails.setAccountNumber("3123456789");
		accountDetails.setBranchCode("123");
		accountDetails.setCurrencyCode("608");
		accountDetails.setOriginatingBranchCode("123");

		return accountDetails;
	}

}
