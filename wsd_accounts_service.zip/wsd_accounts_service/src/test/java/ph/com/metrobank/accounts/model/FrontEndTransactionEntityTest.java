package ph.com.metrobank.accounts.model;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.model.FrontEndTransaction;

@RunWith(SpringJUnit4ClassRunner.class)
public class FrontEndTransactionEntityTest {

	private FrontEndTransaction frontEndTransaction;
	
	@Before
	public void setUp() {
		frontEndTransaction = new FrontEndTransaction();
		frontEndTransaction.setId("1");
		frontEndTransaction.setCode("123");
		frontEndTransaction.setCreated(null);
		frontEndTransaction.setDescription("desc");
		frontEndTransaction.setEnabled("1");
		frontEndTransaction.setName("name");
		frontEndTransaction.setOtpAmount("123");
		frontEndTransaction.setProductTypes("702");
		frontEndTransaction.setTransactionLimit("1000");
	}
	
	@Test
	public void testFrontEndTransactionValue() {	
		assertThat(frontEndTransaction.getId()).isEqualTo("1");
		assertThat(frontEndTransaction.getCode()).isEqualTo("123");
		assertThat(frontEndTransaction.getCreated()).isEqualTo(null);
		assertThat(frontEndTransaction.getDescription()).isEqualTo("desc");
		assertThat(frontEndTransaction.getEnabled()).isEqualTo("1");
		assertThat(frontEndTransaction.getName()).isEqualTo("name");
		assertThat(frontEndTransaction.getOtpAmount()).isEqualTo("123");
		assertThat(frontEndTransaction.getProductTypes()).isEqualTo("702");
		assertThat(frontEndTransaction.getTransactionLimit()).isEqualTo("1000");
		assertThat(frontEndTransaction.toString()).isEqualTo(frontEndTransaction.toString());
	}

}
