package ph.com.metrobank.accounts.hold.pledge.common.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.accounts.hold.pledge.release.models.ConfigurationModel;

@RunWith(SpringJUnit4ClassRunner.class)
public class ConfigurationModelTest {

	private ConfigurationModel configurationModel;

	@Before
	public void setUp() {
		configurationModel = new ConfigurationModel();
		configurationModel.setExpiryDays(182);
		configurationModel.setAggregateLimitAccount(30000);
		configurationModel.setAggregateLimitUser(50000);
		configurationModel.setMaxLinkedAccounts(1);
		configurationModel.setMerchantId("LZD");
		configurationModel.setTxnRenewalCriteria(3);
		configurationModel.setMerchantName("LAZADA");
		configurationModel.setMerchantAlias("LAZADA");
		configurationModel.setBankPrivateKey("bbbb");
		configurationModel.setBankPublicKey("aaaa");
		configurationModel.setMerchantPublicKey("cccc");
	}

	@Test
	public void testDirectLinkConfigurationModelValue() {
		assertThat(configurationModel.getExpiryDays()).isEqualTo(182);
		assertThat(configurationModel.getAggregateLimitAccount()).isEqualTo(30000);
		assertThat(configurationModel.getAggregateLimitUser()).isEqualTo(50000);
		assertThat(configurationModel.getMaxLinkedAccounts()).isEqualTo(1);
		assertThat(configurationModel.getMerchantId()).isEqualTo("LZD");
		assertThat(configurationModel.getTxnRenewalCriteria()).isEqualTo(3);
		assertThat(configurationModel.getMerchantAlias()).isEqualTo("LAZADA");
		assertThat(configurationModel.getMerchantName()).isEqualTo("LAZADA");
		assertThat(configurationModel.getBankPrivateKey()).isEqualTo("bbbb");
		assertThat(configurationModel.getBankPublicKey()).isEqualTo("aaaa");
		assertThat(configurationModel.getMerchantPublicKey()).isEqualTo("cccc");
	}
}
