/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.Locale;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.accounts.hold.pledge.release.models.ConfigurationModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.model.ErrorMessage;
import ph.com.metrobank.accounts.model.TraceLog;

@Service
public class EncryptionService {

	@Autowired
	private LoggingService loggingService;

	@Autowired
	private BuildModelService buildModelService;

	private static final String ENCODING = "UTF-8";
	private static final String RSA = "RSA";
	private static final String SIGNATURE = "SHA256withRSA";
	private static final String MD = "MD5";
	private static final int SIXTEEN = 16;

	public String encrypt(String message, String merchantPublicKey)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, UnsupportedEncodingException, InvalidKeySpecException {
		Cipher cipher = Cipher.getInstance(RSA);
		cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(merchantPublicKey));
		byte[] encryptedBytes = cipher.doFinal(message.getBytes(ENCODING));
		return Base64.getEncoder().encodeToString(encryptedBytes);
	}

	public String sign(String plainText, String bankPrivateKey) throws NoSuchAlgorithmException, InvalidKeyException,
			SignatureException, UnsupportedEncodingException, InvalidKeySpecException {
		Signature privateSignature = Signature.getInstance(SIGNATURE);
		privateSignature.initSign(getPrivateKey(bankPrivateKey));
		privateSignature.update(plainText.getBytes(ENCODING));
		byte[] signature = privateSignature.sign();
		return Base64.getEncoder().encodeToString(signature);
	}

	public PrivateKey getPrivateKey(String privateKeyString) throws NoSuchAlgorithmException, InvalidKeySpecException {
		byte[] pkcs8EncodedBytes = Base64.getDecoder().decode(privateKeyString);
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pkcs8EncodedBytes);
		KeyFactory kf = KeyFactory.getInstance(RSA);
		return kf.generatePrivate(keySpec);
	}

	public PublicKey getPublicKey(String publicKeyString) throws NoSuchAlgorithmException, InvalidKeySpecException {
		byte[] byteKey = Base64.getDecoder().decode(publicKeyString.getBytes());
		X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
		KeyFactory kf = KeyFactory.getInstance(RSA);
		return kf.generatePublic(X509publicKey);
	}

	public String publicKeyToString(Key publicKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeyFactory fact = KeyFactory.getInstance(RSA);
		X509EncodedKeySpec x509 = (X509EncodedKeySpec) fact.getKeySpec(publicKey, X509EncodedKeySpec.class);
		return Base64.getEncoder().encodeToString(x509.getEncoded());
	}

	public String privatekeyToString(Key privateKey) throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeyFactory fact = KeyFactory.getInstance(RSA);
		PKCS8EncodedKeySpec spec = (PKCS8EncodedKeySpec) fact.getKeySpec(privateKey, PKCS8EncodedKeySpec.class);
		return Base64.getEncoder().encodeToString(spec.getEncoded());
	}

	public String decryptByPrivateKey(String encryptedText, String bankPrivateKey)
			throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, UnsupportedEncodingException,
			IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException {
		byte[] bytes = Base64.getDecoder().decode(encryptedText);
		Cipher cipher = Cipher.getInstance(RSA);
		cipher.init(Cipher.DECRYPT_MODE, getPrivateKey(bankPrivateKey));
		return new String(cipher.doFinal(bytes), ENCODING);
	}

	public String decryptByPrivateKeyString(String encryptedString, String bankPrivateKey)
			throws IllegalBlockSizeException, BadPaddingException, InvalidKeyException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException {
		byte[] clear = Base64.getDecoder().decode(bankPrivateKey);
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(clear);
		KeyFactory kf = KeyFactory.getInstance(RSA);
		PrivateKey pk = kf.generatePrivate(keySpec);
		Arrays.fill(clear, (byte) 0);
		Cipher cipher = Cipher.getInstance(RSA);
		cipher.init(Cipher.DECRYPT_MODE, pk);

		byte[] messageBytes = Base64.getDecoder().decode(encryptedString);
		byte[] hexEncodedCipher = cipher.doFinal(messageBytes, 0, messageBytes.length);
		return new String(hexEncodedCipher);
	}

	public KeyPair generateKeys(String uuid) throws NoSuchAlgorithmException {
		loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_JSON_VALIDATION, uuid, "", "");
		final int keySize = 2048;
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(RSA);
		keyPairGenerator.initialize(keySize);
		return keyPairGenerator.genKeyPair();
	}

	public boolean verifySignature(String plainText, String signature, String merchantPublicKey)
			throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, SignatureException,
			UnsupportedEncodingException {
		PublicKey publicKey = getPublicKey(merchantPublicKey);
		Signature publicSignature = Signature.getInstance(SIGNATURE);
		publicSignature.initVerify(publicKey);
		publicSignature.update(plainText.getBytes(ENCODING));
		byte[] signatureBytes = Base64.getDecoder().decode(signature);
		return publicSignature.verify(signatureBytes);
	}

	public <T extends RequestCommonModel> T  buildSignedModel(String json, String uuid, Class<T> type) throws IOException {
		loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_JSON_VALIDATION, uuid, "", json);
		return type.cast(buildModelService.jsonToObject(json, type, uuid));
	}

	public <T extends RequestCommonModel> T verifyModel(T requestModel,
			ConfigurationModel settings, String uuid)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, SignatureException, UnsupportedEncodingException {
		requestModel
				.setData(decryptByPrivateKeyString(requestModel.getData(), settings.getBankPrivateKey()));
		if (!(verifySignature(requestModel.getData(), requestModel.getSignature(),
				settings.getMerchantPublicKey()))) {
			loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_JSON_VALIDATION, uuid, "",
					requestModel.toString() + ErrorMessage.INVALID_SIGNATURE);
			return null;
		} else {
			return requestModel;
		}
	}

	public String encryptMD5(String payload) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance(MD);
		byte[] hashInBytes = md.digest(payload.getBytes(StandardCharsets.UTF_8));

		StringBuilder sb = new StringBuilder();
		for (byte b : hashInBytes) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}

	public String sha256(String uuid, String password) throws NoSuchAlgorithmException {
		loggingService.log(uuid, TraceLog.ENCRYPTIONSERVICE_ENCRYPT, "", "");
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		md.update(password.getBytes());
		byte[] byteData = md.digest();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < byteData.length; i++) {
			sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, SIXTEEN).substring(1));
		}
		return sb.toString().toUpperCase(Locale.ENGLISH);
	}

}
