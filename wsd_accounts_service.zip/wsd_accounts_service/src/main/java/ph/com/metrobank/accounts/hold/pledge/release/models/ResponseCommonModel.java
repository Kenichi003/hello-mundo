/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ResponseCommonModel extends AccountDetails {
	@JsonInclude(Include.NON_NULL)
	private String transactionCode;
	@JsonInclude(Include.NON_NULL)
	private String transactionDesc;
	
	public ResponseCommonModel() {
		super();
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTransactionDesc() {
		return transactionDesc;
	}

	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}
	
}
