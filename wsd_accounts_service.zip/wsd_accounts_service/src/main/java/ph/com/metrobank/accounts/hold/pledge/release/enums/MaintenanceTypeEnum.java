package ph.com.metrobank.accounts.hold.pledge.release.enums;

public enum MaintenanceTypeEnum {

    OVEWRITE("O"), TOP_UP("T");
    /**
     * 
     * @param type
     */
    private MaintenanceTypeEnum(String type) {
	this.type = type;
    }

    private String type;

    /**
     * 
     * @return
     */
    public String getType() {
	return type;
    }
}
