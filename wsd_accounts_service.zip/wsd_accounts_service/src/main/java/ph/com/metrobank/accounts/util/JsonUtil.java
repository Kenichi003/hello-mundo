/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.util;

import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

	private JsonUtil() {
	}

	public static <T> T mapFromJson(String json, Class<T> clazz) throws IOException {
		ObjectMapper objMapper = new ObjectMapper();
		return objMapper.readValue(json, clazz);
	}

}
