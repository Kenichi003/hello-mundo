/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.accounts.model.FrontEndTransaction;

public interface FrontEndTransactionRepository extends CrudRepository<FrontEndTransaction, String> {

	@Query("SELECT f FROM FrontEndTransaction f WHERE f.code = :code")
	FrontEndTransaction getFrontEndTransaction(@Param("code") String code);

}
