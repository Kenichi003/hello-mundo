/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model.ifx;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CurAmt {

	@JsonProperty("Amt")
	private BigDecimal amt;

	public BigDecimal getAmt() {
		return amt;
	}

	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}

}
