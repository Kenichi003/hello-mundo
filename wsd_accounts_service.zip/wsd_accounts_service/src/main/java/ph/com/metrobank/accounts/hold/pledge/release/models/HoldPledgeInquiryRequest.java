/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

public class HoldPledgeInquiryRequest extends DataCommonModel {
	private String searchString;
	private String searchDescription;
	private String keyOfLastRecord;
	
	public HoldPledgeInquiryRequest() {
		super();
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public String getSearchDescription() {
		return searchDescription;
	}

	public void setSearchDescription(String searchDescription) {
		this.searchDescription = searchDescription;
	}

	public String getKeyOfLastRecord() {
		return keyOfLastRecord;
	}

	public void setKeyOfLastRecord(String keyOfLastRecord) {
		this.keyOfLastRecord = keyOfLastRecord;
	}
	
}
