/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.services;

import static ph.com.metrobank.accounts.hold.pledge.release.utils.HoldPledgeReleaseHelper.createTransInfo;
import static ph.com.metrobank.accounts.hold.pledge.release.utils.HoldPledgeReleaseHelper.getDateStamp;
import static ph.com.metrobank.accounts.hold.pledge.release.utils.HoldPledgeReleaseHelper.getTimeStamp;

import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Objects;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeDataRequest;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeResponse;
import ph.com.metrobank.accounts.hold.pledge.release.models.Credentials;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.TransInfo;
import ph.com.metrobank.accounts.hold.pledge.release.models.WsStatus;
import ph.com.metrobank.accounts.hold.pledge.release.utils.HoldPledgeReleaseHelper;
import ph.com.metrobank.accounts.model.ErrorMessage;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.model.TransactionStatus;
import ph.com.metrobank.accounts.services.LoggingService;;


public class AbstractAddReleaseHoldPledge extends AbstractCommonService{
	
	@Autowired
	private LoggingService loggingService;
	 
	@Autowired
    private RestTemplate restTemplate;
	
	@Autowired
	private HoldPledgeReleaseHelper holdPledgeReleaseHelper;
	
	private static final String CURRENCY_PHP = "608";
    
    private static final String NOT_CURRENCY_PHP = "908";

    private static final int ACCOUNT_NUMBER_START_INDEX = 3;
    
    private static final int ZERO_INDEX = 0;

	public AddReleaseHoldPledgeDataRequest createAddReleaseHoldPledgeESBRequest(AddReleaseHoldPledgeDataRequest decryptedAddReleaseHoldPledgeData, String accountNbr,
			String transactionCodeType, String uuid) throws Exception {

		AddReleaseHoldPledgeDataRequest addReleaseHoldPledgeEsbRequest = new AddReleaseHoldPledgeDataRequest();

		String accountNo = accountNbr.substring(ACCOUNT_NUMBER_START_INDEX);

		GregorianCalendar gc = GregorianCalendar.from(ZonedDateTime.now());
		XMLGregorianCalendar dateStamp = getDateStamp(gc.get(Calendar.YEAR), gc.get(Calendar.MONTH) + 1,
				gc.get(Calendar.DAY_OF_MONTH));
		XMLGregorianCalendar timeStamp = getTimeStamp(gc.get(Calendar.HOUR_OF_DAY), gc.get(Calendar.MINUTE),
				gc.get(Calendar.SECOND));

		String branchCode = StringUtils.substring(accountNbr, ZERO_INDEX, ACCOUNT_NUMBER_START_INDEX);
		accountNbr = StringUtils.substring(accountNbr, ACCOUNT_NUMBER_START_INDEX);
		char[] currencyCheck = accountNbr.toCharArray();
		boolean peso = currencyCheck[ZERO_INDEX] == '3';
		String currencyCode = !peso ? NOT_CURRENCY_PHP : CURRENCY_PHP;

		TransInfo transInfo = createTransInfo(accountNo, dateStamp, timeStamp);
		Credentials credentials = holdPledgeReleaseHelper.createCredentials(uuid, dateStamp, timeStamp);

		BeanUtils.copyProperties(decryptedAddReleaseHoldPledgeData, addReleaseHoldPledgeEsbRequest);
		addReleaseHoldPledgeEsbRequest.setAccountNumber(accountNbr);
		addReleaseHoldPledgeEsbRequest.setOriginatingBranchCode(branchCode);
		addReleaseHoldPledgeEsbRequest.setBranchCode(branchCode);
		addReleaseHoldPledgeEsbRequest.setCurrencyCode(currencyCode);
		addReleaseHoldPledgeEsbRequest.setTransactionCodeType(transactionCodeType);
		addReleaseHoldPledgeEsbRequest.setTransactionInformation(transInfo);
		addReleaseHoldPledgeEsbRequest.setCredentials(credentials);

		return addReleaseHoldPledgeEsbRequest;
	}
	
	public AddReleaseHoldPledgeResponse callAddReleaseHoldPledgeEsbApi(
			AddReleaseHoldPledgeDataRequest addReleaseHoldPledgeESBRequest, String uuid, String endPoint,
			String transactionType) throws Exception {
		loggingService.log(this.getClass().toString() + TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE_ESB_CALL, uuid,
				"ENDPOINT: " + endPoint + "TRANS TYPE: " + transactionType, addReleaseHoldPledgeESBRequest.toString());
		// CALL ESB API
		AddReleaseHoldPledgeResponse addReleaseHoldPledgeESBResponse = callESBApi(addReleaseHoldPledgeESBRequest,
				endPoint);
		loggingService.log(this.getClass().toString() + TraceLog.JVZ_ADD_RELEASE_HOLD_PLEDGE_SERVICE_ESB_RESPONSE, uuid,
				" ENDPOINT: " + endPoint + " TRANS TYPE: " + transactionType,
				addReleaseHoldPledgeESBResponse.toString());
		return createResponse(addReleaseHoldPledgeESBResponse);
	}
	
	private AddReleaseHoldPledgeResponse callESBApi(AddReleaseHoldPledgeDataRequest addReleaseHoldPledgeESBRequest,
			String endPoint) throws Exception {
		try {
			HttpEntity<AddReleaseHoldPledgeDataRequest> requestEntity = new HttpEntity<>(
					addReleaseHoldPledgeESBRequest);
			ResponseEntity<AddReleaseHoldPledgeResponse> responseEntity = restTemplate.exchange(endPoint,
					HttpMethod.POST, requestEntity, AddReleaseHoldPledgeResponse.class);
			return responseEntity.getBody();
		} catch (RestClientException exc) {
			throw new RestClientException(
					"RestClientException occurred at AddReleaseHoldPledgeService.callESBApi() for endpoint: " + endPoint
							+ exc.getMessage());
		}
	}
	
	public AddReleaseHoldPledgeResponse createResponse(
			AddReleaseHoldPledgeResponse addReleaseHoldPledgeESBResponse) {
		AddReleaseHoldPledgeResponse response = new AddReleaseHoldPledgeResponse();
		WsStatus esbStatus = addReleaseHoldPledgeESBResponse.getWsStatus();
		if (Objects.nonNull(esbStatus) && esbStatus.getTransactionStatus() > 0) {
			loggingService.log(this.getClass().toString() + TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE_ESB_ERROR, "",
					"", addReleaseHoldPledgeESBResponse.toString());
			response.setTransactionCode(TransactionStatus.FAILED.getCode());
			response.setTransactionDesc(TransactionStatus.FAILED.getDescription());
			response.setWsStatus(esbStatus); // FOR DEBUGGING. REMOVE LATER
		} else {
			response.setDescription(addReleaseHoldPledgeESBResponse.getDescription());
			response.setAmount(addReleaseHoldPledgeESBResponse.getAmount());
			response.setHoldPledgeType(addReleaseHoldPledgeESBResponse.getHoldPledgeType());
			response.setAvailableBalance(addReleaseHoldPledgeESBResponse.getAvailableBalance());
			response.setCurrentBalance(addReleaseHoldPledgeESBResponse.getCurrentBalance());
			response.setTransactionCode(TransactionStatus.SUCCESS.getCode());
			response.setTransactionDesc(TransactionStatus.SUCCESS.getDescription());
		}
		return response;
	}
	
	
	public boolean isValidAccountModel(AccountsModel accountsModel, AddReleaseHoldPledgeResponse response,
			AddReleaseHoldPledgeDataRequest decryptedData, String uuid, String endpoint) {
		boolean isValid = true;
		if (Objects.isNull(accountsModel)) {
			loggingService.log(
					this.getClass().toString() + TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE_INVALID_ACCOUNT_EXCEPTION,
					uuid, endpoint, decryptedData.toString() + TraceLog.CASA_ACCOUNT_BY_TOKEN_NOT_FOUND);
			response.setTransactionCode(TransactionStatus.INVALID_ACCOUNT.getCode());
			response.setTransactionDesc(TransactionStatus.INVALID_ACCOUNT.getDescription());
			isValid = false;
		} else if (accountsModel.isDeleteFlag()) {
			loggingService.log(
					this.getClass().toString() + TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE_INVALID_ACCOUNT_EXCEPTION,
					uuid, endpoint, decryptedData.toString() + TraceLog.CASA_ACCOUNT_BY_TOKEN_NOT_FOUND);
			response.setTransactionCode(TransactionStatus.ACCOUNT_ALREADY_UNLINKED.getCode());
			response.setTransactionDesc(TransactionStatus.ACCOUNT_ALREADY_UNLINKED.getDescription());
			isValid = false;
		} else {
			isValid = true;
		}
		return isValid;
	}
	
	public boolean isValidExternalUserId(AccountsModel accountsModel, AddReleaseHoldPledgeResponse response,
			RequestCommonModel decryptedAddReleaseHoldPledge, AddReleaseHoldPledgeDataRequest decryptedData,
			String uuid, String endpoint) {
		boolean isValid = true;
		if (!accountsModel.getExternalUserId().equals(decryptedData.getExternalUserId())) {
			loggingService.log(
					this.getClass().toString()
							+ TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE_INVALID_EXTERNAL_USER_ID_EXCEPTION,
					uuid + endpoint, decryptedAddReleaseHoldPledge.getChannelId(),
					ErrorMessage.EXTERNAL_USER_ID_MISMATCH);
			response.setTransactionCode(TransactionStatus.INVALID_REQUEST.getCode());
			response.setTransactionDesc(TransactionStatus.INVALID_REQUEST.getDescription());
			isValid = false;
		}
		return isValid;
	}
}
