/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

public class AddReleaseHoldPledgeDataRequest extends AccountDetails {

    private String transactionType;
    private String transactionCodeType;
    private String allFunds;
    private String amount;
    private String lowSerialNumber;
    private String highSerialNumber;
    private String description;
    private String days;
    private String maintenanceType;
    private TransInfo transactionInformation;
    private Credentials credentials;
    
	public AddReleaseHoldPledgeDataRequest() {
		super();
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionCodeType() {
		return transactionCodeType;
	}

	public void setTransactionCodeType(String transactionCodeType) {
		this.transactionCodeType = transactionCodeType;
	}

	public String getAllFunds() {
		return allFunds;
	}

	public void setAllFunds(String allFunds) {
		this.allFunds = allFunds;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getLowSerialNumber() {
		return lowSerialNumber;
	}

	public void setLowSerialNumber(String lowSerialNumber) {
		this.lowSerialNumber = lowSerialNumber;
	}

	public String getHighSerialNumber() {
		return highSerialNumber;
	}

	public void setHighSerialNumber(String highSerialNumber) {
		this.highSerialNumber = highSerialNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	public String getMaintenanceType() {
		return maintenanceType;
	}

	public void setMaintenanceType(String maintenanceType) {
		this.maintenanceType = maintenanceType;
	}

	public TransInfo getTransactionInformation() {
		return transactionInformation;
	}

	public void setTransactionInformation(TransInfo transactionInformation) {
		this.transactionInformation = transactionInformation;
	}

	public Credentials getCredentials() {
		return credentials;
	}

	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}
    
}
