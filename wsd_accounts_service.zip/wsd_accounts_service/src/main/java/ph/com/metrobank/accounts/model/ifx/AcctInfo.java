/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model.ifx;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AcctInfo {

	@JsonProperty("AcctBal")
	private List<AcctBal> acctBal;

	public List<AcctBal> getAcctBal() {
		return Objects.nonNull(acctBal) ? acctBal : new ArrayList<>();
	}

	public void setAcctBal(List<AcctBal> acctBal) {
		this.acctBal = acctBal;
	}

}
