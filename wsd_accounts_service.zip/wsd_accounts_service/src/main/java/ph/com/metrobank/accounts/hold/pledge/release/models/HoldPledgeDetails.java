/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

import java.math.BigDecimal;

public class HoldPledgeDetails {
	private String sequenceNumber;
	
	private String lowSerialNumber;
	
	private String highSerialNumber;
	
	private BigDecimal amount;
	
	private String expirationDate;
	
	private String maintenanceDate;
	
	private String holdPledgeType;
	
	private String description;
	
	private String userId;

	public HoldPledgeDetails() {
		super();
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getLowSerialNumber() {
		return lowSerialNumber;
	}

	public void setLowSerialNumber(String lowSerialNumber) {
		this.lowSerialNumber = lowSerialNumber;
	}

	public String getHighSerialNumber() {
		return highSerialNumber;
	}

	public void setHighSerialNumber(String highSerialNumber) {
		this.highSerialNumber = highSerialNumber;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getMaintenanceDate() {
		return maintenanceDate;
	}

	public void setMaintenanceDate(String maintenanceDate) {
		this.maintenanceDate = maintenanceDate;
	}

	public String getHoldPledgeType() {
		return holdPledgeType;
	}

	public void setHoldPledgeType(String holdPledgeType) {
		this.holdPledgeType = holdPledgeType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
