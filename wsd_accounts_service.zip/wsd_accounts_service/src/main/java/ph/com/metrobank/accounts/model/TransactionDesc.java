/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model;

public class TransactionDesc {

	public static final String SUCCESS = "SUCCESS";
	public static final String FAILED = "FAILED";
	public static final String NO_BALANCE_RETRIEVED = "NO_BALANCE_RETRIEVED";
	public static final String INTERNAL_SERVER_ERROR = "INTERNAL SERVER ERROR";
	public static final String INVALID_REQUEST = "INVALID REQUEST";
	public static final String INVALID_ACCOUNT = "INVALID or ACCOUNT NOT EXISTING";
	public static final String NO_RECORD_FOUND = "NO_RECORD_FOUND";
	public static final String ACCOUNT_ALREADY_UNLINKED = "ACCOUNT ALREADY UNLINKED";

	TransactionDesc() {
		throw new IllegalStateException("Utility class");
	}
}
