/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import static org.springframework.beans.factory.config.BeanDefinition.SCOPE_PROTOTYPE;

import java.nio.charset.Charset;

@Configuration
public class AccountsConfig {

	@Value("${http.read.timeout}")
	private int httpReadTimeout;

	@Value("${http.connection.timeout}")
	private int httpConnectionTimeout;

	@Bean
	@Scope(SCOPE_PROTOTYPE)
	public RestTemplate restTemplate() {
		ClientHttpRequestFactory requestFactory = this.createSimpleHttpRequestFactory();
		final RestTemplate restTemplate = new RestTemplate(requestFactory);
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
		return restTemplate;
	}

	private ClientHttpRequestFactory createSimpleHttpRequestFactory() {
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setReadTimeout(httpReadTimeout);
		factory.setConnectTimeout(httpConnectionTimeout);
		return factory;
	}

}
