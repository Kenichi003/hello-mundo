/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model;

public class CasaResponse extends Format {

	private String id;
	private String accountNo;
	private String accountAlias;
	private String balance;
	private String remarks;

	public CasaResponse(String id, String accountNo, String accountAlias, String balance, String remarks) {
		this.id = id;
		this.accountNo = accountNo;
		this.accountAlias = accountAlias;
		this.balance = balance;
		this.remarks = remarks;
	}

	public CasaResponse() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public String getAccountAlias() {
		return accountAlias;
	}

	public void setAccountAlias(String accountAlias) {
		this.accountAlias = accountAlias;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
