/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pgw.osb.adb.AccountDetailedBalanceResponse;

import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.DataCommonModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.hold.pledge.release.services.AbstractCommonService;
import ph.com.metrobank.accounts.model.CasaModel;
import ph.com.metrobank.accounts.model.CasaResponse;
import ph.com.metrobank.accounts.model.ErrorMessage;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.model.TransactionStatus;
import ph.com.metrobank.accounts.model.ifx.AcctBal;
import ph.com.metrobank.accounts.model.ifx.AcctInfo;
import ph.com.metrobank.accounts.model.ifx.AcctInqRs;
import ph.com.metrobank.accounts.model.ifx.AcctRec;
import ph.com.metrobank.accounts.model.ifx.BalType;
import ph.com.metrobank.accounts.model.ifx.BalTypeValues;
import ph.com.metrobank.accounts.model.ifx.CurAmt;
import ph.com.metrobank.accounts.model.ifx.Status;

@Service
public class OrchestrationService extends AbstractCommonService {

	@Autowired
	private LoggingService loggingService;

	@Autowired
	private CasaService casaService;

	@Autowired
	private FrontEndTransactionService frontEndTransactionService;

	@Autowired
	private AccountBalanceOSBService accountBalanceOSBService;

	@Autowired
	private EADocumentService eaDocumentService;

	private static final String ERROR_MESSAGE = "CANNOT RETRIEVE BALANCE";
	private static final String NA = "NA";
	private static final int MASK = 4;

	public List<CasaResponse> getCasa(String owner, String uuid) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_GET_CASA, "", "", owner);
		List<String> productTypes = Arrays
				.asList(frontEndTransactionService.getFrontEndTransaction().getProductTypes().split("\\s*,\\s*"));
		List<CasaModel> casaList = casaService.getCasaModelByOwner(owner, productTypes);
		return casaList.stream().map((CasaModel c) -> {
			CasaResponse casaResponse = new CasaResponse();
			AccountDetailedBalanceResponse accountDetailedBalanceResponse = accountBalanceOSBService
					.getBalance(c.getAccountNo(), uuid);
			casaResponse.setAccountNo(
					c.getAccountNo().substring(c.getAccountNo().length() - MASK, c.getAccountNo().length()));
			casaResponse.setAccountAlias(eaDocumentService.getAccountAlias(c.getDocumentId()));
			casaResponse.setId(c.getId());
			if (Objects.nonNull(accountDetailedBalanceResponse)) {

				casaResponse.setBalance(accountDetailedBalanceResponse.getAvailableAmount());
				casaResponse.setRemarks("");

			} else {
				casaResponse.setBalance(NA);
				casaResponse.setRemarks(ERROR_MESSAGE);
			}

			return casaResponse;
		}).collect(Collectors.toList());
	}

	public String getAccountNo(String id) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_GET_ACCOUNTNO, "", "", id);
		return casaService.getAccountNo(id);
	}

	public String getAccountNickname(String accountNo) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_GET_ACCOUNT_NICKNAME, "", "", accountNo);
		CasaModel casaModel = casaService.getAccountNickname(accountNo);
		return eaDocumentService.getAccountAlias(casaModel.getDocumentId());
	}

	public AcctInqRs orchestrateCasaBalanceInquiry(String json, String uuid) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_CASA_GET_ACCOUNT_BALANCE, uuid, "", "");
		try {
			RequestCommonModel accountHoldRequestModel = decryptRequest(json, uuid);
			if (Objects.isNull(accountHoldRequestModel)) {
				loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_CASA_GET_ACCOUNT_BALANCE, uuid, "",
						json + ErrorMessage.INVALID_SIGNATURE);
				return createCasaBalanceInquiryResponse(TransactionStatus.INVALID_REQUEST.getCode(),
						TransactionStatus.INVALID_REQUEST.getDescription(), new BigDecimal("0"), new BigDecimal("0"));
			}
			DataCommonModel accountBalanceInquiryData = (DataCommonModel) decryptData(accountHoldRequestModel,
					DataCommonModel.class, uuid);
			AccountsModel accountsModel = getAccountsModel(accountBalanceInquiryData.getToken(),
					accountHoldRequestModel.getChannelId(), uuid);
			if (Objects.isNull(accountsModel)) {
				loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_CASA_GET_ACCOUNT_BALANCE, uuid, "",
						json + ErrorMessage.CASA_ACCOUNT_BY_TOKEN_NOT_FOUND);
				return createCasaBalanceInquiryResponse(TransactionStatus.INVALID_REQUEST.getCode(),
						TransactionStatus.INVALID_REQUEST.getDescription(), new BigDecimal("0"), new BigDecimal("0"));
			}
			if (accountsModel.getExternalUserId().equals(accountBalanceInquiryData.getExternalUserId())) {
				return inquireCasa(accountsModel.getAccountNo(), uuid);
			} else {
				loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_CASA_GET_ACCOUNT_BALANCE, uuid, "",
						json + ErrorMessage.EXTERNAL_USER_ID_MISMATCH);
				return createCasaBalanceInquiryResponse(TransactionStatus.INVALID_REQUEST.getCode(),
						TransactionStatus.INVALID_REQUEST.getDescription(), new BigDecimal("0"), new BigDecimal("0"));
			}
		} catch (Exception e) {
			loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_CASA_GET_ACCOUNT_BALANCE, uuid, "",
					json + e.getMessage());
			return createCasaBalanceInquiryResponse(TransactionStatus.INTERNAL_SERVER_ERROR.getCode(),
					TransactionStatus.INTERNAL_SERVER_ERROR.getDescription(), new BigDecimal("0"), new BigDecimal("0"));
		}
	}

	public AcctInqRs inquireCasa(String accountNo, String uuid) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_INQUIRE_CASA, "", "", accountNo);
		AcctInqRs acctInqRs = new AcctInqRs();
//		Status status = acctInqRs.getStatus();
//		AcctRec acctRec = acctInqRs.getAcctRec();
//		AcctInfo acctInfo = acctRec.getAcctInfo();
//		List<AcctBal> acctBalList = acctInfo.getAcctBal();
//		AcctBal acctBal1 = new AcctBal();
//		AcctBal acctBal2 = new AcctBal();
//		BalType balType1 = new BalType();
//		BalType balType2 = new BalType();
//		CurAmt curAmt1 = new CurAmt();
//		CurAmt curAmt2 = new CurAmt();

		AccountDetailedBalanceResponse accountDetailedBalanceResponse = accountBalanceOSBService.getBalance(accountNo,
				uuid);
		if (Objects.nonNull(accountDetailedBalanceResponse)) {
//			curAmt1.setAmt(new BigDecimal(accountDetailedBalanceResponse.getAvailableAmount()));
//			balType1.setBalTypeValues(BalTypeValues.Avail);
//			acctBal1.setCurAmt(curAmt1);
//			acctBal1.setBalType(balType1);
//			curAmt2.setAmt(new BigDecimal(accountDetailedBalanceResponse.getCurrentBalance()));
//			balType2.setBalTypeValues(BalTypeValues.Current);
//			status.setStatusCode(TransactionStatus.SUCCESS.getCode());
//			status.setStatusDesc(TransactionStatus.SUCCESS.getDescription());
			acctInqRs = createCasaBalanceInquiryResponse(TransactionStatus.SUCCESS.getCode(),
					TransactionStatus.SUCCESS.getDescription(), new BigDecimal(accountDetailedBalanceResponse.getAvailableAmount()),
					new BigDecimal(accountDetailedBalanceResponse.getCurrentBalance()));
		} else {
//			curAmt1.setAmt(new BigDecimal(0));
//			balType1.setBalTypeValues(BalTypeValues.Avail);
//			acctBal1.setCurAmt(curAmt1);
//			acctBal1.setBalType(balType1);
//			curAmt2.setAmt(new BigDecimal(0));
//			balType2.setBalTypeValues(BalTypeValues.Current);
//			status.setStatusCode(TransactionStatus.NO_BALANCE_RETRIEVED.getCode());
//			status.setStatusDesc(TransactionStatus.NO_BALANCE_RETRIEVED.getDescription());
			acctInqRs = createCasaBalanceInquiryResponse(TransactionStatus.NO_BALANCE_RETRIEVED.getCode(),
					TransactionStatus.NO_BALANCE_RETRIEVED.getDescription(), new BigDecimal("0"), new BigDecimal("0"));
		}
//		acctBal2.setCurAmt(curAmt2);
//		acctBal2.setBalType(balType2);
//		acctBalList.add(acctBal1);
//		acctBalList.add(acctBal2);
//		acctInfo.setAcctBal(acctBalList);
//		acctRec.setAcctInfo(acctInfo);
//		acctInqRs.setAcctRec(acctRec);
//		acctInqRs.setStatus(status);
		return acctInqRs;
	}

	private AcctInqRs createCasaBalanceInquiryResponse(String code, String description, BigDecimal avail, BigDecimal current) {
		AcctInqRs acctInqRs = new AcctInqRs();
		Status status = acctInqRs.getStatus();
		AcctRec acctRec = acctInqRs.getAcctRec();
		AcctInfo acctInfo = acctRec.getAcctInfo();
		List<AcctBal> acctBalList = acctInfo.getAcctBal();
		AcctBal acctBal1 = new AcctBal();
		AcctBal acctBal2 = new AcctBal();
		BalType balType1 = new BalType();
		BalType balType2 = new BalType();
		CurAmt curAmt1 = new CurAmt();
		CurAmt curAmt2 = new CurAmt();
		curAmt1.setAmt(avail);
		balType1.setBalTypeValues(BalTypeValues.Avail);
		acctBal1.setCurAmt(curAmt1);
		acctBal1.setBalType(balType1);
		curAmt2.setAmt(current);
		balType2.setBalTypeValues(BalTypeValues.Current);
		status.setStatusCode(code);
		status.setStatusDesc(description);
		acctBal2.setCurAmt(curAmt2);
		acctBal2.setBalType(balType2);
		acctBalList.add(acctBal1);
		acctBalList.add(acctBal2);
		acctInfo.setAcctBal(acctBalList);
		acctRec.setAcctInfo(acctInfo);
		acctInqRs.setAcctRec(acctRec);
		acctInqRs.setStatus(status);
		return acctInqRs;
	}

}
