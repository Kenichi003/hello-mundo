/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

import java.math.BigInteger;

public class TransInfo {
	
	private String dateStamp;
	
	private String timeStamp;
	
	private String sourceProductCode;
	
	private BigInteger sequenceNumber;
	
	private String servicingBranch;
	
	private String processingBranch;
	
	private String channelTransaction;

	public TransInfo() {
		super();
	}

	public String getServicingBranch() {
		return servicingBranch;
	}

	public void setServicingBranch(String servicingBranch) {
		this.servicingBranch = servicingBranch;
	}

	public String getProcessingBranch() {
		return processingBranch;
	}

	public void setProcessingBranch(String processingBranch) {
		this.processingBranch = processingBranch;
	}

	public String getDateStamp() {
		return dateStamp;
	}

	public void setDateStamp(String dateStamp) {
		this.dateStamp = dateStamp;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSourceProductCode() {
		return sourceProductCode;
	}

	public void setSourceProductCode(String sourceProductCode) {
		this.sourceProductCode = sourceProductCode;
	}

	public BigInteger getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(BigInteger sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getChannelTransaction() {
		return channelTransaction;
	}

	public void setChannelTransaction(String channelTransaction) {
		this.channelTransaction = channelTransaction;
	}
	
}
