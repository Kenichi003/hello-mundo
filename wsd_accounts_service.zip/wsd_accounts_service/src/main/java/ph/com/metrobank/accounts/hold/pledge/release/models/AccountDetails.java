/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

public class AccountDetails extends DataCommonModel{
	
	private String originatingBranchCode;
	
	private String currencyCode;
	
	private String branchCode;
	
	private String accountNumber;


	public AccountDetails() {
		super();
	}
	
	public String getOriginatingBranchCode() {
		return originatingBranchCode;
	}

	public void setOriginatingBranchCode(String originatingBranchCode) {
		this.originatingBranchCode = originatingBranchCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

 

 
}
