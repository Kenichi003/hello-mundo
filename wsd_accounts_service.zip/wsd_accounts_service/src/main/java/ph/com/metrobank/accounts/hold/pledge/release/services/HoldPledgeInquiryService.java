/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.services;

import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Objects;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.Credentials;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryEsbRequest;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryRequest;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryResponse;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.TransInfo;
import ph.com.metrobank.accounts.hold.pledge.release.utils.HoldPledgeReleaseHelper;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.model.TransactionStatus;
import ph.com.metrobank.accounts.services.LoggingService;

@Service
public class HoldPledgeInquiryService extends AbstractCommonService {
	@Autowired
	private LoggingService loggingService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private HoldPledgeReleaseHelper accountHoldHelper;

	@Value("${esb.inquire.hold.pledge.api}")
	private String esbHoldPledgeInquiryEndpoint;

	private static final String CURRENCY_CODE_PHP = "608";

	private static final int BRANCH_CODE_START_INDEX = 0;

	private static final int BRANCH_CODE_END_INDEX = 3;

	private static final int ACCOUNT_NUMBER_MASK = 4;

	public HoldPledgeInquiryResponse holdPledgeInquireBalance(String json, String uuid) {
		HoldPledgeInquiryResponse holdInquiryResponse = new HoldPledgeInquiryResponse();
		try {
			RequestCommonModel accountHoldRequestModel = decryptRequest(json, uuid);
			loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_HOLD_PLEDGE_INQUIRY, uuid,
					accountHoldRequestModel.getChannelId(), accountHoldRequestModel.toString());
			
			HoldPledgeInquiryRequest holdPledgeInquiryRequest = (HoldPledgeInquiryRequest) decryptData(
					accountHoldRequestModel, HoldPledgeInquiryRequest.class, uuid);
			holdPledgeInquiryRequest.setChannelId(accountHoldRequestModel.getChannelId());

			AccountsModel accountsModel = getAccountsModel(holdPledgeInquiryRequest.getToken(), holdPledgeInquiryRequest.getChannelId(), uuid);
			if (Objects.isNull(accountsModel)) {
				holdInquiryResponse = createInvalidAccountResponse();
				loggingService.log(
						this.getClass().toString()
								+ TraceLog.CASA_SERVICE_HOLD_PLEDGE_INQUIRY_ACCOUNT_NOT_FOUND_EXCEPTION,
						uuid, accountHoldRequestModel.getChannelId(), holdInquiryResponse.toString());
				return holdInquiryResponse;
			}

			HoldPledgeInquiryEsbRequest holdInquiryRequest = createHoldInquiryRequest(holdPledgeInquiryRequest,
					accountsModel, uuid);

			if (accountsModel.getExternalUserId().equals(holdPledgeInquiryRequest.getExternalUserId())) {
				holdInquiryResponse = createHoldInquiryResponse(holdInquiryRequest);
				loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_HOLD_PLEDGE_INQUIRY, uuid,
						accountHoldRequestModel.getChannelId(),
						"externalUserId: " + holdPledgeInquiryRequest.getExternalUserId() + "referenceNo: "
								+ accountsModel.getReferenceNo() + holdInquiryResponse.toString());

				return holdInquiryResponse;
			} else {
				holdInquiryResponse = createInvalidRequestResponse();
				loggingService.log(
						this.getClass().toString()
								+ TraceLog.CASA_SERVICE_HOLD_PLEDGE_INQUIRY_INVALID_EXTERNAL_USER_ID_EXCEPTION,
						uuid, accountHoldRequestModel.getChannelId(),
						"externalUserId: " + holdPledgeInquiryRequest.getExternalUserId() + "referenceNo: "
								+ accountsModel.getReferenceNo() + holdInquiryResponse.toString());

				return holdInquiryResponse;
			}
		} catch (RestClientException e) {
			loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_HOLD_PLEDGE_INQUIRY_EXCEPTION, uuid,
					"", json + e.getMessage());
			return createInternalServerErrorResponse();
		} catch (Exception e) {
			loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_HOLD_PLEDGE_INQUIRY_EXCEPTION, uuid,
					"", json + e.getMessage());
			return createInvalidRequestResponse();
		}
	}

	private HoldPledgeInquiryResponse createInvalidRequestResponse() {
		HoldPledgeInquiryResponse holdInquiryResponse = new HoldPledgeInquiryResponse();
		holdInquiryResponse.setTransactionCode(TransactionStatus.INVALID_REQUEST.getCode());
		holdInquiryResponse.setTransactionDesc(TransactionStatus.INVALID_REQUEST.getDescription());
		return holdInquiryResponse;
	}

	private HoldPledgeInquiryResponse createInvalidAccountResponse() {
		HoldPledgeInquiryResponse holdInquiryResponse = new HoldPledgeInquiryResponse();
		holdInquiryResponse.setTransactionCode(TransactionStatus.INVALID_ACCOUNT.getCode());
		holdInquiryResponse.setTransactionDesc(TransactionStatus.INVALID_ACCOUNT.getDescription());
		return holdInquiryResponse;
	}

	private HoldPledgeInquiryResponse createInternalServerErrorResponse() {
		HoldPledgeInquiryResponse holdInquiryResponse = new HoldPledgeInquiryResponse();
		holdInquiryResponse.setTransactionCode(TransactionStatus.INTERNAL_SERVER_ERROR.getCode());
		holdInquiryResponse.setTransactionDesc(TransactionStatus.INTERNAL_SERVER_ERROR.getDescription());
		return holdInquiryResponse;
	}

	private HoldPledgeInquiryEsbRequest createHoldInquiryRequest(HoldPledgeInquiryRequest holdPledgeInquiryRequest,
			AccountsModel accountsModel, String uuid) throws Exception {
		HoldPledgeInquiryEsbRequest holdInquiryEsbRequest = new HoldPledgeInquiryEsbRequest();

		String accountNo = accountsModel.getAccountNo().substring(BRANCH_CODE_END_INDEX);
		String branchCode = accountsModel.getAccountNo().substring(BRANCH_CODE_START_INDEX, BRANCH_CODE_END_INDEX);

		GregorianCalendar gc = GregorianCalendar.from(ZonedDateTime.now());
		XMLGregorianCalendar dateStamp = HoldPledgeReleaseHelper.getDateStamp(gc.get(Calendar.YEAR),
				gc.get(Calendar.MONTH) + 1, gc.get(Calendar.DAY_OF_MONTH));
		XMLGregorianCalendar timeStamp = HoldPledgeReleaseHelper.getTimeStamp(gc.get(Calendar.HOUR_OF_DAY),
				gc.get(Calendar.MINUTE), gc.get(Calendar.SECOND));

		TransInfo transInfo = HoldPledgeReleaseHelper.createTransInfo(accountsModel.getAccountNo(), dateStamp,
				timeStamp);

		Credentials credentials = accountHoldHelper.createCredentials(uuid, dateStamp, timeStamp);

		holdInquiryEsbRequest.setOriginatingBranchCode(branchCode);
		holdInquiryEsbRequest.setCurrencyCode(CURRENCY_CODE_PHP);
		holdInquiryEsbRequest.setBranchCode(branchCode);
		holdInquiryEsbRequest.setAccountNumber(accountNo);
		holdInquiryEsbRequest.setSearchString(holdPledgeInquiryRequest.getSearchString());
		if (StringUtils.isEmpty(StringUtils.trim(holdPledgeInquiryRequest.getSearchDescription()))) {
			holdInquiryEsbRequest.setSearchDescription(null); 
		} else {
			holdInquiryEsbRequest.setSearchDescription(holdPledgeInquiryRequest.getSearchDescription());
		}
		if (StringUtils.isEmpty(StringUtils.trim(holdPledgeInquiryRequest.getKeyOfLastRecord()))) {
			holdInquiryEsbRequest.setKeyOfLastRecord(null); 
		} else {
			holdInquiryEsbRequest.setKeyOfLastRecord(holdPledgeInquiryRequest.getKeyOfLastRecord());
		}
		holdInquiryEsbRequest.setTransactionInformation(transInfo);
		holdInquiryEsbRequest.setCredentials(credentials);

		return holdInquiryEsbRequest;
	}

	private HoldPledgeInquiryResponse createHoldInquiryResponse(HoldPledgeInquiryEsbRequest request) {
		HoldPledgeInquiryResponse holdInquiryResponse = new HoldPledgeInquiryResponse();
		HoldPledgeInquiryResponse response = holdPledgeInquiry(request);

		if (response.getWsStatus().getTransactionStatus() > 0) {
			holdInquiryResponse.setTransactionCode(TransactionStatus.NO_RECORD_FOUND.getCode());
			holdInquiryResponse.setTransactionDesc(TransactionStatus.NO_RECORD_FOUND.getDescription());
			holdInquiryResponse.setWsStatus(response.getWsStatus());
		} else {
			String accountNumber = request.getAccountNumber().toString();
			response.setTransactionCode(TransactionStatus.SUCCESS.getCode());
			response.setTransactionDesc(TransactionStatus.SUCCESS.getDescription());
			response.setMaskedAccountNumber(accountNumber.substring(accountNumber.length() - ACCOUNT_NUMBER_MASK));
			holdInquiryResponse = response;
		}

		return holdInquiryResponse;
	}

	private HoldPledgeInquiryResponse holdPledgeInquiry(HoldPledgeInquiryEsbRequest request) {
		try {
			HttpEntity<HoldPledgeInquiryEsbRequest> requestEntity = new HttpEntity<>(request);
			ResponseEntity<HoldPledgeInquiryResponse> responseEntity = restTemplate.exchange(
					esbHoldPledgeInquiryEndpoint, HttpMethod.POST, requestEntity, HoldPledgeInquiryResponse.class);
			return responseEntity.getBody();
		} catch (RestClientException exc) {
			throw new RestClientException(
					"RestClientException occurred at AccountHoldService.holdPledgeInquireBalance()" + exc.getMessage());
		}
	}
}
