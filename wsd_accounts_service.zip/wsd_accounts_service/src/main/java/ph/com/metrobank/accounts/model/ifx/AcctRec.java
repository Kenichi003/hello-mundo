/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model.ifx;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AcctRec {

	@JsonProperty("AcctInfo")
	private AcctInfo acctInfo;

	public AcctInfo getAcctInfo() {
		return Objects.nonNull(acctInfo) ? acctInfo : new AcctInfo();
	}

	public void setAcctInfo(AcctInfo acctInfo) {
		this.acctInfo = acctInfo;
	}

}
