/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.utils;

import java.math.BigInteger;
import java.security.SecureRandom;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import ph.com.metrobank.accounts.hold.pledge.release.models.AccountDetails;
import ph.com.metrobank.accounts.hold.pledge.release.models.Credentials;
import ph.com.metrobank.accounts.hold.pledge.release.models.TransInfo;
import ph.com.metrobank.accounts.services.EncryptionService;

@Component
public class HoldPledgeReleaseHelper {

	@Autowired
	private Environment env;
	
	@Autowired
	private EncryptionService encSvc;
	
	private static final int BRANCH_CODE_START_INDEX = 0;
	
	private static final int BRANCH_CODE_END_INDEX = 3;
	
	private static final String CIF = "CIF";
	
	private static final int LIMIT = 900_000;
	
	private static final long BASE = 100_000L;
	
	private static final String OSB_KEY = "osb.key";
	
	private static final String OSB_SYSTEM_ID = "osb.systemid";
	
	public static AccountDetails createAccountDetails(String accountNo, String currencyCode) {
		AccountDetails accountDetails = new AccountDetails();
		String branchCode = accountNo.substring(BRANCH_CODE_START_INDEX, BRANCH_CODE_END_INDEX);
		
		accountDetails.setBranchCode(branchCode);
		accountDetails.setCurrencyCode(currencyCode);
		accountDetails.setOriginatingBranchCode(branchCode);
		accountDetails.setAccountNumber(accountNo.substring(BRANCH_CODE_END_INDEX));

		return accountDetails;
	}
	
	public static XMLGregorianCalendar getDateStamp(int year, int month, int day) throws Exception {
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(year, month, day,
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
	}

	public static XMLGregorianCalendar getTimeStamp(int hour, int minute, int second) throws Exception {
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(DatatypeConstants.FIELD_UNDEFINED,
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED, hour, minute, second,
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
	}
	
	public static TransInfo createTransInfo(String accountNo, XMLGregorianCalendar dateStamp,
			XMLGregorianCalendar timeStamp) {

		TransInfo transactionInformation = new TransInfo();
		transactionInformation.setDateStamp(dateStamp.toString());
		transactionInformation.setTimeStamp(timeStamp.toString());
		transactionInformation.setSourceProductCode(CIF);
		transactionInformation.setSequenceNumber(createSequenceNumber());
		transactionInformation.setServicingBranch(accountNo.substring(BRANCH_CODE_START_INDEX, BRANCH_CODE_END_INDEX));
		transactionInformation.setProcessingBranch(accountNo.substring(BRANCH_CODE_START_INDEX, BRANCH_CODE_END_INDEX));
		
		return transactionInformation;
	}
	
	public Credentials createCredentials(String uuid, XMLGregorianCalendar dateStamp, XMLGregorianCalendar timeStamp)
			throws Exception {
		String key = env.getProperty(OSB_KEY);
		String systemID = env.getProperty(OSB_SYSTEM_ID);

		String password = encSvc.sha256(uuid, dateStamp + key + timeStamp);
		Credentials credentials = new Credentials();
		credentials.setSystemID(systemID);
		credentials.setPassword(password);
		
		return credentials;
	}
	

	private static BigInteger createSequenceNumber() {
		return BigInteger.valueOf(new SecureRandom().nextInt(LIMIT) + BASE);
	}
}
