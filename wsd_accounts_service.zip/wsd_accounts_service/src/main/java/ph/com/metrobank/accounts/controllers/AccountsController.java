/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.controllers;

import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;

import javax.xml.datatype.DatatypeConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.pgw.osb.account.status.detail.AccountDetailsInquiryResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeResponse;
import ph.com.metrobank.accounts.hold.pledge.release.models.HoldPledgeInquiryResponse;
import ph.com.metrobank.accounts.hold.pledge.release.services.AddHoldPledgeService;
import ph.com.metrobank.accounts.hold.pledge.release.services.HoldPledgeInquiryService;
import ph.com.metrobank.accounts.hold.pledge.release.services.ReleaseHoldPledgeService;
import ph.com.metrobank.accounts.model.CasaResponse;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.model.ifx.AcctInqRs;
import ph.com.metrobank.accounts.services.AccountStatusService;
import ph.com.metrobank.accounts.services.GenerateUUIDService;
import ph.com.metrobank.accounts.services.LoggingService;
import ph.com.metrobank.accounts.services.OrchestrationService;

@RestController
@RequestMapping("${endpoint.url}")
@Api(value = "CASA Controller")
public class AccountsController {

	@Autowired
	private LoggingService loggingService;

	@Autowired
	private GenerateUUIDService generateUUIDService;

	@Autowired
	private OrchestrationService orchestrationService;
	
	@Autowired
	private AccountStatusService accountStatusService;
	
	@Autowired
	private HoldPledgeInquiryService holdPledgeInquiryService;
	
	@Autowired
	private AddHoldPledgeService addHoldPledgeService;
	
	@Autowired
	private ReleaseHoldPledgeService releaseHoldPledgeService;
	
	@Value("${directlink.account.inquiry}")
	private String accountLinkedInquiryEndPoint;
	
	@Value("${directlink.configuration.settings}")
	private String dlConfigurationEndPoint;

	@RequestMapping(value = "/getCasa/{owner}", method = { RequestMethod.GET })
	@ApiOperation(value = "Retrieves CASA Listing and Account Balance")
	public ResponseEntity<List<CasaResponse>> getCasa(@PathVariable String owner) {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.MBL_CONTROLLER_GET_CASA, uuid, "", owner);
		List<CasaResponse> casaList = orchestrationService.getCasa(owner, uuid);
		return new ResponseEntity<>(casaList, HttpStatus.OK);
	}

	@RequestMapping(value = "/getAccountNo/{id}", method = { RequestMethod.GET })
	@ApiOperation(value = "Retrieves Account Number by Account ID")
	public ResponseEntity<String> getAccountNumber(@PathVariable String id) {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.MBL_CONTROLLER_GET_ACCOUNTNO, uuid, "", id);
		String accountNo = orchestrationService.getAccountNo(id);
		return new ResponseEntity<>(accountNo, HttpStatus.OK);
	}

	@RequestMapping(value = "/getAccountNickname/{accountNo}", method = { RequestMethod.GET })
	@ApiOperation(value = "Retrieves Account Nickname by Account No.")
	public ResponseEntity<String> getAccountNickname(@PathVariable String accountNo) {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.MBL_CONTROLLER_GET_ACCOUNT_NICKNAME, uuid, "",
				accountNo);
		String accountNickname = orchestrationService.getAccountNickname(accountNo);
		return new ResponseEntity<>(accountNickname, HttpStatus.OK);
	}

	@RequestMapping(value = "/healthCheck", method = { RequestMethod.GET })
	@ApiOperation(value = "Health Check")
	public @ResponseBody ResponseEntity<String> healthCheck() {
		return new ResponseEntity<>("ACCOUNTS API OK. accountLinkedInquiryEndPoint: " 
	+ accountLinkedInquiryEndPoint + 
	" dlConfigurationEndPoint: " + dlConfigurationEndPoint, HttpStatus.OK);
	}

	// TODO: REMOVE LATER
	@RequestMapping(value = "/inquiry/acctBalance/{accountNo}", method = { RequestMethod.GET })
	@ApiOperation(value = "Retrieves Account Balance by Account Number")
	public ResponseEntity<AcctInqRs> inquireCasa(@PathVariable String accountNo) {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.MBL_CONTROLLER_GET_ACCOUNT_BALANCE, uuid, "",
				accountNo);
		AcctInqRs acctInqRs = orchestrationService.inquireCasa(accountNo, uuid);
		return new ResponseEntity<>(acctInqRs, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/inquiry/acctStatus/{accountNo}/{currencyCode}", method = { RequestMethod.GET })
	@ApiOperation(value = "Retrieves Account Active status by Account Number and currency code")
	public ResponseEntity<Optional<AccountDetailsInquiryResponse>> inquireAccountStatus(@PathVariable String accountNo,
			@PathVariable String currencyCode) throws NoSuchAlgorithmException, DatatypeConfigurationException {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.MBL_CONTROLLER_ACCOUNT_STATUS_SERVICE, uuid, "",
				accountNo);
		Optional<AccountDetailsInquiryResponse> response = accountStatusService.getAccountStatus(accountNo,
				currencyCode, uuid);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	// TODO START: EXPOSE ON 3SCALE
	
	@RequestMapping(value = "/inquiry/holdPledgeInquiry", method = { RequestMethod.GET })
	@ApiOperation(value = "Get Hold and Pledge Info")
	public ResponseEntity<HoldPledgeInquiryResponse> getHoldPledge(@RequestBody String jsonMessage) {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.CASA_GET_PLEDGE_INQUIRY_CONTROLLER, uuid, jsonMessage,
				"");
		HoldPledgeInquiryResponse holdInquiryResponse = holdPledgeInquiryService.holdPledgeInquireBalance(jsonMessage,
				uuid);
		return new ResponseEntity<>(holdInquiryResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/addHoldPledge", method = { RequestMethod.POST })
	@ApiOperation(value = "REST API for Add Hold or Pledge")
	public ResponseEntity<AddReleaseHoldPledgeResponse> addHoldPledgeService(@RequestBody String jsonMessage)
			throws Exception {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.CASA_RELEASE_HOLD_PLEDGE_CONTROLLER, uuid, jsonMessage,
				"");
		AddReleaseHoldPledgeResponse addReleaseHoldPledgeESBResponse = addHoldPledgeService.addHoldPledge(jsonMessage,
				uuid);
		return new ResponseEntity<>(addReleaseHoldPledgeESBResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/releaseHoldPledge", method = { RequestMethod.POST })
	@ApiOperation(value = "REST API for Releasing Hold and Pledge")
	public ResponseEntity<AddReleaseHoldPledgeResponse> releaseHoldPledgeService(@RequestBody String jsonMessage)
			throws Exception {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.CASA_RELEASE_HOLD_PLEDGE_CONTROLLER, uuid, "", "");
		AddReleaseHoldPledgeResponse addReleaseHoldPledgeESBResponse = releaseHoldPledgeService
				.releaseHoldPledge(jsonMessage, uuid);
		return new ResponseEntity<>(addReleaseHoldPledgeESBResponse, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/inquiry/acctBalance", method = { RequestMethod.GET })
	@ApiOperation(value = "Get Account Balance")
	public @ResponseBody ResponseEntity<AcctInqRs> getAcctBalance(@RequestBody String jsonMessage) {
		String uuid = generateUUIDService.generateUUID();
		loggingService.log(this.getClass().toString() + TraceLog.MBL_CONTROLLER_GET_ACCOUNT_BALANCE, uuid, "",
				jsonMessage);
		AcctInqRs acctInqRs = orchestrationService.orchestrateCasaBalanceInquiry(jsonMessage, uuid);
		return new ResponseEntity<>(acctInqRs, HttpStatus.OK);
	}

}
