/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model.ifx;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AcctInqRs {

	@JsonProperty("AcctRec")
	private AcctRec acctRec;

	@JsonProperty("Status")
	private Status status;

	public AcctRec getAcctRec() {
		return Objects.nonNull(acctRec) ? acctRec : new AcctRec();
	}

	public void setAcctRec(AcctRec acctRec) {
		this.acctRec = acctRec;
	}

	public Status getStatus() {
		return Objects.nonNull(status) ? status : new Status();
	}

	public void setStatus(Status status) {
		this.status = status;
	}

}
