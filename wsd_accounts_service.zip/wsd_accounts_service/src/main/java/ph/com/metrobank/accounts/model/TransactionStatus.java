/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model;

import java.util.LinkedHashMap;
import java.util.Map;

public enum TransactionStatus {

	SUCCESS("000", TransactionDesc.SUCCESS), FAILED("001", TransactionDesc.FAILED),
	NO_BALANCE_RETRIEVED("013", TransactionDesc.NO_BALANCE_RETRIEVED),
	OTHERS("005", TransactionDesc.INTERNAL_SERVER_ERROR), INVALID_REQUEST("002", TransactionDesc.INVALID_REQUEST),
	INVALID_ACCOUNT("014", TransactionDesc.INVALID_ACCOUNT),
	ACCOUNT_ALREADY_UNLINKED("015", TransactionDesc.ACCOUNT_ALREADY_UNLINKED),
	INTERNAL_SERVER_ERROR("005", TransactionDesc.INTERNAL_SERVER_ERROR),
	NO_RECORD_FOUND("010", TransactionDesc.NO_RECORD_FOUND);

	private final String code;
	private final String description;
	private static Map<String, String> mapStatus = new LinkedHashMap<>();

	static {
		for (TransactionStatus status : TransactionStatus.values()) {
			mapStatus.put(status.getCode(), status.getDescription());
		}
	}

	TransactionStatus(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	public static String getDescription(String code) {
		return (null == mapStatus.get(code)) ? OTHERS.getDescription() : mapStatus.get(code);
	}

}
