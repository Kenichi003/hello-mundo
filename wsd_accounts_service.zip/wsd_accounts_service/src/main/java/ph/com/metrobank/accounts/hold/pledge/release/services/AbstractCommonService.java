/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.ConfigurationModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.services.BuildModelService;
import ph.com.metrobank.accounts.services.EncryptionService;

public abstract class AbstractCommonService {

	@Autowired
    private EncryptionService encryptionService;
	
	@Autowired
	private BuildModelService buildModelService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${directlink.account.inquiry}")
	private String getAccountByTokenAndMerchantIdEndpoint;
	
	@Value("${directlink.configuration.settings}")
	private String getConfigurationSettingsEndpoint;
	
	public <T extends RequestCommonModel> RequestCommonModel decryptRequest(String json, String uuid) throws Exception {
		RequestCommonModel encryptedRequestModel = encryptionService.buildSignedModel(json, uuid,
				RequestCommonModel.class);
		ConfigurationModel settings = getSettings(encryptedRequestModel.getChannelId(), uuid);
		encryptedRequestModel = encryptionService.verifyModel(encryptedRequestModel, settings, uuid);
		return encryptedRequestModel;
	}
		
	public Object decryptData(RequestCommonModel requestCommonModel, Class<?> clazz, String uuid)
			throws Exception {
		return buildModelService.jsonToObject(requestCommonModel.getData(), clazz,
				uuid);
	}
	
	public AccountsModel getAccountsModel(String token, String merchantId, String uuid) {
		String url = String.format(getAccountByTokenAndMerchantIdEndpoint, token, merchantId);
		return restTemplate.getForObject(url, AccountsModel.class);
	}
	
	private ConfigurationModel getSettings(String channelId, String uuid) {
		String url = String.format(getConfigurationSettingsEndpoint, channelId);
		return restTemplate.getForObject(url, ConfigurationModel.class);
	}
}
