/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.accounts.model.AccountAlias;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.repository.EaDocumentRepository;
import ph.com.metrobank.accounts.util.JsonUtil;

@Service
public class EADocumentService {

	@Autowired
	private LoggingService loggingService;

	@Autowired
	private EaDocumentRepository eaDocumentRepository;

	public String getAccountAlias(String documentId) {
		loggingService.log(this.getClass().toString() + TraceLog.CASA_GET_ACCOUNT_ALIAS, "", "", documentId);
		String jsonData = eaDocumentRepository.getJsonDataByDocumentId(documentId);
		try {
			AccountAlias accountAlias = JsonUtil.mapFromJson(jsonData, AccountAlias.class);
			return accountAlias.getAccountName().getValue();
		} catch (Exception e) {
			return "";
		}
	}
}
