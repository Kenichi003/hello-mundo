/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AddReleaseHoldPledgeResponse extends ResponseCommonModel {

    private String currentBalance;
    private String availableBalance;
    private String holdPledgeType;
    private String amount;
    private String description;
    private TransInfo transactionInformation;
    private WsStatus wsStatus;
    
	public AddReleaseHoldPledgeResponse() {
		super();
	}

	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

	public String getHoldPledgeType() {
		return holdPledgeType;
	}

	public void setHoldPledgeType(String holdPledgeType) {
		this.holdPledgeType = holdPledgeType;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public TransInfo getTransactionInformation() {
		return transactionInformation;
	}

	public void setTransactionInformation(TransInfo transactionInformation) {
		this.transactionInformation = transactionInformation;
	}

	public WsStatus getWsStatus() {
		return wsStatus;
	}

	public void setWsStatus(WsStatus wsStatus) {
		this.wsStatus = wsStatus;
	}
    
}
