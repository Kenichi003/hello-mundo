/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class HoldPledgeInquiryResponse extends ResponseCommonModel{
 
	
	private String maskedAccountNumber;
	
	private BigDecimal currentBalance;
	
	private BigDecimal availableBalance;
	
	private BigDecimal totalHoldBalance;
	
	private BigDecimal totalPledgeBalance;
	
	private BigDecimal totalFloatBalance;
	
	private String fullHoldIndicator;
	
	private String fullPledgeIndicator;
	
	private List<HoldPledgeDetails> holdPledgeDetails;
	
	private String keyOfLastRecord;
	
	private String lastPageIndicator;
	
	private WsStatus wsStatus;

	public HoldPledgeInquiryResponse() {
		super();
	}

	public String getMaskedAccountNumber() {
		return maskedAccountNumber;
	}

	public void setMaskedAccountNumber(String maskedAccountNumber) {
		this.maskedAccountNumber = maskedAccountNumber;
	}

	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	public BigDecimal getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(BigDecimal availableBalance) {
		this.availableBalance = availableBalance;
	}

	public BigDecimal getTotalHoldBalance() {
		return totalHoldBalance;
	}

	public void setTotalHoldBalance(BigDecimal totalHoldBalance) {
		this.totalHoldBalance = totalHoldBalance;
	}

	public BigDecimal getTotalPledgeBalance() {
		return totalPledgeBalance;
	}

	public void setTotalPledgeBalance(BigDecimal totalPledgeBalance) {
		this.totalPledgeBalance = totalPledgeBalance;
	}

	public BigDecimal getTotalFloatBalance() {
		return totalFloatBalance;
	}

	public void setTotalFloatBalance(BigDecimal totalFloatBalance) {
		this.totalFloatBalance = totalFloatBalance;
	}

	public String getFullHoldIndicator() {
		return fullHoldIndicator;
	}

	public void setFullHoldIndicator(String fullHoldIndicator) {
		this.fullHoldIndicator = fullHoldIndicator;
	}

	public String getFullPledgeIndicator() {
		return fullPledgeIndicator;
	}

	public void setFullPledgeIndicator(String fullPledgeIndicator) {
		this.fullPledgeIndicator = fullPledgeIndicator;
	}

	public List<HoldPledgeDetails> getHoldPledgeDetails() {
		return holdPledgeDetails;
	}

	public void setHoldPledgeDetails(List<HoldPledgeDetails> holdPledgeDetails) {
		this.holdPledgeDetails = holdPledgeDetails;
	}

	public String getKeyOfLastRecord() {
		return keyOfLastRecord;
	}

	public void setKeyOfLastRecord(String keyOfLastRecord) {
		this.keyOfLastRecord = keyOfLastRecord;
	}

	public String getLastPageIndicator() {
		return lastPageIndicator;
	}

	public void setLastPageIndicator(String lastPageIndicator) {
		this.lastPageIndicator = lastPageIndicator;
	}

	public WsStatus getWsStatus() {
		return wsStatus;
	}

	public void setWsStatus(WsStatus wsStatus) {
		this.wsStatus = wsStatus;
	}
	
}
