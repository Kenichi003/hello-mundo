package ph.com.metrobank.accounts.hold.pledge.release.enums;

public enum TransactionCodeEnum {

    RELEASE("30"), ADD_HOLD("34"), ADD_PLEDGE("35"), HOLD("H"), PLEDGE("P");
    /**
     * 
     * @param type
     */
    private TransactionCodeEnum(String type) {
	this.type = type;
    }

    private String type;

    /**
     * 
     * @return
     */
    public String getType() {
	return type;
    }
}
