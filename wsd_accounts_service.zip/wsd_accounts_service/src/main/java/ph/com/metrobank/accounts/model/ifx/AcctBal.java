/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model.ifx;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AcctBal {

	@JsonProperty("CurAmt")
	private CurAmt curAmt;

	@JsonProperty("BalType")
	private BalType balType;

	public CurAmt getCurAmt() {
		return Objects.nonNull(curAmt) ? curAmt : new CurAmt();
	}

	public void setCurAmt(CurAmt curAmt) {
		this.curAmt = curAmt;
	}

	public BalType getBalType() {
		return Objects.nonNull(balType) ? balType : new BalType();
	}

	public void setBalType(BalType balType) {
		this.balType = balType;
	}

}
