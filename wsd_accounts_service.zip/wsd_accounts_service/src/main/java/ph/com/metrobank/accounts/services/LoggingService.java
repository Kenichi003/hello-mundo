/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LoggingService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingService.class);

	public String log(String component, String uuid, String accountNo, String info) {
		Map<String, String> map = new HashMap<>();
		if (!"".equals(component)) {
			map.put("COMPONENT", component);
		}
		if (!"".equals(uuid)) {
			map.put("UUID", uuid);
		}
		if (!"".equals(accountNo)) {
			map.put("ACCOUNT NUMBER", accountNo);
		}
		if (!"".equals(info)) {
			map.put("INFO", info);
		}
		String stringMap = map.toString();
		LOGGER.info(stringMap);
		return stringMap;
	}

}
