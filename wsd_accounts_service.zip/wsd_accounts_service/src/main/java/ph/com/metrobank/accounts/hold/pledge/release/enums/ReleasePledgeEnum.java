package ph.com.metrobank.accounts.hold.pledge.release.enums;

public enum ReleasePledgeEnum {

    ALL_FUNDS("1"), NOT_ALL_FUNDS("0");
    /**
     * 
     * @param type
     */
    private ReleasePledgeEnum(String type) {
	this.type = type;
    }

    private String type;

    /**
     * 
     * @return
     */
    public String getType() {
	return type;
    }
}
