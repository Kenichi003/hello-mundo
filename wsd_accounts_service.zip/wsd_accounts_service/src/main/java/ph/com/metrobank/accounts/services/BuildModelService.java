/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import ph.com.metrobank.accounts.model.TraceLog;

@Service
public class BuildModelService {
	@Autowired
	private LoggingService loggingService;

	@Autowired
	private ObjectMapper mapper;

	public Object jsonToObject(String json, Class<?> clazz, String uuid) throws IOException {
		loggingService.log(this.getClass().toString() + TraceLog.CASA_SERVICE_JSON_VALIDATION, uuid, "", json);
		return mapper.readValue(json, clazz);
	}
}
