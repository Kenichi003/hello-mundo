/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.accounts.model.CasaModel;

public interface CasaRepository extends CrudRepository<CasaModel, String> {

	@Query("SELECT c FROM CasaModel c WHERE c.owner = :owner AND c.currencyCode =:currencyCode "
			+ "AND c.productType IN :productType")
	List<CasaModel> getCasaModelByOwner(@Param("owner") String owner, @Param("currencyCode") String currencyCode,
			@Param("productType") List<String> productType);

	@Query("SELECT c.accountNo FROM CasaModel c WHERE c.id = :id")
	String getAccountNo(@Param("id") String id);

	@Query("SELECT c FROM CasaModel c WHERE c.accountNo = :accountNo")
	CasaModel getCasaModelByAccountNo(@Param("accountNo") String accountNo);

}
