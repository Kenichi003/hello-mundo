/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model;

public class ErrorMessage {

	public static final String MESSAGE_FORMAT_ERROR = "MESSAGE_FORMAT_ERROR ";
	public static final String PRINCIPAL_AND_OWNER_MISMATCH = "PRINCIPAL_AND_OWNER_MISMATCH ";
	public static final String UNAUTHORIZED = "UNAUTHORIZED: ";
	public static final String INVALID_SIGNATURE = "INVALID_SIGNATURE ";
	public static final String EXTERNAL_USER_ID_MISMATCH = "EXTERNAL_USER_ID_MISMATCH ";
	
	public static final String CASA_ACCOUNT_BY_TOKEN_NOT_FOUND = "ACCOUNT BY TOKEN NOT FOUND.";

	ErrorMessage() {
		throw new IllegalStateException("Utility class");
	}
}
