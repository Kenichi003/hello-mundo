/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email emmanuel.ombrosa@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import ph.com.metrobank.accounts.hold.pledge.release.enums.TransactionCodeEnum;
import ph.com.metrobank.accounts.hold.pledge.release.models.AccountsModel;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeDataRequest;
import ph.com.metrobank.accounts.hold.pledge.release.models.AddReleaseHoldPledgeResponse;
import ph.com.metrobank.accounts.hold.pledge.release.models.RequestCommonModel;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.model.TransactionStatus;
import ph.com.metrobank.accounts.services.LoggingService;

/**
 * This service handles Releasing of Hold and Pledge transaction
 * 
 * @author 34785
 *
 */
@Service
public class ReleaseHoldPledgeService extends AbstractAddReleaseHoldPledge {

	@Autowired
	private LoggingService loggingService;

	@Value("${esb.release.hold.pledge.api}")
	private String releaseHoldPledgeEndpoint;

	public AddReleaseHoldPledgeResponse releaseHoldPledge(String json, String uuid) {

		AddReleaseHoldPledgeResponse addReleaseHoldPledgeResponse = new AddReleaseHoldPledgeResponse();

		final String transactionType = TransactionCodeEnum.RELEASE.getType();

		try {

			RequestCommonModel decryptedAddReleaseHoldPledge = decryptRequest(json, uuid);

			AddReleaseHoldPledgeDataRequest decryptedAddReleaseHoldPledgeData = (AddReleaseHoldPledgeDataRequest) decryptData(
					decryptedAddReleaseHoldPledge, AddReleaseHoldPledgeDataRequest.class, uuid);
			
			AccountsModel accountsModel = getAccountsModel(decryptedAddReleaseHoldPledgeData.getToken(),
					decryptedAddReleaseHoldPledge.getChannelId(), uuid);
			// Validate Account by Token
			if (!isValidAccountModel(accountsModel, addReleaseHoldPledgeResponse, decryptedAddReleaseHoldPledgeData,
					uuid, releaseHoldPledgeEndpoint)) {
				return addReleaseHoldPledgeResponse;
			}
			// Validate External user id
			if (!isValidExternalUserId(accountsModel, addReleaseHoldPledgeResponse, decryptedAddReleaseHoldPledge,
					decryptedAddReleaseHoldPledgeData, uuid, releaseHoldPledgeEndpoint)) {
				return addReleaseHoldPledgeResponse;
			}
			// Create ESB Request
			AddReleaseHoldPledgeDataRequest addReleaseHoldPledgeESBRequest = createAddReleaseHoldPledgeESBRequest(
					decryptedAddReleaseHoldPledgeData, accountsModel.getAccountNo(), transactionType, uuid);
			// Call ESB Rest API
			addReleaseHoldPledgeResponse = callAddReleaseHoldPledgeEsbApi(addReleaseHoldPledgeESBRequest, uuid,
					releaseHoldPledgeEndpoint, transactionType);

			loggingService.log(this.getClass().toString() + TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE, uuid,
					"ENDPOINT: " + releaseHoldPledgeEndpoint + "TRANS TYPE: " + transactionType,
					"externalUserId: " + accountsModel.getExternalUserId() + "referenceNo: "
							+ accountsModel.getReferenceNo() + addReleaseHoldPledgeESBRequest.toString());
		} catch (RestClientException r) {
		    loggingService.log(this.getClass().toString() + TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE_EXCEPTION,
			    uuid, " ENDPOINT: " + releaseHoldPledgeEndpoint + " TRANS TYPE: " + transactionType,
			    json + r.getMessage());
		    addReleaseHoldPledgeResponse.setTransactionCode(TransactionStatus.INTERNAL_SERVER_ERROR.getCode());
		    addReleaseHoldPledgeResponse
			    .setTransactionDesc(TransactionStatus.INTERNAL_SERVER_ERROR.getDescription());
		    return addReleaseHoldPledgeResponse;
		} catch (Exception e) {
			loggingService.log(this.getClass().toString() + TraceLog.CASA_ADD_RELEASE_HOLD_PLEDGE_SERVICE_EXCEPTION,
					uuid, " ENDPOINT: " + releaseHoldPledgeEndpoint + " TRANS TYPE: " + transactionType,
					json + e.getMessage());
			addReleaseHoldPledgeResponse.setTransactionCode(TransactionStatus.INVALID_REQUEST.getCode());
			addReleaseHoldPledgeResponse.setTransactionDesc(TransactionStatus.INVALID_REQUEST.getDescription());
			return addReleaseHoldPledgeResponse;
		}
		return addReleaseHoldPledgeResponse;
	}

}
