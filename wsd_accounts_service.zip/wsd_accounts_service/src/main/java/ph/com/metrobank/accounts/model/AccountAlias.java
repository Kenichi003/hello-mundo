/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountAlias {

	private String id;
	private Account accountName;

	public AccountAlias() {
		super();
	}

	@JsonCreator
	public AccountAlias(@JsonProperty("id") String id, @JsonProperty("accountName") Account accountName) {
		this.id = id;
		this.accountName = accountName;
	}

	public String getId() {
		return id;
	}

	public Account getAccountName() {
		return Objects.nonNull(accountName) ? accountName : new Account();
	}

}
