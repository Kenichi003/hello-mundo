/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class HoldPledgeInquiryEsbRequest extends AccountDetails {


	
	private String searchDescription;
	
	private String searchString;
	
	private String keyOfLastRecord;
	
	private TransInfo transactionInformation;
	
	private Credentials credentials;

	public HoldPledgeInquiryEsbRequest() {
		super();
	}

	
	public String getSearchDescription() {
		return searchDescription;
	}

	public void setSearchDescription(String searchDescription) {
		this.searchDescription = searchDescription;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public String getKeyOfLastRecord() {
		return keyOfLastRecord;
	}

	public void setKeyOfLastRecord(String keyOfLastRecord) {
		this.keyOfLastRecord = keyOfLastRecord;
	}

	public TransInfo getTransactionInformation() {
		return transactionInformation;
	}

	public void setTransactionInformation(TransInfo transactionInformation) {
		this.transactionInformation = transactionInformation;
	}

	public Credentials getCredentials() {
		return credentials;
	}

	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}
	
}
