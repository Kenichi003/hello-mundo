/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author t-jmcastro
 *  @date 2019-10-25
 *  @email jemuel.castro@metrobank.com.ph
 */
package ph.com.metrobank.accounts.hold.pledge.release.models;

public class WsStatus {

    private String soaResponseCode;
    private String errorMessage;
    private int transactionStatus;

    public String getSoaResponseCode() {
	return soaResponseCode;
    }

    public void setSoaResponseCode(String soaResponseCode) {
	this.soaResponseCode = soaResponseCode;
    }

    public String getErrorMessage() {
	return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
	this.errorMessage = errorMessage;
    }

    public int getTransactionStatus() {
	return transactionStatus;
    }

    public void setTransactionStatus(int transactionStatus) {
	this.transactionStatus = transactionStatus;
    }

}
