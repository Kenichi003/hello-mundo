/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.accounts.model.CasaModel;
import ph.com.metrobank.accounts.model.TraceLog;
import ph.com.metrobank.accounts.repository.CasaRepository;

@Service
public class CasaService {

	@Autowired
	private LoggingService loggingService;

	@Autowired
	private CasaRepository casaRepository;

	private static final String PESO_CURRENCY = "001";

	public List<CasaModel> getCasaModelByOwner(String owner, List<String> productTypes) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_GET_CASA, "", "", owner);
		return casaRepository.getCasaModelByOwner(owner, PESO_CURRENCY, productTypes);
	}

	public String getAccountNo(String id) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_GET_ACCOUNTNO, "", "", id);
		return casaRepository.getAccountNo(id);
	}

	public CasaModel getAccountNickname(String accountNo) {
		loggingService.log(this.getClass().toString() + TraceLog.MBL_SERVICE_GET_ACCOUNT_NICKNAME, "", "", accountNo);
		return casaRepository.getCasaModelByAccountNo(accountNo);
	}

}
