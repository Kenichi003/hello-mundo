/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email emmanuel.ombrose@metrobank.com.ph
 */
package ph.com.metrobank.accounts.services;

import java.math.BigInteger;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Optional;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.pgw.osb.account.status.detail.AccountDetails;
import com.pgw.osb.account.status.detail.AccountDetailsInquiryResponse;
import com.pgw.osb.account.status.detail.CASAInformationInquiryStatusDetails;
import com.pgw.osb.account.status.detail.CASAInformationInquiryStatusDetailsService;
import com.pgw.osb.account.status.detail.Credentials;
import com.pgw.osb.account.status.detail.ObjectFactory;
import com.pgw.osb.account.status.detail.TransInfo;

import ph.com.metrobank.accounts.model.TraceLog;

@Service
public class AccountStatusService {

	@Autowired
	private Environment env;

	@Autowired
	private EncryptionService encSvc;

	@Autowired
	private LoggingService loggingService;

	private static final String OSB_KEY = "osb.key";
	private static final String OSB_SYSTEM_ID = "osb.systemid";
	private static final String OSB_ACCOUNT_STATUS_ENDPOINT = "osb.account.status.endpoint";
	private static final String CHANNEL = "BS";
	private static final String SEQ = "777777";
	private static final int ZERO = 0;
	private static final int THREE = 3;
	private static final int THIRTEEN = 13;

	public Optional<AccountDetailsInquiryResponse> getAccountStatus(final String accountNo, final String currencyCode, final String uuid)
			throws DatatypeConfigurationException, NoSuchAlgorithmException {
		loggingService.log(TraceLog.ACCOUNT_STATUS_SERVICE, uuid, accountNo, "");
		String key = env.getProperty(OSB_KEY);
		String systemID = env.getProperty(OSB_SYSTEM_ID);
		ObjectFactory objectFactory = new ObjectFactory();

		AccountDetails accountDetailsTransform = objectFactory.createAccountDetails();
		accountDetailsTransform.setOriginatingBranchCode(accountNo.substring(ZERO, THREE));
		accountDetailsTransform.setCurrencyCode(new BigInteger(currencyCode));
		accountDetailsTransform.setBranchCode(accountNo.substring(ZERO, THREE));
		accountDetailsTransform.setAccountNumber(new BigInteger(accountNo.substring(THREE, THIRTEEN)));

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(new Date());
		XMLGregorianCalendar dateStamp = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc.get(Calendar.YEAR),
				gc.get(Calendar.MONTH) + 1, gc.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED,
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
				DatatypeConstants.FIELD_UNDEFINED);
		XMLGregorianCalendar timeStamp = DatatypeFactory.newInstance().newXMLGregorianCalendar(
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
				gc.get(Calendar.HOUR_OF_DAY), gc.get(Calendar.MINUTE), gc.get(Calendar.SECOND),
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);

		TransInfo transactionInformation = objectFactory.createTransInfo();
		transactionInformation.setDateStamp(dateStamp);
		transactionInformation.setTimeStamp(timeStamp);
		transactionInformation.setSequenceNumber(new BigInteger(SEQ));
		transactionInformation.setServicingBranch(accountNo.substring(ZERO, THREE));
		transactionInformation.setProcessingBranch(accountNo.substring(ZERO, THREE));
		transactionInformation.setChannelTransaction(CHANNEL);

		String password = encSvc.sha256(uuid, dateStamp + key + timeStamp);
		Credentials credentials = objectFactory.createCredentials();
		credentials.setSystemID(systemID);
		credentials.setPassword(password);

		try {
			loggingService.log(TraceLog.ACCOUNT_STATUS_SERVICE_REQUEST_PARAM, uuid, accountNo,
					"Account Number: " + accountNo + "Currency Code: " + currencyCode + " Date Stamp: "
							+ transactionInformation.getDateStamp() + " Time Stamp: "
							+ transactionInformation.getTimeStamp());
			AccountDetailsInquiryResponse response = createCASAInformationInquiryBalanceAndDetailsServiceStub()
					.getStatusDetails(accountDetailsTransform, transactionInformation, credentials);
			loggingService.log(TraceLog.ACCOUNT_STATUS_SERVICE, uuid, response.getAccountNumber(), "ESB RESPONSE: " + response.getWSS().getSOAResponseCode()
					+ response.getWSS().getErrorMessage() + response.getWSS().getTransactionStatus());
			return Optional.of(response);
		} catch (WebServiceException w) {
			loggingService.log(TraceLog.ACCOUNT_STATUS_SERVICE, uuid, accountNo, w.getMessage());
			throw new WebServiceException("Exception occurred at ESB getAccountStatus()" + w.getMessage());
		}
	}

	protected CASAInformationInquiryStatusDetails createCASAInformationInquiryBalanceAndDetailsServiceStub() {
		CASAInformationInquiryStatusDetails stub = createCASAInformationInquiryStatusDetailsService()
				.getCASAInformationInquiryStatusDetailsPort();
		BindingProvider bindingProvider = (BindingProvider) stub;
		bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
				env.getProperty(OSB_ACCOUNT_STATUS_ENDPOINT));
		return stub;
	}

	protected CASAInformationInquiryStatusDetailsService createCASAInformationInquiryStatusDetailsService() {
		URL baseURL = Thread.currentThread().getContextClassLoader()
				.getResource("wsdl/GetAccountStatusDetailsService.wsdl");
		QName casaInformationInquiryBalanceAndDetailsService = new QName(
				"http://ph.com.metrobank.CASAInformationInquiryStatusDetailsWS/", "CASAInformationInquiryStatusDetailsService");
		return new CASAInformationInquiryStatusDetailsService(baseURL,
				casaInformationInquiryBalanceAndDetailsService);
	}
}
