# wsd_accounts_service

APIGW  -  66932  - Microservice for Accounts related transaction (Hold, Release, Pledge and Inquiry