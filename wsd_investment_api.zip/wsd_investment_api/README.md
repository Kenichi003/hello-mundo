# wsd_earnest_api

For Earnest API v2 development. Implement LZD encryption, linking and OTP generation