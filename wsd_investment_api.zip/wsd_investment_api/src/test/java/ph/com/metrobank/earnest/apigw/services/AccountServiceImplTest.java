package ph.com.metrobank.earnest.apigw.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.Transaction;
import ph.com.metrobank.earnest.apigw.model.request.*;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.LinkedAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;
import ph.com.metrobank.earnest.apigw.model.subscription.InvestmentAccount;
import ph.com.metrobank.earnest.apigw.services.impl.AccountServiceImpl;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesTransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.util.StringUtil;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
public class AccountServiceImplTest {

    private final ObjectMapper mapper = new ObjectMapper();

    @Mock
    private DirectLinkService directLinkService;

    @Mock
    private LoggingService loggingService;

    @Mock
    private TfesService tfesService;

    @Mock
    private CasaService casaService;

    AccountServiceImpl accountService;

    private DirectLinkRequestCommonModel directLinkRequestCommonModel;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        accountService = new AccountServiceImpl(directLinkService, loggingService, tfesService, casaService);
        directLinkRequestCommonModel = new DirectLinkRequestCommonModel();
        directLinkRequestCommonModel.setChannelId("SAMPLE_CHANNEL_ID");
        directLinkRequestCommonModel.setData("SAMPLE_DATA");
        directLinkRequestCommonModel.setSignature("SAMPLE_SIGNATURE");
    }

    @Test
    public void getLinkedAccountWithInvalidToken() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(null);

        LinkedAccountResponse response = accountService.getLinkedAccount(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
    }

    @Test
    public void getLinkedAccountWithValidTokenAndAccountTypeEqualsT() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(casaService.isAccountActive(anyString(), anyString(), anyString())).thenReturn(true);

        LinkedAccountResponse templateResponse = accountService.getLinkedAccount(directLinkRequestCommonModel, UUID.randomUUID().toString());

        LinkedAccountResponse linkedAccountResponse = (LinkedAccountResponse)templateResponse;
        Assert.assertEquals(StringUtil.getLastChars(linkedAccountResponse.getAccountNumber(), 6), StringUtil.getLastChars(accountsModel.getAccountNo(), 6));
        Assert.assertEquals("T", linkedAccountResponse.getAccountType());
        Assert.assertTrue(linkedAccountResponse.isAccountStatus());

    }

    @Test
    public void getLinkedAccountWithValidTokenAndAccountTypeEqualsI() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("4903190244564");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(casaService.isAccountActive(anyString(), anyString(), anyString())).thenReturn(true);

        LinkedAccountResponse linkedAccountResponse = accountService.getLinkedAccount(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(StringUtil.getLastChars(linkedAccountResponse.getAccountNumber(), 6), StringUtil.getLastChars(linkedAccountResponse.getAccountNumber(), 6));
        Assert.assertEquals("I", linkedAccountResponse.getAccountType());
        Assert.assertTrue(linkedAccountResponse.isAccountStatus());

    }
    @Test
    public void getLinkedAccountWithValidTokenAndAccountTypeEqualsS() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(casaService.isAccountActive(anyString(), anyString(), anyString())).thenReturn(true);

        LinkedAccountResponse linkedAccountResponse = accountService.getLinkedAccount(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(StringUtil.getLastChars(linkedAccountResponse.getAccountNumber(), 6), StringUtil.getLastChars(linkedAccountResponse.getAccountNumber(), 6));
        Assert.assertEquals("S", linkedAccountResponse.getAccountType());
        Assert.assertTrue(linkedAccountResponse.isAccountStatus());

    }

    @Test
    public void getInvestmentAccountSummaryWithInvalidToken() throws Exception{
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(null);

        TfesInvestmentAccountSummaryDetailResponse response = accountService.getInvestmentAccountSummary(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());

    }

    @Test
    public void getInvestmentAccountSummaryWithValidTokenAndAuthenticationFailed() throws Exception{
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesInvestmentAccountSummaryDetailResponse tfesInvestmentAccountSummaryDetailResponse = new TfesInvestmentAccountSummaryDetailResponse();
        tfesInvestmentAccountSummaryDetailResponse.setReturnCode("9700001");
        tfesInvestmentAccountSummaryDetailResponse.setLastSAFUpdateDate(new Date().toString());
        tfesInvestmentAccountSummaryDetailResponse.setInvestmentAccounts(null);
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString())).thenReturn(ResponseEntity.ok(tfesInvestmentAccountSummaryDetailResponse));

        TfesInvestmentAccountSummaryDetailResponse response = accountService.getInvestmentAccountSummary(directLinkRequestCommonModel, UUID.randomUUID().toString());
        verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        verify(tfesService, atLeastOnce()).getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_AUTHENTICATION.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_AUTHENTICATION.getTransactionCode());

    }

    @Test
    public void getInvestmentAccountSummaryWithValidTokenAndSettlementAccountDoesNotExist() throws Exception{
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesInvestmentAccountSummaryDetailResponse tfesInvestmentAccountSummaryDetailResponse = new TfesInvestmentAccountSummaryDetailResponse();
        tfesInvestmentAccountSummaryDetailResponse.setReturnCode("9700003");
        tfesInvestmentAccountSummaryDetailResponse.setLastSAFUpdateDate(new Date().toString());
        tfesInvestmentAccountSummaryDetailResponse.setInvestmentAccounts(null);
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString())).thenReturn(ResponseEntity.ok(tfesInvestmentAccountSummaryDetailResponse));

        TfesInvestmentAccountSummaryDetailResponse response = accountService.getInvestmentAccountSummary(directLinkRequestCommonModel, UUID.randomUUID().toString());
        verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString());
        verify(tfesService, atLeastOnce()).getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());

    }

    @Test
    public void getInvestmentAccountSummaryWithValidTokenAndErrorInTFES() throws Exception{
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesInvestmentAccountSummaryDetailResponse tfesInvestmentAccountSummaryDetailResponse = new TfesInvestmentAccountSummaryDetailResponse();
        tfesInvestmentAccountSummaryDetailResponse.setReturnCode("9700014");
        tfesInvestmentAccountSummaryDetailResponse.setLastSAFUpdateDate(new Date().toString());
        tfesInvestmentAccountSummaryDetailResponse.setInvestmentAccounts(null);
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString())).thenReturn(ResponseEntity.ok(tfesInvestmentAccountSummaryDetailResponse));

        TfesInvestmentAccountSummaryDetailResponse response = accountService.getInvestmentAccountSummary(directLinkRequestCommonModel, UUID.randomUUID().toString());

        verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString());
        verify(tfesService, atLeastOnce()).getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.EXCEPTION_ERROR_TFES.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.EXCEPTION_ERROR_TFES.getTransactionCode());
    }


    @Test
    public void getInvestmentAccountSummaryWithValidToken() throws Exception{
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesInvestmentAccountSummaryDetailResponse tfesInvestmentAccountSummaryDetailResponse = new TfesInvestmentAccountSummaryDetailResponse();
        tfesInvestmentAccountSummaryDetailResponse.setReturnCode("9700002");
        tfesInvestmentAccountSummaryDetailResponse.setLastSAFUpdateDate(new Date().toString());
        List<InvestmentAccount> investmentAccounts = new ArrayList<>();
        InvestmentAccount investmentAccount = new InvestmentAccount();
        investmentAccount.setInvestmentAccountNumber("123123123123");
        investmentAccounts.add(investmentAccount);
        tfesInvestmentAccountSummaryDetailResponse.setInvestmentAccounts(investmentAccounts);
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString())).thenReturn(ResponseEntity.ok(tfesInvestmentAccountSummaryDetailResponse));

        TfesInvestmentAccountSummaryDetailResponse response = accountService.getInvestmentAccountSummary(directLinkRequestCommonModel,  UUID.randomUUID().toString());
        verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString());
        verify(tfesService, atLeastOnce()).getInvestmentAccountSummaryDetail(any(InvestmentAccountSummaryDetailRequest.class), anyString());
        Assert.assertTrue(response.getReturnCode().equals("9700002"));
        Assert.assertEquals(response.getInvestmentAccounts().get(0).getInvestmentAccountNumber(),"123123123123");

    }

    @Test
    public void getTransactionDetailsWithInvalidTokenOrExternalUserId() throws Exception{
        TransactionDetailsRequest transactionDetailsRequest = new TransactionDetailsRequest();
        transactionDetailsRequest.setToken("SAMPLE_TOKEN");
        transactionDetailsRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        List<String> accountIds = new ArrayList<>();
        accountIds.add("UT180000100961");
        accountIds.add("UT180000100962");
        accountIds.add("UT180000100963");
        transactionDetailsRequest.setAccountIds(accountIds);
        transactionDetailsRequest.setAsOfDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(transactionDetailsRequest));
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(null);

        TransactionDetailsResponse response = accountService.getTransactionDetails(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());

    }

    @Test
    public void getTransactionDetailsWithEmptyInvestmentAccountNumber() throws Exception{
        TransactionDetailsRequest transactionDetailsRequest = new TransactionDetailsRequest();
        transactionDetailsRequest.setToken("SAMPLE_TOKEN");
        transactionDetailsRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        List<String> accountIds = new ArrayList<>();
        accountIds.add("UT180000100961");
        transactionDetailsRequest.setAccountIds(accountIds);
        transactionDetailsRequest.setAsOfDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(transactionDetailsRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesTransactionDetailsResponse transactionDetailsResponse = new TfesTransactionDetailsResponse();
        transactionDetailsResponse.setTransactions(null);
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getTransactionDetails(any(TfesTransactionDetailsRequest.class), anyString())).thenReturn(ResponseEntity.ok(transactionDetailsResponse));

        TransactionDetailsResponse response = accountService.getTransactionDetails(directLinkRequestCommonModel,  UUID.randomUUID().toString());
        Assert.assertEquals(0, response.getTransactions().get("UT180000100961").size());

    }

    @Test
    public void getTransactionDetails() throws Exception{
        TransactionDetailsRequest transactionDetailsRequest = new TransactionDetailsRequest();
        transactionDetailsRequest.setToken("SAMPLE_TOKEN");
        transactionDetailsRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        List<String> accountIds = new ArrayList<>();
        accountIds.add("UT180000100961");
        accountIds.add("UT180000100962");
        accountIds.add("UT180000100963");
        transactionDetailsRequest.setAccountIds(accountIds);
        transactionDetailsRequest.setAsOfDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(transactionDetailsRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesTransactionDetailsResponse transactionDetailsResponse = new TfesTransactionDetailsResponse();
        List<Transaction> transactions = new ArrayList<>();
        Transaction transaction = new Transaction();
        transaction.setNavpuRate(BigDecimal.valueOf(12.5));
        transaction.setNumOfUnits(Long.valueOf(12345));
        transaction.setProduct("12412");
        transactions.add(transaction);
        transactionDetailsResponse.setTransactions(transactions);
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getTransactionDetails(any(TfesTransactionDetailsRequest.class), anyString())).thenReturn(ResponseEntity.ok(transactionDetailsResponse));

        TransactionDetailsResponse response = accountService.getTransactionDetails(directLinkRequestCommonModel,  UUID.randomUUID().toString());
        Assert.assertEquals(3, response.getTransactions().size());
        verify(tfesService, atMost(accountIds.size())).getTransactionDetails(any(TfesTransactionDetailsRequest.class), anyString());

    }

    @Test
    public void getInvestmentAccountsWithInvalidTokenAndExternalUserId() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(null);

        EnrollTrustAccountResponse response = accountService.getInvestmentAccounts(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());

    }

    @Test
    public void getInvestmentAccountsWithValidTokenAndExternalUserId() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        EnrollTrustAccountResponse enrollTrustAccountResponse = new EnrollTrustAccountResponse();
        enrollTrustAccountResponse.setSettlementAccountNumber("2903190244564");
        enrollTrustAccountResponse.setSettlementAccountName("SAMPLE NAME");
        List<InvestmentAccount> investmentAccountList = new ArrayList<>();
        InvestmentAccount investmentAccount = new InvestmentAccount();
        investmentAccount.setInvestmentAccountNumber("123123123123");
        investmentAccountList.add(investmentAccount);
        enrollTrustAccountResponse.setInvestmentAccounts(investmentAccountList);
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(ResponseEntity.ok(enrollTrustAccountResponse));

        EnrollTrustAccountResponse response = accountService.getInvestmentAccounts(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(StringUtil.getLastChars(accountsModel.getAccountNo(), 6), StringUtil.getLastChars(response.getSettlementAccountNumber(), 6));
        Assert.assertEquals(response.getInvestmentAccounts().get(0).getInvestmentAccountNumber(),"123123123123");

    }

    @Test
    public void getInvestmentAccountDetailsWithInvalidTokenAndExternalUserId() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(null);

        TfesInvestmentAccountDetailsResponse response = accountService.getInvestmentAccountDetails(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
    }

    @Test
    public void getInvestmentAccountDetailsWithValidTokenAndExternalUserIdAndWithoutExistingData() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        tfesInvestmentAccountDetailsResponse.setReturnCode("9700006");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getInvestmentAccountDetails(any(TfesInvestmentAccountDetailsRequest.class), anyString())).thenReturn(ResponseEntity.ok(tfesInvestmentAccountDetailsResponse));

        TfesInvestmentAccountDetailsResponse response = accountService.getInvestmentAccountDetails(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.DATA_DOESNT_EXIST.getTransactionCode());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.DATA_DOESNT_EXIST.getTransactionDesc());

    }

    @Test
    public void getInvestmentAccountDetailsWithValidTokenAndExternalUserIdAndWithExistingData() throws Exception {
        CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("2903190244564");
        accountsModel.setRmNumber("1234576");
        TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        tfesInvestmentAccountDetailsResponse.setReturnCode("9700002");
        tfesInvestmentAccountDetailsResponse.setInvestmentAccountNumber("2903190244564");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(),anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getInvestmentAccountDetails(any(TfesInvestmentAccountDetailsRequest.class), anyString())).thenReturn(ResponseEntity.ok(tfesInvestmentAccountDetailsResponse));

        TfesInvestmentAccountDetailsResponse response = accountService.getInvestmentAccountDetails(directLinkRequestCommonModel, UUID.randomUUID().toString());
        Assert.assertEquals(response.getInvestmentAccountNumber(), accountsModel.getAccountNo());

    }
}