package ph.com.metrobank.earnest.apigw.services;

import org.apache.commons.codec.DecoderException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ph.com.metrobank.earnest.apigw.services.impl.EncryptionServiceImpl;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
public class EncryptionServiceImplTest {

    @Mock
    private LoggingService loggingService;

    private EncryptionService encryptionService;

    private String uuid;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        encryptionService = new EncryptionServiceImpl(loggingService);
        uuid = "123";
    }

    @Test
    public void testEncrypt() throws InterruptedException, ExecutionException, DecoderException, UnsupportedEncodingException, NoSuchAlgorithmException {
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");

        String result = encryptionService.encryptMD5("payload", uuid);
        Assert.assertNotNull(result);
    }

}
