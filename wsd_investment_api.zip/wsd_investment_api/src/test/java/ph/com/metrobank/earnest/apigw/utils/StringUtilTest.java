package ph.com.metrobank.earnest.apigw.utils;

import static org.mockito.Mockito.spy;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.earnest.apigw.util.StringUtil;

@RunWith(SpringJUnit4ClassRunner.class)
public class StringUtilTest {

	@Test
	public void testConstructor() {
		spy(new StringUtil());
		Assert.assertEquals(true, true);
	}
	
    @Test
    public void testMask() {
        String result = StringUtil.getLastChars("123456789" , 6);
        Assert.assertEquals(result, "456789");

        result = StringUtil.getLastChars(null, 6);
        Assert.assertEquals(result, "");

        result = StringUtil.getLastChars("123456", 6);
        Assert.assertEquals(result, "123456");
    }
}
