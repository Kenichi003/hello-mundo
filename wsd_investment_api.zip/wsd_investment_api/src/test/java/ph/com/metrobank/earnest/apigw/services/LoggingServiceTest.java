package ph.com.metrobank.earnest.apigw.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;

import java.util.UUID;

@RunWith(SpringJUnit4ClassRunner.class)
public class LoggingServiceTest {

    private LoggingService loggingService;
    private final ObjectMapper mapper = new ObjectMapper();

    @Before
    public void setUp() throws Exception {
        loggingService = new LoggingService();
    }

    @Test
    public void log() {
        String uuid = UUID.randomUUID().toString();
        String output = loggingService.log("SAMPLE_COMPONENT", uuid, new Object());
        Assert.assertEquals(String.format("{COMPONENT=SAMPLE_COMPONENT, UUID=%s}", uuid), output);
    }

    @Test
    public void logFailToStringify() {
        String uuid = UUID.randomUUID().toString();
        String output = loggingService.log("SAMPLE_COMPONENT", uuid, "Failed to Stringify");
        Assert.assertEquals("Failed to Stringify", "Failed to Stringify");
    }

    @Test
    public void error() {
        String uuid = UUID.randomUUID().toString();
        String output = loggingService.error("SAMPLE_COMPONENT", uuid, "SAMPLE_MESSAGE", new Object());
        Assert.assertEquals(String.format("{ERROR_MESSAGE=SAMPLE_MESSAGE, COMPONENT=SAMPLE_COMPONENT, UUID=%s}", uuid), output);
    }

    @Test
    public void errorFailToStringify() {
        String uuid = UUID.randomUUID().toString();
        String output = loggingService.error("SAMPLE_COMPONENT", uuid, "SAMPLE_MESSAGE", "Failed to Stringify");
        Assert.assertEquals("Failed to Stringify", "Failed to Stringify");
    }
}