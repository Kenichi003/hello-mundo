package ph.com.metrobank.earnest.apigw.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import ph.com.metrobank.earnest.apigw.config.CasaServiceConfiguration;
import ph.com.metrobank.earnest.apigw.model.WsStatus;
import ph.com.metrobank.earnest.apigw.model.response.AccountStatusDlsResponse;
import ph.com.metrobank.earnest.apigw.services.impl.CasaServiceImpl;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;

@RunWith(SpringJUnit4ClassRunner.class)
public class CasaServiceImplTest {

    private final ObjectMapper mapper = new ObjectMapper();
    CasaServiceImpl casaService;

    @Mock
    @Qualifier("restTemplateApigw")
    private RestTemplate restTemplate;

    @Mock
    private CasaServiceConfiguration casaServiceConfiguration;

    @Mock
    private LoggingService loggingService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        casaService = new CasaServiceImpl(restTemplate, casaServiceConfiguration, loggingService);
    }

    @Test
    public void isAccountActiveWithActiveAccount() throws Exception{
        WsStatus wsStatus = new WsStatus();
        wsStatus.setTransactionStatus("0");
        wsStatus.setErrorMessage("");

        AccountStatusDlsResponse  accountStatusDlsResponse = new AccountStatusDlsResponse();
        accountStatusDlsResponse.setWss(wsStatus);
        when(casaServiceConfiguration.getAccountStatusUrl(anyString(), anyString())).thenReturn("SAMPLE_URL");
        when(restTemplate.exchange(anyString(), any(), any(), (Class<Object>) any()))
                .thenReturn(new ResponseEntity(accountStatusDlsResponse, HttpStatus.OK));
        Boolean isActive = casaService.isAccountActive("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER", "SAMPLE_CURRENCY_CODE", UUID.randomUUID().toString());
        Assert.assertTrue(isActive);
    }

    @Test
    public void isAccountActiveWithInactiveAccount() throws Exception{
        WsStatus wsStatus = new WsStatus();
        wsStatus.setTransactionStatus("1");
        wsStatus.setErrorMessage("SOME_ERROR");

        AccountStatusDlsResponse  accountStatusDlsResponse = new AccountStatusDlsResponse();
        accountStatusDlsResponse.setWss(wsStatus);
        when(casaServiceConfiguration.getAccountStatusUrl(anyString(), anyString())).thenReturn("SAMPLE_URL");
        when(restTemplate.exchange(anyString(), any(), any(), (Class<Object>) any()))
                .thenReturn(new ResponseEntity(accountStatusDlsResponse, HttpStatus.OK));
        Boolean isActive = casaService.isAccountActive("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER", "SAMPLE_CURRENCY_CODE", UUID.randomUUID().toString());

        Assert.assertFalse(isActive);

    }
}