package ph.com.metrobank.earnest.apigw.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.earnest.apigw.util.Constants;

@RunWith(SpringJUnit4ClassRunner.class)
public class ConstantsUtilTest {

    @Test(expected = IllegalStateException.class)
    public void constantInitialization(){
        new Constants();
    }
}
