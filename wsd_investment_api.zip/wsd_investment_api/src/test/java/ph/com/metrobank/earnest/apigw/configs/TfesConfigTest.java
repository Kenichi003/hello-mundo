package ph.com.metrobank.earnest.apigw.configs;

import org.apache.commons.codec.DecoderException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import generator.JatisTfesAuthGen;
import ph.com.metrobank.earnest.apigw.config.TfesConfig;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

@RunWith(SpringJUnit4ClassRunner.class)
public class TfesConfigTest {

    TfesConfig config = new TfesConfig();
    
    @Mock
    LoggingService loggingService;
    
    @InjectMocks
    @Spy
    TfesConfig tfesConfig;

    @Before
    public void setUp() {
    	MockitoAnnotations.initMocks(this);
    	
        ReflectionTestUtils.setField(config, "shouldGenerateSaltAndSign", false);
        ReflectionTestUtils.setField(config, "salt", "salt");
        ReflectionTestUtils.setField(config, "sign", "sign");
        ReflectionTestUtils.setField(config, "systemId", "sws001");
        ReflectionTestUtils.setField(config, "systemPassword", "yk3GTa2CrRQ+TIeKK/Mzw5r962S6o9QDPz/gTYmzdO7+JEZ5aCnHwV5unMTOUWEg0OUpO0xENmlIjpSVyUL4kWpnsyAk0fsc");
//        ReflectionTestUtils.setField(config, "publicKey", "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAyuEZ4n+V/xVlqTxBcPy+zFytlvL+zYRwxd3uOG7kpjgddEVqFhrasS9nmL47iLJDFg0U381a7BBE5XQwDjJAoh8FmnYNO9F0LryW6NGeisQEfpfsNfFYo5zvsxqWtoAcDq/QZZXfdFhI4btlRxbXDaVKln5oDPC6Dk2CP47OAcTtQ97rgK/XMdY6QSnpU3Brx6oba6gCT1gJtrLIuaAWoy4CjIj3XcJH7BssNkgow9MG3W6MlqS8l21KoCF3Zz8nG58DWdoHSSIw6+5MM5sQH78JAQtFwfILLdzztXmGPqBRhBR7B6XJbCWk1IJVRm22VUl4MbnavaUQRSMRlTghug/4gElAqbvVQxbI2YMR4DSz3dRpBE/Nb5opmQHERJSqCBNOhA2shtBzRRn2NbLgpybcN27dHhHUjxSo3+z7wdi+d3SHES4jmlg6sm3biA/9TVND5oZ4E9NHPbXXSyeFnYHgzjurCBRZUjMTe/kqr30NutILSwms8jpqK7ezmBmoF8q4AebMc4SxaCzUkVgCRgecUYIVgCQOULK3QIQoaRrj7BTvmsT3dUdHOjhPmcPu0Bpmp2CkvPjJOm6gldLRs19W5AY/8uuRtLaZE3HxBdaPUC5H2hTkLl+sEVleL5nIINkpdHP15eP0kl6LNyjsC1Coq91jt2cmcy5qrbA86VECAwEAAQ==");
//        ReflectionTestUtils.setField(config, "privateKey", "MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQDK4Rnif5X/FWWpPEFw/L7MXK2W8v7NhHDF3e44buSmOB10RWoWGtqxL2eYvjuIskMWDRTfzVrsEETldDAOMkCiHwWadg070XQuvJbo0Z6KxAR+l+w18VijnO+zGpa2gBwOr9Blld90WEjhu2VHFtcNpUqWfmgM8LoOTYI/js4BxO1D3uuAr9cx1jpBKelTcGvHqhtrqAJPWAm2ssi5oBajLgKMiPddwkfsGyw2SCjD0wbdboyWpLyXbUqgIXdnPycbnwNZ2gdJIjDr7kwzmxAfvwkBC0XB8gst3PO1eYY+oFGEFHsHpclsJaTUglVGbbZVSXgxudq9pRBFIxGVOCG6D/iASUCpu9VDFsjZgxHgNLPd1GkET81vmimZAcRElKoIE06EDayG0HNFGfY1suCnJtw3bt0eEdSPFKjf7PvB2L53dIcRLiOaWDqybduID/1NU0PmhngT00c9tddLJ4WdgeDOO6sIFFlSMxN7+SqvfQ260gtLCazyOmort7OYGagXyrgB5sxzhLFoLNSRWAJGB5xRghWAJA5QsrdAhChpGuPsFO+axPd1R0c6OE+Zw+7QGmanYKS8+Mk6bqCV0tGzX1bkBj/y65G0tpkTcfEF1o9QLkfaFOQuX6wRWV4vmcgg2Sl0c/Xl4/SSXos3KOwLUKir3WO3ZyZzLmqtsDzpUQIDAQABAoICAGYoAsiyRe0z8QTOeoVSPyDYafBgWz1ROxfnMFTqQegQyYQKj+ihjQ07OYcIAyJJ4M3xuFkZJndHmemQH8KGO1VnGYM1fmRoi4AdJkAFjTeCjGDSTva6mE+KbohZExrCV15t2RnN5b7H1asUmWK6dX9Bg9VTwUEC1iztinBGkCUD7BUI4rzhzhIiNSMq33pMWXkohrYm20Loqbt9OuV9Xui7+jyZmzVy5pRU+mY634v7brGBQPl56hy1w6XuNBmhCyg1YZKU3qZMuSWT0HsL0YqqvvXvnyiRoF9vqqfukVJnl6RSS8EGEe6K5fy7xAS6qd04KXWgiCyGOTMW/XuN0CzijKjB7/N7TYLVej++eSn7pa940KZmm6FQ7dwsCTpyGIyieYSSD5bdYLelEoyM3zvPiwehpartv+c+Le3glrlm26I/HaRJoNoSUx3JIMdqj91IKCtQ4JZDTjsS6KZvvOnXwxSPcnpW2xRzRxxgbMm07Q+lujBV/pqLtN/jmTQboT71XDr+feYzMoEAuQq/m9r9TEChW6NYtJ+lqXoCExxTLk2q/J4zFiCxHOLENOmEVwlP6pcB84YRd4rWYRFsXI1vTMquJ2/salGI8OsYmRizro201PUkOKNhCpAH1eBgX+tDqm9sHbNoaDxHwjDpHnxIalZ3ZWuL47pnRmAYWFKhAoIBAQDxMN3lGABLkq+E5Dn9dTWGBcCwek507FbF92c2VfLaifWCYejWuoVDNM2ZizXdgeWhdZxS1iNpgqa3lbE0lfYik3uUWwKoUikuZIXR+WlQEsVnjXuADhIpmxyJt91tYQ8GDVyMwglgJqggnVFy8U3H7nM02ajM6zO4YKCb/u2BKqElsom51GegbA+Wj2BnIgA7DujXDsX5eDw8gLRv20Cgh93s9YNoaFHVuJun2AkW7GhUlzaVM6hCjA4H+Jo1OMc4l8F6cfenSXmEOXtQlzUH7Gls2VIWKnV90xMg3aBYUKm80DVhNN3lPnPUojTo9yuPAtB4aD2yVtncDuRIRkAnAoIBAQDXVgmrxXJtdaqyAEL75HehloGwr1pCYXBcbO0kEtqLfpnF0HAtyke0KMTIw3w1Ga1cY0LSsUzMmnrXaxdF3DEjK1kB3zMFIGqfVtM1bq7j+psY6ZdUBYl7tnG32reTg96RUqKBXXgFpDWovqfUCgNMztBP2iSv8xQCcfan1IF5Wy+YlaIraRWgbuThiK+p47pXA/XvwZ4E6mrk+4e1H26OwdP+0CELmTma6IPeqnj1feyXLCrhFMvwKPhpC9cFEW4jcKzLVpeBZPsv3zi7OobrAPl4vPXlLHmxBZs3JzDQJEadFIV2EsTMSji6dBTXoykO/HCy5nnh32Aj/kQsAn3HAoIBAQDnnl35G0ttR7h2jhWCaYS05+FbmJivgCb0hdoAPBmz9LhoNU48p3JCT/sBcMaRqaSzoRY2Fp57PJSNyJscPMbZ/Xe3yI6Mxhn2C2LXegTAeMZJ43yuRNT8T5DgUEm8OHENBtfR9KS8SWM7rtgA4eooDb1lC4EnCNfqQCD8rZu3ZxDJ+uJ4Kpo5XIy7sYSKhgRisra3j+Be6jAuigq9QHiXsOJWJI/FPCkabOZOERDpiq3GTlCEh88V2RnAXeT5J0Vp+5I53ChP5idj6y+Y/RxYN5gmh6xkzPF3m7PK5AqPxSa7w9b/Op29AHSLxhm5f2O9Op6ogrJ9CRq+US64mX4RAoIBAEFc32ChdWNeZSrUw4BcUCffXIx6HaaqlwWnFrBtfKL9EcYmx/ZOQUehXGIoXGpt2d6CTsVPhiVQ+tqqqgzNkqi/Pqw/yOfUeCjXnRLJ/xI6fpuoRAQADkRcE9af8Ds5uvRXpfYongbwWk1XWfAV/fxxhm/Gon46BafcWeeFrKtej2r8eJY+to7VOmpvKAskkepZzGwzVDjfwwSwiPfki5WPpj7hhDZWE1M/ItAS5NZ3m7ojcPyTaHgEp6qTKnhiWxEs4XZzWVewhEJ6umiykkOBLziD+wvOXT3rmrq6DaoQaNLDaON3PP9ZxDBsjesKnqrq23aiWPrD6BXk12KYev8CggEAbooJip8xhE6EUb2naKZo1LvLZnhWwbEcePYUUiGXMsjd5OHVKOQd9K2AyZpKsqR1/zgpMuadakD1wAVMMaAr0uGhR4YhiBByFw1+/jHBGJzLvL37lD6B1/t3xFKaGuq9/q39FmtpGQmTtY8k9I9wsMcTGbtz4srDe8GUZJ99CORHXL3hnJqSBaptgJ65lTiLIWasv0X43c3goq5EzLoXmMNqCdD7GmYavf8mNEzwJ2j7BjiA+lH9UPMEgZvXtSLEF4+celPVAZZK5s4dE3yKyY8M9gmUeCXCDmT3Bhb8EiJkEPDVAYJup+aSF5YXk9N9+dmxdTwQnJaU8dmOPf/CcQ==");
 //       ReflectionTestUtils.setField(config, "configurationSettingsEndpoint", "http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/%s");
        ReflectionTestUtils.setField(config, "investmentAccountSummaryDetailUrl", "investmentAccountSummaryDetailUrl");
        ReflectionTestUtils.setField(config, "transactionDetailUrl", "transactionDetailUrl");
        ReflectionTestUtils.setField(config, "createRedemption", "createRedemption");
        ReflectionTestUtils.setField(config, "investmentAccountDetailsUrl", "investmentAccountDetailsUrl");
        ReflectionTestUtils.setField(config, "investmentProductsUrl", "investmentProductsUrl");
        ReflectionTestUtils.setField(config, "suitabilityExpirationDateUrl", "suitabilityExpirationDateUrl");
        ReflectionTestUtils.setField(config, "validateClientProductRiskProfileUrl", "validateClientProductRiskProfileUrl");
        ReflectionTestUtils.setField(config, "updateSuitabilityAssessmentFormUrl", "updateSuitabilityAssessmentFormUrl");
        ReflectionTestUtils.setField(config, "assessmentResultPerProductUrl", "assessmentResultPerProductUrl");
    }
 
    @Test
    public void testAsyncConfiguration() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, UnsupportedEncodingException, DecoderException {
        Assert.assertEquals(config.getSystemId(), "sws001");
        Assert.assertNotNull(config.getSaltValue());
        Assert.assertNotNull(config.getSignValue());
       // Assert.assertNotNull(config.getConfigurationSettingsEndpoint());
       // Assert.assertEquals(config.getConfigurationSettingsEndpoint(), "http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/%s");
        //Assert.assertEquals(config.getPublicKey(), "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAyuEZ4n+V/xVlqTxBcPy+zFytlvL+zYRwxd3uOG7kpjgddEVqFhrasS9nmL47iLJDFg0U381a7BBE5XQwDjJAoh8FmnYNO9F0LryW6NGeisQEfpfsNfFYo5zvsxqWtoAcDq/QZZXfdFhI4btlRxbXDaVKln5oDPC6Dk2CP47OAcTtQ97rgK/XMdY6QSnpU3Brx6oba6gCT1gJtrLIuaAWoy4CjIj3XcJH7BssNkgow9MG3W6MlqS8l21KoCF3Zz8nG58DWdoHSSIw6+5MM5sQH78JAQtFwfILLdzztXmGPqBRhBR7B6XJbCWk1IJVRm22VUl4MbnavaUQRSMRlTghug/4gElAqbvVQxbI2YMR4DSz3dRpBE/Nb5opmQHERJSqCBNOhA2shtBzRRn2NbLgpybcN27dHhHUjxSo3+z7wdi+d3SHES4jmlg6sm3biA/9TVND5oZ4E9NHPbXXSyeFnYHgzjurCBRZUjMTe/kqr30NutILSwms8jpqK7ezmBmoF8q4AebMc4SxaCzUkVgCRgecUYIVgCQOULK3QIQoaRrj7BTvmsT3dUdHOjhPmcPu0Bpmp2CkvPjJOm6gldLRs19W5AY/8uuRtLaZE3HxBdaPUC5H2hTkLl+sEVleL5nIINkpdHP15eP0kl6LNyjsC1Coq91jt2cmcy5qrbA86VECAwEAAQ==");
        //Assert.assertEquals(config.getPrivateKey(), "MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQDK4Rnif5X/FWWpPEFw/L7MXK2W8v7NhHDF3e44buSmOB10RWoWGtqxL2eYvjuIskMWDRTfzVrsEETldDAOMkCiHwWadg070XQuvJbo0Z6KxAR+l+w18VijnO+zGpa2gBwOr9Blld90WEjhu2VHFtcNpUqWfmgM8LoOTYI/js4BxO1D3uuAr9cx1jpBKelTcGvHqhtrqAJPWAm2ssi5oBajLgKMiPddwkfsGyw2SCjD0wbdboyWpLyXbUqgIXdnPycbnwNZ2gdJIjDr7kwzmxAfvwkBC0XB8gst3PO1eYY+oFGEFHsHpclsJaTUglVGbbZVSXgxudq9pRBFIxGVOCG6D/iASUCpu9VDFsjZgxHgNLPd1GkET81vmimZAcRElKoIE06EDayG0HNFGfY1suCnJtw3bt0eEdSPFKjf7PvB2L53dIcRLiOaWDqybduID/1NU0PmhngT00c9tddLJ4WdgeDOO6sIFFlSMxN7+SqvfQ260gtLCazyOmort7OYGagXyrgB5sxzhLFoLNSRWAJGB5xRghWAJA5QsrdAhChpGuPsFO+axPd1R0c6OE+Zw+7QGmanYKS8+Mk6bqCV0tGzX1bkBj/y65G0tpkTcfEF1o9QLkfaFOQuX6wRWV4vmcgg2Sl0c/Xl4/SSXos3KOwLUKir3WO3ZyZzLmqtsDzpUQIDAQABAoICAGYoAsiyRe0z8QTOeoVSPyDYafBgWz1ROxfnMFTqQegQyYQKj+ihjQ07OYcIAyJJ4M3xuFkZJndHmemQH8KGO1VnGYM1fmRoi4AdJkAFjTeCjGDSTva6mE+KbohZExrCV15t2RnN5b7H1asUmWK6dX9Bg9VTwUEC1iztinBGkCUD7BUI4rzhzhIiNSMq33pMWXkohrYm20Loqbt9OuV9Xui7+jyZmzVy5pRU+mY634v7brGBQPl56hy1w6XuNBmhCyg1YZKU3qZMuSWT0HsL0YqqvvXvnyiRoF9vqqfukVJnl6RSS8EGEe6K5fy7xAS6qd04KXWgiCyGOTMW/XuN0CzijKjB7/N7TYLVej++eSn7pa940KZmm6FQ7dwsCTpyGIyieYSSD5bdYLelEoyM3zvPiwehpartv+c+Le3glrlm26I/HaRJoNoSUx3JIMdqj91IKCtQ4JZDTjsS6KZvvOnXwxSPcnpW2xRzRxxgbMm07Q+lujBV/pqLtN/jmTQboT71XDr+feYzMoEAuQq/m9r9TEChW6NYtJ+lqXoCExxTLk2q/J4zFiCxHOLENOmEVwlP6pcB84YRd4rWYRFsXI1vTMquJ2/salGI8OsYmRizro201PUkOKNhCpAH1eBgX+tDqm9sHbNoaDxHwjDpHnxIalZ3ZWuL47pnRmAYWFKhAoIBAQDxMN3lGABLkq+E5Dn9dTWGBcCwek507FbF92c2VfLaifWCYejWuoVDNM2ZizXdgeWhdZxS1iNpgqa3lbE0lfYik3uUWwKoUikuZIXR+WlQEsVnjXuADhIpmxyJt91tYQ8GDVyMwglgJqggnVFy8U3H7nM02ajM6zO4YKCb/u2BKqElsom51GegbA+Wj2BnIgA7DujXDsX5eDw8gLRv20Cgh93s9YNoaFHVuJun2AkW7GhUlzaVM6hCjA4H+Jo1OMc4l8F6cfenSXmEOXtQlzUH7Gls2VIWKnV90xMg3aBYUKm80DVhNN3lPnPUojTo9yuPAtB4aD2yVtncDuRIRkAnAoIBAQDXVgmrxXJtdaqyAEL75HehloGwr1pCYXBcbO0kEtqLfpnF0HAtyke0KMTIw3w1Ga1cY0LSsUzMmnrXaxdF3DEjK1kB3zMFIGqfVtM1bq7j+psY6ZdUBYl7tnG32reTg96RUqKBXXgFpDWovqfUCgNMztBP2iSv8xQCcfan1IF5Wy+YlaIraRWgbuThiK+p47pXA/XvwZ4E6mrk+4e1H26OwdP+0CELmTma6IPeqnj1feyXLCrhFMvwKPhpC9cFEW4jcKzLVpeBZPsv3zi7OobrAPl4vPXlLHmxBZs3JzDQJEadFIV2EsTMSji6dBTXoykO/HCy5nnh32Aj/kQsAn3HAoIBAQDnnl35G0ttR7h2jhWCaYS05+FbmJivgCb0hdoAPBmz9LhoNU48p3JCT/sBcMaRqaSzoRY2Fp57PJSNyJscPMbZ/Xe3yI6Mxhn2C2LXegTAeMZJ43yuRNT8T5DgUEm8OHENBtfR9KS8SWM7rtgA4eooDb1lC4EnCNfqQCD8rZu3ZxDJ+uJ4Kpo5XIy7sYSKhgRisra3j+Be6jAuigq9QHiXsOJWJI/FPCkabOZOERDpiq3GTlCEh88V2RnAXeT5J0Vp+5I53ChP5idj6y+Y/RxYN5gmh6xkzPF3m7PK5AqPxSa7w9b/Op29AHSLxhm5f2O9Op6ogrJ9CRq+US64mX4RAoIBAEFc32ChdWNeZSrUw4BcUCffXIx6HaaqlwWnFrBtfKL9EcYmx/ZOQUehXGIoXGpt2d6CTsVPhiVQ+tqqqgzNkqi/Pqw/yOfUeCjXnRLJ/xI6fpuoRAQADkRcE9af8Ds5uvRXpfYongbwWk1XWfAV/fxxhm/Gon46BafcWeeFrKtej2r8eJY+to7VOmpvKAskkepZzGwzVDjfwwSwiPfki5WPpj7hhDZWE1M/ItAS5NZ3m7ojcPyTaHgEp6qTKnhiWxEs4XZzWVewhEJ6umiykkOBLziD+wvOXT3rmrq6DaoQaNLDaON3PP9ZxDBsjesKnqrq23aiWPrD6BXk12KYev8CggEAbooJip8xhE6EUb2naKZo1LvLZnhWwbEcePYUUiGXMsjd5OHVKOQd9K2AyZpKsqR1/zgpMuadakD1wAVMMaAr0uGhR4YhiBByFw1+/jHBGJzLvL37lD6B1/t3xFKaGuq9/q39FmtpGQmTtY8k9I9wsMcTGbtz4srDe8GUZJ99CORHXL3hnJqSBaptgJ65lTiLIWasv0X43c3goq5EzLoXmMNqCdD7GmYavf8mNEzwJ2j7BjiA+lH9UPMEgZvXtSLEF4+celPVAZZK5s4dE3yKyY8M9gmUeCXCDmT3Bhb8EiJkEPDVAYJup+aSF5YXk9N9+dmxdTwQnJaU8dmOPf/CcQ==");
        Assert.assertEquals(config.getSystemPassword(), "yk3GTa2CrRQ+TIeKK/Mzw5r962S6o9QDPz/gTYmzdO7+JEZ5aCnHwV5unMTOUWEg0OUpO0xENmlIjpSVyUL4kWpnsyAk0fsc");
        Assert.assertEquals(config.getInvestmentAccountSummaryDetailUrl(), "investmentAccountSummaryDetailUrl");
        Assert.assertEquals(config.getTransactionDetailUrl(), "transactionDetailUrl");
        Assert.assertEquals(config.getCreateRedemption(), "createRedemption");
        Assert.assertEquals(config.getInvestmentAccountDetailsUrl(), "investmentAccountDetailsUrl");
        Assert.assertEquals(config.getInvestmentProductsUrl(), "investmentProductsUrl");
        Assert.assertEquals(config.getSuitabilityExpirationDateUrl(), "suitabilityExpirationDateUrl");
        Assert.assertEquals(config.getValidateClientProductRiskProfileUrl(), "validateClientProductRiskProfileUrl");
        Assert.assertEquals(config.getUpdateSuitabilityAssessmentFormUrl(), "updateSuitabilityAssessmentFormUrl");
        Assert.assertEquals(config.getAssessmentResultPerProductUrl(), "assessmentResultPerProductUrl");
        ReflectionTestUtils.setField(config, "shouldGenerateSaltAndSign", true);
        Assert.assertNotNull(config.getSaltValue());
        Assert.assertNotNull(config.getSignValue());
        Assert.assertNotNull(config.getSignValue());
        Assert.assertNotNull(config.getSaltValue());
        Assert.assertNotNull(config.verifyApplicationProperties());
    } 
    
    @Test()
    public void testSignException() throws UnsupportedEncodingException, DecoderException {
    	when(tfesConfig.parseString(Mockito.anyString())).thenThrow(JsonSyntaxException.class);
    	ReflectionTestUtils.setField(tfesConfig, "systemId", "sws001");
        ReflectionTestUtils.setField(tfesConfig, "systemPassword", "yk3GTa2CrRQ+TIeKK/Mzw5r962S6o9QDPz/gTYmzdO7+JEZ5aCnHwV5unMTOUWEg0OUpO0xENmlIjpSVyUL4kWpnsyAk0fsc");
    	ReflectionTestUtils.setField(tfesConfig, "shouldGenerateSaltAndSign", true);
    	String signValue = tfesConfig.getSignValue();
    	Assert.assertNull(signValue);
    }
    
    @Test()
    public void testSaltException() throws UnsupportedEncodingException, DecoderException {
    	when(tfesConfig.parseString(Mockito.anyString())).thenThrow(JsonSyntaxException.class);
    	ReflectionTestUtils.setField(tfesConfig, "systemId", "sws001");
        ReflectionTestUtils.setField(tfesConfig, "systemPassword", "yk3GTa2CrRQ+TIeKK/Mzw5r962S6o9QDPz/gTYmzdO7+JEZ5aCnHwV5unMTOUWEg0OUpO0xENmlIjpSVyUL4kWpnsyAk0fsc");
    	ReflectionTestUtils.setField(tfesConfig, "shouldGenerateSaltAndSign", true);
    	String saltValue = tfesConfig.getSaltValue();
    	Assert.assertNull(saltValue);
    	
    }
    
    @Test(expected = JsonSyntaxException.class)
    public void testParseStringException() throws UnsupportedEncodingException, DecoderException {
    	JsonElement jsoneELement = tfesConfig.parseString("[]]");
    }
}
