package ph.com.metrobank.earnest.apigw.models;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.ConfigurationModel;
import ph.com.metrobank.earnest.apigw.model.CustomerDetails;
import ph.com.metrobank.earnest.apigw.model.Format;
import ph.com.metrobank.earnest.apigw.model.GenericResponse;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.Transaction;
import ph.com.metrobank.earnest.apigw.model.ValidateOrSendOTPResponse;
import ph.com.metrobank.earnest.apigw.model.WsStatus;
import ph.com.metrobank.earnest.apigw.model.auth.AuthCode;
import ph.com.metrobank.earnest.apigw.model.request.CommonAccountDetailRequest;
import ph.com.metrobank.earnest.apigw.model.request.CreateRedemptionPayload;
import ph.com.metrobank.earnest.apigw.model.request.CreateRedemptionRequest;
import ph.com.metrobank.earnest.apigw.model.request.CreateSubscriptionPayload;
import ph.com.metrobank.earnest.apigw.model.request.CreateSubscriptionRequest;
import ph.com.metrobank.earnest.apigw.model.request.EnrollTrustAccountRequest;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountSummaryDetailRequest;
import ph.com.metrobank.earnest.apigw.model.request.Question;
import ph.com.metrobank.earnest.apigw.model.request.TfesCommonRequestModel;
import ph.com.metrobank.earnest.apigw.model.request.TfesInvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesTransactionDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesUpdateSuitabilityAssessmentRequest;
import ph.com.metrobank.earnest.apigw.model.response.BindResponse;
import ph.com.metrobank.earnest.apigw.model.response.CreateRedemptionResponse;
import ph.com.metrobank.earnest.apigw.model.response.CreateSubscriptionResponse;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.InvestmentSummaryDetail;
import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;
import ph.com.metrobank.earnest.apigw.model.subscription.InvestmentAccount;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProduct;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesTransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

public class ModelsTest {

    private AuthCode authCode = new AuthCode();
    private InvestmentAccount investmentAccount = new InvestmentAccount();
    private CustomerDetails customerDetails = new CustomerDetails();
    private AccountsModel accountsModel = new AccountsModel();
    private ConfigurationModel configurationModel = new ConfigurationModel();
    private CreateSubscriptionRequest request = new CreateSubscriptionRequest();
    private BindResponse bindResponse = new BindResponse();
    private GenericResponse genericResponse = new GenericResponse();
    private ValidateOrSendOTPResponse otResponse = new ValidateOrSendOTPResponse();
    private CommonAccountDetailRequest commonAccountDetailRequest = new CommonAccountDetailRequest();
    private InvestmentAccountDetailsRequest investmentAccountDetailsRequest = new InvestmentAccountDetailsRequest();
    private InvestmentAccountSummaryDetailRequest investmentAccountSummaryDetailRequest = new InvestmentAccountSummaryDetailRequest();
    private InvestmentAccountDetailsRequest investmentProductModel = new InvestmentAccountDetailsRequest();
    private Question question = new Question();
    private TfesCommonRequestModel tfesCommonRequestModel = new TfesCommonRequestModel();
    private TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
    private TfesTransactionDetailsRequest tfesTransactionDetailsRequest = new TfesTransactionDetailsRequest();
    private TfesUpdateSuitabilityAssessmentRequest tfesUpdateSuitabilityAssessmentRequest = new TfesUpdateSuitabilityAssessmentRequest();
    private EnrollTrustAccountRequest enrollTrustAccountRequest = new EnrollTrustAccountRequest();
    private CreateRedemptionRequest createRedemptionRequest = new CreateRedemptionRequest();
    private CreateRedemptionPayload createRedemptionPayload = new CreateRedemptionPayload();
    private CreateSubscriptionPayload createSubscriptionPayload = new CreateSubscriptionPayload();
    private CreateRedemptionResponse createRedemptionResponse = new CreateRedemptionResponse();
    private CreateSubscriptionResponse createSubscriptionResponse = new CreateSubscriptionResponse();
    private EnrollTrustAccountResponse enrollTrustAccountResponse = new EnrollTrustAccountResponse();
    private InvestmentSummaryDetail investmentSummaryDetail = new InvestmentSummaryDetail();
    private TranCodesResponse tranCodesResponse = new TranCodesResponse();
    private TranCodesResponse unbindResponse = new TranCodesResponse();
    private ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
    private TfesProduct tfesProduct = new TfesProduct();
    private TfesProductsResponse tfesProductsResponse = new TfesProductsResponse();
    private TfesSuitabilityExpirationResponse tfesSuitabilityExpirationResponse = new TfesSuitabilityExpirationResponse();
    private TfesCommonTransactionResponse tfesCommonTransactionResponse = new TfesCommonTransactionResponse();
    private TfesClientProductRiskProfileResponse tfesClientProductRiskProfileResponse = new TfesClientProductRiskProfileResponse();
    private TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
    private TfesInvestmentAccountSummaryDetailResponse tfesInvestmentAccountSummaryDetailResponse = new TfesInvestmentAccountSummaryDetailResponse();
    private TfesTransactionDetailsResponse tfesTransactionDetailsResponse = new TfesTransactionDetailsResponse();
    private TfesUpdateSuitabilityAssessmentResponse tfesUpdateSuitabilityAssessmentResponse = new TfesUpdateSuitabilityAssessmentResponse();
    private Format format = new Format();
    private Transaction transaction = new Transaction();
    private ValidateOrSendOTPResponse validateOrSendOTPResponse = new ValidateOrSendOTPResponse();
    private WsStatus wsStatus = new WsStatus();


    @Before
    public void setUp() {
        authCode.setCode("code");
        authCode.setOtpGenId("otpgen");
        authCode.setResend(true);

        investmentAccount.setInvestmentAccountNumber("123");
        investmentAccount.setInvestmentAccountName("asd");
        investmentAccount.setJointAccount("joint");
        investmentAccount.setStatementAddress("address");
        investmentAccount.setAccountType("SAMPLE_ACCOUNT_TYPE");
        investmentAccount.setCurrencyCode("SAMPLE_CURRENCY_CODE");
        investmentAccount.setTotalMarketValue(BigDecimal.valueOf(12345));
        investmentAccount.setServicingBranch("SAMPLE_SERVICING_BRANCH");

        customerDetails.setCustomerNo("1");
        customerDetails.setBirthDate("123");
        customerDetails.setCustomerName("asd");
        customerDetails.setEmailAddress("test@email.com");
        customerDetails.setMobileNumber("1323123");
        customerDetails.setTin("123123");
        customerDetails.setRelConnectorCode("rel");

        accountsModel.setDlId("12");
        accountsModel.setAccountRef("12");
        accountsModel.setMerchantId("12");
        accountsModel.setOwner("12");
        accountsModel.setDateModified(new Date());
        accountsModel.setDateExpired(new Date());
        accountsModel.setDeleteFlag(true);
        accountsModel.setRmNumber("SAMPLE_RM_NUMBER");
        accountsModel.setAccountNo("SAMPLE_ACCOUNT_NO");
        accountsModel.setDateExpired(new Date());
        accountsModel.setReferenceNo("SAMPLE_REFERENCE_NUMBER");
        accountsModel.setOwner("SAMPLE_OWNER");
        accountsModel.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        accountsModel.setToken("SAMPLE_TOKEN");
        accountsModel.setDateCreated(new Date());
        
        configurationModel.setExpiryDays(1);
        configurationModel.setMerchantId("SAMPLE_MERCHANT_ID");
        configurationModel.setMerchantName("SAMPLE_MERCHANT_NAME");
        configurationModel.setMerchantAlias("SAMPLE_MERCHANT_ALIAS");
        configurationModel.setAggregateLimitAccount(12345);
        configurationModel.setAggregateLimitUser(12345);
        configurationModel.setMaxLinkedAccounts(123);
        configurationModel.setTxnRenewalCriteria(12345);
        configurationModel.setBankPublicKey("SAMPLE_BANK_PUBLIC_KEY");
        configurationModel.setBankPrivateKey("SAMPLE_BANK_PRIVATE_KEY");
        configurationModel.setMerchantPublicKey("SAMPLE_MERCHANT_PUBLIC_KEY");

        request.setUserId("test");
        request.setSignValue("test");
        request.setSaltValue("test");
        request.setRmNumber("test");
        request.setInvestmentAccountNumber("test");
        request.setProductCode("test");
        request.setPtaNumber("test");
        request.setSettlementAccountNumber("test");
        request.setTransactionType("test");

        request.setOrderDate(LocalDate.now().toString());
        request.setAmount(new BigDecimal(2));
        request.setRspAmount(new BigDecimal(2));
        request.setInstallmentPeriod(1);
        request.setInstallmentDate(23);
        request.setRemarks("test");
        request.setIsBeyondCutOff(true);

        bindResponse.setAccountRef("acc");
        bindResponse.setReferenceNo("23123");
        bindResponse.setToken("token");

        genericResponse.setDate(new Date());
        genericResponse.setMessage("asdasd");
        genericResponse.setProgramName("dsfgsgf");
        genericResponse.setBody(new Object());

        otResponse.setAmount(new BigDecimal(2));
        otResponse.setReferenceNo("eqw4");
        otResponse.setTransactionDate("qweq");
        otResponse.setMaskedMobileNumber("qweqwe");
        otResponse.setnToken("qweqwe");

        commonAccountDetailRequest.setReferenceNo("SAMPLE_REFERENCE_NO");

        investmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        investmentAccountDetailsRequest.setProductCode("SAMPLE_PRODUCT_CODE");
        investmentAccountDetailsRequest.setRmNumber("SAMPLE_RM_NUMBER");

        investmentAccountSummaryDetailRequest.setRmNumber("SAMPLE_RM_NUMBER");
        investmentAccountSummaryDetailRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
        
        investmentProductModel.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        investmentProductModel.setProductCode("SAMPLE_PRODUCT_CODE");
        
        question.setQuestionId("SAMPLE_QUESTION_ID");
        question.setAnswerId("SAMPLE_ANSWER_ID");

        tfesCommonRequestModel.setSaltValue("SAMPLE_SALT_VALUE");
        tfesCommonRequestModel.setSignValue("SAMPLE_SIGN_VALUE");
        tfesCommonRequestModel.setUserId("SAMPLE_USERID_VALUE");

        tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
        tfesInvestmentAccountDetailsRequest.setRmNumber("SAMPLE_RM_NUMBER");
        tfesInvestmentAccountDetailsRequest.setProductCode("SAMPLE_PRODUCT_CODE");

        tfesTransactionDetailsRequest.setAsOfDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        tfesTransactionDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        
        tfesUpdateSuitabilityAssessmentRequest.setQuestionnaireId("SAMPLE_QUESTIONNAIRE_ID");
        tfesUpdateSuitabilityAssessmentRequest.setQuestions(new ArrayList<>());
        tfesUpdateSuitabilityAssessmentRequest.setRmNumber("SAMPLE_RM_NUMBER");
        tfesUpdateSuitabilityAssessmentRequest.setUserId("SAMPLE_USER_ID");
        tfesUpdateSuitabilityAssessmentRequest.setSaltValue("SAMPLE_SALT_VALUE");
        tfesUpdateSuitabilityAssessmentRequest.setSignValue("SAMPLE_SIGN_VALUE");

        enrollTrustAccountRequest.setRmNumber("SAMPLE_RM_NUMBER_VALUE");
        enrollTrustAccountRequest.setSaltValue("SAMPLE_SALT_VALUE");
        enrollTrustAccountRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_VALUE");
        enrollTrustAccountRequest.setSignValue("SAMPLE_SIGN_VALUE");
        enrollTrustAccountRequest.setSystemID("SAMPLE_SYSTEMID_VALUE");
        enrollTrustAccountRequest.setUserId("SAMPLE_USERID_VALUE");

        createRedemptionRequest.setAmountOrUnits(BigDecimal.valueOf(1234));
        createRedemptionRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        createRedemptionRequest.setIsBeyondCutOff(false);
        createRedemptionRequest.setOrderDate("SAMPLE_ORDER_DATE");
        createRedemptionRequest.setProductCode("SAMPLE_PRODUCT_CODE");
        createRedemptionRequest.setRedemptionType("SAMPLE_REDEMPTION_TYPE");
        createRedemptionRequest.setRemarks("SAMPLE_REMARKS");
        createRedemptionRequest.setRmNumber("SAMPLE_RM_NUMBER");
        createRedemptionRequest.setTransactionType("SAMPLE_TRANSACTIONTYPE");
        createRedemptionRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NO");

        createRedemptionPayload.setAmountOrUnits(BigDecimal.valueOf(12345));
        createRedemptionPayload.setAuth(new AuthCode());
        createRedemptionPayload.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        createRedemptionPayload.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        createRedemptionPayload.setIsBeyondCutoff(false);
        createRedemptionPayload.setOrderDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        createRedemptionPayload.setProductCode("SAMPLE_PRODUCT_CODE");
        createRedemptionPayload.setRedemptionType("SAMPLE_REDEMPTION_TYPE");
        createRedemptionPayload.setReferenceNo("SAMPLE_REFERENCE_NO");
        createRedemptionPayload.setRemarks("SAMPLE_REMARKS");
        createRedemptionPayload.setToken("SAMPLE_TOKEN");

        createSubscriptionPayload.setAmount(BigDecimal.valueOf(123456));
        createSubscriptionPayload.setAuth(new AuthCode());
        createSubscriptionPayload.setExternalUserId("SAMPLE_EXTERNAL_USERID");
        createSubscriptionPayload.setInitial(false);
        createSubscriptionPayload.setInstallmentDate(1);
        createSubscriptionPayload.setInstallmentPeriod(2);
        createSubscriptionPayload.setIsBeyondCutoff(false);
        createSubscriptionPayload.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        createSubscriptionPayload.setOrderDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        createSubscriptionPayload.setProductCode("SAMPLE_PRODUCT_CODE");
        createSubscriptionPayload.setPtaNumber("SAMPLE_PTA_NUMBER");
        createSubscriptionPayload.setReferenceNo("SAMPLE_REFERENCE_NO");
        createSubscriptionPayload.setRemarks("SAMPLE_REMARKS");
        createSubscriptionPayload.setRspAmount(BigDecimal.valueOf(12345));
        createSubscriptionPayload.setToken("SAMPLE_TOKEN");

        createRedemptionResponse.setData("SAMPLTE_DATA");
        createRedemptionResponse.setTransactionDate("SAMPLE_DATE");

        createSubscriptionResponse.setData("SAMPLTE_DATA");
        createSubscriptionResponse.setTransactionDate("SAMPLE_TRANSACTION_DATE");

        enrollTrustAccountResponse.setSettlementAccountName("SAMPLE_SETTLEMENT_ACCOUNT_NAME");
        enrollTrustAccountResponse.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
        enrollTrustAccountResponse.setInvestmentAccounts(new ArrayList<>());
        enrollTrustAccountResponse.setReturnCode("SAMPLE_RETURN_CODE");

        investmentSummaryDetail.setAbsoluteROI(BigDecimal.valueOf(123));
        investmentSummaryDetail.setAverageCost(BigDecimal.valueOf(132));
        investmentSummaryDetail.setMarketValue(BigDecimal.valueOf(123));
        investmentSummaryDetail.setNavpuRate(BigDecimal.valueOf(132));
        investmentSummaryDetail.setOutstandingUnits(BigDecimal.valueOf(123));
        investmentSummaryDetail.setPercentOfTotal(1);
        investmentSummaryDetail.setProduct("SAMPLE_PRODUCT");
        investmentSummaryDetail.setPtaNumber("SAMPLE_PTA_NUMBER");
        investmentSummaryDetail.setUnrealizedGainLoss(BigDecimal.valueOf(132));
        
        tranCodesResponse.setTransactionCode("SAMPLE_TRANSACTION_CODE");
        tranCodesResponse.setTransactionDesc("SAMPLE_TRANSACTION_DESC");
        tranCodesResponse.setReturnCode("SAMPLE_RETURN_CODE");
        tranCodesResponse.setReturnDescription("SAMPLE_RETURN_DESC");
        
        unbindResponse.setTransactionCode("SAMPLE_TRANSACTION_CODE");
        unbindResponse.setTransactionDesc("SAMPLE_TRANSACTION_DESC");

        validateDlsResponse.setData("SAMPLE_DATA");
        validateDlsResponse.setTransactionDate("SAMPLE_TRANSACTION_DATE");

        tfesProduct.setProductId("SAMPLE_PRODUCT_ID");
        tfesProduct.setProductCode("SAMPLE_PRODUCT_CODE");
        tfesProduct.setProductName("SAMPLE_PRODUCT_NAME");
        tfesProduct.setCutOffTime("SAMPLE_CUTOFF_TIME");
        tfesProduct.setProductTypeName("SAMPLE_PRODUCT_TYPE_NAME");
        tfesProduct.setCurrency("SAMPLE_CURRENCY");
        tfesProduct.setInvestmentHorizon("SAMPLE_INVESTMENT_HORIZON");
        tfesProduct.setSettlementPeriod(1);
        tfesProduct.setLaunchDate("SAMPLE_LAUNCH_DATE");
        tfesProduct.setRiskProfile("SAMPLE_RISK_PROFILE");
        tfesProduct.setBenchmark("SAMPLE_BENCHMARK");
        tfesProduct.setFundObjective("SAMPLE_FUND_OBJECTIVE");
        tfesProduct.setMinSubscriptionAmount(BigDecimal.valueOf(12345));
        tfesProduct.setMaxSubscriptionAmount(BigDecimal.valueOf(12345));
        tfesProduct.setMinSubscriptionTopup(BigDecimal.valueOf(12345));
        tfesProduct.setMaxSubscriptionTopup(BigDecimal.valueOf(12345));
        tfesProduct.setMinRedemptionUnit(BigDecimal.valueOf(12345));
        tfesProduct.setMaxRedemptionUnit(BigDecimal.valueOf(12345));
        tfesProduct.setMinRedemptionAmount(BigDecimal.valueOf(12345));
        tfesProduct.setMaxRedemptionAmount(BigDecimal.valueOf(12345));
        tfesProduct.setMinBalAfterRedemptionAmount(BigDecimal.valueOf(12345));
        tfesProduct.setMinBalAfterRedemptionUnit(BigDecimal.valueOf(12345));
        tfesProduct.setInitialNav(BigDecimal.valueOf(12345));
        tfesProduct.setAllowSubscription("SAMPLE_ALLOW_SUBSCRIPTION");
        tfesProduct.setAllowRedemption("SAMPLE_ALLOW_REDEMPTION");
        tfesProduct.setRspFlag("SAMPLE_RSP_FLAG");
        tfesProduct.setLatestNav(BigDecimal.valueOf(12345));
        tfesProduct.setTaxApplied("SAMPLE_TAX_APPLIED");
        tfesProduct.setTaxRate(BigDecimal.valueOf(12345));
        tfesProduct.setUnitRounding(1);
        tfesProduct.setUnitDecimal(1);
        tfesProduct.setManagementFee(BigDecimal.valueOf(12345));
        tfesProduct.setInvestmentOutlet("SAMPLE_INVESTMENT_OUTLET");
        tfesProduct.setMinHoldingPeriod(1);
        tfesProduct.setRedemptionFee(1);
        tfesProduct.setFeeChargeFrom("SAMPLE_FEE_CHARGE_FROM");
        tfesProduct.setProductStatus("SAMPLE_PRODUCT_STATUS");
        tfesProduct.setProductType("SAMPLE_PRODUCT_TYPE");
        
    	tfesProductsResponse.setReturnCode("SAMPLE_RETURN_CODE");
    	tfesProductsResponse.setReturnDescription("SAMPLE_RETURN_DESCRIPTION");
    	tfesProductsResponse.setProducts(new ArrayList<>());
        
        tfesSuitabilityExpirationResponse.setLastSAFUpdateDate("SAMPLE_DATE");
        tfesSuitabilityExpirationResponse.setReturnCode("SAMPLE_RETURN_CODE");
        tfesSuitabilityExpirationResponse.setReturnDescription("SAMPLE_RETURN_DESCRIPTION");
        
        tfesCommonTransactionResponse.setDateTimeStamp("SAMPLE_TIMESTAMP");
        tfesCommonTransactionResponse.setDebitAccountName("SAMPLE_DEBIT_ACCOUNT_NAME");
        tfesCommonTransactionResponse.setReturnCode("SAMPLE_RETURN_CODE");
        tfesCommonTransactionResponse.setTransactionNumber("SAMPLE_TRANSACTION_NUMBER");
        tfesCommonTransactionResponse.setSettlementDate("SAMPLE_SETTLEMENT_DATE");
        tfesCommonTransactionResponse.setCustomerNumber("SAMPLE_CUSTOMER_NUMBER");
        tfesCommonTransactionResponse.setMaskedSettlementAccountNumber("SAMPLE_MASKED_SETTLEMENT_ACCOUNT_NUMBER");
        tfesCommonTransactionResponse.setReturnDescription("SAMPLE_RETURN_DESC");
        
        tfesClientProductRiskProfileResponse.setRiskProfileCode("SAMPLE_RISK_PROFILE_RESULT_CODE");

        tfesInvestmentAccountDetailsResponse.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        tfesInvestmentAccountDetailsResponse.setReturnCode("SAMPLE_RETURN_CODE");
        tfesInvestmentAccountDetailsResponse.setAccountType("SAMPLE_ACCOUNT_TYPE");
        tfesInvestmentAccountDetailsResponse.setCurrencyCode("SAMPLE_CURRENCY_CODE");
        tfesInvestmentAccountDetailsResponse.setInvestmentAccountName("SAMPLE_INVESTMENT_ACCOUNT_NAME");
        tfesInvestmentAccountDetailsResponse.setInvestmentSummaryDetails(new ArrayList<>());
        tfesInvestmentAccountDetailsResponse.setLastSAFUpdateDate("SAMPLE_DATE");
        tfesInvestmentAccountDetailsResponse.setServicingBranch("SAMPLE_SERVICING_BRANCH");
        tfesInvestmentAccountDetailsResponse.setTotalMarketValue(BigDecimal.valueOf(1234));

        tfesInvestmentAccountSummaryDetailResponse.setInvestmentAccounts(new ArrayList<>());
        tfesInvestmentAccountSummaryDetailResponse.setLastSAFUpdateDate("SAMPLE_DATE");
        tfesInvestmentAccountSummaryDetailResponse.setReturnCode("SAMPLE_RETURN_CODE");

        tfesTransactionDetailsResponse.setReturnCode("SAMPLE_RETURN_CODE");
        tfesTransactionDetailsResponse.setReturnDescription("SAMPLE_RETURN_DESCRIPTION");
        tfesTransactionDetailsResponse.setTransactions(new ArrayList<>());
        
        tfesUpdateSuitabilityAssessmentResponse.setRiskProfile("SAMPLE_RISK_PROFILE");

        transaction.setNumOfUnits(1345L);
        transaction.setProduct("SAMPLE_PRODUCT");
        transaction.setNavpuRate(BigDecimal.valueOf(12345));
        transaction.setSalesCode("SAMPLE_SALES_CODE");
        transaction.setSalesName("SAMPLE_SALES_NAME");
        transaction.setSettlementAmount(BigDecimal.valueOf(12345));
        transaction.setTransactionDate(new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        transaction.setTransactionNumber("SAMPLE_TRANSCTION_NUMBER");
        transaction.setTransactionType("SAMPLE_TRANSACTION_TYPE");

        validateOrSendOTPResponse.setnToken("SAMPLE_TOKEN");
        validateOrSendOTPResponse.setAmount(BigDecimal.valueOf(12345));
        validateOrSendOTPResponse.setMaskedMobileNumber("SAMPLE_MASKED_MOBILE_NUMBER");
        validateOrSendOTPResponse.setOtpGenId("SAMPLE_OTP_GEN_ID");
        validateOrSendOTPResponse.setReferenceNo("SAMPLE_REFERENCE_NO");
        validateOrSendOTPResponse.setTransactionDate("SAMPLE_TRANSACTION_DATE");

        wsStatus.setErrorMessage("SAMPLE_ERROR_MESSAGE");
        wsStatus.setSOAResponseCode("SAMPLE_SOAP_RESPONSE)_CODE");
        wsStatus.setTransactionStatus("SAMPLE_TRANSACTION_STATUS");
    }

    @Test
    public void testAuthCode() {

        Assert.assertEquals("", format.toString());

        Assert.assertNotNull(authCode.getCode());
        Assert.assertNotNull(authCode.getOtpGenId());
        Assert.assertNotNull(authCode.isResend());

        Assert.assertNotNull(investmentAccount.getInvestmentAccountNumber());
        Assert.assertNotNull(investmentAccount.getInvestmentAccountName());
        Assert.assertNotNull(investmentAccount.getJointAccount());
        Assert.assertNotNull(investmentAccount.getStatementAddress());
        Assert.assertNotNull(investmentAccount.getAccountType());
        Assert.assertNotNull(investmentAccount.getCurrencyCode());
        Assert.assertNotNull(investmentAccount.getServicingBranch());
        Assert.assertNotNull(investmentAccount.getTotalMarketValue());

        Assert.assertNotNull(customerDetails.getCustomerNo());
        Assert.assertNotNull(customerDetails.getBirthDate());
        Assert.assertNotNull(customerDetails.getCustomerName());
        Assert.assertNotNull(customerDetails.getEmailAddress());
        Assert.assertNotNull(customerDetails.getMobileNumber());
        Assert.assertNotNull(customerDetails.getRelConnectorCode());
        Assert.assertNotNull(customerDetails.getTin());
        Assert.assertNotNull(new CustomerDetails("2", "asd", "asd", "asd", "asd", "asd", "asd"));

        Assert.assertNotNull(accountsModel.getDlId());
        Assert.assertNotNull(accountsModel.getAccountRef());
        Assert.assertNotNull(accountsModel.getMerchantId());
        Assert.assertNotNull(accountsModel.getOwner());
        Assert.assertNotNull(accountsModel.getDateExpired());
        Assert.assertNotNull(accountsModel.getDateModified());
        Assert.assertNotNull(accountsModel.isDeleteFlag());
        Assert.assertNotNull(accountsModel.getRmNumber());
        Assert.assertNotNull(accountsModel.getAccountNo());
        Assert.assertNotNull(accountsModel.getDateExpired());
        Assert.assertNotNull(accountsModel.getReferenceNo());
        Assert.assertNotNull(accountsModel.getOwner());
        Assert.assertNotNull(accountsModel.getExternalUserId());
        Assert.assertNotNull(accountsModel.getToken());
        Assert.assertNotNull(accountsModel.getDateCreated());
        
        Assert.assertNotNull(configurationModel.getExpiryDays());
        Assert.assertNotNull(configurationModel.getMerchantId());
        Assert.assertNotNull(configurationModel.getMerchantName());
        Assert.assertNotNull(configurationModel.getMerchantAlias());
        Assert.assertNotNull(configurationModel.getAggregateLimitAccount());
        Assert.assertNotNull(configurationModel.getAggregateLimitUser());
        Assert.assertNotNull(configurationModel.getMaxLinkedAccounts());
        Assert.assertNotNull(configurationModel.getTxnRenewalCriteria());
        Assert.assertNotNull(configurationModel.getBankPublicKey());
        Assert.assertNotNull(configurationModel.getBankPrivateKey());
        Assert.assertNotNull(configurationModel.getMerchantPublicKey());
        Assert.assertNotNull(configurationModel.toString());

        Assert.assertNotNull(request.getUserId());
        Assert.assertNotNull(request.getSignValue());
        Assert.assertNotNull(request.getSaltValue());
        Assert.assertNotNull(request.getRmNumber());
        Assert.assertNotNull(request.getInvestmentAccountNumber());
        Assert.assertNotNull(request.getProductCode());
        Assert.assertNotNull(request.getPtaNumber());
        Assert.assertNotNull(request.getSettlementAccountNumber());
        Assert.assertNotNull(request.getTransactionType());
        Assert.assertNotNull(request.getOrderDate());
        Assert.assertNotNull(request.getAmount());
        Assert.assertNotNull(request.getRspAmount());
        Assert.assertNotNull(request.getInstallmentPeriod());
        Assert.assertNotNull(request.getInstallmentDate());
        Assert.assertNotNull(request.getRemarks());
        Assert.assertNotNull(request.getIsBeyondCutOff());

        Assert.assertNotNull(bindResponse.getAccountRef());
        Assert.assertNotNull(bindResponse.getReferenceNo());
        Assert.assertNotNull(bindResponse.getToken());

        Assert.assertNotNull(genericResponse.getMessage());
        Assert.assertNotNull(genericResponse.getDate());
        Assert.assertNotNull(genericResponse.getProgramName());
        Assert.assertNotNull(genericResponse.getBody());
        Assert.assertNotNull(new GenericResponse());

        Assert.assertNotNull(otResponse.getAmount());
        Assert.assertNotNull(otResponse.getReferenceNo());
        Assert.assertNotNull(otResponse.getTransactionDate());
        Assert.assertNotNull(otResponse.getMaskedMobileNumber());
        Assert.assertNotNull(otResponse.getnToken());

        Assert.assertNotNull(commonAccountDetailRequest.getReferenceNo());

        Assert.assertNotNull(investmentAccountDetailsRequest.getInvestmentAccountNumber());
        Assert.assertNotNull(investmentAccountDetailsRequest.getProductCode());
        Assert.assertNotNull(investmentAccountDetailsRequest.getRmNumber());

        Assert.assertNotNull(investmentAccountSummaryDetailRequest.getRmNumber());
        Assert.assertNotNull(investmentAccountSummaryDetailRequest.getSettlementAccountNumber());
        
        Assert.assertNotNull(investmentProductModel.getInvestmentAccountNumber());
        Assert.assertNotNull(investmentProductModel.getProductCode());

        Assert.assertNotNull(question.getQuestionId());
        Assert.assertNotNull(question.getAnswerId());
        
        Assert.assertNotNull(tfesCommonRequestModel.getSaltValue());
        Assert.assertNotNull(tfesCommonRequestModel.getSignValue());
        Assert.assertNotNull(tfesCommonRequestModel.getUserId());

        Assert.assertNotNull(tfesInvestmentAccountDetailsRequest.getSettlementAccountNumber());
        Assert.assertNotNull(tfesInvestmentAccountDetailsRequest.getRmNumber());
        Assert.assertNotNull(tfesInvestmentAccountDetailsRequest.getProductCode());

        Assert.assertNotNull(tfesTransactionDetailsRequest.getInvestmentAccountNumber());
        Assert.assertNotNull(tfesTransactionDetailsRequest.getAsOfDate());
        
        Assert.assertNotNull(tfesUpdateSuitabilityAssessmentRequest.getQuestionnaireId());
        Assert.assertNotNull(tfesUpdateSuitabilityAssessmentRequest.getQuestions());
        Assert.assertNotNull(tfesUpdateSuitabilityAssessmentRequest.getRmNumber());
        Assert.assertNotNull(tfesUpdateSuitabilityAssessmentRequest.getUserId());
        Assert.assertNotNull(tfesUpdateSuitabilityAssessmentRequest.getSaltValue());
        Assert.assertNotNull(tfesUpdateSuitabilityAssessmentRequest.getSignValue());

        Assert.assertNotNull(enrollTrustAccountRequest.getRmNumber());
        Assert.assertNotNull(enrollTrustAccountRequest.getSaltValue());
        Assert.assertNotNull(enrollTrustAccountRequest.getSettlementAccountNumber());
        Assert.assertNotNull(enrollTrustAccountRequest.getSignValue());
        Assert.assertNotNull(enrollTrustAccountRequest.getSystemID());
        Assert.assertNotNull(enrollTrustAccountRequest.getUserId());

        Assert.assertNotNull(createRedemptionRequest.getAmountOrUnits());
        Assert.assertNotNull(createRedemptionRequest.getInvestmentAccountNumber());
        Assert.assertNotNull(createRedemptionRequest.getIsBeyondCutOff());
        Assert.assertNotNull(createRedemptionRequest.getOrderDate());
        Assert.assertNotNull(createRedemptionRequest.getProductCode());
        Assert.assertNotNull(createRedemptionRequest.getRedemptionType());
        Assert.assertNotNull(createRedemptionRequest.getRemarks());
        Assert.assertNotNull(createRedemptionRequest.getRmNumber());
        Assert.assertNotNull(createRedemptionRequest.getSettlementAccountNumber());
        Assert.assertNotNull(createRedemptionRequest.getTransactionType());

        Assert.assertNotNull(createRedemptionPayload.getAmountOrUnits());
        Assert.assertNotNull(createRedemptionPayload.getAuth());
        Assert.assertNotNull(createRedemptionPayload.getExternalUserId());
        Assert.assertNotNull(createRedemptionPayload.getInvestmentAccountNumber());
        Assert.assertNotNull(createRedemptionPayload.getIsBeyondCutoff());
        Assert.assertNotNull(createRedemptionPayload.getOrderDate());
        Assert.assertNotNull(createRedemptionPayload.getProductCode());
        Assert.assertNotNull(createRedemptionPayload.getRedemptionType());
        Assert.assertNotNull(createRedemptionPayload.getReferenceNo());
        Assert.assertNotNull(createRedemptionPayload.getRemarks());
        Assert.assertNotNull(createRedemptionPayload.getToken());

        Assert.assertNotNull(createSubscriptionPayload.getAmount());
        Assert.assertNotNull(createSubscriptionPayload.getAuth());
        Assert.assertNotNull(createSubscriptionPayload.getExternalUserId());
        Assert.assertNotNull(createSubscriptionPayload.getInitial());
        Assert.assertNotNull(createSubscriptionPayload.getInstallmentDate());
        Assert.assertNotNull(createSubscriptionPayload.getInstallmentPeriod());
        Assert.assertNotNull(createSubscriptionPayload.getInvestmentAccountNumber());
        Assert.assertNotNull(createSubscriptionPayload.getIsBeyondCutoff());
        Assert.assertNotNull(createSubscriptionPayload.getOrderDate());
        Assert.assertNotNull(createSubscriptionPayload.getProductCode());
        Assert.assertNotNull(createSubscriptionPayload.getPtaNumber());
        Assert.assertNotNull(createSubscriptionPayload.getReferenceNo());
        Assert.assertNotNull(createSubscriptionPayload.getRemarks());
        Assert.assertNotNull(createSubscriptionPayload.getToken());
        Assert.assertNotNull(createSubscriptionPayload.isInitial());

        Assert.assertNotNull(createRedemptionResponse.getData());
        Assert.assertNotNull(createRedemptionResponse.getTransactionDate());

        Assert.assertNotNull(createSubscriptionResponse.getData());
        Assert.assertNotNull(createSubscriptionResponse.getTransactionDate());

        Assert.assertNotNull(enrollTrustAccountResponse.getReturnCode());
        Assert.assertNotNull(enrollTrustAccountResponse.getInvestmentAccounts());
        Assert.assertNotNull(enrollTrustAccountResponse.getSettlementAccountName());
        Assert.assertNotNull(new EnrollTrustAccountResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC", new ArrayList<>()));

        Assert.assertNotNull(investmentSummaryDetail.getAbsoluteROI());
        Assert.assertNotNull(investmentSummaryDetail.getAverageCost());
        Assert.assertNotNull(investmentSummaryDetail.getMarketValue());
        Assert.assertNotNull(investmentSummaryDetail.getNavpuRate());
        Assert.assertNotNull(investmentSummaryDetail.getOutstandingUnits());
        Assert.assertNotNull(investmentSummaryDetail.getPercentOfTotal());
        Assert.assertNotNull(investmentSummaryDetail.getProduct());
        Assert.assertNotNull(investmentSummaryDetail.getPtaNumber());
        Assert.assertNotNull(investmentSummaryDetail.getUnrealizedGainLoss());
        
        Assert.assertNotNull(tranCodesResponse.getTransactionCode());
        Assert.assertNotNull(tranCodesResponse.getTransactionDesc());
        Assert.assertNotNull(tranCodesResponse.getReturnCode());
        Assert.assertNotNull(tranCodesResponse.getReturnDescription());
        
        Assert.assertNotNull(unbindResponse.getTransactionCode());
        Assert.assertNotNull(unbindResponse.getTransactionDesc());

        Assert.assertNotNull(validateDlsResponse.getData());
        Assert.assertNotNull(validateDlsResponse.getTransactionDate());

        Assert.assertNotNull(tfesProduct.getProductId());
        Assert.assertNotNull(tfesProduct.getProductCode());
        Assert.assertNotNull(tfesProduct.getProductName());
        Assert.assertNotNull(tfesProduct.getCutOffTime());
        Assert.assertNotNull(tfesProduct.getProductTypeName());
        Assert.assertNotNull(tfesProduct.getCurrency());
        Assert.assertNotNull(tfesProduct.getInvestmentHorizon());
        Assert.assertNotNull(tfesProduct.getSettlementPeriod());
        Assert.assertNotNull(tfesProduct.getLaunchDate());
        Assert.assertNotNull(tfesProduct.getRiskProfile());
        Assert.assertNotNull(tfesProduct.getBenchmark());
        Assert.assertNotNull(tfesProduct.getFundObjective());
        Assert.assertNotNull(tfesProduct.getMinSubscriptionAmount());
        Assert.assertNotNull(tfesProduct.getMaxSubscriptionAmount());
        Assert.assertNotNull(tfesProduct.getMinSubscriptionTopup());
        Assert.assertNotNull(tfesProduct.getMaxSubscriptionTopup());
        Assert.assertNotNull(tfesProduct.getMinRedemptionUnit());
        Assert.assertNotNull(tfesProduct.getMaxRedemptionUnit());
        Assert.assertNotNull(tfesProduct.getMinRedemptionAmount());
        Assert.assertNotNull(tfesProduct.getMaxRedemptionAmount());
        Assert.assertNotNull(tfesProduct.getMinBalAfterRedemptionAmount());
        Assert.assertNotNull(tfesProduct.getMinBalAfterRedemptionUnit());
        Assert.assertNotNull(tfesProduct.getInitialNav());
        Assert.assertNotNull(tfesProduct.getAllowSubscription());
        Assert.assertNotNull(tfesProduct.getAllowRedemption());
        Assert.assertNotNull(tfesProduct.getRspFlag());
        Assert.assertNotNull(tfesProduct.getLatestNav());
        Assert.assertNotNull(tfesProduct.getTaxApplied());
        Assert.assertNotNull(tfesProduct.getTaxRate());
        Assert.assertNotNull(tfesProduct.getUnitRounding());
        Assert.assertNotNull(tfesProduct.getUnitDecimal());
        Assert.assertNotNull(tfesProduct.getManagementFee());
        Assert.assertNotNull(tfesProduct.getInvestmentOutlet());
        Assert.assertNotNull(tfesProduct.getMinHoldingPeriod());
        Assert.assertNotNull(tfesProduct.getRedemptionFee());
        Assert.assertNotNull(tfesProduct.getFeeChargeFrom());
        Assert.assertNotNull(tfesProduct.getProductStatus());
        Assert.assertNotNull(tfesProduct.getProductType());

        Assert.assertNotNull(tfesProductsResponse.getReturnCode());
        Assert.assertNotNull(tfesProductsResponse.getReturnDescription());
        Assert.assertNotNull(tfesProductsResponse.getProducts());
        Assert.assertNotNull(new TfesProductsResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC"));
        Assert.assertNotNull(new TfesProductsResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC", new ArrayList<>()));

        Assert.assertNotNull(tfesSuitabilityExpirationResponse.getLastSAFUpdateDate());
        Assert.assertNotNull(tfesSuitabilityExpirationResponse.getReturnCode());
        Assert.assertNotNull(tfesSuitabilityExpirationResponse.getReturnDescription());
        Assert.assertNotNull(new TfesSuitabilityExpirationResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC", 
        		"SAMPLE_LAST_SAF_UPDATE_DATE"));
        
        Assert.assertNotNull(tfesCommonTransactionResponse.getDateTimeStamp());
        Assert.assertNotNull(tfesCommonTransactionResponse.getDebitAccountName());
        Assert.assertNotNull(tfesCommonTransactionResponse.getReturnCode());
        Assert.assertNotNull(tfesCommonTransactionResponse.getTransactionNumber());
        Assert.assertNotNull(tfesCommonTransactionResponse.getSettlementDate());
        Assert.assertNotNull(tfesCommonTransactionResponse.getCustomerNumber());
        Assert.assertNotNull(tfesCommonTransactionResponse.getMaskedSettlementAccountNumber());
        Assert.assertNotNull(tfesCommonTransactionResponse.getReturnDescription());
        Assert.assertNotNull(new TfesCommonTransactionResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC"));
        Assert.assertNotNull(new TfesCommonTransactionResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC", "SAMPLE_RM_NUMBER",
        		"SAMPLE_MASKED_SETTLEMENT_ACCOUNT_NUMBER"));
        Assert.assertNotNull(new TfesCommonTransactionResponse(validateOrSendOTPResponse));
         
        Assert.assertNotNull(tfesClientProductRiskProfileResponse.getRiskProfileCode());
        Assert.assertNotNull(new TfesClientProductRiskProfileResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC"));
        Assert.assertNotNull(new TfesClientProductRiskProfileResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC",
        		"SAMPLE_RISK_PROFILE_RESULT_CODE"));

        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getInvestmentAccountNumber());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getReturnCode());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getAccountType());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getCurrencyCode());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getInvestmentAccountName());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getInvestmentSummaryDetails());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getLastSAFUpdateDate());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getServicingBranch());
        Assert.assertNotNull(tfesInvestmentAccountDetailsResponse.getTotalMarketValue());

        Assert.assertNotNull(tfesInvestmentAccountSummaryDetailResponse.getInvestmentAccounts());
        Assert.assertNotNull(tfesInvestmentAccountSummaryDetailResponse.getLastSAFUpdateDate());
        Assert.assertNotNull(tfesInvestmentAccountSummaryDetailResponse.getReturnCode());

        Assert.assertNotNull(tfesTransactionDetailsResponse.getReturnCode());
        Assert.assertNotNull(tfesTransactionDetailsResponse.getReturnDescription());
        Assert.assertNotNull(tfesTransactionDetailsResponse.getTransactions());
        
        Assert.assertNotNull(tfesUpdateSuitabilityAssessmentResponse.getRiskProfile());
        Assert.assertNotNull(new TfesUpdateSuitabilityAssessmentResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC"));
        Assert.assertNotNull(new TfesUpdateSuitabilityAssessmentResponse("SAMPLE_TRANSACTION_CODE", "SAMPLE_TRANSACTION_DESC",
        		"SAMPLE_RISK_PROFILE"));

        Assert.assertNotNull(transaction.getNavpuRate());
        Assert.assertNotNull(transaction.getNumOfUnits());
        Assert.assertNotNull(transaction.getProduct());
        Assert.assertNotNull(transaction.getSalesCode());
        Assert.assertNotNull(transaction.getSalesName());
        Assert.assertNotNull(transaction.getSettlementAmount());
        Assert.assertNotNull(transaction.getTransactionDate());
        Assert.assertNotNull(transaction.getTransactionNumber());
        Assert.assertNotNull(transaction.getTransactionType());

        Assert.assertNotNull(validateOrSendOTPResponse.getnToken());
        Assert.assertNotNull(validateOrSendOTPResponse.getAmount());
        Assert.assertNotNull(validateOrSendOTPResponse.getMaskedMobileNumber());
        Assert.assertNotNull(validateOrSendOTPResponse.getReferenceNo());
        Assert.assertNotNull(validateOrSendOTPResponse.getOtpGenId());
        Assert.assertNotNull(validateOrSendOTPResponse.getTransactionDate());

        Assert.assertNotNull(wsStatus.getErrorMessage());
        Assert.assertNotNull(wsStatus.getSOAResponseCode());
        Assert.assertNotNull(wsStatus.getTransactionStatus());

    }

    @Test(expected = IllegalStateException.class)
    public void testTraceLog(){
        TraceLog traceLog = new TraceLog();
    }


}
