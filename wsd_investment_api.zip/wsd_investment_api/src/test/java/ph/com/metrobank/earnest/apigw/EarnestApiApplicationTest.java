package ph.com.metrobank.earnest.apigw;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EarnestApiApplicationTest {
	
    @Test
    public void contextLoads(){
		EarnestApiApplication.main(new String[] {});
        Assert.assertNotEquals(1, 2);
    }
}
