package ph.com.metrobank.earnest.apigw.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.CreateSubscriptionResponse;
import ph.com.metrobank.earnest.apigw.services.TransactionService;
import ph.com.metrobank.earnest.apigw.services.impl.GenerateUUIDService;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;

import java.util.Date;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
public class TransactionControllerTest {
    @Mock
    GenerateUUIDService generateUUIDService;
    @Mock
    TransactionService transactionService;
    private ObjectMapper mapper = new ObjectMapper();
    @Mock
    private LoggingService loggingService;
    private TransactionController controller;

    private MockMvc mockMvc;

    //Mocked Objects
    private DirectLinkRequestCommonModel directLinkRequestCommonModel;
    private TfesCommonTransactionResponse response;
    private String uuid;
    private String accessToken;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        controller = new TransactionController(generateUUIDService, loggingService, transactionService);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("endpoint.url", "/investments")
                .build();

        directLinkRequestCommonModel = new DirectLinkRequestCommonModel();
        directLinkRequestCommonModel.setChannelId("SAMPLE_CHANNEL_ID");
        directLinkRequestCommonModel.setData("SAMPLE_DATA");
        directLinkRequestCommonModel.setSignature("SAMPLE_SIGNATURE");

        response = new TfesCommonTransactionResponse();
        response.setTransactionCode("transaction code");
        response.setTransactionDesc("transaction desc");
        response.setTransactionDate(new Date().toString());

        uuid = UUID.randomUUID().toString();
        accessToken = "accessToken";
    }

    @Test
    public void createSubscription() throws Exception {

        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(transactionService.createSubscription(any(), anyString())).thenReturn(response);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/create-subscription")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(transactionService, atLeastOnce()).createSubscription(any(), anyString());
    }

    @Test
    public void createRedemption() throws Exception {
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(transactionService.createRedemption(any(), anyString())).thenReturn(response);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/create-redemption")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(transactionService, atLeastOnce()).createRedemption(any(), anyString());
    }
}
