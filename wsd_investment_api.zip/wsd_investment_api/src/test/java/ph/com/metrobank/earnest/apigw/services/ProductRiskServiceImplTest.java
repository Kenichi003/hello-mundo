package ph.com.metrobank.earnest.apigw.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesInvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesUpdateSuitabilityAssessmentRequest;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.services.impl.ProductRiskServiceImpl;
import ph.com.metrobank.earnest.apigw.services.impl.TranCodeLogResponseHelper;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class ProductRiskServiceImplTest {
	
	@Mock
	private DirectLinkService directLinkService;

	@Mock
	private LoggingService loggingService;

	@Mock
	private TfesService tfesService;

	@Mock
	private TranCodeLogResponseHelper tranCodeLogResponseHelper;
	
	private ProductRiskService productRiskService;
	private DirectLinkRequestCommonModel directLinkRequestCommonModel;
	
	private final ObjectMapper mapper = new ObjectMapper();
	
    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        productRiskService = new ProductRiskServiceImpl(directLinkService, loggingService, tfesService, tranCodeLogResponseHelper);
        
        directLinkRequestCommonModel = new DirectLinkRequestCommonModel();
		directLinkRequestCommonModel.setChannelId("SAMPLE_CHANNEL_ID");
        directLinkRequestCommonModel.setData("SAMPLE_DATA");
        directLinkRequestCommonModel.setSignature("SAMPLE_SIGNATURE");
    }
    
    @Test
    public void testValidateClientProductRiskProfile() throws Exception {
		TfesClientProductRiskProfileResponse tfesClientProductRiskProfileResponse = new TfesClientProductRiskProfileResponse();
		tfesClientProductRiskProfileResponse.setReturnCode("9700002");
		tfesClientProductRiskProfileResponse.setRiskProfileCode("SAMPLE_RISK_PROFILE_RESULT_CODE");
		tfesClientProductRiskProfileResponse.setTransactionDesc(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
		tfesClientProductRiskProfileResponse.setTransactionCode(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
    	
    	AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        accountsModel.setRmNumber("1234576");
        
        InvestmentAccountDetailsRequest investmentAccountDetailsRequest = new InvestmentAccountDetailsRequest();
        investmentAccountDetailsRequest.setRmNumber(accountsModel.getRmNumber());
        investmentAccountDetailsRequest.setInvestmentAccountNumber("123123123123");
        investmentAccountDetailsRequest.setToken("SAMPLE_TOKEN");
        investmentAccountDetailsRequest.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        investmentAccountDetailsRequest.setProductCode("SAMPLE_PRODUCT_CODE");
        
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(investmentAccountDetailsRequest));
    	
    	when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
    	when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
    	when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
    	when(tfesService.validateClientProductRiskProfile(any(TfesInvestmentAccountDetailsRequest.class), anyString())).thenReturn(
    			ResponseEntity.ok(tfesClientProductRiskProfileResponse));
    	
    	TfesClientProductRiskProfileResponse response = productRiskService.validateClientProductRiskProfile(
    			directLinkRequestCommonModel, UUID.randomUUID().toString());
    	
    	verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        verify(tfesService, atLeastOnce()).validateClientProductRiskProfile(any(TfesInvestmentAccountDetailsRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
    }
    
    @Test
    public void testValidateClientProductRiskProfileOnNonExistentAccount() throws Exception {
        InvestmentAccountDetailsRequest investmentAccountDetailsRequest = new InvestmentAccountDetailsRequest();
        investmentAccountDetailsRequest.setRmNumber("1234576");
        investmentAccountDetailsRequest.setInvestmentAccountNumber("123123123123");
        investmentAccountDetailsRequest.setToken("SAMPLE_TOKEN");
        investmentAccountDetailsRequest.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        investmentAccountDetailsRequest.setProductCode("SAMPLE_PRODUCT_CODE");
        
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(investmentAccountDetailsRequest));
    	
    	when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
    	when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
    	when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(null);
    	
    	TfesClientProductRiskProfileResponse response = productRiskService.validateClientProductRiskProfile(
    			directLinkRequestCommonModel, UUID.randomUUID().toString());
    	
    	verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
    }
    
    @Test
    public void testUpdateSuitabilityAssessment() throws Exception {
    	TfesUpdateSuitabilityAssessmentResponse tfesUpdateSuitabilityAssessmentResponse = new TfesUpdateSuitabilityAssessmentResponse();
    	tfesUpdateSuitabilityAssessmentResponse.setReturnCode("9700002");
    	tfesUpdateSuitabilityAssessmentResponse.setTransactionDesc(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
    	tfesUpdateSuitabilityAssessmentResponse.setTransactionCode(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
    	
    	AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        accountsModel.setRmNumber("1234576");
        
        TfesUpdateSuitabilityAssessmentRequest tfesUpdateSuitabilityAssessmentRequest = new TfesUpdateSuitabilityAssessmentRequest();
        tfesUpdateSuitabilityAssessmentRequest.setToken("SAMPLE_TOKEN");
        tfesUpdateSuitabilityAssessmentRequest.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        tfesUpdateSuitabilityAssessmentRequest.setQuestionnaireId("SAMPLE_QUESTIONNAIRE_ID");
        tfesUpdateSuitabilityAssessmentRequest.setQuestionnaireId("SAMPLE_QUESTIONNAIRE_ID");
        tfesUpdateSuitabilityAssessmentRequest.setQuestions(new ArrayList<>());
        
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(tfesUpdateSuitabilityAssessmentRequest));
    	
    	when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
    	when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
    	when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
    	when(tfesService.updateSuitabilityAssessment(any(TfesUpdateSuitabilityAssessmentRequest.class), anyString())).thenReturn(
    			ResponseEntity.ok(tfesUpdateSuitabilityAssessmentResponse));
    	
    	TfesUpdateSuitabilityAssessmentResponse response = productRiskService.updateSuitabilityAssessment(
    			directLinkRequestCommonModel, UUID.randomUUID().toString());
    	
    	verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        verify(tfesService, atLeastOnce()).updateSuitabilityAssessment(any(TfesUpdateSuitabilityAssessmentRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
    }
    
    @Test
    public void testUpdateSuitabilityAssessmentOnNonExistentAccount() throws Exception {
        TfesUpdateSuitabilityAssessmentRequest tfesUpdateSuitabilityAssessmentRequest = new TfesUpdateSuitabilityAssessmentRequest();
        tfesUpdateSuitabilityAssessmentRequest.setToken("SAMPLE_TOKEN");
        tfesUpdateSuitabilityAssessmentRequest.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        tfesUpdateSuitabilityAssessmentRequest.setQuestionnaireId("SAMPLE_QUESTIONNAIRE_ID");
        tfesUpdateSuitabilityAssessmentRequest.setQuestionnaireId("SAMPLE_QUESTIONNAIRE_ID");
        tfesUpdateSuitabilityAssessmentRequest.setQuestions(new ArrayList<>());
        
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(tfesUpdateSuitabilityAssessmentRequest));
    	
    	when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
    	when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
    	when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(null);
    	
    	TfesUpdateSuitabilityAssessmentResponse response = productRiskService.updateSuitabilityAssessment(
    			directLinkRequestCommonModel, UUID.randomUUID().toString());
    	
    	verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
    }
    
    @Test
    public void testGetSuitabilityAssessmentResults() throws Exception {
    	TfesProductsResponse tfesProductsResponse = new TfesProductsResponse();
    	tfesProductsResponse.setReturnCode("9700002");
    	tfesProductsResponse.setTransactionDesc(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
    	tfesProductsResponse.setTransactionCode(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
    	
    	AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        accountsModel.setRmNumber("1234576");
        
        InvestmentAccountDetailsRequest investmentAccountDetailsRequest = new InvestmentAccountDetailsRequest();
        investmentAccountDetailsRequest.setRmNumber(accountsModel.getRmNumber());
        investmentAccountDetailsRequest.setInvestmentAccountNumber("123123123123");
        investmentAccountDetailsRequest.setToken("SAMPLE_TOKEN");
        investmentAccountDetailsRequest.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        investmentAccountDetailsRequest.setProductCode("SAMPLE_PRODUCT_CODE");
        
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(investmentAccountDetailsRequest));
    	
    	when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
    	when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
    	when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
    	when(tfesService.getSuitabilityAssessmentResults(any(TfesInvestmentAccountDetailsRequest.class), anyString())).thenReturn(
    			ResponseEntity.ok(tfesProductsResponse));
    	
    	TfesProductsResponse response = productRiskService.getSuitabilityAssessmentResults(directLinkRequestCommonModel, 
    			UUID.randomUUID().toString());
    	
    	verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        verify(tfesService, atLeastOnce()).getSuitabilityAssessmentResults(any(TfesInvestmentAccountDetailsRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
    }
    
    @Test
    public void testGetSuitabilityAssessmentResultsOnNonExistentAccount() throws Exception {
    	AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        accountsModel.setRmNumber("1234576");
        
        InvestmentAccountDetailsRequest investmentAccountDetailsRequest = new InvestmentAccountDetailsRequest();
        investmentAccountDetailsRequest.setRmNumber(accountsModel.getRmNumber());
        investmentAccountDetailsRequest.setInvestmentAccountNumber("123123123123");
        investmentAccountDetailsRequest.setToken("SAMPLE_TOKEN");
        investmentAccountDetailsRequest.setExternalUserId("SAMPLE_EXTERNAL_USER_ID");
        investmentAccountDetailsRequest.setProductCode("SAMPLE_PRODUCT_CODE");
        
        ValidateDlsResponse validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(investmentAccountDetailsRequest));
    	
    	when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
    	when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
    	when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(null);
    	
    	TfesProductsResponse response = productRiskService.getSuitabilityAssessmentResults(directLinkRequestCommonModel, 
    			UUID.randomUUID().toString());
    	
    	verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
    }
}
