package ph.com.metrobank.earnest.apigw.configs;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ph.com.metrobank.earnest.apigw.config.SwaggerConfig;

@RunWith(SpringJUnit4ClassRunner.class)
public class SwaggerConfigTest {

    @Test
    public void testSwaggerConfig() {
        SwaggerConfig config = new SwaggerConfig();
        Assert.assertNotNull(config.apiInfo());
        Assert.assertNotNull(config.mobileToCasaApi());
    }
}
