package ph.com.metrobank.earnest.apigw.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.services.impl.TranCodeLogResponseHelper;

@RunWith(SpringJUnit4ClassRunner.class)
public class TranCodeLogResponseHelperTest {
	@Mock
	private LoggingService loggingService;
	private TranCodeLogResponseHelper tranCodeLogResponseHelper;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		tranCodeLogResponseHelper = new TranCodeLogResponseHelper();
		ReflectionTestUtils.setField(tranCodeLogResponseHelper, "loggingService", loggingService);
	}
	
	@Test
	public void testSetAndLogValidTranCode() {
		TranCodesResponse tranCodesResponse = new TranCodesResponse();
		tranCodesResponse.setReturnDescription(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
		tranCodesResponse.setReturnCode("9700002");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		tranCodeLogResponseHelper.setAndLogTranCode(tranCodesResponse, TraceLog.APIGW_DATA_CONTROLLER_CREATE_INVESTMENT_ACCOUNT, 
				this.getClass().toString(), UUID.randomUUID().toString());
		
		Assert.assertEquals(tranCodesResponse.getTransactionCode(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
		Assert.assertEquals(tranCodesResponse.getTransactionDesc(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
	} 
	
	@Test
	public void testSetAndLogInvalidTranCode() {
		TranCodesResponse tranCodesResponse = new TranCodesResponse();
		tranCodesResponse.setReturnDescription(null);
		tranCodesResponse.setReturnCode("000");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		tranCodeLogResponseHelper.setAndLogTranCode(tranCodesResponse, TraceLog.APIGW_DATA_CONTROLLER_CREATE_INVESTMENT_ACCOUNT, 
				this.getClass().toString(), UUID.randomUUID().toString());
		
		Assert.assertEquals(tranCodesResponse.getTransactionCode(), TransactionCode.UNMAPPED_ERROR.getTransactionCode());
		Assert.assertEquals(tranCodesResponse.getTransactionDesc(), TransactionCode.UNMAPPED_ERROR.getTransactionDesc());
	}
}
