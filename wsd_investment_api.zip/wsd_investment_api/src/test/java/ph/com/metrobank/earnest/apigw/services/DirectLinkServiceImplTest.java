package ph.com.metrobank.earnest.apigw.services;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;
import ph.com.metrobank.earnest.apigw.config.DirectLinkServiceConfiguration;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.ValidateOrSendOTPResponse;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;
import ph.com.metrobank.earnest.apigw.services.impl.DirectLinkServiceImpl;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;

import java.util.Date;
import java.util.concurrent.CompletableFuture;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
public class DirectLinkServiceImplTest {

    @Mock
    DirectLinkServiceConfiguration dlsConfig;
    @Mock
    LoggingService loggingService;
    @Mock
    @Qualifier("restTemplateApigw")
    private RestTemplate restTemplate;
    private DirectLinkServiceImpl directLinkService;

    private ValidateDlsResponse validateDlsResponse;
    private DirectLinkRequestCommonModel directLinkRequestCommonModel;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        directLinkService = new DirectLinkServiceImpl(restTemplate, dlsConfig, loggingService);

        directLinkRequestCommonModel = new DirectLinkRequestCommonModel();
        directLinkRequestCommonModel.setChannelId("SAMPLE_CHANNEL_ID");
        directLinkRequestCommonModel.setData("SAMPLE_DATA");
        directLinkRequestCommonModel.setSignature("SAMPLE_SIGNATURE");

        validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData("SAMPLE_DATA");
        validateDlsResponse.setTransactionDate(new Date().toString());
    }

    @Test
    public void decryptRequest() throws Exception {
        when(restTemplate.exchange(anyString(), any(), any(), (Class<Object>) any()))
                .thenReturn(new ResponseEntity(validateDlsResponse, HttpStatus.OK));
        when(dlsConfig.getDecryptRequestUrl()).thenReturn("DECRYPT_URL");

        ResponseEntity<ValidateDlsResponse> response =
                directLinkService.decryptRequest(directLinkRequestCommonModel, "");
        Assert.assertNotNull(response.getBody());
    }

    @Test
    public void validateOrSendOTP() throws Exception {
        ValidateOrSendOTPResponse validateOrSendOTPResponse = new ValidateOrSendOTPResponse();
        validateOrSendOTPResponse.setTransactionCode("011");
        validateOrSendOTPResponse.setTransactionDesc("VALID OTP");
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), ArgumentMatchers.<Class<?>>any()))
                .thenReturn(new ResponseEntity(validateOrSendOTPResponse, HttpStatus.OK));
        when(dlsConfig.getValidateOrSendOtpUrl()).thenReturn("GET_VALIDATE_OR_SEND_OTP_URL");
        ResponseEntity<ValidateOrSendOTPResponse> response = directLinkService.validateOrSendOTP(directLinkRequestCommonModel, "");
        Assert.assertTrue(response.getBody().getTransactionCode().equals(validateOrSendOTPResponse.getTransactionCode()));
    }
    
    @Test
    public void getAccountByTokenAndExternalUserId() {
    	AccountsModel accountsModel = new AccountsModel();
    	accountsModel.setAccountNo("1111111111111");
		accountsModel.setAccountRef("1111");
		accountsModel.setDateCreated(new Date());
		accountsModel.setDateExpired(new Date());
		accountsModel.setDateModified(new Date());
		accountsModel.setDeleteFlag(false);
		accountsModel.setDlId("1");
		accountsModel.setExternalUserId("testexternaluserid");
		accountsModel.setMerchantId("JVZ");
		accountsModel.setOwner("testowner");
		accountsModel.setToken("testtoken");
		
		when(restTemplate.getForObject(anyString(), ArgumentMatchers.<Class<AccountsModel>>any()))
			.thenReturn(accountsModel);
		when(dlsConfig.getAccountByTokenAndExternalUserId("testtoken", "testexternaluserid")).thenReturn("GET_ACCOUNT_BY_TOKEN_EXTERNAL_USER_ID");
		
		AccountsModel response  = directLinkService.getAccountByTokenAndExternalUserId("testtoken", "testexternaluserid", "1");
		assertEquals("1111111111111", response.getAccountNo());
    }
}