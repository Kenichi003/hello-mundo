package ph.com.metrobank.earnest.apigw.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import ph.com.metrobank.earnest.apigw.config.TfesConfig;
import ph.com.metrobank.earnest.apigw.model.request.CreateRedemptionRequest;
import ph.com.metrobank.earnest.apigw.model.request.CreateSubscriptionRequest;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountSummaryDetailRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesCommonRequestModel;
import ph.com.metrobank.earnest.apigw.model.request.TfesInvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesTransactionDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesUpdateSuitabilityAssessmentRequest;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.services.impl.TfesServiceImpl;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TfesServiceImplTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private TfesConfig tfesConfig;

    @Mock
    private LoggingService loggingService;

    private TfesService tfesService;

    String rmNumber;
    String settlementAccountNumber;
    String uuid;
    String uri;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        tfesService = new TfesServiceImpl(restTemplate, tfesConfig, loggingService);

        rmNumber = "test_rm_number";
        settlementAccountNumber = "test_settlement_account_number";
        uuid = "uuid";
        uri = "uri";
    }

    @Test
    public void testEnrollTrustAccountSuccess() throws InterruptedException, ExecutionException, DecoderException, UnsupportedEncodingException {
        EnrollTrustAccountResponse expected = new EnrollTrustAccountResponse();
        expected.setInvestmentAccounts(new ArrayList<>());

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(tfesConfig.getSystemId()).thenReturn("systemId");
        when(tfesConfig.getSaltValue()).thenReturn("saltValue");
        when(tfesConfig.getSignValue()).thenReturn("signValue");
        when(tfesConfig.getEnrollTrustAccount()).thenReturn("enrolltrustaccounturi");
        when(restTemplate.exchange(anyString(), any(), any(), (Class<Object>) any()))
            .thenReturn(new ResponseEntity(expected, HttpStatus.OK));

        ResponseEntity<EnrollTrustAccountResponse> result =
                tfesService.enrollTrustAccount(rmNumber, settlementAccountNumber, uuid);

        Assert.assertNotNull(result.getBody());
    }
    
    @Test
    public void testEnrollTrustAccountFail() throws InterruptedException, ExecutionException, DecoderException, UnsupportedEncodingException {
        EnrollTrustAccountResponse expected = new EnrollTrustAccountResponse();
        expected.setInvestmentAccounts(new ArrayList<>());

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(tfesConfig.getSystemId()).thenReturn("systemId");
        when(tfesConfig.getSaltValue()).thenReturn("saltValue");
        when(tfesConfig.getSignValue()).thenReturn("signValue");
        when(tfesConfig.getEnrollTrustAccount()).thenReturn("enrolltrustaccounturi");
        when(restTemplate.exchange(anyString(), any(), any(), (Class<Object>) any())).thenThrow(RestClientException.class);

        tfesService.enrollTrustAccount(rmNumber, settlementAccountNumber, uuid);

        MockRestServiceServer server = MockRestServiceServer.createServer(restTemplate);
		server.expect(requestTo(tfesConfig.getEnrollTrustAccount())).andRespond(withServerError());
    }
    
    @Test
    public void testCreateSubscription() throws InterruptedException, ExecutionException, DecoderException, UnsupportedEncodingException {
        EnrollTrustAccountResponse expected = new EnrollTrustAccountResponse();
        CreateSubscriptionRequest request = new CreateSubscriptionRequest();

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(restTemplate.exchange(anyString(), any(), any(), (Class<Object>) any()))
            .thenReturn(new ResponseEntity(expected, HttpStatus.OK));

        ResponseEntity<TfesCommonTransactionResponse> result =
            tfesService.createSubscription(request, uri, uuid);

        Assert.assertNotNull(result.getBody());
    }

    @Test
    public void testCreateRedemption() throws InterruptedException, ExecutionException, DecoderException, UnsupportedEncodingException {
        TfesCommonTransactionResponse response = new TfesCommonTransactionResponse();
        CreateRedemptionRequest request = new CreateRedemptionRequest();

        when(tfesConfig.getCreateRedemption()).thenReturn("");
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(restTemplate.exchange(anyString(), any(), any(), (Class<Object>) any()))
            .thenReturn(new ResponseEntity(response, HttpStatus.OK));

        ResponseEntity<TfesCommonTransactionResponse> result =
            tfesService.createRedemption(request, uuid);

        Assert.assertNotNull(result.getBody());
    }

    @Test
    public void getInvestmentAccountSummaryDetail() throws Exception{
        InvestmentAccountSummaryDetailRequest investmentAccountSummaryDetailRequest = new InvestmentAccountSummaryDetailRequest();
        investmentAccountSummaryDetailRequest.setRmNumber("123456");
        investmentAccountSummaryDetailRequest.setSettlementAccountNumber("1903190244564");
        TfesInvestmentAccountSummaryDetailResponse tfesInvestmentAccountSummaryDetailResponse = new TfesInvestmentAccountSummaryDetailResponse();
        tfesInvestmentAccountSummaryDetailResponse.setReturnCode("9700002");
        tfesInvestmentAccountSummaryDetailResponse.setLastSAFUpdateDate(new Date().toString());
        tfesInvestmentAccountSummaryDetailResponse.setInvestmentAccounts(null);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), ArgumentMatchers.<Class<?>>any()))
                .thenReturn(new ResponseEntity(tfesInvestmentAccountSummaryDetailResponse, HttpStatus.OK));
        when(tfesConfig.getSystemId()).thenReturn("systemId");
        when(tfesConfig.getSaltValue()).thenReturn("saltValue");
        when(tfesConfig.getSignValue()).thenReturn("signValue");

        ResponseEntity investmentAccountSummaryDetail = tfesService.getInvestmentAccountSummaryDetail(investmentAccountSummaryDetailRequest, UUID.randomUUID().toString());

        verify(tfesConfig, atMost(1)).getInvestmentAccountSummaryDetailUrl();

    }

    @Test
    public void getTransactionDetails() throws Exception{
        TfesTransactionDetailsRequest ttdRequest = new TfesTransactionDetailsRequest();

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), ArgumentMatchers.<Class<?>>any()))
                .thenReturn(new ResponseEntity(ttdRequest, HttpStatus.OK));
        when(tfesConfig.getSystemId()).thenReturn("systemId");
        when(tfesConfig.getSaltValue()).thenReturn("saltValue");
        when(tfesConfig.getSignValue()).thenReturn("signValue");

        ResponseEntity response = tfesService.getTransactionDetails(ttdRequest, UUID.randomUUID().toString());
        verify(tfesConfig, atMost(1)).getTransactionDetailUrl();

    }

    @Test
    public void getInvestmentAccountDetailsWithExistingData() throws Exception{
        TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
        tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
        tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");

        TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        tfesInvestmentAccountDetailsResponse.setReturnCode("9700002");
        tfesInvestmentAccountDetailsResponse.setInvestmentAccountNumber(tfesInvestmentAccountDetailsRequest.getInvestmentAccountNumber());


        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), ArgumentMatchers.<Class<?>>any()))
                .thenReturn(new ResponseEntity(tfesInvestmentAccountDetailsResponse, HttpStatus.OK));
        when(tfesConfig.getSystemId()).thenReturn("systemId");
        when(tfesConfig.getSaltValue()).thenReturn("saltValue");
        when(tfesConfig.getSignValue()).thenReturn("signValue");
        when(tfesConfig.getInvestmentAccountDetailsUrl()).thenReturn("sample_url");

        ResponseEntity investmentAccountSummaryDetail = tfesService.getInvestmentAccountDetails(tfesInvestmentAccountDetailsRequest, UUID.randomUUID().toString());

        TfesInvestmentAccountDetailsResponse response = (TfesInvestmentAccountDetailsResponse) investmentAccountSummaryDetail.getBody();
        verify(tfesConfig, atMost(1)).getInvestmentAccountDetailsUrl();
        Assert.assertFalse(response.getReturnCode().equals("9700006"));

    }
    @Test
    public void getInvestmentAccountDetailsWithoutExistingData() throws Exception{
        TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
        tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
        tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        tfesInvestmentAccountDetailsResponse.setReturnCode("9700006");
        when(tfesConfig.getInvestmentAccountDetailsUrl()).thenReturn("sample_url");


        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), ArgumentMatchers.<Class<?>>any()))
                .thenReturn(new ResponseEntity(tfesInvestmentAccountDetailsResponse, HttpStatus.OK));
        when(tfesConfig.getSystemId()).thenReturn("systemId");
        when(tfesConfig.getSaltValue()).thenReturn("saltValue");
        when(tfesConfig.getSignValue()).thenReturn("signValue");

        ResponseEntity investmentAccountSummaryDetail = tfesService.getInvestmentAccountDetails(tfesInvestmentAccountDetailsRequest, UUID.randomUUID().toString());

        TfesInvestmentAccountDetailsResponse response = (TfesInvestmentAccountDetailsResponse) investmentAccountSummaryDetail.getBody();
        verify(tfesConfig, atMost(1)).getInvestmentAccountDetailsUrl();
        Assert.assertEquals("9700006", response.getReturnCode());

    }
    
	@Test
	public void getProductDetails() throws Exception {
		TfesCommonRequestModel request = new TfesCommonRequestModel();

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenReturn(new ResponseEntity(request, HttpStatus.OK));
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");

		ResponseEntity response = tfesService.getInvestmentProducts(UUID.randomUUID().toString());
		verify(tfesConfig, atMost(1)).getTransactionDetailUrl();

	}
	
	@Test
	public void getProductDetailsFailToRetrieveProduct() throws Exception {
		TfesCommonRequestModel request = new TfesCommonRequestModel();

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenThrow(RestClientException.class);
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getInvestmentProductsUrl()).thenReturn("sample_url");

		tfesService.getInvestmentProducts(UUID.randomUUID().toString());
		
		MockRestServiceServer server = MockRestServiceServer.createServer(restTemplate);
		server.expect(requestTo(tfesConfig.getInvestmentProductsUrl())).andRespond(withServerError());
	}
	
	@Test
	public void testGetSuitabilityExpirationDate() throws Exception {
		TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
		tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
		tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
		
		TfesSuitabilityExpirationResponse tfesSuitabilityExpirationResponse = new TfesSuitabilityExpirationResponse();
		tfesSuitabilityExpirationResponse.setReturnCode("9700002");
		tfesSuitabilityExpirationResponse.setLastSAFUpdateDate(new Date().toString());
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenReturn(new ResponseEntity(tfesSuitabilityExpirationResponse, HttpStatus.OK));
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getSuitabilityExpirationDateUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		ResponseEntity suitabilityExpirationDetails = tfesService.getSuitabilityExpirationDate(tfesInvestmentAccountDetailsRequest, 
				UUID.randomUUID().toString());
		
		TfesSuitabilityExpirationResponse response = (TfesSuitabilityExpirationResponse) suitabilityExpirationDetails.getBody();
		verify(tfesConfig, atMost(1)).getSuitabilityExpirationDateUrl();
		Assert.assertFalse(response.getReturnCode().equals("9700006"));
	}
	
	@Test
	public void testGetSuitabilityExpirationDateFailToRetrieveData() throws Exception {
		TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
		tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
		tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
		
		TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        tfesInvestmentAccountDetailsResponse.setReturnCode("9700002");
        tfesInvestmentAccountDetailsResponse.setInvestmentAccountNumber(tfesInvestmentAccountDetailsRequest.getInvestmentAccountNumber());
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenThrow(RestClientException.class);
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getSuitabilityExpirationDateUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		tfesService.getSuitabilityExpirationDate(tfesInvestmentAccountDetailsRequest, UUID.randomUUID().toString());
		
		MockRestServiceServer server = MockRestServiceServer.createServer(restTemplate);
		server.expect(requestTo(tfesConfig.getSuitabilityExpirationDateUrl())).andRespond(withServerError());
	}
	
	@Test
	public void testValidateClientProductRiskProfile() throws Exception {
		TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
		tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
		tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
		
		TfesClientProductRiskProfileResponse tfesClientProductRiskProfileResponse = new TfesClientProductRiskProfileResponse();
		tfesClientProductRiskProfileResponse.setReturnCode("9700002");
		tfesClientProductRiskProfileResponse.setRiskProfileCode("SAMPLE_RISK_PROFILE_RESULT_CODE");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenReturn(new ResponseEntity(tfesClientProductRiskProfileResponse, HttpStatus.OK));
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getValidateClientProductRiskProfileUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		ResponseEntity clientProductRiskProfileDetails = tfesService.validateClientProductRiskProfile(tfesInvestmentAccountDetailsRequest, 
				UUID.randomUUID().toString());
		
		TfesClientProductRiskProfileResponse response = (TfesClientProductRiskProfileResponse) clientProductRiskProfileDetails.getBody();
		verify(tfesConfig, atMost(1)).getValidateClientProductRiskProfileUrl();
		Assert.assertFalse(response.getReturnCode().equals("9700006"));
	}
	
	@Test
	public void testValidateClientProductRiskProfileFailToValidate() throws Exception {
		TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
		tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
		tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
		
		TfesClientProductRiskProfileResponse tfesClientProductRiskProfileResponse = new TfesClientProductRiskProfileResponse();
		tfesClientProductRiskProfileResponse.setReturnCode("9700002");
		tfesClientProductRiskProfileResponse.setRiskProfileCode("SAMPLE_RISK_PROFILE_RESULT_CODE");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenThrow(RestClientException.class);
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getValidateClientProductRiskProfileUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		tfesService.validateClientProductRiskProfile(tfesInvestmentAccountDetailsRequest,  UUID.randomUUID().toString());
		
		MockRestServiceServer server = MockRestServiceServer.createServer(restTemplate);
		server.expect(requestTo(tfesConfig.getValidateClientProductRiskProfileUrl())).andRespond(withServerError());
	}
	
	@Test
	public void testUpdateSuitabilityAssessment() throws Exception {
		TfesUpdateSuitabilityAssessmentRequest tfesUpdateSuitabilityAssessmentRequest = new TfesUpdateSuitabilityAssessmentRequest();
		tfesUpdateSuitabilityAssessmentRequest.setRmNumber("SAMPLE_RM_NUMBER");
		tfesUpdateSuitabilityAssessmentRequest.setQuestionnaireId("SAMPLE_QUESTIONNAIRE_ID");
		tfesUpdateSuitabilityAssessmentRequest.setQuestions(new ArrayList<>());
		
		TfesUpdateSuitabilityAssessmentResponse tfesUpdateSuitabilityAssessmentResponse = new TfesUpdateSuitabilityAssessmentResponse();
		tfesUpdateSuitabilityAssessmentResponse.setReturnCode("9700002");
		tfesUpdateSuitabilityAssessmentResponse.setRiskProfile("SAMPLE_RISK_PROFILE");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenReturn(new ResponseEntity(tfesUpdateSuitabilityAssessmentResponse, HttpStatus.OK));
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getUpdateSuitabilityAssessmentFormUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		ResponseEntity updateSuitabilityAssessmentDetails = tfesService.updateSuitabilityAssessment(tfesUpdateSuitabilityAssessmentRequest, 
				UUID.randomUUID().toString());
		
		TfesUpdateSuitabilityAssessmentResponse response = (TfesUpdateSuitabilityAssessmentResponse) updateSuitabilityAssessmentDetails
				.getBody();
		verify(tfesConfig, atMost(1)).getUpdateSuitabilityAssessmentFormUrl();
		Assert.assertFalse(response.getReturnCode().equals("9700006"));
	}
	
	@Test
	public void testUpdateSuitabilityAssessmentFailToUpdate() throws Exception {
		TfesUpdateSuitabilityAssessmentRequest tfesUpdateSuitabilityAssessmentRequest = new TfesUpdateSuitabilityAssessmentRequest();
		tfesUpdateSuitabilityAssessmentRequest.setRmNumber("SAMPLE_RM_NUMBER");
		tfesUpdateSuitabilityAssessmentRequest.setQuestionnaireId("SAMPLE_QUESTIONNAIRE_ID");
		tfesUpdateSuitabilityAssessmentRequest.setQuestions(new ArrayList<>());
		
		TfesUpdateSuitabilityAssessmentResponse tfesUpdateSuitabilityAssessmentResponse = new TfesUpdateSuitabilityAssessmentResponse();
		tfesUpdateSuitabilityAssessmentResponse.setReturnCode("9700002");
		tfesUpdateSuitabilityAssessmentResponse.setRiskProfile("SAMPLE_RISK_PROFILE");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenThrow(RestClientException.class);
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getUpdateSuitabilityAssessmentFormUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		tfesService.updateSuitabilityAssessment(tfesUpdateSuitabilityAssessmentRequest, UUID.randomUUID().toString());
		MockRestServiceServer server = MockRestServiceServer.createServer(restTemplate);
		server.expect(requestTo(tfesConfig.getUpdateSuitabilityAssessmentFormUrl())).andRespond(withServerError());
	}
	
	@Test
	public void testGetSuitabilityAssessmentResults() throws Exception {
		TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
		tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
        tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        tfesInvestmentAccountDetailsResponse.setReturnCode("9700002");
		
        TfesProductsResponse tfesProductsResponse = new TfesProductsResponse();
        tfesProductsResponse.setReturnCode("9700002");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenReturn(new ResponseEntity(tfesProductsResponse, HttpStatus.OK));
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getAssessmentResultPerProductUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		ResponseEntity suitabilityAssessmentResultDetails = tfesService.getSuitabilityAssessmentResults(
				tfesInvestmentAccountDetailsRequest, UUID.randomUUID().toString());
		
		TfesProductsResponse response = (TfesProductsResponse) suitabilityAssessmentResultDetails.getBody();
		verify(tfesConfig, atMost(1)).getAssessmentResultPerProductUrl();
		Assert.assertFalse(response.getReturnCode().equals("9700006"));
	}

	@Test
	public void testGetSuitabilityAssessmentResultsFailToGetAssessmentResults() throws Exception {
		TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
		tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber("SAMPLE_SETTLEMENT_ACCOUNT_NUMBER");
        tfesInvestmentAccountDetailsRequest.setInvestmentAccountNumber("SAMPLE_INVESTMENT_ACCOUNT_NUMBER");
        TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        tfesInvestmentAccountDetailsResponse.setReturnCode("9700002");
		
        TfesProductsResponse tfesProductsResponse = new TfesProductsResponse();
        tfesProductsResponse.setReturnCode("9700002");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class),
				ArgumentMatchers.<Class<?>>any())).thenThrow(RestClientException.class);
		when(tfesConfig.getSystemId()).thenReturn("systemId");
		when(tfesConfig.getSaltValue()).thenReturn("saltValue");
		when(tfesConfig.getSignValue()).thenReturn("signValue");
		when(tfesConfig.getAssessmentResultPerProductUrl()).thenReturn("sample_url");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		
		tfesService.getSuitabilityAssessmentResults(tfesInvestmentAccountDetailsRequest, UUID.randomUUID().toString());
		MockRestServiceServer server = MockRestServiceServer.createServer(restTemplate);
		server.expect(requestTo(tfesConfig.getAssessmentResultPerProductUrl())).andRespond(withServerError());
	}
}
