package ph.com.metrobank.earnest.apigw.services;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ph.com.metrobank.earnest.apigw.services.impl.GenerateUUIDService;

import java.util.UUID;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
public class GenerateUUIDServiceTest {

    private GenerateUUIDService generateUUIDService;

    @Before
    public void setUp() throws Exception {
        generateUUIDService = new GenerateUUIDService();
    }

    @Test
    public void generateUUID() {
        String generatedUUID = generateUUIDService.generateUUID();
        Assert.assertNotNull(generatedUUID);
        Assert.assertNotEquals(generatedUUID, "");
        Assert.assertEquals(generatedUUID, UUID.fromString(generatedUUID).toString());
    }
}