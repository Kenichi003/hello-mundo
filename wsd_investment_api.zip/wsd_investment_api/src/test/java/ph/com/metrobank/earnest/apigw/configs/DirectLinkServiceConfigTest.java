package ph.com.metrobank.earnest.apigw.configs;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import ph.com.metrobank.earnest.apigw.config.DirectLinkServiceConfiguration;
import ph.com.metrobank.earnest.apigw.config.TfesConfig;

@RunWith(SpringJUnit4ClassRunner.class)
public class DirectLinkServiceConfigTest {

    DirectLinkServiceConfiguration config = new DirectLinkServiceConfiguration();
    TfesConfig tfesConfig = new TfesConfig();
    @Before
    public void setUp() {
        ReflectionTestUtils.setField(config, "baseUrl", "https://api-oic-stg2-uat.metrobank.ph:443/directlink");
        ReflectionTestUtils.setField(config, "decryptRequestUrl", "/decryptRequest");
        ReflectionTestUtils.setField(config, "validateOrSendOtpUrl", "/validateOrSendOTP");
        ReflectionTestUtils.setField(config, "accountByTokenAndExternalUserId", "/getAccountByTokenAndExternalUserId");
        ReflectionTestUtils.setField(tfesConfig, "enrollTrustAccount", "http://172.26.68.42:9080/avantrade/services/create/invAccount");
        ReflectionTestUtils.setField(tfesConfig, "createInitialSubscription", "http://172.26.68.42:9080/avantrade/services/transaction/subscription-list");
        ReflectionTestUtils.setField(tfesConfig, "createAdditionalSubscription", "http://172.26.68.42:9080/avantrade/services/transaction/add-subscription-list");
        ReflectionTestUtils.setField(config, "configuration", "/getSettings");

    }

    @Test
    public void testDirectLinkConfig() {
        Assert.assertEquals(tfesConfig.getCreateAdditionalSubscription(), "http://172.26.68.42:9080/avantrade/services/transaction/add-subscription-list");
        Assert.assertEquals(tfesConfig.getCreateInitialSubscription(), "http://172.26.68.42:9080/avantrade/services/transaction/subscription-list");
        Assert.assertEquals(config.getDecryptRequestUrl(), "https://api-oic-stg2-uat.metrobank.ph:443/directlink/decryptRequest");
        Assert.assertEquals(config.getBaseUrl(), "https://api-oic-stg2-uat.metrobank.ph:443/directlink");
        Assert.assertEquals(config.getValidateOrSendOtpUrl(), "https://api-oic-stg2-uat.metrobank.ph:443/directlink/validateOrSendOTP");
        Assert.assertEquals(config.getAccountByTokenAndExternalUserId("token", "externalUserId"), "https://api-oic-stg2-uat.metrobank.ph:443/directlink/getAccountByTokenAndExternalUserId/token/externalUserId");
        Assert.assertEquals(tfesConfig.getEnrollTrustAccount(), "http://172.26.68.42:9080/avantrade/services/create/invAccount");
        Assert.assertEquals(config.getConfiguration(), "https://api-oic-stg2-uat.metrobank.ph:443/directlink/getSettings/ERN");
        Assert.assertNotNull(config.verifyApplicationProperties());
    }
}
 