package ph.com.metrobank.earnest.apigw.utils;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ph.com.metrobank.earnest.apigw.exceptions.ErrorCodeNotFoundException;
import ph.com.metrobank.earnest.apigw.exceptions.base.*;
import ph.com.metrobank.earnest.apigw.exceptions.tfes.InvalidMinimumRspAmountException;
import ph.com.metrobank.earnest.apigw.util.ControllerUtil;

@RunWith(SpringJUnit4ClassRunner.class)
public class ControllerUtilTest {

    @Test
    public void testHandleError() {
        ResponseEntity badRequest = ControllerUtil.handleThrowableErrors(new InvalidMinimumRspAmountException());
        ResponseEntity forbidden = ControllerUtil.handleThrowableErrors(new ForbiddenBaseException(""));
        ResponseEntity unauthorized = ControllerUtil.handleThrowableErrors(new UnauthorizedBaseException(""));
        ResponseEntity notFound = ControllerUtil.handleThrowableErrors(new ErrorCodeNotFoundException());
        ResponseEntity notFound2 = ControllerUtil.handleThrowableErrors(new ErrorCodeNotFoundException(""));
        ResponseEntity internalServerError = ControllerUtil.handleThrowableErrors(new InternalServerBaseException(""));

        Assert.assertEquals(badRequest.getStatusCode(), HttpStatus.BAD_REQUEST);
        Assert.assertEquals(forbidden.getStatusCode(), HttpStatus.FORBIDDEN);
        Assert.assertEquals(unauthorized.getStatusCode(), HttpStatus.UNAUTHORIZED);
        Assert.assertEquals(notFound.getStatusCode(), HttpStatus.NOT_FOUND);
        Assert.assertEquals(notFound2.getStatusCode(), HttpStatus.NOT_FOUND);
        Assert.assertEquals(internalServerError.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
