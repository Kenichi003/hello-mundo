package ph.com.metrobank.earnest.apigw.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.request.CommonAccountDetailRequest;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.TfesInvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.services.impl.SuitabilityAssessmentServiceImpl;
import ph.com.metrobank.earnest.apigw.services.impl.TranCodeLogResponseHelper;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class SuitabilityAssessmentServiceImplTest {
	
	@Mock
	private DirectLinkService directLinkService;

	@Mock
	private LoggingService loggingService;
	
	@Mock
	private TfesService tfesService;
	
	@Mock
	private TranCodeLogResponseHelper tranCodeLogResponseHelper;
	
	private SuitabilityAssessmentService suitabilityAssessmentService;
	private DirectLinkRequestCommonModel directLinkRequestCommonModel;
	private CommonAccountDetailRequest commonAccountDetailRequest;
	private ValidateDlsResponse validateDlsResponse;
	
	private final ObjectMapper mapper = new ObjectMapper();
	
	@Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        suitabilityAssessmentService = new SuitabilityAssessmentServiceImpl(directLinkService, loggingService, tfesService, 
        		tranCodeLogResponseHelper);
        
        directLinkRequestCommonModel = new DirectLinkRequestCommonModel();
		directLinkRequestCommonModel.setChannelId("SAMPLE_CHANNEL_ID");
        directLinkRequestCommonModel.setData("SAMPLE_DATA");
        directLinkRequestCommonModel.setSignature("SAMPLE_SIGNATURE");
        
        commonAccountDetailRequest = new CommonAccountDetailRequest();
        commonAccountDetailRequest.setToken("SAMPLE_TOKEN");
        commonAccountDetailRequest.setExternalUserId("f3303d68-f708-11e9-8f0b-362b9e155667");
        
        validateDlsResponse = new ValidateDlsResponse();
        validateDlsResponse.setData(mapper.writeValueAsString(commonAccountDetailRequest));
    }
	
	@Test
	public void testGetSuitabilityExpirationWithExistingAccountAndInvalidAuthentication() throws Exception {
		TfesSuitabilityExpirationResponse tfesSuitabilityExpirationResponse = new TfesSuitabilityExpirationResponse();
        tfesSuitabilityExpirationResponse.setLastSAFUpdateDate(new Date().toString());
		tfesSuitabilityExpirationResponse.setReturnCode("9700001");
		tfesSuitabilityExpirationResponse.setTransactionCode(TransactionCode.INVALID_AUTHENTICATION.getTransactionCode());
		tfesSuitabilityExpirationResponse.setTransactionDesc(TransactionCode.INVALID_AUTHENTICATION.getTransactionDesc());
		
		AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        accountsModel.setRmNumber("1234576");
        
        TfesInvestmentAccountDetailsRequest investmentAccountDetailsRequest;
        investmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
        investmentAccountDetailsRequest.setRmNumber(accountsModel.getRmNumber());
        investmentAccountDetailsRequest.setInvestmentAccountNumber("123123123123");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getSuitabilityExpirationDate(any(TfesInvestmentAccountDetailsRequest.class), anyString()))
        	.thenReturn(ResponseEntity.ok(tfesSuitabilityExpirationResponse));

        TfesSuitabilityExpirationResponse response = suitabilityAssessmentService
        		.getSuitabilityExpiration(directLinkRequestCommonModel, UUID.randomUUID().toString());
        
		verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        verify(tfesService, atLeastOnce()).getSuitabilityExpirationDate(any(TfesInvestmentAccountDetailsRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_AUTHENTICATION.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_AUTHENTICATION.getTransactionCode());
	}
	
	@Test
	public void testGetSuitabilityExpirationWithExistingAccountAndIsSuccessfullyProcessed() throws Exception {
		TfesSuitabilityExpirationResponse tfesSuitabilityExpirationResponse = new TfesSuitabilityExpirationResponse();
        tfesSuitabilityExpirationResponse.setLastSAFUpdateDate(new Date().toString());
		tfesSuitabilityExpirationResponse.setReturnCode("9700002");
		tfesSuitabilityExpirationResponse.setTransactionCode(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
		tfesSuitabilityExpirationResponse.setTransactionDesc(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
		
		AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        accountsModel.setRmNumber("1234576");
        
        TfesInvestmentAccountDetailsRequest investmentAccountDetailsRequest;
        investmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
        investmentAccountDetailsRequest.setRmNumber(accountsModel.getRmNumber());
        investmentAccountDetailsRequest.setInvestmentAccountNumber("123123123123");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getSuitabilityExpirationDate(any(TfesInvestmentAccountDetailsRequest.class), anyString()))
        	.thenReturn(ResponseEntity.ok(tfesSuitabilityExpirationResponse));

        TfesSuitabilityExpirationResponse response = suitabilityAssessmentService
        		.getSuitabilityExpiration(directLinkRequestCommonModel, UUID.randomUUID().toString());
        
		verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        verify(tfesService, atLeastOnce()).getSuitabilityExpirationDate(any(TfesInvestmentAccountDetailsRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
	}
	
	@Test
	public void testGetSuitabilityExpirationWithExistingAccountAndHasUnmappedError() throws Exception {
		TfesSuitabilityExpirationResponse tfesSuitabilityExpirationResponse = new TfesSuitabilityExpirationResponse();
        tfesSuitabilityExpirationResponse.setLastSAFUpdateDate(new Date().toString());
		tfesSuitabilityExpirationResponse.setReturnCode("00000");
		tfesSuitabilityExpirationResponse.setTransactionCode(TransactionCode.UNMAPPED_ERROR.getTransactionCode());
		tfesSuitabilityExpirationResponse.setTransactionDesc(TransactionCode.UNMAPPED_ERROR.getTransactionDesc());
		
		AccountsModel accountsModel = new AccountsModel();
        accountsModel.setAccountNo("1903190244564");
        accountsModel.setRmNumber("1234576");
        
        TfesInvestmentAccountDetailsRequest investmentAccountDetailsRequest;
        investmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
        investmentAccountDetailsRequest.setRmNumber(accountsModel.getRmNumber());
        investmentAccountDetailsRequest.setInvestmentAccountNumber("123123123123");
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(tfesService.getSuitabilityExpirationDate(any(TfesInvestmentAccountDetailsRequest.class), anyString()))
        	.thenReturn(ResponseEntity.ok(tfesSuitabilityExpirationResponse));

        TfesSuitabilityExpirationResponse response = suitabilityAssessmentService
        		.getSuitabilityExpiration(directLinkRequestCommonModel, UUID.randomUUID().toString());
        
		verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());
        verify(tfesService, atLeastOnce()).getSuitabilityExpirationDate(any(TfesInvestmentAccountDetailsRequest.class), anyString());
        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.UNMAPPED_ERROR.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.UNMAPPED_ERROR.getTransactionCode());
	}
	
	@Test
	public void testGetSuitabilityExpirationWithNonExistentAccount() throws Exception {
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(directLinkService.decryptRequest(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(
        		ResponseEntity.ok(validateDlsResponse));
        when(directLinkService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(null);

        TfesSuitabilityExpirationResponse response = suitabilityAssessmentService
        		.getSuitabilityExpiration(directLinkRequestCommonModel, UUID.randomUUID().toString());
        
		verify(directLinkService, atLeastOnce()).decryptRequest(any(DirectLinkRequestCommonModel.class), anyString());
        verify(directLinkService, atLeastOnce()).getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString());

        Assert.assertEquals(response.getTransactionDesc(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
        Assert.assertEquals(response.getTransactionCode(), TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode());
	}
}
