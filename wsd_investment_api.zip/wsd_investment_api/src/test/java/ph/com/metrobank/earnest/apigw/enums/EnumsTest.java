package ph.com.metrobank.earnest.apigw.enums;

import static ph.com.metrobank.earnest.apigw.enums.CurrencyCode.PHP;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.earnest.apigw.exceptions.CurrencyCodeNotFoundException;
import ph.com.metrobank.earnest.apigw.exceptions.ErrorCodeNotFoundException;

@RunWith(SpringJUnit4ClassRunner.class)
public class EnumsTest {
    @Test
    public void testEnums() {
        Assert.assertFalse(TransactionCode.contains("99999"));
        Assert.assertTrue(TransactionCode.contains("00017"));
        Assert.assertTrue(PHP.getCurrencyCode().equalsIgnoreCase("PHP"));
        Assert.assertTrue(TransactionCode.fromExternalTransactionCode("9700002").isPresent());
    }
    @Test(expected = CurrencyCodeNotFoundException.class)
    public void testEnumsFailedCurrencyCode() {
        CurrencyCode.getCurrencyValueByProductType(234123);
    }

    @Test
    public void testEnumsSuccessCurerncy() {
        Assert.assertEquals(PHP.getCurrencyValue(), CurrencyCode.getCurrencyValueByProductType(3));
    }

    @Test(expected = ErrorCodeNotFoundException.class)
    public void transactionCodeFailed(){
        TransactionCode.getAsError(null);
    }

}
