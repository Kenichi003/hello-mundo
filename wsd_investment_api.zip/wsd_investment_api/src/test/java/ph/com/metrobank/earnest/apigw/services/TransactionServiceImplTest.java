package ph.com.metrobank.earnest.apigw.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.PENDING_OTP;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;

import ph.com.metrobank.earnest.apigw.config.DirectLinkServiceConfiguration;
import ph.com.metrobank.earnest.apigw.config.TfesConfig;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.ConfigurationModel;
import ph.com.metrobank.earnest.apigw.model.ValidateOrSendOTPResponse;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;
import ph.com.metrobank.earnest.apigw.model.subscription.InvestmentAccount;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.services.impl.TransactionServiceImpl;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TransactionServiceImplTest {

    @Mock
    private DirectLinkServiceConfiguration dlsConfig;

    @Mock
    private TfesConfig tfesConfig;
    
    @Mock
    private DirectLinkServiceConfiguration directLinkServiceConfiguration;

    @Mock
    private LoggingService loggingService;

//    @Mock
//    @Qualifier("restTemplateApigw")
//    private RestTemplate restTemplate;

    @Mock
    private DirectLinkService dlsService;

    @Mock
    private TfesService tfesService;
    
    @Mock
    @Qualifier("restTemplate")
    private RestTemplate restTemplate;

    private TransactionService transactionService;

    String accessToken;
    String uuid;
    private ConfigurationModel config;

    public TransactionServiceImplTest() {
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        transactionService = new TransactionServiceImpl(
                tfesService, dlsService, tfesConfig, loggingService, restTemplate, directLinkServiceConfiguration
        );

        uuid = "uuid";
        accessToken = "accessToken";
        config = generateConfigurationModel();
       }
    
    private ConfigurationModel generateConfigurationModel() {
		ConfigurationModel configurationModel = new ConfigurationModel();
		configurationModel.setAggregateLimitAccount(1);
		configurationModel.setAggregateLimitUser(1);
		configurationModel.setBankPublicKey("MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAyuEZ4n+V/xVlqTxBcPy+zFytlvL+zYRwxd3uOG7kpjgddEVqFhrasS9nmL47iLJDFg0U381a7BBE5XQwDjJAoh8FmnYNO9F0LryW6NGeisQEfpfsNfFYo5zvsxqWtoAcDq/QZZXfdFhI4btlRxbXDaVKln5oDPC6Dk2CP47OAcTtQ97rgK/XMdY6QSnpU3Brx6oba6gCT1gJtrLIuaAWoy4CjIj3XcJH7BssNkgow9MG3W6MlqS8l21KoCF3Zz8nG58DWdoHSSIw6+5MM5sQH78JAQtFwfILLdzztXmGPqBRhBR7B6XJbCWk1IJVRm22VUl4MbnavaUQRSMRlTghug/4gElAqbvVQxbI2YMR4DSz3dRpBE/Nb5opmQHERJSqCBNOhA2shtBzRRn2NbLgpybcN27dHhHUjxSo3+z7wdi+d3SHES4jmlg6sm3biA/9TVND5oZ4E9NHPbXXSyeFnYHgzjurCBRZUjMTe/kqr30NutILSwms8jpqK7ezmBmoF8q4AebMc4SxaCzUkVgCRgecUYIVgCQOULK3QIQoaRrj7BTvmsT3dUdHOjhPmcPu0Bpmp2CkvPjJOm6gldLRs19W5AY/8uuRtLaZE3HxBdaPUC5H2hTkLl+sEVleL5nIINkpdHP15eP0kl6LNyjsC1Coq91jt2cmcy5qrbA86VECAwEAAQ==");
		configurationModel.setBankPrivateKey("MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQDK4Rnif5X/FWWpPEFw/L7MXK2W8v7NhHDF3e44buSmOB10RWoWGtqxL2eYvjuIskMWDRTfzVrsEETldDAOMkCiHwWadg070XQuvJbo0Z6KxAR+l+w18VijnO+zGpa2gBwOr9Blld90WEjhu2VHFtcNpUqWfmgM8LoOTYI/js4BxO1D3uuAr9cx1jpBKelTcGvHqhtrqAJPWAm2ssi5oBajLgKMiPddwkfsGyw2SCjD0wbdboyWpLyXbUqgIXdnPycbnwNZ2gdJIjDr7kwzmxAfvwkBC0XB8gst3PO1eYY+oFGEFHsHpclsJaTUglVGbbZVSXgxudq9pRBFIxGVOCG6D/iASUCpu9VDFsjZgxHgNLPd1GkET81vmimZAcRElKoIE06EDayG0HNFGfY1suCnJtw3bt0eEdSPFKjf7PvB2L53dIcRLiOaWDqybduID/1NU0PmhngT00c9tddLJ4WdgeDOO6sIFFlSMxN7+SqvfQ260gtLCazyOmort7OYGagXyrgB5sxzhLFoLNSRWAJGB5xRghWAJA5QsrdAhChpGuPsFO+axPd1R0c6OE+Zw+7QGmanYKS8+Mk6bqCV0tGzX1bkBj/y65G0tpkTcfEF1o9QLkfaFOQuX6wRWV4vmcgg2Sl0c/Xl4/SSXos3KOwLUKir3WO3ZyZzLmqtsDzpUQIDAQABAoICAGYoAsiyRe0z8QTOeoVSPyDYafBgWz1ROxfnMFTqQegQyYQKj+ihjQ07OYcIAyJJ4M3xuFkZJndHmemQH8KGO1VnGYM1fmRoi4AdJkAFjTeCjGDSTva6mE+KbohZExrCV15t2RnN5b7H1asUmWK6dX9Bg9VTwUEC1iztinBGkCUD7BUI4rzhzhIiNSMq33pMWXkohrYm20Loqbt9OuV9Xui7+jyZmzVy5pRU+mY634v7brGBQPl56hy1w6XuNBmhCyg1YZKU3qZMuSWT0HsL0YqqvvXvnyiRoF9vqqfukVJnl6RSS8EGEe6K5fy7xAS6qd04KXWgiCyGOTMW/XuN0CzijKjB7/N7TYLVej++eSn7pa940KZmm6FQ7dwsCTpyGIyieYSSD5bdYLelEoyM3zvPiwehpartv+c+Le3glrlm26I/HaRJoNoSUx3JIMdqj91IKCtQ4JZDTjsS6KZvvOnXwxSPcnpW2xRzRxxgbMm07Q+lujBV/pqLtN/jmTQboT71XDr+feYzMoEAuQq/m9r9TEChW6NYtJ+lqXoCExxTLk2q/J4zFiCxHOLENOmEVwlP6pcB84YRd4rWYRFsXI1vTMquJ2/salGI8OsYmRizro201PUkOKNhCpAH1eBgX+tDqm9sHbNoaDxHwjDpHnxIalZ3ZWuL47pnRmAYWFKhAoIBAQDxMN3lGABLkq+E5Dn9dTWGBcCwek507FbF92c2VfLaifWCYejWuoVDNM2ZizXdgeWhdZxS1iNpgqa3lbE0lfYik3uUWwKoUikuZIXR+WlQEsVnjXuADhIpmxyJt91tYQ8GDVyMwglgJqggnVFy8U3H7nM02ajM6zO4YKCb/u2BKqElsom51GegbA+Wj2BnIgA7DujXDsX5eDw8gLRv20Cgh93s9YNoaFHVuJun2AkW7GhUlzaVM6hCjA4H+Jo1OMc4l8F6cfenSXmEOXtQlzUH7Gls2VIWKnV90xMg3aBYUKm80DVhNN3lPnPUojTo9yuPAtB4aD2yVtncDuRIRkAnAoIBAQDXVgmrxXJtdaqyAEL75HehloGwr1pCYXBcbO0kEtqLfpnF0HAtyke0KMTIw3w1Ga1cY0LSsUzMmnrXaxdF3DEjK1kB3zMFIGqfVtM1bq7j+psY6ZdUBYl7tnG32reTg96RUqKBXXgFpDWovqfUCgNMztBP2iSv8xQCcfan1IF5Wy+YlaIraRWgbuThiK+p47pXA/XvwZ4E6mrk+4e1H26OwdP+0CELmTma6IPeqnj1feyXLCrhFMvwKPhpC9cFEW4jcKzLVpeBZPsv3zi7OobrAPl4vPXlLHmxBZs3JzDQJEadFIV2EsTMSji6dBTXoykO/HCy5nnh32Aj/kQsAn3HAoIBAQDnnl35G0ttR7h2jhWCaYS05+FbmJivgCb0hdoAPBmz9LhoNU48p3JCT/sBcMaRqaSzoRY2Fp57PJSNyJscPMbZ/Xe3yI6Mxhn2C2LXegTAeMZJ43yuRNT8T5DgUEm8OHENBtfR9KS8SWM7rtgA4eooDb1lC4EnCNfqQCD8rZu3ZxDJ+uJ4Kpo5XIy7sYSKhgRisra3j+Be6jAuigq9QHiXsOJWJI/FPCkabOZOERDpiq3GTlCEh88V2RnAXeT5J0Vp+5I53ChP5idj6y+Y/RxYN5gmh6xkzPF3m7PK5AqPxSa7w9b/Op29AHSLxhm5f2O9Op6ogrJ9CRq+US64mX4RAoIBAEFc32ChdWNeZSrUw4BcUCffXIx6HaaqlwWnFrBtfKL9EcYmx/ZOQUehXGIoXGpt2d6CTsVPhiVQ+tqqqgzNkqi/Pqw/yOfUeCjXnRLJ/xI6fpuoRAQADkRcE9af8Ds5uvRXpfYongbwWk1XWfAV/fxxhm/Gon46BafcWeeFrKtej2r8eJY+to7VOmpvKAskkepZzGwzVDjfwwSwiPfki5WPpj7hhDZWE1M/ItAS5NZ3m7ojcPyTaHgEp6qTKnhiWxEs4XZzWVewhEJ6umiykkOBLziD+wvOXT3rmrq6DaoQaNLDaON3PP9ZxDBsjesKnqrq23aiWPrD6BXk12KYev8CggEAbooJip8xhE6EUb2naKZo1LvLZnhWwbEcePYUUiGXMsjd5OHVKOQd9K2AyZpKsqR1/zgpMuadakD1wAVMMaAr0uGhR4YhiBByFw1+/jHBGJzLvL37lD6B1/t3xFKaGuq9/q39FmtpGQmTtY8k9I9wsMcTGbtz4srDe8GUZJ99CORHXL3hnJqSBaptgJ65lTiLIWasv0X43c3goq5EzLoXmMNqCdD7GmYavf8mNEzwJ2j7BjiA+lH9UPMEgZvXtSLEF4+celPVAZZK5s4dE3yKyY8M9gmUeCXCDmT3Bhb8EiJkEPDVAYJup+aSF5YXk9N9+dmxdTwQnJaU8dmOPf/CcQ==");
		configurationModel.setExpiryDays(1);
		configurationModel.setMaxLinkedAccounts(1);
		configurationModel.setMerchantAlias("Jarvis");
		configurationModel.setMerchantId("testChannelId");
		configurationModel.setMerchantName("Jarvis");
		configurationModel.setMerchantPublicKey("testmerchatnpublickey");
		configurationModel.setTxnRenewalCriteria(1);
		
		return configurationModel;
	}

    @Test
    public void testCreateSubscriptionSuccess() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
            new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
            new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
            new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
        
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
            transactionService.createSubscription(createSubscriptionModel, uuid);

        TfesCommonTransactionResponse response = (TfesCommonTransactionResponse) result;

        Assert.assertNotNull(result);
        Assert.assertEquals(response.getTransactionCode(), "9700015");
    }

    @Test
    public void testCreateSubscriptionSuccess2() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
            new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
            new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
            new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
            transactionService.createSubscription(createSubscriptionModel, uuid);

        TfesCommonTransactionResponse response = (TfesCommonTransactionResponse) result;

        Assert.assertNotNull(result);
        Assert.assertEquals(response.getTransactionCode(), "9700015");
    }


    @Test
    public void testCreateSubscription_WithoutPTA_Investmentaccount_INITIAL() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
            new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
            new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
            new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(decryptResponseWithoutPTA_InvestmentAccount_INITIAL());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);  when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00033");
    }


    @Test
    public void testCreateSubscription_WithoutPTA_Investmentaccount_INITIAL2() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
                new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(decryptResponseWithoutPTA_InvestmentAccount_INITIAL2());
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00033");
    }


    @Test
    public void testCreateSubscriptio_AccountModelNotFound() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = null;

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00009");
    }


    @Test
    public void testCreateSubscriptionOtp_002() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp002 =
                new ResponseEntity(generateOtpResponse002(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp002);
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00008");
    }

    @Test
    public void testCreateSubscriptionOtp_003() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp =
                new ResponseEntity(generateOtpResponse003(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp);
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00005");
    }
    @Test
    public void testCreateSubscriptionOtp_009() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp =
                new ResponseEntity(generateOtpResponse009(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
        
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        ValidateOrSendOTPResponse response = (ValidateOrSendOTPResponse) result;

        Assert.assertNotNull(result);
        Assert.assertEquals(response.getTransactionCode(), PENDING_OTP.getTransactionCode());
        Assert.assertEquals(response.getTransactionDesc(), PENDING_OTP.getTransactionDesc());
    }

    @Test
    public void testCreateSubscriptionOtp_014() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp =
                new ResponseEntity(generateOtpResponse014(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp);
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00009");
    }




    @Test
    public void testCreateSubscription_failedEnrollTrustAccount001() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateEnrollTrustAccountResponse("9700001"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
                new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00010");
    }

    @Test
    public void testCreateRedemptionFailed_InvestmentAccount_null() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700001"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateEnrollTrustAccountResponseNull("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
         when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(anyString(), Mockito.any())).thenReturn(config);
        
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00015");
    }


    @Test
    public void testCreateSubscription_failedEnrollTrustAccount003() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateEnrollTrustAccountResponse("9700003"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
                new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00027");
    }


    @Test
    public void testCreateSubscription_failedEnrollTrustAccount004() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateEnrollTrustAccountResponse("9700004"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
                new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(true));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00028");
    }


    @Test
    public void testCreateSubscriptionFailed_InvestmentAccount() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponseDifferentInvestmentAccount("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700001"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);
        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00015");
    }



    @Test
    public void testCreateSubscriptionFailed_InvestmentAccount_unmapped() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponseDifferentInvestmentAccount("unmapped"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700001"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00015");
    }

    @Test
    public void testCreateSubscriptionFailed_001() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700001"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);
 
        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00010");
    }

    @Test
    public void testCreateSubscriptionFailed_014() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700014"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00026");
    }



    @Test
    public void testCreateSubscriptionFailed_022() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700022"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00011");
    }




    @Test
    public void testCreateSubscriptionFailed_024() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700024"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00012");
    }






    @Test
    public void testCreateSubscriptionFailed_042() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700042"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00013");
    }




    @Test
    public void testCreateSubscriptionFailed_047() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700047"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00014");
    }


    @Test
    public void testCreateSubscriptionFailed_049() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700049"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00016");
    }





    @Test
    public void testCreateSubscriptionFailed_051() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("9700051"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00017");
    }




    @Test
    public void testCreateSubscriptionFailed_unmapped() throws Exception {
        DirectLinkRequestCommonModel createSubscriptionModel = new DirectLinkRequestCommonModel();
        createSubscriptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> invalidJatisCrateSubscriptionResponse =
                new ResponseEntity(generateInvalidJatisCrateSubscriptionResponse("unmapped_code"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptResponse(false));
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(invalidJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createSubscription(createSubscriptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00000");
    }





    @Test
    public void testCreateRedemptionSuccess() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generateValidJatisCrateRedemptionResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        TfesCommonTransactionResponse response = (TfesCommonTransactionResponse) result;

        Assert.assertNotNull(result);
        Assert.assertEquals(response.getTransactionCode(), "9700015");
    }

    @Test
    public void testCreateRedemptionFailed_AccountsModel() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = null;

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generateValidJatisCrateRedemptionResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);


        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00009");
    }


    @Test
    public void testCreateRedemptionOtp_002() throws Exception {
        DirectLinkRequestCommonModel createRedemptionModel = new DirectLinkRequestCommonModel();
        createRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp002 =
                new ResponseEntity(generateOtpResponse002(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp002);
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);       when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(createRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00008");
    }
    @Test
    public void testCreateRedemptionOtp_unmapped() throws Exception {
        DirectLinkRequestCommonModel createRedemptionModel = new DirectLinkRequestCommonModel();
        createRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp002 =
                new ResponseEntity(generateOtpResponseUnmapped(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp002);
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(createRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00000");
    }

    @Test
    public void testCreateRedemptionOtp_003() throws Exception {
        DirectLinkRequestCommonModel createRedemptionModel = new DirectLinkRequestCommonModel();
        createRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp =
                new ResponseEntity(generateOtpResponse003(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp);
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(createRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00005");
    }
    @Test
    public void testCreateRedemptionOtp_009() throws Exception {
        DirectLinkRequestCommonModel createRedemptionModel = new DirectLinkRequestCommonModel();
        createRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp =
                new ResponseEntity(generateOtpResponse009(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);        when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(createRedemptionModel, uuid);

        ValidateOrSendOTPResponse response = (ValidateOrSendOTPResponse) result;

        Assert.assertNotNull(result);
        Assert.assertEquals(response.getTransactionCode(), PENDING_OTP.getTransactionCode());
        Assert.assertEquals(response.getTransactionDesc(), PENDING_OTP.getTransactionDesc());
    }

    @Test
    public void testCreateRedemptionOtp_014() throws Exception {
        DirectLinkRequestCommonModel createRedemptionModel = new DirectLinkRequestCommonModel();
        createRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> failedOtp =
                new ResponseEntity(generateOtpResponse014(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(failedOtp);
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);   when(tfesConfig.getSystemId()).thenReturn("");
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(createRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00009");
    }


    @Test
    public void testCreateRedemption_failedEnrollTrustAccount001() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateEnrollTrustAccountResponse("9700001"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
                new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00010");
    }


    @Test
    public void testCreateRedemption_failedEnrollTrustAccount003() throws Exception {
        DirectLinkRequestCommonModel createRedemptionModel = new DirectLinkRequestCommonModel();
        createRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateEnrollTrustAccountResponse("9700003"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
                new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);  when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(createRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00027");
    }


    @Test
    public void testCreateRedemption_failedEnrollTrustAccount004() throws Exception {
        DirectLinkRequestCommonModel createRedemptionModel = new DirectLinkRequestCommonModel();
        createRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
            new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
            new ResponseEntity(generateEnrollTrustAccountResponse("9700004"), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCrateSubscriptionResponse =
            new ResponseEntity(generateValidJatisCrateSubscriptionResponse(), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);  when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesConfig.getCreateInitialSubscription()).thenReturn("");
        when(tfesConfig.getCreateAdditionalSubscription()).thenReturn("");
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(tfesService.createSubscription(any(), anyString(), anyString())).thenReturn(validJatisCrateSubscriptionResponse);

        TfesCommonTransactionResponse result =
            transactionService.createRedemption(createRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00028");
    }

    @Test
    public void testCreateRedemptionFailed_InvestmentAccount() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700001"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponseDifferentInvestmentAccount("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00015");
    }


    @Test
    public void testCreateRedemptionFailed001() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700001"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
       // when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00010");
    }


    @Test
    public void testCreateRedemptionFailed014() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700014"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);  when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00026");
    }

    @Test
    public void testCreateRedemptionFailed026() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700026"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00018");
    }

    @Test
    public void testCreateRedemptionFailed028() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700028"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);  when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00019");
    }

    @Test
    public void testCreateRedemptionFailed029() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700029"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00020");
    }

    @Test
    public void testCreateRedemptionFailed031() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700031"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00021");
    }

    @Test
    public void testCreateRedemptionFailed036() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700036"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00022");
    }

    @Test
    public void testCreateRedemptionFailed038() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700038"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00023");
    }


    @Test
    public void testCreateRedemptionFailed040() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700040"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00024");
    }

    @Test
    public void testCreateRedemptionFailed030() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700030"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00031");
    }
    @Test
    public void testCreateRedemptionFailed032() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("9700032"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config); when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00032");
    }


    @Test
    public void testCreateRedemptionFailed_unmapped() throws Exception {
        DirectLinkRequestCommonModel crateRedemptionModel = new DirectLinkRequestCommonModel();
        crateRedemptionModel.setChannelId("testChannelId");
        AccountsModel accountsModel = new AccountsModel();
        accountsModel.setRmNumber("rm123123");
        accountsModel.setAccountNo("123123");
        accountsModel.setReferenceNo("ref12312");
        accountsModel.setExternalUserId("external123123");

        ResponseEntity<ValidateOrSendOTPResponse> validOtpResponse =
                new ResponseEntity(generateValidOtpResponse(), HttpStatus.OK);
        ResponseEntity<TfesCommonTransactionResponse> validJatisCreateRedemptionResponse =
                new ResponseEntity(generatJatisCrateRedemptionResponse("unmapped_code"), HttpStatus.OK);
        ResponseEntity<EnrollTrustAccountResponse> validEnrollTustAccountResponse =
                new ResponseEntity(generateValidEnrollTrustAccountResponse("9700002"), HttpStatus.OK);

        when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
        when(dlsService.decryptRequest(any(), anyString())).thenReturn(validDecryptRedemptionResponse());
        //when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);when(tfesConfig.getSystemId()).thenReturn("");
        when(tfesConfig.getSignValue()).thenReturn("");
        when(tfesConfig.getSaltValue()).thenReturn("");
        when(dlsService.getAccountByTokenAndExternalUserId(anyString(), anyString(), anyString())).thenReturn(accountsModel);
        when(directLinkServiceConfiguration.getConfiguration()).thenReturn("http://direct-link-api.mblink-dev.svc:8229/directlink/getSettings/ERN");
        when(restTemplate.getForObject(Mockito.anyString(), Mockito.eq(ConfigurationModel.class))).thenReturn(config);
       
        when(tfesService.enrollTrustAccount(anyString(), anyString(), anyString())).thenReturn(validEnrollTustAccountResponse);
        when(dlsService.validateOrSendOTP(any(), anyString())).thenReturn(validOtpResponse);
        when(tfesService.createRedemption(any(), anyString())).thenReturn(validJatisCreateRedemptionResponse);

        TfesCommonTransactionResponse result =
                transactionService.createRedemption(crateRedemptionModel, uuid);

        Assert.assertNotNull(result);
        Assert.assertEquals(result.getTransactionCode(), "00000");
    }

    private ResponseEntity validDecryptResponse(boolean isInitial) throws JsonProcessingException {
        ValidateDlsResponse response = new ValidateDlsResponse();
        response.setData(
                "{\n" +
                        "\t\"token\": \"0165248265441249767324695981937206506920\",\n" +
                        "\t\"externalUserId\": \"f3303d68-f708-11e9-8f0b-362b9e155667\",\n" +
                        "\t\"referenceNo\": \"222222000002\",\n" +
                        "\t\"ptaNumber\": \"ptaNumber\",\n" +
                        "\t\"investmentAccountNumber\": \"234\",\n" +
                        "\t\"productCode\": \"productCode\",\n" +
                        "\t\"rspAmount\": 7500.00,\n" +
                        "\t\"orderDate\": \"28-Aug-2019\",\n" +
                        "\t\"amount\": 1100.00,\n" +
                        "\t\"installmentPeriod\": 24,\n" +
                        "\t\"installmentDate\": 30,\n" +
                        "\t\"remarks\": \"Online Subscription\",\n" +
                        "\t\"isBeyondCutoff\": false,\n" +
                        "\t\"initial\": " + (isInitial?"true":"false") +"\n" +
                        "}"
        );

        return new ResponseEntity(response, HttpStatus.OK);
    }


    private ResponseEntity decryptResponseWithoutPTA_InvestmentAccount_INITIAL() throws JsonProcessingException {
        ValidateDlsResponse response = new ValidateDlsResponse();
        response.setData(
                "{\n" +
                        "\t\"token\": \"0165248265441249767324695981937206506920\",\n" +
                        "\t\"externalUserId\": \"f3303d68-f708-11e9-8f0b-362b9e155667\",\n" +
                        "\t\"referenceNo\": \"222222000002\",\n" +
                        "\t\"ptaNumber\": \"\",\n" +
                        "\t\"investmentAccountNumber\": \"\",\n" +
                        "\t\"productCode\": \"productCode\",\n" +
                        "\t\"rspAmount\": 7500.00,\n" +
                        "\t\"orderDate\": \"28-Aug-2019\",\n" +
                        "\t\"amount\": 1100.00,\n" +
                        "\t\"installmentPeriod\": 24,\n" +
                        "\t\"installmentDate\": 30,\n" +
                        "\t\"remarks\": \"Online Subscription\",\n" +
                        "\t\"isBeyondCutoff\": false,\n" +
                        "\t\"initial\": true\n" +
                        "}"
        );

        return new ResponseEntity(response, HttpStatus.OK);
    }

    private ResponseEntity decryptResponseWithoutPTA_InvestmentAccount_INITIAL2() throws JsonProcessingException {
        ValidateDlsResponse response = new ValidateDlsResponse();
        response.setData(
                "{\n" +
                        "\t\"token\": \"0165248265441249767324695981937206506920\",\n" +
                        "\t\"externalUserId\": \"f3303d68-f708-11e9-8f0b-362b9e155667\",\n" +
                        "\t\"referenceNo\": \"222222000002\",\n" +
                        "\t\"productCode\": \"productCode\",\n" +
                        "\t\"rspAmount\": 7500.00,\n" +
                        "\t\"orderDate\": \"28-Aug-2019\",\n" +
                        "\t\"amount\": 1100.00,\n" +
                        "\t\"installmentPeriod\": 24,\n" +
                        "\t\"installmentDate\": 30,\n" +
                        "\t\"remarks\": \"Online Subscription\",\n" +
                        "\t\"isBeyondCutoff\": false,\n" +
                        "\t\"initial\": true\n" +
                        "}"
        );

        return new ResponseEntity(response, HttpStatus.OK);
    }

    private ResponseEntity validDecryptRedemptionResponse() throws JsonProcessingException {
        ValidateDlsResponse response = new ValidateDlsResponse();
        response.setData(
            "{\n" +
                "\"token\": \"0327826807405679338272864514547578504615\",\n" +
                "\"externalUserId\": \"f3303d68-f708-11e9-8f0b-362b9e155667\",\n" +
                "\"referenceNo\": \"f3303d68-f708-11e9-8f0b-362b9e155667\",\n" +
                "\"investmentAccountNumber\": \"234\",\n" +
                "\"productCode\" : \"asdasdas\",\n" +
                "\"redemptionType\": \"asasd\",\n" +
                "\"orderDate\": \"28-Aug-2019\",\n" +
                "\"amountOrUnits\" : 12.00,\n" +
                "\"remarks\": \"123123\",\n" +
                "\"isBeyondCutoff\": false\n" +
            "}"
        );

        return new ResponseEntity(response, HttpStatus.OK);
    }

    private ValidateOrSendOTPResponse generateValidOtpResponse() {
        ValidateOrSendOTPResponse response = new ValidateOrSendOTPResponse();
        response.setTransactionCode("011");
        return response;
    }

    private ValidateOrSendOTPResponse generateOtpResponse002() {
        ValidateOrSendOTPResponse response = new ValidateOrSendOTPResponse();
        response.setTransactionCode("002");
        return response;
    }

    private ValidateOrSendOTPResponse generateOtpResponseUnmapped() {
        ValidateOrSendOTPResponse response = new ValidateOrSendOTPResponse();
        response.setTransactionCode("unmapped");
        return response;
    }

    private ValidateOrSendOTPResponse generateOtpResponse003() {
        ValidateOrSendOTPResponse response = new ValidateOrSendOTPResponse();
        response.setTransactionCode("003");
        return response;
    }

    private ValidateOrSendOTPResponse generateOtpResponse009() {
        ValidateOrSendOTPResponse response = new ValidateOrSendOTPResponse();
        response.setTransactionCode("009");
        return response;
    }

    private ValidateOrSendOTPResponse generateOtpResponse014() {
        ValidateOrSendOTPResponse response = new ValidateOrSendOTPResponse();
        response.setTransactionCode("014");
        return response;
    }

    private EnrollTrustAccountResponse generateValidEnrollTrustAccountResponse(String returncode) {
        EnrollTrustAccountResponse response = new EnrollTrustAccountResponse();
        InvestmentAccount investmentAccount = new InvestmentAccount();
        investmentAccount.setInvestmentAccountNumber("234");
        List<InvestmentAccount> investmentAccountList = new ArrayList<>();
        investmentAccountList.add(investmentAccount);

        response.setInvestmentAccounts(investmentAccountList);
        response.setReturnCode(returncode);

        return response;
    }


    private EnrollTrustAccountResponse generateValidEnrollTrustAccountResponseDifferentInvestmentAccount(String returncode) {
        EnrollTrustAccountResponse response = new EnrollTrustAccountResponse();
        InvestmentAccount investmentAccount = new InvestmentAccount();
        investmentAccount.setInvestmentAccountNumber("123");
        List<InvestmentAccount> investmentAccountList = new ArrayList<>();
        investmentAccountList.add(investmentAccount);

        response.setInvestmentAccounts(investmentAccountList);
        response.setReturnCode(returncode);

        return response;
    }

    private EnrollTrustAccountResponse generateEnrollTrustAccountResponse(String returncode) {
        EnrollTrustAccountResponse response = new EnrollTrustAccountResponse();
        InvestmentAccount investmentAccount = new InvestmentAccount();
        investmentAccount.setInvestmentAccountNumber("234");
        List<InvestmentAccount> investmentAccountList = new ArrayList<>();
        investmentAccountList.add(investmentAccount);

        response.setInvestmentAccounts(investmentAccountList);
        response.setReturnCode(returncode);

        return response;
    }

    private EnrollTrustAccountResponse generateEnrollTrustAccountResponseNull(String returncode) {
        EnrollTrustAccountResponse response = new EnrollTrustAccountResponse();
        InvestmentAccount investmentAccount = new InvestmentAccount();
        investmentAccount.setInvestmentAccountNumber("234");

        response.setInvestmentAccounts(null);
        response.setReturnCode(returncode);

        return response;
    }

    private TfesCommonTransactionResponse generateValidJatisCrateSubscriptionResponse() {
        TfesCommonTransactionResponse response = new TfesCommonTransactionResponse();
        response.setReturnCode("9700015");
        response.setTransactionCode("9700015");
        return response;
    }

    private TfesCommonTransactionResponse generateInvalidJatisCrateSubscriptionResponse(String returnCode) {
        TfesCommonTransactionResponse response = new TfesCommonTransactionResponse();
        response.setReturnCode(returnCode);
        response.setTransactionCode(returnCode);
        return response;
    }

    private TfesCommonTransactionResponse generateValidJatisCrateRedemptionResponse() {
        TfesCommonTransactionResponse response = new TfesCommonTransactionResponse();
        response.setReturnCode("9700015");
        response.setTransactionCode("9700015");
        return response;
    }

    private TfesCommonTransactionResponse generatJatisCrateRedemptionResponse(String code) {
        TfesCommonTransactionResponse response = new TfesCommonTransactionResponse();
        response.setReturnCode(code);
        response.setTransactionCode(code);
        return response;
    }
}
