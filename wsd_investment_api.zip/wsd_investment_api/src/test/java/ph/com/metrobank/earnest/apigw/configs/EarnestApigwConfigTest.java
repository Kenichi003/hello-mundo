package ph.com.metrobank.earnest.apigw.configs;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import ph.com.metrobank.earnest.apigw.config.EarnestApigwConfig;

@RunWith(SpringJUnit4ClassRunner.class)
public class EarnestApigwConfigTest {

    @Test
    public void testEarnestApigwConfig() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, CertificateException {
        EarnestApigwConfig config = new EarnestApigwConfig();
        boolean isDollarLinkingAllowed = config.isDollarLinkingAllowed();
        int tokenExpiryDays = config.getTokenExpiryDays();
        RestTemplate rt1 = config.restTemplate();
        RestTemplate rt2 = config.restTemplateApigw();

        Assert.assertNotNull(isDollarLinkingAllowed);
        Assert.assertNotNull(tokenExpiryDays);
        Assert.assertNotNull(rt1);
        Assert.assertNotNull(rt2);
    }
}
