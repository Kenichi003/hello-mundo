package ph.com.metrobank.earnest.apigw.controllers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import ph.com.metrobank.earnest.apigw.config.CasaServiceConfiguration;
import ph.com.metrobank.earnest.apigw.config.DirectLinkServiceConfiguration;
import ph.com.metrobank.earnest.apigw.config.TfesConfig;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.TransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.LinkedAccountResponse;
import ph.com.metrobank.earnest.apigw.services.AccountService;
import ph.com.metrobank.earnest.apigw.services.CreateInvestmentService;
import ph.com.metrobank.earnest.apigw.services.InvestmentDataService;
import ph.com.metrobank.earnest.apigw.services.ProductRiskService;
import ph.com.metrobank.earnest.apigw.services.SuitabilityAssessmentService;
import ph.com.metrobank.earnest.apigw.services.impl.GenerateUUIDService;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class DataControllerTest {
    private ObjectMapper mapper = new ObjectMapper();

    @Mock
    GenerateUUIDService generateUUIDService;

    @Mock
    private LoggingService loggingService;

    @Mock
    AccountService accountService;
    
    @Mock
    private TfesConfig tfesConfig;
    
    @Mock
    private DirectLinkServiceConfiguration directLinkServiceConfiguration;
    
    @Mock
    private CasaServiceConfiguration casaServiceConfiguration;
    
    @Mock
	private InvestmentDataService investmentDataService;
    
    @Mock
    private SuitabilityAssessmentService suitabilityAssessmentService;
    
    @Mock
	private ProductRiskService productRiskService;
    
    @Mock
	private CreateInvestmentService createInvestmentService;

    private DataController controller;

    private MockMvc mockMvc;

    //Mocked Objects
    private DirectLinkRequestCommonModel directLinkRequestCommonModel;
    private LinkedAccountResponse linkedAccountResponse;
    private EnrollTrustAccountResponse enrollTrustAccountResponse;
    private TfesInvestmentAccountDetailsResponse tfesInvestmentAccountDetailsResponse;
    private TransactionDetailsResponse transactionDetailsResponse;
    private TfesInvestmentAccountSummaryDetailResponse tfesInvestmentAccountSummaryDetailResponse;
    private TfesProductsResponse tfesProductsResponse;
    private TfesSuitabilityExpirationResponse tfesSuitabilityExpirationResponse;
    private TfesClientProductRiskProfileResponse tfesClientProductRiskProfileResponse;
    private TfesUpdateSuitabilityAssessmentResponse tfesUpdateSuitabilityAssessmentResponse;
    private String uuid;
    private String accessToken;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        controller = new DataController(loggingService, accountService, generateUUIDService, tfesConfig
        		,directLinkServiceConfiguration, casaServiceConfiguration, investmentDataService, 
        		suitabilityAssessmentService, productRiskService, createInvestmentService);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .addPlaceholderValue("endpoint.url", "/investments")
                .build(); 

        directLinkRequestCommonModel = new DirectLinkRequestCommonModel();
        directLinkRequestCommonModel.setChannelId("SAMPLE_CHANNEL_ID");
        directLinkRequestCommonModel.setData("SAMPLE_DATA");
        directLinkRequestCommonModel.setSignature("SAMPLE_SIGNATURE");

        linkedAccountResponse = new LinkedAccountResponse();
        enrollTrustAccountResponse = new EnrollTrustAccountResponse();
        tfesInvestmentAccountDetailsResponse = new TfesInvestmentAccountDetailsResponse();
        transactionDetailsResponse = new TransactionDetailsResponse();
        tfesInvestmentAccountSummaryDetailResponse = new TfesInvestmentAccountSummaryDetailResponse();
        tfesProductsResponse = new TfesProductsResponse();
        tfesSuitabilityExpirationResponse = new TfesSuitabilityExpirationResponse();
        tfesClientProductRiskProfileResponse = new TfesClientProductRiskProfileResponse();

        uuid = UUID.randomUUID().toString();
        accessToken = "accessToken";
    }

    @Test
    public void getLinkedAccount() throws Exception {

        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(accountService.getLinkedAccount(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(linkedAccountResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/linked-accounts")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();


        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(accountService, atLeastOnce()).getLinkedAccount(any(DirectLinkRequestCommonModel.class), anyString());
    }

    @Test
    public void getInvestmentAccountSummary() throws Exception {
        LinkedAccountResponse r = linkedAccountResponse;

        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(accountService.getInvestmentAccountSummary(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(tfesInvestmentAccountSummaryDetailResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/investment-account-summary")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(accountService, atLeastOnce()).getInvestmentAccountSummary(any(DirectLinkRequestCommonModel.class), anyString());
    }

    @Test
    public void getTransactionDetails() throws Exception {
        LinkedAccountResponse r = linkedAccountResponse;

        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(accountService.getTransactionDetails(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(transactionDetailsResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/transaction-details")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();


        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(accountService, atLeastOnce()).getTransactionDetails(any(DirectLinkRequestCommonModel.class), anyString());
    }

    @Test
    public void getInvestmentAccounts() throws Exception {
        LinkedAccountResponse r = linkedAccountResponse;

        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(accountService.getInvestmentAccounts(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(enrollTrustAccountResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/investment-accounts")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(accountService, atLeastOnce()).getInvestmentAccounts(any(DirectLinkRequestCommonModel.class), anyString());
    }

    @Test
    public void getInvestmentAccountDetails() throws Exception {
        LinkedAccountResponse r = linkedAccountResponse;
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(accountService.getInvestmentAccountDetails(any(DirectLinkRequestCommonModel.class), anyString())).thenReturn(tfesInvestmentAccountDetailsResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/investment-account-details")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(accountService, atLeastOnce()).getInvestmentAccountDetails(any(DirectLinkRequestCommonModel.class), anyString());
    }
    
    @Test
    public void getInvestmentProducts() throws Exception {
        LinkedAccountResponse r = linkedAccountResponse;
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(investmentDataService.getProducts(uuid)).thenReturn(tfesProductsResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        mockMvc.perform(get("/investments/products")).andExpect(status().isOk());

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
    }
    
    @Test
    public void getSuitabilityExpiration() throws Exception {
    	LinkedAccountResponse r = linkedAccountResponse;
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(suitabilityAssessmentService.getSuitabilityExpiration(any(DirectLinkRequestCommonModel.class), anyString()))
        	.thenReturn(tfesSuitabilityExpirationResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/suitability-expiration")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(suitabilityAssessmentService, atLeastOnce()).getSuitabilityExpiration(any(DirectLinkRequestCommonModel.class), 
        		anyString());
    }
    
    @Test
    public void validateClientProductRiskProfile() throws Exception {
    	LinkedAccountResponse r = linkedAccountResponse;
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(productRiskService.validateClientProductRiskProfile(any(DirectLinkRequestCommonModel.class), anyString()))
        	.thenReturn(tfesClientProductRiskProfileResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/validate-client-product-risk-profile")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(productRiskService, atLeastOnce()).validateClientProductRiskProfile(any(DirectLinkRequestCommonModel.class), 
        		anyString());
    }
    
    @Test
    public void updateSuitabilityAssessment() throws Exception {
    	LinkedAccountResponse r = linkedAccountResponse;
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(productRiskService.updateSuitabilityAssessment(any(DirectLinkRequestCommonModel.class), anyString()))
        	.thenReturn(tfesUpdateSuitabilityAssessmentResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/update-suitability-assessment")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(productRiskService, atLeastOnce()).updateSuitabilityAssessment(any(DirectLinkRequestCommonModel.class), anyString());
    }
    
    @Test
    public void createInvestmentAccount() throws Exception {
    	LinkedAccountResponse r = linkedAccountResponse;
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(createInvestmentService.createInvestmentAccount(any(DirectLinkRequestCommonModel.class), anyString()))
        	.thenReturn(enrollTrustAccountResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/create-investment-account")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(createInvestmentService, atLeastOnce()).createInvestmentAccount(any(DirectLinkRequestCommonModel.class), anyString());
    }
    
    @Test
    public void getSuitabilityAssessment() throws Exception {
    	LinkedAccountResponse r = linkedAccountResponse;
        when(generateUUIDService.generateUUID()).thenReturn(uuid);
        when(productRiskService.getSuitabilityAssessmentResults(any(DirectLinkRequestCommonModel.class), anyString()))
        	.thenReturn(tfesProductsResponse);
        when(loggingService.log(anyString(), anyString(), any())).thenReturn("SAMPLE_LOG_MESSAGE");

        MvcResult result = mockMvc.perform(post("/investments/suitability-assessment-results")
                .content(mapper.writeValueAsString(directLinkRequestCommonModel))
                .header("access_token", accessToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        verify(generateUUIDService, atLeastOnce()).generateUUID();
        verify(loggingService, atLeastOnce()).log(anyString(), anyString(), any());
        verify(productRiskService, atLeastOnce()).getSuitabilityAssessmentResults(any(DirectLinkRequestCommonModel.class), anyString());
    }
    
    @Test
	public void testHealthCheck() throws Exception {
		mockMvc.perform(get("/investments/healthCheck")).andExpect(status().isOk());
	}
}
