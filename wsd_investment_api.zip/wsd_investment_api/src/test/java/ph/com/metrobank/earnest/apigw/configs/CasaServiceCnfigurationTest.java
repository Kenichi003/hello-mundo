package ph.com.metrobank.earnest.apigw.configs;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import ph.com.metrobank.earnest.apigw.config.CasaServiceConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
public class CasaServiceCnfigurationTest {

    CasaServiceConfiguration config = new CasaServiceConfiguration();

    @Before
    public void setUp() {

        ReflectionTestUtils.setField(config, "baseUrl", "baseUrl");
        ReflectionTestUtils.setField(config, "accountStatusUrl", "accountStatusUrl");
    }

    @Test
    public void testGetAccountStatusUrl() {
        Assert.assertEquals(config.getAccountStatusUrl("1", "2"),
                "baseUrlaccountStatusUrl/1/2");
        Assert.assertNotNull(config.getAccountStatusUrl());
        Assert.assertNotNull(config.verifyApplicationProperties());
    }
}