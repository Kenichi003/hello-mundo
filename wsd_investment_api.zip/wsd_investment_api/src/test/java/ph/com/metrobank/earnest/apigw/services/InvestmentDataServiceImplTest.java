package ph.com.metrobank.earnest.apigw.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.services.impl.InvestmentDataServiceImpl;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.services.impl.TranCodeLogResponseHelper;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class InvestmentDataServiceImplTest {

	@Mock
	private TfesService tfesService;

	@Mock
	private LoggingService loggingService;

	@Mock
	private TranCodeLogResponseHelper tranCodeLogResponseHelper;
	
	private InvestmentDataService investmentDataService;
	
	@Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        investmentDataService = new InvestmentDataServiceImpl(tfesService, loggingService, tranCodeLogResponseHelper);
    }
	
	@Test
	public void testGetProducts() throws Exception {
		TfesProductsResponse tfesProductsResponse = new TfesProductsResponse();
		tfesProductsResponse.setProducts(new ArrayList<>());
		tfesProductsResponse.setReturnCode("9700002");
		tfesProductsResponse.setTransactionCode(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
		tfesProductsResponse.setTransactionDesc(TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
		
		when(loggingService.log(anyString(), anyString(), any())).thenReturn("");
		when(tfesService.getInvestmentProducts(anyString())).thenReturn(ResponseEntity.ok(tfesProductsResponse));
		
		TfesProductsResponse response = investmentDataService.getProducts(UUID.randomUUID().toString());
		Assert.assertEquals(response.getTransactionCode(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionCode());
		Assert.assertEquals(response.getTransactionDesc(), TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED.getTransactionDesc());
	}
}