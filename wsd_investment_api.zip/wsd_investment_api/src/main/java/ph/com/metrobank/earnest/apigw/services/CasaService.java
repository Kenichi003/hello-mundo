package ph.com.metrobank.earnest.apigw.services;

public interface CasaService {

    Boolean isAccountActive(String settlementAccountNumber, String currencyCode, String uuid);
}
