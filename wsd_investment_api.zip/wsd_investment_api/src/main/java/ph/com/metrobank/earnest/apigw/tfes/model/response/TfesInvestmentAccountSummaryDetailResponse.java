package ph.com.metrobank.earnest.apigw.tfes.model.response;

import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;
import ph.com.metrobank.earnest.apigw.model.subscription.InvestmentAccount;

import java.util.List;

public class TfesInvestmentAccountSummaryDetailResponse extends TranCodesResponse {
    List<InvestmentAccount> investmentAccounts;
    private String lastSAFUpdateDate;
    private String returnCode;

    public TfesInvestmentAccountSummaryDetailResponse() { }

    public TfesInvestmentAccountSummaryDetailResponse(
        String transactionCode,
        String transactionDesc
    ) {
        this.setTransactionCode(transactionCode);
        this.setTransactionDesc(transactionDesc);
    }

    public List<InvestmentAccount> getInvestmentAccounts() {
        return investmentAccounts;
    }

    public void setInvestmentAccounts(List<InvestmentAccount> investmentAccounts) {
        this.investmentAccounts = investmentAccounts;
    }

    public String getLastSAFUpdateDate() {
        return lastSAFUpdateDate;
    }

    public void setLastSAFUpdateDate(String lastSAFUpdateDate) {
        this.lastSAFUpdateDate = lastSAFUpdateDate;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }
}
