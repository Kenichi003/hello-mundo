package ph.com.metrobank.earnest.apigw.model.request;

public class EnrollTrustAccountRequest {
    private String rmNumber;
    private String settlementAccountNumber;
    private String systemID;
    private String userId;
    private String saltValue;
    private String signValue;

    public String getRmNumber() {
        return rmNumber;
    }

    public void setRmNumber(String rmNumber) {
        this.rmNumber = rmNumber;
    }

    public String getSettlementAccountNumber() {
        return settlementAccountNumber;
    }

    public void setSettlementAccountNumber(String settlementAccountNumber) {
        this.settlementAccountNumber = settlementAccountNumber;
    }

    public String getSystemID() {
        return systemID;
    }

    public void setSystemID(String systemID) {
        this.systemID = systemID;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSaltValue() {
        return saltValue;
    }

    public void setSaltValue(String saltValue) {
        this.saltValue = saltValue;
    }

    public String getSignValue() {
        return signValue;
    }

    public void setSignValue(String signValue) {
        this.signValue = signValue;
    }
}

