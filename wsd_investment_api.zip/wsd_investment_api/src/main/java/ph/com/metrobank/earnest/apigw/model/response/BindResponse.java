package ph.com.metrobank.earnest.apigw.model.response;

/**
 * Created by petechungtuyco on 10/21/19.
 */
public class BindResponse extends TranCodesResponse{
    private String accountRef;
    private String referenceNo;
    private String token;

    public BindResponse() {
        super();
    }

    public String getAccountRef() {
        return accountRef;
    }

    public void setAccountRef(String accountRef) {
        this.accountRef = accountRef;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
