package ph.com.metrobank.earnest.apigw.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LinkedAccountResponse extends TranCodesResponse {
    private String accountNumber;
    private String accountType;
    private boolean accountStatus;

    public LinkedAccountResponse() {
    }

    public LinkedAccountResponse(
        String transactionCode,
        String transactionDesc
    ) {
        this.setTransactionCode(transactionCode);
        this.setTransactionDesc(transactionDesc);
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public boolean isAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(boolean accountStatus) {
        this.accountStatus = accountStatus;
    }
}
