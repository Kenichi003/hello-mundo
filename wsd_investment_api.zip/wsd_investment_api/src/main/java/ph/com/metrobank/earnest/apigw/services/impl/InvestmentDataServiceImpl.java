package ph.com.metrobank.earnest.apigw.services.impl;

import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_INVESTMENT_DATA_SERVICE_GET_INVESTMENT_PRODUCTS;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.earnest.apigw.services.InvestmentDataService;
import ph.com.metrobank.earnest.apigw.services.TfesService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;

@Service
public class InvestmentDataServiceImpl implements InvestmentDataService {

	private TfesService tfesService;

	private LoggingService loggingService;
 
	private TranCodeLogResponseHelper tranCodeLogResponseHelper;
		
	@Autowired
	public InvestmentDataServiceImpl(TfesService tfesService, LoggingService loggingService,
			TranCodeLogResponseHelper tranCodeLogResponseHelper) {
		super();
		this.tfesService = tfesService;
		this.loggingService = loggingService;
		this.tranCodeLogResponseHelper = tranCodeLogResponseHelper;
	}

	@Override
	public TfesProductsResponse getProducts(String uuid) throws UnsupportedEncodingException, DecoderException {

		loggingService.log(
				String.format("%s%s", this.getClass().toString(),
						APIGW_INVESTMENT_DATA_SERVICE_GET_INVESTMENT_PRODUCTS),
				uuid, "A call to InvestmentDataService.getProducts() started.");

		TfesProductsResponse tfesProductsResponse = tfesService.getInvestmentProducts(uuid).getBody();

		tranCodeLogResponseHelper.setAndLogTranCode(tfesProductsResponse,
				APIGW_INVESTMENT_DATA_SERVICE_GET_INVESTMENT_PRODUCTS, this.getClass().toString(), uuid);

		return tfesProductsResponse;
	}

}
