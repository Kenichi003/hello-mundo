package ph.com.metrobank.earnest.apigw.exceptions.tfes;

import ph.com.metrobank.earnest.apigw.exceptions.base.NotFoundBaseException;

public class SettlementAccountNotFoundException extends NotFoundBaseException {
    public SettlementAccountNotFoundException() {
        super("Settlement Account not found.");
    }
}
