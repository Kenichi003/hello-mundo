package ph.com.metrobank.earnest.apigw.exceptions;

import ph.com.metrobank.earnest.apigw.exceptions.base.NotFoundBaseException;

public class ErrorCodeNotFoundException extends NotFoundBaseException {
    public ErrorCodeNotFoundException() {
        super("Error code does not exist");
    }
    
    public ErrorCodeNotFoundException(String message) {
        super(message);
    }
}
