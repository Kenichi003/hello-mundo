package ph.com.metrobank.earnest.apigw.exceptions.tfes;

import ph.com.metrobank.earnest.apigw.exceptions.base.UnauthorizedBaseException;

public class InvalidAuthenticationException extends UnauthorizedBaseException {
    public InvalidAuthenticationException() {
        super("Invalid Authentication.");
    }
}
