package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateRedemptionRequest extends TfesCommonRequestModel {

    private String settlementAccountNumber;
    private String redemptionType;
    private BigDecimal amountOrUnits;

    public String getSettlementAccountNumber() {
        return settlementAccountNumber;
    }

    public void setSettlementAccountNumber(String settlementAccountNumber) {
        this.settlementAccountNumber = settlementAccountNumber;
    }

    public String getRedemptionType() {
        return redemptionType;
    }

    public void setRedemptionType(String redemptionType) {
        this.redemptionType = redemptionType;
    }

    public BigDecimal getAmountOrUnits() {
        return amountOrUnits;
    }

    public void setAmountOrUnits(BigDecimal amountOrUnits) {
        this.amountOrUnits = amountOrUnits;
    }

}
