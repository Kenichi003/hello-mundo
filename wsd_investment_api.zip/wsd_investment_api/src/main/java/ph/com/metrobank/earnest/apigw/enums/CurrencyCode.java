package ph.com.metrobank.earnest.apigw.enums;

import ph.com.metrobank.earnest.apigw.exceptions.CurrencyCodeNotFoundException;

public enum CurrencyCode {
    PHP("PHP", 608, 3),
    USD("USD", 840, 2);

    private String currencyCode;
    private int currencyValue;
    private int productType;

    CurrencyCode(String currencyCode, int currencyValue, int productType) {
        this.currencyCode = currencyCode;
        this.currencyValue = currencyValue;
        this.productType = productType;

    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public int getCurrencyValue() {
        return currencyValue;
    }

    public int getProductType() {
        return productType;
    }

    public static int getCurrencyValueByProductType(int productType){
        for (CurrencyCode c : CurrencyCode.values()) {
            if (c.getProductType() == productType) {
                return c.getCurrencyValue();
            }
        }
        throw new CurrencyCodeNotFoundException();
    }
}
