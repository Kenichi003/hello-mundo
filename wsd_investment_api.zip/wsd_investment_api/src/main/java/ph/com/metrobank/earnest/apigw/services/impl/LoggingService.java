package ph.com.metrobank.earnest.apigw.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by petechungtuyco on 10/21/19.
 */
@Service
public class LoggingService {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingService.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    public String log(String component, String uuid, Object object) {
        Map<String, String> map = new HashMap<>();
        if (!"".equals(component)) {
            map.put("COMPONENT", component);
        }
        if (!"".equals(uuid)) {
            map.put("UUID", uuid);
        }
        if (object != null) {
            try {
                map.put("INFO", mapper.writeValueAsString(object));
            } catch (JsonProcessingException e) {
                LOGGER.error("Failed to stringify object: {}", e.getMessage());
            }
        }
        String stringMap = map.toString();
        LOGGER.info(stringMap);
        return stringMap;
    }

    public String error(String component, String uuid, String message, Object object){
        Map<String, String> map = new HashMap<>();
        if (!"".equals(component)) {
            map.put("COMPONENT", component);
        }
        if (!"".equals(uuid)) {
            map.put("UUID", uuid);
        }
        if (!"".equals(message)) {
            map.put("ERROR_MESSAGE", message);
        }
        if (object != null) {
            try {
                map.put("INFO", mapper.writeValueAsString(object));
            } catch (JsonProcessingException e) {
                LOGGER.error("Failed to stringify object: {}", e.getMessage());
            }
        }
        String stringMap = map.toString();
        LOGGER.error(stringMap);
        return stringMap;
    }

}
