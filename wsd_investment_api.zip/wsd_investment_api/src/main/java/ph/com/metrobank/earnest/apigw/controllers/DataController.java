package ph.com.metrobank.earnest.apigw.controllers;

import static ph.com.metrobank.earnest.apigw.util.Constants.PROGRAM_NAME;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import ph.com.metrobank.earnest.apigw.config.CasaServiceConfiguration;
import ph.com.metrobank.earnest.apigw.config.DirectLinkServiceConfiguration;
import ph.com.metrobank.earnest.apigw.config.TfesConfig;
import ph.com.metrobank.earnest.apigw.model.GenericResponse;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.Transaction;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.TransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.LinkedAccountResponse;
import ph.com.metrobank.earnest.apigw.services.AccountService;
import ph.com.metrobank.earnest.apigw.services.CreateInvestmentService;
import ph.com.metrobank.earnest.apigw.services.InvestmentDataService;
import ph.com.metrobank.earnest.apigw.services.ProductRiskService;
import ph.com.metrobank.earnest.apigw.services.SuitabilityAssessmentService;
import ph.com.metrobank.earnest.apigw.services.impl.GenerateUUIDService;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

/**
 * Created by petechungtuyco on 10/21/19.
 *            emmanuel.b.ombrosa on 01/08/20
 */
@RestController
@RequestMapping("${endpoint.url}")
@Api(value = "Earnest APIGW Controller", tags = { "Account Information" })
public class DataController {

	private LoggingService loggingService;

	private AccountService accountService;

	private GenerateUUIDService generateUUIDService;
	
	private TfesConfig tfesConfig;
	
	private DirectLinkServiceConfiguration directLinkServiceConfiguration;
	
	private CasaServiceConfiguration casaServiceConfiguration;
	
	private InvestmentDataService investmentDataService;
	
	private SuitabilityAssessmentService suitabilityAssessmentService;
	
	private ProductRiskService productRiskService;
	
	private CreateInvestmentService createInvestmentService;

	@Autowired
	public DataController(LoggingService loggingService, AccountService accountService,
			GenerateUUIDService generateUUIDService, TfesConfig tfesConfig,
			DirectLinkServiceConfiguration directLinkServiceConfiguration,
			CasaServiceConfiguration casaServiceConfiguration,
			InvestmentDataService investmentDataService,
			SuitabilityAssessmentService suitabilityAssessmentService,
			ProductRiskService productRiskService,
			CreateInvestmentService createInvestmentService) {
		this.loggingService = loggingService;
		this.accountService = accountService;
		this.generateUUIDService = generateUUIDService;
		this.tfesConfig = tfesConfig;
		this.directLinkServiceConfiguration = directLinkServiceConfiguration;
		this.casaServiceConfiguration = casaServiceConfiguration;
		this.investmentDataService = investmentDataService;
		this.suitabilityAssessmentService = suitabilityAssessmentService;
		this.productRiskService = productRiskService;
		this.createInvestmentService = createInvestmentService;
	}

	@PostMapping(value = "/linked-accounts", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Linked Account", response = LinkedAccountResponse.class)
	public ResponseEntity<GenericResponse<LinkedAccountResponse>> getLinkedAccounts(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_LINK_ACCOUNT), uuid,
				request);
		GenericResponse<LinkedAccountResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(), "",
				accountService.getLinkedAccount(request, uuid));
		return ResponseEntity.ok(response);
	}

	@PostMapping(value = "/investment-account-summary", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Investment Account Summary", response = TfesInvestmentAccountSummaryDetailResponse.class)
	public ResponseEntity<GenericResponse<TfesInvestmentAccountSummaryDetailResponse>> getInvestmentAccountSummary(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_DATA_CONTROLLER_INVESTMENT_ACCOUNT_SUMMARY), uuid, request);
		GenericResponse<TfesInvestmentAccountSummaryDetailResponse> response = new GenericResponse<>(PROGRAM_NAME,
				new Date(), "", accountService.getInvestmentAccountSummary(request, uuid));
		return ResponseEntity.ok(response);
	}

	@PostMapping(value = "/transaction-details", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Transaction Details", response = Transaction.class)
	public ResponseEntity<GenericResponse<TransactionDetailsResponse>> getTransactionDetails(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_TRANSACTION_DETAILS),
				uuid, request);
		GenericResponse<TransactionDetailsResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(), "",
				accountService.getTransactionDetails(request, uuid));
		return ResponseEntity.ok(response);
	}

	@PostMapping(value = "/investment-accounts", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Investment Accounts", response = EnrollTrustAccountResponse.class)
	public ResponseEntity<GenericResponse<EnrollTrustAccountResponse>> getInvestmentAccounts(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_INVESTMENT_ACCOUNTS),
				uuid, request);
		GenericResponse<EnrollTrustAccountResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(), "",
				accountService.getInvestmentAccounts(request, uuid));
		return ResponseEntity.ok(response);
	}

	@PostMapping(value = "/investment-account-details", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Investment Account Details", response = TfesInvestmentAccountDetailsResponse.class)
	public ResponseEntity<GenericResponse<TfesInvestmentAccountDetailsResponse>> getInvestmentAccountDetails(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_INVESTMENT_ACCOUNTS),
				uuid, request);
		GenericResponse<TfesInvestmentAccountDetailsResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(),
				"", accountService.getInvestmentAccountDetails(request, uuid));
		return ResponseEntity.ok(response);
	}

	@GetMapping(value = "/products")
	@ApiOperation(value = "Get Investment Products", response = TfesProductsResponse.class)
	public @ResponseBody ResponseEntity<GenericResponse<TfesProductsResponse>> getInvestmentProducts() throws UnsupportedEncodingException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_INVESTMENT_PRODUCTS),
				uuid, "");
		GenericResponse<TfesProductsResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(), "",
				investmentDataService.getProducts(uuid));
		return ResponseEntity.ok(response);
	}
	
	@PostMapping(value = "/suitability-expiration", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Customer's suitability expiration date", response = TfesSuitabilityExpirationResponse.class)
	public ResponseEntity<GenericResponse<TfesSuitabilityExpirationResponse>> getSuitabilityExpiration(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_GET_SUITABILITY_ASSESSMENT),
				uuid, request);
		GenericResponse<TfesSuitabilityExpirationResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(),
				"", suitabilityAssessmentService.getSuitabilityExpiration(request, uuid));
		return ResponseEntity.ok(response);
	}
	
	@PostMapping(value = "/validate-client-product-risk-profile", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Customer's risk profile per Product", response = TfesClientProductRiskProfileResponse.class)
	public ResponseEntity<GenericResponse<TfesClientProductRiskProfileResponse>> validateClientProductRiskProfile(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_VALIDATE_CLIENT_PRODUCT_RISK_PROFILE),
				uuid, request);
		GenericResponse<TfesClientProductRiskProfileResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(),
				"", productRiskService.validateClientProductRiskProfile(request, uuid));
		return ResponseEntity.ok(response);
	}
	
	@PostMapping(value = "/update-suitability-assessment", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Update Customer's Suitability Assessment by set of Products questionnaire", response = TfesUpdateSuitabilityAssessmentResponse.class)
	public ResponseEntity<GenericResponse<TfesUpdateSuitabilityAssessmentResponse>> updateSuitabilityAssessment(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_UPDATE_SUITABILITY_ASSESSMENT),
				uuid, request);
		GenericResponse<TfesUpdateSuitabilityAssessmentResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(),
				"", productRiskService.updateSuitabilityAssessment(request, uuid));
		return ResponseEntity.ok(response);
	}
	
	@PostMapping(value = "/create-investment-account", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create new Customer's Investment Account on TFES", response = EnrollTrustAccountResponse.class)
	public ResponseEntity<GenericResponse<EnrollTrustAccountResponse>> createInvestmentAccount(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_CREATE_INVESTMENT_ACCOUNT),
				uuid, request);
		GenericResponse<EnrollTrustAccountResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(),
				"", createInvestmentService.createInvestmentAccount(request, uuid));
		return ResponseEntity.ok(response);
	}
	
	@PostMapping(value = "/suitability-assessment-results", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Customer's Suitability Assessment result (risk profile) per Product", response = TfesProductsResponse.class)
	public ResponseEntity<GenericResponse<TfesProductsResponse>> getSuitabilityAssessment(
			@RequestBody DirectLinkRequestCommonModel request) throws ExecutionException, InterruptedException,
			IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, DecoderException {
		final String uuid = generateUUIDService.generateUUID();
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_GET_SUITABILITY_ASSESSMENT_RESULT),
				uuid, request);
		GenericResponse<TfesProductsResponse> response = new GenericResponse<>(PROGRAM_NAME, new Date(),
				"", productRiskService.getSuitabilityAssessmentResults(request, uuid));
		return ResponseEntity.ok(response);
	}
	
	@GetMapping(value = "/healthCheck")
	@ApiOperation(value = "Health Check")
	public @ResponseBody ResponseEntity<String> healthCheck() {
		return new ResponseEntity<>("Investment API OK " + tfesConfig.verifyApplicationProperties()
		+ directLinkServiceConfiguration.verifyApplicationProperties()
		+ casaServiceConfiguration.verifyApplicationProperties(), HttpStatus.OK);
	}
}
