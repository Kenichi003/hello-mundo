package ph.com.metrobank.earnest.apigw.exceptions.tfes;

import ph.com.metrobank.earnest.apigw.exceptions.base.BadRequestBaseException;

public class InvalidMinimumRspAmountException extends BadRequestBaseException {
    public InvalidMinimumRspAmountException() {
        super("Invalid minimum rsp amount exception.");
    }
}
