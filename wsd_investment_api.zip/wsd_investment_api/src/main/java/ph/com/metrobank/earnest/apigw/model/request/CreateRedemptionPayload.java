package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import ph.com.metrobank.earnest.apigw.model.auth.AuthCode;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CreateRedemptionPayload {
    private String token;
    private String externalUserId;
    private String referenceNo;
    private String investmentAccountNumber;
    private String productCode;
    private String redemptionType;

    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonFormat(pattern = "dd-MMM-yyyy")
    private LocalDate orderDate;
    private BigDecimal amountOrUnits;
    private String remarks;
    private boolean isBeyondCutoff;
    private AuthCode auth;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getExternalUserId() {
        return externalUserId;
    }

    public void setExternalUserId(String externalUserId) {
        this.externalUserId = externalUserId;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public String getInvestmentAccountNumber() {
        return investmentAccountNumber;
    }

    public void setInvestmentAccountNumber(String investmentAccountNumber) {
        this.investmentAccountNumber = investmentAccountNumber;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getRedemptionType() {
        return redemptionType;
    }

    public void setRedemptionType(String redemptionType) {
        this.redemptionType = redemptionType;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public BigDecimal getAmountOrUnits() {
        return amountOrUnits;
    }

    public void setAmountOrUnits(BigDecimal amountOrUnits) {
        this.amountOrUnits = amountOrUnits;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public boolean getIsBeyondCutoff() {
        return isBeyondCutoff;
    }

    public void setIsBeyondCutoff(boolean isBeyondCutoff) {
        this.isBeyondCutoff = isBeyondCutoff;
    }

    public AuthCode getAuth() {
        return auth;
    }

    public void setAuth(AuthCode auth) {
        this.auth = auth;
    }
}
