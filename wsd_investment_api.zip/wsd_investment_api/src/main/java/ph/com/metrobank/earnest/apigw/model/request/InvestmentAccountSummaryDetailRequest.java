package ph.com.metrobank.earnest.apigw.model.request;

public class InvestmentAccountSummaryDetailRequest extends TfesCommonRequestModel{
    private String rmNumber;
    private String settlementAccountNumber;

    public String getRmNumber() {
        return rmNumber;
    }

    public void setRmNumber(String rmNumber) {
        this.rmNumber = rmNumber;
    }

    public String getSettlementAccountNumber() {
        return settlementAccountNumber;
    }

    public void setSettlementAccountNumber(String settlementAccountNumber) {
        this.settlementAccountNumber = settlementAccountNumber;
    }
}
