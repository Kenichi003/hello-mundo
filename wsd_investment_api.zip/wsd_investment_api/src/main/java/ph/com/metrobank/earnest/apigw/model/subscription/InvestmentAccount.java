package ph.com.metrobank.earnest.apigw.model.subscription;

import com.fasterxml.jackson.annotation.JsonInclude;
import ph.com.metrobank.earnest.apigw.model.CommonAccountDetails;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InvestmentAccount extends CommonAccountDetails {

    private String statementAddress;
    private String jointAccount;
    private String currencyCode;
    private BigDecimal totalMarketValue;
    private String servicingBranch;


    public String getStatementAddress() {
        return statementAddress;
    }

    public void setStatementAddress(String statementAddress) {
        this.statementAddress = statementAddress;
    }

    public String getJointAccount() {
        return jointAccount;
    }

    public void setJointAccount(String jointAccount) {
        this.jointAccount = jointAccount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getTotalMarketValue() {
        return totalMarketValue;
    }

    public void setTotalMarketValue(BigDecimal totalMarketValue) {
        this.totalMarketValue = totalMarketValue;
    }

    public String getServicingBranch() {
        return servicingBranch;
    }

    public void setServicingBranch(String servicingBranch) {
        this.servicingBranch = servicingBranch;
    }
}
