package ph.com.metrobank.earnest.apigw.tfes.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import ph.com.metrobank.earnest.apigw.model.ValidateOrSendOTPResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesCommonTransactionResponse extends ValidateOrSendOTPResponse {

	private String transactionNumber;
	private String debitAccountName;
	private String dateTimeStamp;
	private String returnCode;
	private String settlementDate;
	private String customerNumber;
	private String maskedSettlementAccountNumber;
	private String returnDescription;

	public TfesCommonTransactionResponse() {
	}

	public TfesCommonTransactionResponse(String transactionCode, String transactionDesc) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
	}

	public TfesCommonTransactionResponse(String transactionCode, String transactionDesc, String rmNumber, String maskedSettlementAccountNumber) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
		this.setCustomerNumber(rmNumber);
		this.setMaskedSettlementAccountNumber(maskedSettlementAccountNumber);
	}

	public TfesCommonTransactionResponse(ValidateOrSendOTPResponse vosResponse) {
		this.setAmount(vosResponse.getAmount());
		this.setReferenceNo(vosResponse.getReferenceNo());
		this.setTransactionCode(vosResponse.getTransactionCode());
		this.setMaskedMobileNumber(vosResponse.getMaskedMobileNumber());
		this.setnToken(vosResponse.getnToken());
		this.setOtpGenId(vosResponse.getOtpGenId());
		this.setTransactionCode(vosResponse.getTransactionCode());
		this.setTransactionDesc(vosResponse.getTransactionDesc());
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getDebitAccountName() {
		return debitAccountName;
	}

	public void setDebitAccountName(String debitAccountName) {
		this.debitAccountName = debitAccountName;
	}

	public String getDateTimeStamp() {
		return dateTimeStamp;
	}

	public void setDateTimeStamp(String dateTimeStamp) {
		this.dateTimeStamp = dateTimeStamp;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

    public String getMaskedSettlementAccountNumber() {
        return maskedSettlementAccountNumber;
    }

    public void setMaskedSettlementAccountNumber(String maskedSettlementAccountNumber) {
        this.maskedSettlementAccountNumber = maskedSettlementAccountNumber;
    }

	public String getReturnDescription() {
		return returnDescription;
	}

	public void setReturnDescription(String returnDescription) {
		this.returnDescription = returnDescription;
	}
    
    
}
