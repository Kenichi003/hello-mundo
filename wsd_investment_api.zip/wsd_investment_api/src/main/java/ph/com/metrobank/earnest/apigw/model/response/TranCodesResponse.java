package ph.com.metrobank.earnest.apigw.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import ph.com.metrobank.earnest.apigw.model.Format;

/**
 * Created by petechungtuyco on 10/21/19.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TranCodesResponse extends Format {
    private String transactionCode;
    private String transactionDesc;
    
    // TFES codes
	private String returnCode;
	private String returnDescription;

    public TranCodesResponse() {
        super();
    }

    public String getTransactionCode() {
        return transactionCode;
    }

    public void setTransactionCode(String transactionCode) {
        this.transactionCode = transactionCode;
    }

    public String getTransactionDesc() {
        return transactionDesc;
    }

    public void setTransactionDesc(String transactionDesc) {
        this.transactionDesc = transactionDesc;
    }

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnDescription() {
		return returnDescription;
	}

	public void setReturnDescription(String returnDescription) {
		this.returnDescription = returnDescription;
	}
    
    
}
