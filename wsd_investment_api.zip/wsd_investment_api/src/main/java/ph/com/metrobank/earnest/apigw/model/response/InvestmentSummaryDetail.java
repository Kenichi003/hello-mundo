package ph.com.metrobank.earnest.apigw.model.response;

import java.math.BigDecimal;

public class InvestmentSummaryDetail {
    private String product;
    private String ptaNumber;
    private BigDecimal outstandingUnits;
    private BigDecimal averageCost;
    private BigDecimal navpuRate;
    private BigDecimal marketValue;
    private Integer percentOfTotal;
    private BigDecimal unrealizedGainLoss;
    private BigDecimal absoluteROI;

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getPtaNumber() {
        return ptaNumber;
    }

    public void setPtaNumber(String ptaNumber) {
        this.ptaNumber = ptaNumber;
    }

    public BigDecimal getOutstandingUnits() {
        return outstandingUnits;
    }

    public void setOutstandingUnits(BigDecimal outstandingUnits) {
        this.outstandingUnits = outstandingUnits;
    }

    public BigDecimal getAverageCost() {
        return averageCost;
    }

    public void setAverageCost(BigDecimal averageCost) {
        this.averageCost = averageCost;
    }

    public BigDecimal getNavpuRate() {
        return navpuRate;
    }

    public void setNavpuRate(BigDecimal navpuRate) {
        this.navpuRate = navpuRate;
    }

    public BigDecimal getMarketValue() {
        return marketValue;
    }

    public void setMarketValue(BigDecimal marketValue) {
        this.marketValue = marketValue;
    }

    public Integer getPercentOfTotal() {
        return percentOfTotal;
    }

    public void setPercentOfTotal(Integer percentOfTotal) {
        this.percentOfTotal = percentOfTotal;
    }

    public BigDecimal getUnrealizedGainLoss() {
        return unrealizedGainLoss;
    }

    public void setUnrealizedGainLoss(BigDecimal unrealizedGainLoss) {
        this.unrealizedGainLoss = unrealizedGainLoss;
    }

    public BigDecimal getAbsoluteROI() {
        return absoluteROI;
    }

    public void setAbsoluteROI(BigDecimal absoluteROI) {
        this.absoluteROI = absoluteROI;
    }
}
