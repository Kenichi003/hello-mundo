package ph.com.metrobank.earnest.apigw.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import ph.com.metrobank.earnest.apigw.model.subscription.InvestmentAccount;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnrollTrustAccountResponse extends TranCodesResponse {
	private String settlementAccountNumber;
	private String settlementAccountName;
	private List<InvestmentAccount> investmentAccounts;
	private String returnCode;

	public EnrollTrustAccountResponse() {
	}

	public EnrollTrustAccountResponse(String transactionCode, String transactionDesc) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
	}
	
	public EnrollTrustAccountResponse(String transactionCode, String transactionDesc, List<InvestmentAccount> investmentAccounts) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
		this.investmentAccounts = investmentAccounts;
	}

	public String getSettlementAccountNumber() {
		return settlementAccountNumber;
	}

	public void setSettlementAccountNumber(String settlementAccountNumber) {
		this.settlementAccountNumber = settlementAccountNumber;
	}

	public String getSettlementAccountName() {
		return settlementAccountName;
	}

	public void setSettlementAccountName(String settlementAccountName) {
		this.settlementAccountName = settlementAccountName;
	}

	public List<InvestmentAccount> getInvestmentAccounts() {
		return investmentAccounts;
	}

	public void setInvestmentAccounts(List<InvestmentAccount> investmentAccounts) {
		this.investmentAccounts = investmentAccounts;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
}
