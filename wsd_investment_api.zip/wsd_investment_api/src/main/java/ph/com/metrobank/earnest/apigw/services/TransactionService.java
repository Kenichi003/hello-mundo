package ph.com.metrobank.earnest.apigw.services;

import org.apache.commons.codec.DecoderException;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.util.concurrent.ExecutionException;

/**
 * Created by petechungtuyco on 10/21/19.
 */
public interface TransactionService {

    TfesCommonTransactionResponse createRedemption(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException, InterruptedException, IOException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException, InvalidKeySpecException, NoSuchPaddingException, SignatureException, DecoderException;

    TfesCommonTransactionResponse createSubscription(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, InvalidKeySpecException, SignatureException, InterruptedException, ExecutionException, DecoderException;
}
