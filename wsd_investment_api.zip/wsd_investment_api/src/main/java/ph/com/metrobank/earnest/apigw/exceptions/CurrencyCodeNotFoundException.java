package ph.com.metrobank.earnest.apigw.exceptions;

import ph.com.metrobank.earnest.apigw.exceptions.base.NotFoundBaseException;

public class CurrencyCodeNotFoundException extends NotFoundBaseException {
    public CurrencyCodeNotFoundException() {
        super("Currency code does not exist");
    }
}
