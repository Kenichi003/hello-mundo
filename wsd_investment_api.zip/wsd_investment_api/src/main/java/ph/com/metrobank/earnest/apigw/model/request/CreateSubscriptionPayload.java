package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import ph.com.metrobank.earnest.apigw.model.auth.AuthCode;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CreateSubscriptionPayload extends CommonAccountDetailRequest{
    private String ptaNumber;
    private String investmentAccountNumber;
    private String productCode;
    private BigDecimal rspAmount;
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonFormat(pattern = "dd-MMM-yyyy")
    private LocalDate orderDate;

    private BigDecimal amount;
    private int installmentPeriod;
    private int installmentDate;
    private String remarks;
    private boolean isBeyondCutoff;
    private boolean initial;
    private AuthCode auth;

    public String getPtaNumber() {
        return ptaNumber;
    }

    public void setPtaNumber(String ptaNumber) {
        this.ptaNumber = ptaNumber;
    }

    public String getInvestmentAccountNumber() {
        return investmentAccountNumber;
    }

    public void setInvestmentAccountNumber(String investmentAccountNumber) {
        this.investmentAccountNumber = investmentAccountNumber;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }


    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public boolean getInitial() {
        return initial;
    }

    public AuthCode getAuth() {
        return auth;
    }

    public void setAuth(AuthCode auth) {
        this.auth = auth;
    }

    public BigDecimal getRspAmount() {
        return rspAmount;
    }

    public void setRspAmount(BigDecimal rspAmount) {
        this.rspAmount = rspAmount;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public int getInstallmentPeriod() {
        return installmentPeriod;
    }

    public void setInstallmentPeriod(int installmentPeriod) {
        this.installmentPeriod = installmentPeriod;
    }

    public int getInstallmentDate() {
        return installmentDate;
    }

    public void setInstallmentDate(int installmentDate) {
        this.installmentDate = installmentDate;
    }

    public boolean getIsBeyondCutoff() {
        return isBeyondCutoff;
    }

    public void setIsBeyondCutoff(boolean beyondCutoff) {
        isBeyondCutoff = beyondCutoff;
    }

    public boolean isInitial() {
        return initial;
    }

    public void setInitial(boolean initial) {
        this.initial = initial;
    }
}
