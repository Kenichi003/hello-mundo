package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;

import ph.com.metrobank.earnest.apigw.model.CommonAccountDetails;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesCommonRequestModel extends CommonAccountDetails {
    private String userId;
    private String signValue;
    private String saltValue;
    private String rmNumber;
    private String productCode;
    private String transactionType;
    private String orderDate;
    private String remarks;
    private boolean isBeyondCutOff;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSignValue() {
        return signValue;
    }

    public void setSignValue(String signValue) {
        this.signValue = signValue;
    }

    public String getSaltValue() {
        return saltValue;
    }

    public void setSaltValue(String saltValue) {
        this.saltValue = saltValue;
    }

    public String getRmNumber() {
        return rmNumber;
    }

    public void setRmNumber(String rmNumber) {
        this.rmNumber = rmNumber;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public boolean getIsBeyondCutOff() {
        return isBeyondCutOff;
    }

    public void setIsBeyondCutOff(boolean beyondCutOff) {
        isBeyondCutOff = beyondCutOff;
    }
}
