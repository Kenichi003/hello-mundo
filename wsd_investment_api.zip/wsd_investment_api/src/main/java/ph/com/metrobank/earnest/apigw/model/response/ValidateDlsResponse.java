package ph.com.metrobank.earnest.apigw.model.response;

public class ValidateDlsResponse extends TranCodesResponse{
    private String data;
    private String transactionDate;

    public ValidateDlsResponse() {
    	// Object creation for JSON serialization.
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }
}
