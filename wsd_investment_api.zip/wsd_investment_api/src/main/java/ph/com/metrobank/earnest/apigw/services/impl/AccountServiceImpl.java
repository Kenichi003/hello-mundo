package ph.com.metrobank.earnest.apigw.services.impl;

import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.DATA_DOESNT_EXIST;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.EXCEPTION_ERROR_TFES;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_AUTHENTICATION;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.SETTLEMENT_ACCOUNT_NOT_FOUND;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_DETAILS;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_ACCOUNT_SERVICE_GET_LINKED_ACCOUNTS;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_ACCOUNT_SERVICE_GET_TRANSACTION_DETAILS;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_ACCOUNT_SERVICE_INVESTMENT_ACCOUNTS;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.earnest.apigw.enums.AccountType;
import ph.com.metrobank.earnest.apigw.enums.CurrencyCode;
import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.Transaction;
import ph.com.metrobank.earnest.apigw.model.request.CommonAccountDetailRequest;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountSummaryDetailRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesInvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesTransactionDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TransactionDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.LinkedAccountResponse;
import ph.com.metrobank.earnest.apigw.services.AccountService;
import ph.com.metrobank.earnest.apigw.services.CasaService;
import ph.com.metrobank.earnest.apigw.services.DirectLinkService;
import ph.com.metrobank.earnest.apigw.services.TfesService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesTransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.util.JsonUtil;
import ph.com.metrobank.earnest.apigw.util.StringUtil;

/**
 * Created by petechungtuyco on 10/21/19.
 */

@Service
public class AccountServiceImpl implements AccountService {

	private DirectLinkService directLinkService;

	private LoggingService loggingService;

	private TfesService tfesService;

	private CasaService casaService;
	
	private static final int LAST_SIX_CHARS = 6;

	@Autowired
	public AccountServiceImpl(DirectLinkService directLinkService, LoggingService loggingService,
			TfesService tfesService, CasaService casaService) {
		this.directLinkService = directLinkService;
		this.loggingService = loggingService;
		this.tfesService = tfesService;
		this.casaService = casaService;
	}

	@Override
	public LinkedAccountResponse getLinkedAccount(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException {
		loggingService.log(String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_GET_LINKED_ACCOUNTS),
				uuid, request);

		CommonAccountDetailRequest commonAccountDetailRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(), CommonAccountDetailRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				commonAccountDetailRequest.getToken(), commonAccountDetailRequest.getExternalUserId(), uuid);
		if (accountsModel == null) {
			return new LinkedAccountResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		LinkedAccountResponse linkedAccountResponse = new LinkedAccountResponse();
		linkedAccountResponse.setAccountNumber(StringUtil.getLastChars(accountsModel.getAccountNo(), LAST_SIX_CHARS));
		//linkedAccountResponse.setAccountNumber(accountsModel.getAccountNo()); // DSD REQUIREMENT
		// Check if account is active
		int productType = Integer.parseInt(accountsModel.getAccountNo().substring(3, 4));
		boolean isAccountActive = casaService.isAccountActive(accountsModel.getAccountNo(),
				String.valueOf(CurrencyCode.getCurrencyValueByProductType(productType)), uuid);
		linkedAccountResponse.setAccountStatus(isAccountActive);

		// Set what is the accountType depending on the first digit of
		// settlementAccountNumber
		String settlementAccountNumberFirstDigit = accountsModel.getAccountNo().substring(0, 1);
		String accountType = AccountType.getAccountTypeBySettlementFirstDigit(settlementAccountNumberFirstDigit);
		linkedAccountResponse.setAccountType(accountType);

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DATA_CONTROLLER_LINK_ACCOUNT), uuid,
				linkedAccountResponse);
		return linkedAccountResponse;
	}

	@Override
	public EnrollTrustAccountResponse getInvestmentAccounts(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_INVESTMENT_ACCOUNTS),
				uuid, request);

		CommonAccountDetailRequest commonAccountDetailRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(), CommonAccountDetailRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				commonAccountDetailRequest.getToken(), commonAccountDetailRequest.getExternalUserId(), uuid);

		if (accountsModel == null) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_INVESTMENT_ACCOUNTS), uuid,
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new EnrollTrustAccountResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		EnrollTrustAccountResponse response = tfesService
				.enrollTrustAccount(accountsModel.getRmNumber(), accountsModel.getAccountNo(), uuid).getBody();
		response.setSettlementAccountNumber(StringUtil.getLastChars(response.getSettlementAccountNumber(), LAST_SIX_CHARS));

		loggingService.log(String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_INVESTMENT_ACCOUNTS),
				uuid, response);
		return response;
	}

	@Override
	public TfesInvestmentAccountDetailsResponse getInvestmentAccountDetails(DirectLinkRequestCommonModel request,
			String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_DETAILS),
				uuid, request);

		InvestmentAccountDetailsRequest investmentAccountDetailsRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(),
				InvestmentAccountDetailsRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				investmentAccountDetailsRequest.getToken(), investmentAccountDetailsRequest.getExternalUserId(), uuid);

		if (accountsModel == null) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_DETAILS),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesInvestmentAccountDetailsResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		TfesInvestmentAccountDetailsRequest tfesInvestmentAccountDetailsRequest = new TfesInvestmentAccountDetailsRequest();
		tfesInvestmentAccountDetailsRequest
				.setInvestmentAccountNumber(investmentAccountDetailsRequest.getInvestmentAccountNumber());
		tfesInvestmentAccountDetailsRequest.setSettlementAccountNumber(accountsModel.getAccountNo());

		TfesInvestmentAccountDetailsResponse response = tfesService
				.getInvestmentAccountDetails(tfesInvestmentAccountDetailsRequest, uuid).getBody();

		if (response.getReturnCode().equals(DATA_DOESNT_EXIST.getExternalTransactionCode())) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_DETAILS),
					uuid, DATA_DOESNT_EXIST.getTransactionDesc(), TransactionCode.getAsError(DATA_DOESNT_EXIST));
			return new TfesInvestmentAccountDetailsResponse(DATA_DOESNT_EXIST.getTransactionCode(),
					DATA_DOESNT_EXIST.getTransactionDesc());

		} else {

			loggingService.log(String.format("%s%s", this.getClass().toString(),
					APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_DETAILS), uuid, response);
			return response;
		}
	}

	@Override
	public TransactionDetailsResponse getTransactionDetails(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_GET_TRANSACTION_DETAILS), uuid,
				request);

		TransactionDetailsRequest transactionDetailsRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(), TransactionDetailsRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				transactionDetailsRequest.getToken(), transactionDetailsRequest.getExternalUserId(), uuid);

		if (accountsModel == null) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_GET_TRANSACTION_DETAILS),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TransactionDetailsResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		// Call TFES for each investment account number
		Map<String, List<Transaction>> transactionList = new LinkedHashMap<>();
		for (String investmentAccountNumber : transactionDetailsRequest.getAccountIds()) {
			TfesTransactionDetailsRequest detailsRequest = new TfesTransactionDetailsRequest();
			detailsRequest.setAsOfDate(transactionDetailsRequest.getAsOfDate());
			detailsRequest.setInvestmentAccountNumber(investmentAccountNumber);
			TfesTransactionDetailsResponse response = (TfesTransactionDetailsResponse) tfesService
					.getTransactionDetails(detailsRequest, uuid).getBody();

			if (response.getTransactions() == null) {
				transactionList.put(investmentAccountNumber, new ArrayList<>());
			} else {
				transactionList.put(investmentAccountNumber, response.getTransactions());
			}
		}
		TransactionDetailsResponse transactionDetailsResponse = new TransactionDetailsResponse();
		transactionDetailsResponse.setTransactions(transactionList);

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_GET_TRANSACTION_DETAILS), uuid,
				transactionDetailsResponse);
		return transactionDetailsResponse;
	}

	@Override
	public TfesInvestmentAccountSummaryDetailResponse getInvestmentAccountSummary(DirectLinkRequestCommonModel request,
			String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY),
				uuid, request);

		CommonAccountDetailRequest commonAccountDetailRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(), CommonAccountDetailRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				commonAccountDetailRequest.getToken(), commonAccountDetailRequest.getExternalUserId(), uuid);

		if (accountsModel == null) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesInvestmentAccountSummaryDetailResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		InvestmentAccountSummaryDetailRequest investmentAccountSummaryDetailRequest = new InvestmentAccountSummaryDetailRequest();
		investmentAccountSummaryDetailRequest.setSettlementAccountNumber(accountsModel.getAccountNo());
		investmentAccountSummaryDetailRequest.setRmNumber(accountsModel.getRmNumber());

		TfesInvestmentAccountSummaryDetailResponse investmentResponse = tfesService
				.getInvestmentAccountSummaryDetail(investmentAccountSummaryDetailRequest, uuid).getBody();

		if (investmentResponse.getReturnCode().equals(INVALID_AUTHENTICATION.getExternalTransactionCode())) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY),
					uuid, INVALID_AUTHENTICATION.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_AUTHENTICATION));
			return new TfesInvestmentAccountSummaryDetailResponse(INVALID_AUTHENTICATION.getTransactionCode(),
					INVALID_AUTHENTICATION.getTransactionDesc());

		} else if (investmentResponse.getReturnCode()
				.equals(SETTLEMENT_ACCOUNT_NOT_FOUND.getExternalTransactionCode())) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesInvestmentAccountSummaryDetailResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());

		} else if (investmentResponse.getReturnCode().equals(EXCEPTION_ERROR_TFES.getExternalTransactionCode())) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY),
					uuid, EXCEPTION_ERROR_TFES.getTransactionDesc(), TransactionCode.getAsError(EXCEPTION_ERROR_TFES));
			return new TfesInvestmentAccountSummaryDetailResponse(EXCEPTION_ERROR_TFES.getTransactionCode(),
					EXCEPTION_ERROR_TFES.getTransactionDesc());

		} else {

			loggingService.log(String.format("%s%s", this.getClass().toString(),
					APIGW_ACCOUNT_SERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY), uuid, investmentResponse);
			return investmentResponse;
		}
	}
}
