package ph.com.metrobank.earnest.apigw.exceptions.tfes;

import ph.com.metrobank.earnest.apigw.exceptions.base.NotFoundBaseException;

public class LinkedInvestmentAccountsNotFoundException extends NotFoundBaseException {
    public LinkedInvestmentAccountsNotFoundException() {
        super("Linked investment account not found.");
    }
}
