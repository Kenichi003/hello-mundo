package ph.com.metrobank.earnest.apigw.services;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;

import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;

public interface CreateInvestmentService {

	EnrollTrustAccountResponse createInvestmentAccount(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException;
	
	// For other channel
	EnrollTrustAccountResponse createInvestmentAccount(final String rmNumber, final String accountNo,
			String uuid) throws ExecutionException, InterruptedException, IOException, DecoderException;
}
