package ph.com.metrobank.earnest.apigw.model.request;

import ph.com.metrobank.earnest.apigw.model.Transaction;
import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

import java.util.List;
import java.util.Map;

public class TransactionDetailsResponse extends TranCodesResponse {

    private Map<String, List<Transaction>> transactions;

    public TransactionDetailsResponse( ) {}

    public TransactionDetailsResponse(
        String transactionCode,
        String transactionDesc
    ) {
        this.setTransactionCode(transactionCode);
        this.setTransactionDesc(transactionDesc);
    }

    public Map<String, List<Transaction>> getTransactions() {
        return transactions;
    }

    public void setTransactions(Map<String, List<Transaction>> transactions) {
        this.transactions = transactions;
    }
}
