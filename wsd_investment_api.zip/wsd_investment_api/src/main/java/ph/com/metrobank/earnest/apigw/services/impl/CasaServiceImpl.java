package ph.com.metrobank.earnest.apigw.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import ph.com.metrobank.earnest.apigw.config.CasaServiceConfiguration;
import ph.com.metrobank.earnest.apigw.model.response.AccountStatusDlsResponse;
import ph.com.metrobank.earnest.apigw.services.CasaService;

import java.util.Objects;

import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_CASA_SERVICE_GET_ACCOUNT_STATUS;

@Service
public class CasaServiceImpl implements CasaService {

	private RestTemplate restTemplate;
	private CasaServiceConfiguration casaServiceConfiguration;
	private LoggingService loggingService;

	@Autowired
	public CasaServiceImpl(RestTemplate restTemplate, CasaServiceConfiguration casaServiceConfiguration,
			LoggingService loggingService) {
		this.restTemplate = restTemplate;
		this.casaServiceConfiguration = casaServiceConfiguration;
		this.loggingService = loggingService;
	}

	@Override
	public Boolean isAccountActive(String settlementAccountNumber, String currencyCode, String uuid) {
		loggingService.log(String.format("%s%s", this.getClass().toString(), APIGW_CASA_SERVICE_GET_ACCOUNT_STATUS),
				uuid, null);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> httpEntity = new HttpEntity<>(headers);

		ResponseEntity<AccountStatusDlsResponse> response = restTemplate.exchange(
				casaServiceConfiguration.getAccountStatusUrl(settlementAccountNumber, currencyCode), HttpMethod.GET,
				httpEntity, AccountStatusDlsResponse.class);

		return !Objects.isNull(response.getBody())
				&& StringUtils.isEmpty(response.getBody().getWss().getErrorMessage());

	}
}
