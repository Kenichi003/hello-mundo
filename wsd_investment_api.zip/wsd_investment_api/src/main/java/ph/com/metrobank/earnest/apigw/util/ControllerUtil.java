package ph.com.metrobank.earnest.apigw.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ph.com.metrobank.earnest.apigw.exceptions.base.BadRequestBaseException;
import ph.com.metrobank.earnest.apigw.exceptions.base.ForbiddenBaseException;
import ph.com.metrobank.earnest.apigw.exceptions.base.NotFoundBaseException;
import ph.com.metrobank.earnest.apigw.exceptions.base.UnauthorizedBaseException;
import ph.com.metrobank.earnest.apigw.model.GenericResponse;

import java.util.Date;
import java.util.function.Function;

/**
 * Created by petechungtuyco on 10/22/19.
 */
public class ControllerUtil {

    private ControllerUtil(){}

    public static final Function<Throwable, ResponseEntity> handleExceptionBadRequest =
            throwable -> new ResponseEntity(new GenericResponse(Constants.PROGRAM_NAME, new Date(), throwable.getMessage(), null), HttpStatus.BAD_REQUEST);

    public static final Function<Throwable, ResponseEntity> handleExceptionUnauthorizedRequest =
            throwable -> new ResponseEntity<>(new GenericResponse(Constants.PROGRAM_NAME, new Date(), throwable.getMessage(), null), HttpStatus.UNAUTHORIZED);

    public static final Function<Throwable, ResponseEntity> handleExceptionForbidden =
            throwable -> new ResponseEntity<>(new GenericResponse(Constants.PROGRAM_NAME, new Date(), throwable.getMessage(), null), HttpStatus.FORBIDDEN);

    public static final Function<Throwable, ResponseEntity> handleExceptionNotFound =
            throwable -> new ResponseEntity<>(new GenericResponse(Constants.PROGRAM_NAME, new Date(), throwable.getMessage(), null), HttpStatus.NOT_FOUND);

    public static final Function<Throwable, ResponseEntity> handleExceptionInternalServerError =
            throwable -> new ResponseEntity(new GenericResponse(Constants.PROGRAM_NAME, new Date(), throwable.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);

    public static ResponseEntity handleThrowableErrors(Throwable e) {
        if (e instanceof BadRequestBaseException) {
            return ControllerUtil.handleExceptionBadRequest.apply(e);
        } else if (e instanceof UnauthorizedBaseException) {
            return ControllerUtil.handleExceptionUnauthorizedRequest.apply(e);
        } else if (e instanceof ForbiddenBaseException) {
            return ControllerUtil.handleExceptionForbidden.apply(e);
        } else if (e instanceof NotFoundBaseException) {
            return ControllerUtil.handleExceptionNotFound.apply(e);
        } else {
            return ControllerUtil.handleExceptionInternalServerError.apply(e);
        }
    }
}
