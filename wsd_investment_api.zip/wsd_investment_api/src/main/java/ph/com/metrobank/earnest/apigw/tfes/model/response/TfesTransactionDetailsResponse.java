package ph.com.metrobank.earnest.apigw.tfes.model.response;

import ph.com.metrobank.earnest.apigw.model.Transaction;
import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

import java.util.List;

public class TfesTransactionDetailsResponse extends TranCodesResponse {
    List<Transaction> transactions;
 

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }

}
