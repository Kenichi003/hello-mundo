package ph.com.metrobank.earnest.apigw.util;

public class StringUtil {

    public static String getLastChars(String str, int count) {
        if (str == null) {
            return "";
        }

        String lastFourDigits = "";

        if (str.length() > count) {
            lastFourDigits = str.substring(str.length() - count);
        }

        else {
            lastFourDigits = str;
        }

        return lastFourDigits;
    }
}
