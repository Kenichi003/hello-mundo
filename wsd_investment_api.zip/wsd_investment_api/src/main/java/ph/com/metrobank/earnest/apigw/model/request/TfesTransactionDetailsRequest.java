package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import java.time.LocalDate;

public class TfesTransactionDetailsRequest extends TfesCommonRequestModel {

    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonFormat(pattern = "dd-MMM-yyyy")
    private LocalDate asOfDate;

    private String investmentAccountNumber;

    public LocalDate getAsOfDate() {
        return asOfDate;
    }

    public void setAsOfDate(LocalDate asOfDate) {
        this.asOfDate = asOfDate;
    }

    public String getInvestmentAccountNumber() {
        return investmentAccountNumber;
    }

    public void setInvestmentAccountNumber(String investmentAccountNumber) {
        this.investmentAccountNumber = investmentAccountNumber;
    }
}
