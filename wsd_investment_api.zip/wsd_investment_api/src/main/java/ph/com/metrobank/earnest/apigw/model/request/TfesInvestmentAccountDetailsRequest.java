package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesInvestmentAccountDetailsRequest extends TfesCommonRequestModel {

	private String settlementAccountNumber;
//    private String investmentAccountNumber;
//    private String productCode;

	public String getSettlementAccountNumber() {
		return settlementAccountNumber;
	}

	public void setSettlementAccountNumber(String settlementAccountNumber) {
		this.settlementAccountNumber = settlementAccountNumber;
	}

}
