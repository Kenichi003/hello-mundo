package ph.com.metrobank.earnest.apigw.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonAccountDetails extends TranCodesResponse {

    private String investmentAccountNumber;
    private String investmentAccountName;
    private String accountType;

    public String getInvestmentAccountNumber() {
        return investmentAccountNumber;
    }

    public void setInvestmentAccountNumber(String investmentAccountNumber) {
        this.investmentAccountNumber = investmentAccountNumber;
    }

    public String getInvestmentAccountName() {
        return investmentAccountName;
    }

    public void setInvestmentAccountName(String investmentAccountName) {
        this.investmentAccountName = investmentAccountName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
