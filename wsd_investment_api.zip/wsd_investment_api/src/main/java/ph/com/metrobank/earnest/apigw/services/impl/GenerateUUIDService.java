package ph.com.metrobank.earnest.apigw.services.impl;

import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * Created by petechungtuyco on 10/21/19.
 */
@Service
public class GenerateUUIDService {
    public String generateUUID() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}
