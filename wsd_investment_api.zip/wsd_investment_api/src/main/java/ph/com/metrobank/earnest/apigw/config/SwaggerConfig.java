/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email emmanuel.ombrosa@metrobank.com.ph
 */
package ph.com.metrobank.earnest.apigw.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Collections;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket mobileToCasaApi() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("ph.com.metrobank.earnest.apigw")).paths(PathSelectors.any()).build()
				.apiInfo(apiInfo());
	}

	public ApiInfo apiInfo() {
		ApiInfo apiInfo = null;
		apiInfo = new ApiInfo("Metrobank EARNEST APIGW", "API for EARNEST", "1.0",
				"Terms of Service: ...", new Contact("WEBSERVICES", "DDD-Gateway Service Department", ""),
				"License Version 1.0", "", Collections.emptyList());
		return apiInfo;
	}

}
