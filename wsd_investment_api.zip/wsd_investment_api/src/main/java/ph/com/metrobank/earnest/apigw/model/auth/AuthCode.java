package ph.com.metrobank.earnest.apigw.model.auth;

public class AuthCode {
    private String code;
    private boolean resend;
    private String otpGenId;
    public AuthCode() {
        super();
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public boolean isResend() {
        return resend;
    }
    public void setResend(boolean resend) {
        this.resend = resend;
    }
    public String getOtpGenId() {
        return otpGenId;
    }
    public void setOtpGenId(String otpGenId) {
        this.otpGenId = otpGenId;
    }
}

