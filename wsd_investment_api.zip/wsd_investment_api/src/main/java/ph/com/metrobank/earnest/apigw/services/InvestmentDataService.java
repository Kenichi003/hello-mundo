package ph.com.metrobank.earnest.apigw.services;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.DecoderException;

import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;

public interface InvestmentDataService {

	TfesProductsResponse getProducts(String uuid) throws UnsupportedEncodingException, DecoderException;

}
