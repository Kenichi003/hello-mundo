package ph.com.metrobank.earnest.apigw.services.impl;

import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_SERVICE_VALIDATE_CLIENT_PRODUCT_RISK_PROFILE;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT_RESULT;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.Question;
import ph.com.metrobank.earnest.apigw.model.request.TfesInvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesUpdateSuitabilityAssessmentRequest;
import ph.com.metrobank.earnest.apigw.services.DirectLinkService;
import ph.com.metrobank.earnest.apigw.services.ProductRiskService;
import ph.com.metrobank.earnest.apigw.services.TfesService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;
import ph.com.metrobank.earnest.apigw.util.JsonUtil;

/**
 * 
 * @author 34785 - emmanuel.b.ombrosa
 *
 */

@Service
public class ProductRiskServiceImpl implements ProductRiskService {

	private DirectLinkService directLinkService;

	private LoggingService loggingService;

	private TfesService tfesService;

	private TranCodeLogResponseHelper tranCodeLogResponseHelper;

	@Autowired
	public ProductRiskServiceImpl(DirectLinkService directLinkService, LoggingService loggingService,
			TfesService tfesService, TranCodeLogResponseHelper tranCodeLogResponseHelper) {
		this.directLinkService = directLinkService;
		this.loggingService = loggingService;
		this.tfesService = tfesService;
		this.tranCodeLogResponseHelper = tranCodeLogResponseHelper;
	}

	@Override
	public TfesClientProductRiskProfileResponse validateClientProductRiskProfile(DirectLinkRequestCommonModel request,
			String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), APIGW_SERVICE_VALIDATE_CLIENT_PRODUCT_RISK_PROFILE),
				uuid, request);

		InvestmentAccountDetailsRequest investmentProductRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(),
				InvestmentAccountDetailsRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				investmentProductRequest.getToken(), investmentProductRequest.getExternalUserId(), uuid);

		if (Objects.isNull(accountsModel)) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							TraceLog.APIGW_SERVICE_VALIDATE_CLIENT_PRODUCT_RISK_PROFILE),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesClientProductRiskProfileResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		return validateClientProductRiskProfile(accountsModel.getRmNumber(),
				investmentProductRequest.getInvestmentAccountNumber(), investmentProductRequest.getProductCode(), uuid);
	}

	@Override
	public TfesUpdateSuitabilityAssessmentResponse updateSuitabilityAssessment(DirectLinkRequestCommonModel request,
			String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {

		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_SUITABILITY_ASSESSMENT_SERVICE_UPDATE_SUITABILITY_ASSESSMENT), uuid, request);

		TfesUpdateSuitabilityAssessmentRequest updateRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(),
				TfesUpdateSuitabilityAssessmentRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(updateRequest.getToken(),
				updateRequest.getExternalUserId(), uuid);

		if (Objects.isNull(accountsModel)) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							TraceLog.APIGW_SUITABILITY_ASSESSMENT_SERVICE_UPDATE_SUITABILITY_ASSESSMENT),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesUpdateSuitabilityAssessmentResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		return updateSuitabilityAssessment(accountsModel.getRmNumber(), updateRequest.getQuestionnaireId(),
				updateRequest.getQuestions(), uuid);
	}

	@Override
	public TfesProductsResponse getSuitabilityAssessmentResults(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT_RESULT),
				uuid, request);

		InvestmentAccountDetailsRequest investmentProductRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(),
				InvestmentAccountDetailsRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				investmentProductRequest.getToken(), investmentProductRequest.getExternalUserId(), uuid);

		if (Objects.isNull(accountsModel)) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT_RESULT),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesProductsResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		return getSuitabilityAssessmentResults(accountsModel.getRmNumber(),
				investmentProductRequest.getInvestmentAccountNumber(), uuid);
	}
	
	@Override
	public TfesClientProductRiskProfileResponse validateClientProductRiskProfile(final String rmNumber,
			final String investmentAccountNumber, final String productCode, String uuid)
			throws IOException, DecoderException {

		TfesInvestmentAccountDetailsRequest investmentAccntDtlRequest = new TfesInvestmentAccountDetailsRequest();
		investmentAccntDtlRequest.setRmNumber(rmNumber);
		investmentAccntDtlRequest.setInvestmentAccountNumber(investmentAccountNumber);
		investmentAccntDtlRequest.setProductCode(productCode);

		TfesClientProductRiskProfileResponse response = tfesService
				.validateClientProductRiskProfile(investmentAccntDtlRequest, uuid).getBody();

		tranCodeLogResponseHelper.setAndLogTranCode(response,
				TraceLog.APIGW_SERVICE_VALIDATE_CLIENT_PRODUCT_RISK_PROFILE, this.getClass().toString(),
				uuid);

		return response;
	}

	@Override
	public TfesUpdateSuitabilityAssessmentResponse updateSuitabilityAssessment(final String rmNumber,
			final String questionnaireId, final List<Question> questions, String uuid)
			throws IOException, DecoderException {

		TfesUpdateSuitabilityAssessmentRequest updateSuitabilityAssessmentRequest = new TfesUpdateSuitabilityAssessmentRequest();
		updateSuitabilityAssessmentRequest.setRmNumber(rmNumber);
		updateSuitabilityAssessmentRequest.setQuestionnaireId(questionnaireId);
		updateSuitabilityAssessmentRequest.setQuestions(questions);

		TfesUpdateSuitabilityAssessmentResponse response = tfesService
				.updateSuitabilityAssessment(updateSuitabilityAssessmentRequest, uuid).getBody();

		tranCodeLogResponseHelper.setAndLogTranCode(response,
				TraceLog.APIGW_SUITABILITY_ASSESSMENT_SERVICE_UPDATE_SUITABILITY_ASSESSMENT, this.getClass().toString(),
				uuid);

		return response;
	}
	
	@Override
	public TfesProductsResponse getSuitabilityAssessmentResults(final String rmNumber,
			final String investmentAccountNumber, final String uuid) throws IOException, DecoderException {

		TfesInvestmentAccountDetailsRequest request = new TfesInvestmentAccountDetailsRequest();
		request.setRmNumber(rmNumber);
		request.setInvestmentAccountNumber(investmentAccountNumber);

		TfesProductsResponse response = tfesService.getSuitabilityAssessmentResults(request, uuid).getBody();

		tranCodeLogResponseHelper.setAndLogTranCode(response, APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT_RESULT,
				this.getClass().toString(), uuid);

		return response;
	}

}
