package ph.com.metrobank.earnest.apigw.model.otp;

import ph.com.metrobank.earnest.apigw.model.auth.AuthCode;

public class ValidateOrSendOtpRequest {
    private String channelId;
    private String accountNo;
    private String externalUserId;
    private String referenceNo;
    private AuthCode auth;

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getExternalUserId() {
        return externalUserId;
    }

    public void setExternalUserId(String externalUserId) {
        this.externalUserId = externalUserId;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public AuthCode getAuth() {
        return auth;
    }

    public void setAuth(AuthCode auth) {
        this.auth = auth;
    }
}
