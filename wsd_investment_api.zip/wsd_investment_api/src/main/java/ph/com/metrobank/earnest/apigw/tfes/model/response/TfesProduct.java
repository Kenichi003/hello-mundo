package ph.com.metrobank.earnest.apigw.tfes.model.response;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesProduct {

	private String productId;
	private String productCode;
	private String productName;
	private String cutOffTime;
	private String productTypeName;
	private String currency;
	private String investmentHorizon;
	private Integer settlementPeriod;
	private String launchDate;
	private String riskProfile;
	private String benchmark;
	private String fundObjective;
	private BigDecimal minSubscriptionAmount;
	private BigDecimal maxSubscriptionAmount;
	private BigDecimal minSubscriptionTopup;
	private BigDecimal maxSubscriptionTopup;
	private BigDecimal minRedemptionUnit;
	private BigDecimal maxRedemptionUnit;
	private BigDecimal minRedemptionAmount;
	private BigDecimal maxRedemptionAmount;
	private BigDecimal minBalAfterRedemptionAmount;
	private BigDecimal minBalAfterRedemptionUnit;
	private BigDecimal initialNav;
	private String allowSubscription;
	private String allowRedemption;
	private String rspFlag;
	private BigDecimal latestNav;
	private String taxApplied;
	private BigDecimal taxRate;
	private Integer unitRounding;
	private Integer unitDecimal;
	private BigDecimal managementFee;
	private String investmentOutlet;
	private Integer minHoldingPeriod;
	private Integer redemptionFee;
	private String feeChargeFrom;
	private String productStatus;
	private String productType;
	private String lastNAVDate;

	public TfesProduct() {
		super();
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCutOffTime() {
		return cutOffTime;
	}

	public void setCutOffTime(String cutOffTime) {
		this.cutOffTime = cutOffTime;
	}

	public String getProductTypeName() {
		return productTypeName;
	}

	public void setProductTypeName(String productTypeName) {
		this.productTypeName = productTypeName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getInvestmentHorizon() {
		return investmentHorizon;
	}

	public void setInvestmentHorizon(String investmentHorizon) {
		this.investmentHorizon = investmentHorizon;
	}

	public Integer getSettlementPeriod() {
		return settlementPeriod;
	}

	public void setSettlementPeriod(Integer settlementPeriod) {
		this.settlementPeriod = settlementPeriod;
	}

	public String getLaunchDate() {
		return launchDate;
	}

	public void setLaunchDate(String launchDate) {
		this.launchDate = launchDate;
	}

	public String getRiskProfile() {
		return riskProfile;
	}

	public void setRiskProfile(String riskProfile) {
		this.riskProfile = riskProfile;
	}

	public String getBenchmark() {
		return benchmark;
	}

	public void setBenchmark(String benchmark) {
		this.benchmark = benchmark;
	}

	public String getFundObjective() {
		return fundObjective;
	}

	public void setFundObjective(String fundObjective) {
		this.fundObjective = fundObjective;
	}

	public BigDecimal getMinSubscriptionAmount() {
		return minSubscriptionAmount;
	}

	public void setMinSubscriptionAmount(BigDecimal minSubscriptionAmount) {
		this.minSubscriptionAmount = minSubscriptionAmount;
	}

	public BigDecimal getMaxSubscriptionAmount() {
		return maxSubscriptionAmount;
	}

	public void setMaxSubscriptionAmount(BigDecimal maxSubscriptionAmount) {
		this.maxSubscriptionAmount = maxSubscriptionAmount;
	}

	public BigDecimal getMinSubscriptionTopup() {
		return minSubscriptionTopup;
	}

	public void setMinSubscriptionTopup(BigDecimal minSubscriptionTopup) {
		this.minSubscriptionTopup = minSubscriptionTopup;
	}

	public BigDecimal getMaxSubscriptionTopup() {
		return maxSubscriptionTopup;
	}

	public void setMaxSubscriptionTopup(BigDecimal maxSubscriptionTopup) {
		this.maxSubscriptionTopup = maxSubscriptionTopup;
	}

	public BigDecimal getMinRedemptionUnit() {
		return minRedemptionUnit;
	}

	public void setMinRedemptionUnit(BigDecimal minRedemptionUnit) {
		this.minRedemptionUnit = minRedemptionUnit;
	}

	public BigDecimal getMaxRedemptionUnit() {
		return maxRedemptionUnit;
	}

	public void setMaxRedemptionUnit(BigDecimal maxRedemptionUnit) {
		this.maxRedemptionUnit = maxRedemptionUnit;
	}

	public BigDecimal getMinRedemptionAmount() {
		return minRedemptionAmount;
	}

	public void setMinRedemptionAmount(BigDecimal minRedemptionAmount) {
		this.minRedemptionAmount = minRedemptionAmount;
	}

	public BigDecimal getMaxRedemptionAmount() {
		return maxRedemptionAmount;
	}

	public void setMaxRedemptionAmount(BigDecimal maxRedemptionAmount) {
		this.maxRedemptionAmount = maxRedemptionAmount;
	}

	public BigDecimal getMinBalAfterRedemptionAmount() {
		return minBalAfterRedemptionAmount;
	}

	public void setMinBalAfterRedemptionAmount(BigDecimal minBalAfterRedemptionAmount) {
		this.minBalAfterRedemptionAmount = minBalAfterRedemptionAmount;
	}

	public BigDecimal getMinBalAfterRedemptionUnit() {
		return minBalAfterRedemptionUnit;
	}

	public void setMinBalAfterRedemptionUnit(BigDecimal minBalAfterRedemptionUnit) {
		this.minBalAfterRedemptionUnit = minBalAfterRedemptionUnit;
	}

	public BigDecimal getInitialNav() {
		return initialNav;
	}

	public void setInitialNav(BigDecimal initialNav) {
		this.initialNav = initialNav;
	}

	public String getAllowSubscription() {
		return allowSubscription;
	}

	public void setAllowSubscription(String allowSubscription) {
		this.allowSubscription = allowSubscription;
	}

	public String getAllowRedemption() {
		return allowRedemption;
	}

	public void setAllowRedemption(String allowRedemption) {
		this.allowRedemption = allowRedemption;
	}

	public String getRspFlag() {
		return rspFlag;
	}

	public void setRspFlag(String rspFlag) {
		this.rspFlag = rspFlag;
	}

	public BigDecimal getLatestNav() {
		return latestNav;
	}

	public void setLatestNav(BigDecimal latestNav) {
		this.latestNav = latestNav;
	}

	public String getTaxApplied() {
		return taxApplied;
	}

	public void setTaxApplied(String taxApplied) {
		this.taxApplied = taxApplied;
	}

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public Integer getUnitRounding() {
		return unitRounding;
	}

	public void setUnitRounding(Integer unitRounding) {
		this.unitRounding = unitRounding;
	}

	public Integer getUnitDecimal() {
		return unitDecimal;
	}

	public void setUnitDecimal(Integer unitDecimal) {
		this.unitDecimal = unitDecimal;
	}

	public BigDecimal getManagementFee() {
		return managementFee;
	}

	public void setManagementFee(BigDecimal managementFee) {
		this.managementFee = managementFee;
	}

	public String getInvestmentOutlet() {
		return investmentOutlet;
	}

	public void setInvestmentOutlet(String investmentOutlet) {
		this.investmentOutlet = investmentOutlet;
	}

	public Integer getMinHoldingPeriod() {
		return minHoldingPeriod;
	}

	public void setMinHoldingPeriod(Integer minHoldingPeriod) {
		this.minHoldingPeriod = minHoldingPeriod;
	}

	public Integer getRedemptionFee() {
		return redemptionFee;
	}

	public void setRedemptionFee(Integer redemptionFee) {
		this.redemptionFee = redemptionFee;
	}

	public String getFeeChargeFrom() {
		return feeChargeFrom;
	}

	public void setFeeChargeFrom(String feeChargeFrom) {
		this.feeChargeFrom = feeChargeFrom;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getLastNAVDate() {
		return lastNAVDate;
	}

	public void setLastNAVDate(String lastNAVDate) {
		this.lastNAVDate = lastNAVDate;
	}
	
	

}
