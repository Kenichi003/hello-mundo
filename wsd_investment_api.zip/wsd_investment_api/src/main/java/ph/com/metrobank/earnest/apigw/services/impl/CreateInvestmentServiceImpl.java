package ph.com.metrobank.earnest.apigw.services.impl;

import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_SERVICE_CREATE_INVESTMENT_ACCOUNT_SERVICE;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.request.CommonAccountDetailRequest;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.services.CreateInvestmentService;
import ph.com.metrobank.earnest.apigw.services.DirectLinkService;
import ph.com.metrobank.earnest.apigw.services.TfesService;
import ph.com.metrobank.earnest.apigw.util.JsonUtil;

/**
 * 
 * @author 34785 - emmanuel.b.ombrosa
 *
 */

@Service
public class CreateInvestmentServiceImpl implements CreateInvestmentService {

	private DirectLinkService directLinkService;

	private LoggingService loggingService;

	private TfesService tfesService;
	
	private TranCodeLogResponseHelper tranCodeLogResponseHelper;

	@Autowired
	public CreateInvestmentServiceImpl(DirectLinkService directLinkService, LoggingService loggingService,
			TfesService tfesService, TranCodeLogResponseHelper tranCodeLogResponseHelper) {
		this.directLinkService = directLinkService;
		this.loggingService = loggingService;
		this.tfesService = tfesService;
		this.tranCodeLogResponseHelper = tranCodeLogResponseHelper;
	}

	@Override
	public EnrollTrustAccountResponse createInvestmentAccount(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), APIGW_SERVICE_CREATE_INVESTMENT_ACCOUNT_SERVICE),
				uuid, request);

		CommonAccountDetailRequest commonAccountDetailRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(), CommonAccountDetailRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				commonAccountDetailRequest.getToken(), commonAccountDetailRequest.getExternalUserId(), uuid);

		if (Objects.isNull(accountsModel)) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), APIGW_SERVICE_CREATE_INVESTMENT_ACCOUNT_SERVICE),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new EnrollTrustAccountResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}
		
		return createInvestmentAccount(accountsModel.getRmNumber(), accountsModel.getAccountNo(), uuid);
	}
	
	@Override
	public EnrollTrustAccountResponse createInvestmentAccount(final String rmNumber, final String accountNo,
			String uuid) throws ExecutionException, InterruptedException, IOException, DecoderException {

		EnrollTrustAccountResponse response = tfesService.enrollTrustAccount(rmNumber, accountNo, uuid).getBody();

		tranCodeLogResponseHelper.setAndLogTranCode(response, TraceLog.APIGW_SERVICE_CREATE_INVESTMENT_ACCOUNT_SERVICE,
				this.getClass().toString(), uuid);

		return response;
	}

}
