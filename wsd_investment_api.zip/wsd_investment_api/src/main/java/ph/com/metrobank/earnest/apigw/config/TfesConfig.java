
package ph.com.metrobank.earnest.apigw.config;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import generator.JatisTfesAuthGen;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;

@Configuration
public class TfesConfig {

	@Autowired
	private LoggingService loggingService;

	@Value("${shouldGenerateSaltAndSign}")
	private boolean shouldGenerateSaltAndSign;

	@Value("${tfes.salt}")
	private String salt;

	@Value("${tfes.sign}")
	private String sign;

	@Value("${systemId}")
	private String systemId;

	@Value("${systemPassword}")
	private String systemPassword;

	@Value("${transact.uri.enroll}")
	private String enrollTrustAccount;

	@Value("${transact.uri.createInitialSubscription}")
	private String createInitialSubscription;

	@Value("${transact.uri.createAdditionalSubscription}")
	private String createAdditionalSubscription;

	@Value("${transact.uri.createRedemption}")
	private String createRedemption;

	@Value("${transact.uri.accountSummary}")
	private String investmentAccountSummaryDetailUrl;

	@Value("${transact.uri.productTransactions}")
	private String transactionDetailUrl;

	@Value("${transact.uri.accountDetails}")
	private String investmentAccountDetailsUrl;

	@Value("${tfes.uri.products}")
	private String investmentProductsUrl;

	@Value("${transact.uri.viewSuitabilityExpirationDate}")
	private String suitabilityExpirationDateUrl;

	@Value("${transact.uri.validateClientProductRiskProfile}")
	private String validateClientProductRiskProfileUrl;

	@Value("${transact.uri.updateSuitabilityAssessmentForm}")
	private String updateSuitabilityAssessmentFormUrl;

	@Value("${transact.uri.productList}")
	private String assessmentResultPerProductUrl;

	private JsonObject saltAndSignJsonObject;

	public String getEnrollTrustAccount() {
		return enrollTrustAccount;
	}

	public String getCreateInitialSubscription() {
		return createInitialSubscription;
	}

	public String getCreateAdditionalSubscription() {
		return createAdditionalSubscription;
	}

	public String getCreateRedemption() {
		return createRedemption;
	}

	public String getTransactionDetailUrl() {
		return transactionDetailUrl;
	}

	public String getSystemId() {
		return systemId;
	}

	public String getSystemPassword() {
		return systemPassword;
	}

	public String getInvestmentAccountSummaryDetailUrl() {
		return investmentAccountSummaryDetailUrl;
	}

	public String getInvestmentAccountDetailsUrl() {
		return investmentAccountDetailsUrl;
	}

	public String getSaltValue() throws UnsupportedEncodingException, DecoderException {
		if (shouldGenerateSaltAndSign) {
			if (saltAndSignJsonObject == null) {
				try {
					saltAndSignJsonObject = parseString(JatisTfesAuthGen.hashed(systemId, systemPassword))
							.getAsJsonObject();
				} catch (Exception e) {
					loggingService.log(this.getClass().toString() + TraceLog.APIGW_TFESCONFIG_AUTHGEN_EXCEPTION, "",
							"ERROR: " + e.getMessage());
					return null;
				}
				return saltAndSignJsonObject.get("saltValue").getAsString();
			} else {
				String saltValue = saltAndSignJsonObject.get("saltValue").getAsString();
				saltAndSignJsonObject = null;
				return saltValue;
			}
		} else {
			return salt;
		}
	}

	public String getSignValue() throws UnsupportedEncodingException, DecoderException {
		if (shouldGenerateSaltAndSign) {
			if (saltAndSignJsonObject == null) {
				try {
					saltAndSignJsonObject = parseString(JatisTfesAuthGen.hashed(systemId, systemPassword))
							.getAsJsonObject();
				} catch (Exception e) {
					loggingService.log(this.getClass().toString() + TraceLog.APIGW_TFESCONFIG_AUTHGEN_EXCEPTION, "",
							"ERROR: " + e.getMessage());
					return null;
				}
				return saltAndSignJsonObject.get("signValue").getAsString();
			} else {
				String signValue = saltAndSignJsonObject.get("signValue").getAsString();
				saltAndSignJsonObject = null;
				return signValue;
			}
		} else {
			return sign;
		}
	}

	public JsonElement parseString(String toParse) {
		try {
			JsonElement jsonElement = JsonParser.parseString(toParse);
			return jsonElement;
		} catch (JsonSyntaxException e) {
			throw new JsonSyntaxException(e.getMessage());
		}
	}

	public String getInvestmentProductsUrl() {
		return investmentProductsUrl;
	}

	public String getSuitabilityExpirationDateUrl() {
		return suitabilityExpirationDateUrl;
	}

	public String getValidateClientProductRiskProfileUrl() {
		return validateClientProductRiskProfileUrl;
	}

	public String getUpdateSuitabilityAssessmentFormUrl() {
		return updateSuitabilityAssessmentFormUrl;
	}

	public String getAssessmentResultPerProductUrl() {
		return assessmentResultPerProductUrl;
	}

	public String verifyApplicationProperties() {
		StringBuilder builder = new StringBuilder();
		builder.append("INVESTMENTS API PROPERTIES: ").append(getInvestmentAccountSummaryDetailUrl())
				.append(getInvestmentAccountDetailsUrl()).append(getTransactionDetailUrl())
				.append(getCreateInitialSubscription()).append(getCreateAdditionalSubscription())
				.append(getCreateRedemption());
		return builder.toString();
	}

}
