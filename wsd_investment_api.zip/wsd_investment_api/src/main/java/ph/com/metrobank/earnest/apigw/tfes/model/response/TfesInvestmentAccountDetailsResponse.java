package ph.com.metrobank.earnest.apigw.tfes.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import ph.com.metrobank.earnest.apigw.model.CommonAccountDetails;
import ph.com.metrobank.earnest.apigw.model.response.InvestmentSummaryDetail;

import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesInvestmentAccountDetailsResponse extends CommonAccountDetails {
    private String currencyCode;
    private BigDecimal totalMarketValue;
    private String servicingBranch;
    private String lastSAFUpdateDate;
    private String returnCode;
    private List<InvestmentSummaryDetail> investmentSummaryDetails;

    public TfesInvestmentAccountDetailsResponse() {}

    public TfesInvestmentAccountDetailsResponse(
        String transactionCode,
        String transactionDesc
    ) {
        this.setTransactionCode(transactionCode);
        this.setTransactionDesc(transactionDesc);
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getTotalMarketValue() {
        return totalMarketValue;
    }

    public void setTotalMarketValue(BigDecimal totalMarketValue) {
        this.totalMarketValue = totalMarketValue;
    }

    public String getServicingBranch() {
        return servicingBranch;
    }

    public void setServicingBranch(String servicingBranch) {
        this.servicingBranch = servicingBranch;
    }

    public String getLastSAFUpdateDate() {
        return lastSAFUpdateDate;
    }

    public void setLastSAFUpdateDate(String lastSAFUpdateDate) {
        this.lastSAFUpdateDate = lastSAFUpdateDate;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public List<InvestmentSummaryDetail> getInvestmentSummaryDetails() {
        return investmentSummaryDetails;
    }

    public void setInvestmentSummaryDetails(List<InvestmentSummaryDetail> investmentSummaryDetails) {
        this.investmentSummaryDetails = investmentSummaryDetails;
    }
}
