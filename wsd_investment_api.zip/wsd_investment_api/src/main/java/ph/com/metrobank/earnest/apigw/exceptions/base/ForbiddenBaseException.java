package ph.com.metrobank.earnest.apigw.exceptions.base;

/**
 * Created by petechungtuyco on 10/22/19.
 */
public class ForbiddenBaseException extends RuntimeException {
    public ForbiddenBaseException(String message) {
        super(message);
    }
}
