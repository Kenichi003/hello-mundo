package ph.com.metrobank.earnest.apigw.model.response;


import ph.com.metrobank.earnest.apigw.model.WsStatus;

public class AccountStatusDlsResponse {
    private WsStatus wss;

    public WsStatus getWss() {
        return wss;
    }

    public void setWss(WsStatus wss) {
        this.wss = wss;
    }
}
