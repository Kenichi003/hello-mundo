package ph.com.metrobank.earnest.apigw.enums;

public enum AccountType {
    FOUR("4", "I"),
    SEVEN("7", "I"),
    ZERO("0", "T"),
    ONE("1", "T"),
    DEFAULT("", "S");

    private String settlementFirstDigit;
    private String accountTypeSign;

    AccountType(String settlementFirstDigit, String accountTypeSign) {
        this.settlementFirstDigit = settlementFirstDigit;
        this.accountTypeSign = accountTypeSign;

    }

    public static String getAccountTypeBySettlementFirstDigit(String settlementFirstDigit) {
        for(AccountType accountType : values()){
            if(accountType.settlementFirstDigit.equals(settlementFirstDigit)){
                return accountType.accountTypeSign;
            }
        }
        return DEFAULT.accountTypeSign;
    }
}
