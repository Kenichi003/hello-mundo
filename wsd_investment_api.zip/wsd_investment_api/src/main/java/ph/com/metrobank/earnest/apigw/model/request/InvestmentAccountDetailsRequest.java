package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InvestmentAccountDetailsRequest extends CommonAccountDetailRequest {
    private String investmentAccountNumber;
    private String productCode;
    private String rmNumber; 

    public String getInvestmentAccountNumber() {
        return investmentAccountNumber;
    }

    public void setInvestmentAccountNumber(String investmentAccountNumber) {
        this.investmentAccountNumber = investmentAccountNumber;
    }

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getRmNumber() {
		return rmNumber;
	}

	public void setRmNumber(String rmNumber) {
		this.rmNumber = rmNumber;
	}
    
}
