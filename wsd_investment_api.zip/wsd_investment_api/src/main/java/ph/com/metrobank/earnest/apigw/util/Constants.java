package ph.com.metrobank.earnest.apigw.util;

/**
 * Created by petechungtuyco on 10/22/19.
 */
public class Constants {

    public Constants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String PROGRAM_NAME = "ERN_API_GATEWAY";
    public static final String MERCHANT_ID = "ERN";
}
