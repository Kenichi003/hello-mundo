package ph.com.metrobank.earnest.apigw.services;

import org.apache.commons.codec.DecoderException;
import org.springframework.http.ResponseEntity;
import ph.com.metrobank.earnest.apigw.model.request.*;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesTransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.ExecutionException;

public interface TfesService {
    ResponseEntity<EnrollTrustAccountResponse> enrollTrustAccount(String rmNumber, String settlementAccountNumber, String uuid) throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException;

    ResponseEntity<TfesCommonTransactionResponse> createSubscription(CreateSubscriptionRequest request, String uri, String uuid) throws ExecutionException, InterruptedException;

    ResponseEntity<TfesCommonTransactionResponse> createRedemption(CreateRedemptionRequest request, String uuid) throws ExecutionException, InterruptedException;

    ResponseEntity<TfesInvestmentAccountSummaryDetailResponse> getInvestmentAccountSummaryDetail(InvestmentAccountSummaryDetailRequest request, String uuid) throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException;

    ResponseEntity<TfesTransactionDetailsResponse> getTransactionDetails(TfesTransactionDetailsRequest request, String uuid) throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException;

    ResponseEntity<TfesInvestmentAccountDetailsResponse> getInvestmentAccountDetails(TfesInvestmentAccountDetailsRequest request, String uuid) throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException;
    
    ResponseEntity<TfesProductsResponse> getInvestmentProducts(String uuid) throws UnsupportedEncodingException, DecoderException;

    ResponseEntity<TfesSuitabilityExpirationResponse> getSuitabilityExpirationDate(TfesInvestmentAccountDetailsRequest request, String uuid) throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException;
    
    ResponseEntity<TfesClientProductRiskProfileResponse> validateClientProductRiskProfile(TfesInvestmentAccountDetailsRequest request, String uuid) throws UnsupportedEncodingException, DecoderException;

    ResponseEntity<TfesUpdateSuitabilityAssessmentResponse> updateSuitabilityAssessment(TfesUpdateSuitabilityAssessmentRequest request, String uuid) throws UnsupportedEncodingException, DecoderException;
    
    ResponseEntity<TfesProductsResponse> getSuitabilityAssessmentResults(TfesInvestmentAccountDetailsRequest request, String uuid) throws UnsupportedEncodingException, DecoderException;
}
