package ph.com.metrobank.earnest.apigw.enums;

import ph.com.metrobank.earnest.apigw.exceptions.ErrorCodeNotFoundException;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

public enum TransactionCode {
    UNMAPPED_ERROR("00000", "00000", "Unmapped Error"),
    INVALID_SETTLEMENT_ACCOUNT_NUMBER("00001", "", "Invalid Settlement Account Number"),
    PHP_ONLY_SETTLEMENT_ACCOUNT("00002", "", "Settlement Account Number is not PHP"),
    SETTLEMENT_ACCOUNT_ALREADY_LINKED("00003", "", "Settlement Account Number is already linked"),
    SETTLEMENT_ACCOUNT_INACTIVE("00004", "", "Settlement Account is inactive"),
    INVALID_OTP("00005", "003", "Invalid Otp"),
    PENDING_OTP("00006", "009", "Pending Otp"),
    VALID_OTP("00007", "011", "Valid Otp"),
    INVALID_OTP_REQUEST("00008", "002", "Invalid Otp Request"),
    INVALID_OR_ACCOUNT_NOT_EXISTING("00009", "014", "Invalid or account does not exist"),

    INVALID_AUTHENTICATION("00010", "9700001", "Invalid Authentication"),
    INVALID_MINIMUM_SUBSCRIPTION_AMOUNT("00011", "9700022", "Invalid minimum subscription amount"),
    INVALID_MAXIMUM_SUBSCRIPTION_AMOUNT("00012", "9700024", "Invalid maximum subscription amount"),
    INVALID_MINIMUM_RSP_AMOUNT("00013", "9700042", "Invalid minimum rsp amount"),
    INVALID_MAXIMUM_RSP_AMOUNT("00014", "9700047", "Invalid maximum rsp amount."),
    ACCOUNTS_DOES_NOT_MATCH("00015", "", "Investment account and settle account doesn't match"),
    INVALID_MINIMUM_TOPUP_AMOUNT("00016", "9700049", "Invalid minimum topup amount."),
    INVALID_MAXIMUM_TOPUP_AMOUNT("00017", "9700051", "Invalid maximum topup amount."),

    INVALID_MINIMUM_REDEMPTION_UNIT("00018", "9700026", "Invalid minimum redemption unit."),
    INVALID_MAXIMUM_REDEMPTION_UNIT("00019", "9700028", "Invalid maximum redemption unit."),
    VALID_MINIMUM_REDEMPTION_AMOUNT("00020", "9700029", "Valid minimum redemption amount."),
    VALID_MAXIMUM_REDEMPTION_AMOUNT("00021", "9700031", "Valid maximum redemption amount."),
    INVALID_AVAILABLE_UNIT("00022", "9700036", "Invalid available unit"),
    INVALID_MINIMUM_MAINTAINING_UNIT_AFTER_REDEMPTION("00023", "9700038", "Invalid minimum maintaining unit after redemption."),
    INVALID_MINIMUM_MAINTAINING_AMOUNT_AFTER_REDEMPTION("00024", "9700040", "Invalid minimum maintaining amount after redemption."),
    TRANSACTION_SUCCESS("00025", "9700015", "Transaction success"),
    EXCEPTION_ERROR_TFES("00026", "9700014", "Exception error in TFES."),
    SETTLEMENT_ACCOUNT_NOT_FOUND("00027", "9700003", "Settlement account not found."),
    LINKED_INVESTMENT_ACCOUNT_NOT_FOUND("00028", "9700004", "Linked Investment Account(s) not found."),
    REQUEST_SUCCESSFULLY_PROCESSED("00029", "9700002", "Request successfully processed."),
    DATA_DOESNT_EXIST("00030", "9700006", "Data doesn't exist yet."),
    INVALID_MINIMUM_REDEMPTION_AMOUNT("00031", "9700030", "Invalid minimum redemption amount."),
    INVALID_MAXIMUM_REDEMPTION_AMOUNT("00032", "9700032", "Invalid maximum redemption amount."),
    PENDING_INVESTMENT_ACCOUNT_CREATION("00033", "", "Pending Investment Account Creation"),
	
	PRODUCT_RISK_EQUAL_TO_CLIENT_RISK("00034", "9700043", "Product risk profile is equal to client risk profile"),
	PRODUCT_RISK_LOWER_TO_CLIENT_RISK("00035", "9700044", "Product risk profile is lower than the client risk profile"),
	PRODUCT_RISK_HIGHER_TO_CLIENT_RISK("00036", "9700045", "Product risk profile is higher than the client risk profile");

    private final String transactionCode;
    private final String externalTransactionCode;
    private final String transactionDesc;

    TransactionCode(String transactionCode, String externalTransactionCode, String transactionDesc) {
        this.transactionCode = transactionCode;
        this.transactionDesc = transactionDesc;
        this.externalTransactionCode = externalTransactionCode;
    }

    public String getTransactionCode() {
        return transactionCode;
    }

    public String getTransactionDesc() {
        return transactionDesc;
    }

    public String getExternalTransactionCode() {
        return externalTransactionCode;
    }

    public static boolean contains(String errorCode) {
        for (TransactionCode c : TransactionCode.values()) {
            if (c.getTransactionCode().equals(errorCode)) {
                return true;
            }
        }
        return false;
    }

    public static Map<String, String> getAsError(TransactionCode transactionCode){
        for (TransactionCode c : TransactionCode.values()) {
            if (c.equals(transactionCode)) {
                Map<String, String> error = new LinkedHashMap<>();
                error.put("transactionCode", transactionCode.getTransactionCode());
                error.put("transactionDesc", transactionCode.getTransactionDesc());
                return error;
            }
        }
        throw new ErrorCodeNotFoundException();
    }
    
    public static Optional<TransactionCode> fromExternalTransactionCode(String returnCode) {
        return Arrays.stream(values())
          .filter(t -> t.externalTransactionCode.equals(returnCode))
          .findFirst();
    }


}
