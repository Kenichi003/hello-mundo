package ph.com.metrobank.earnest.apigw.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CasaServiceConfiguration {

	@Value("${casa.base.endpoint}")
	private String baseUrl;

	@Value("${casa.accountstatus.endpoint}")
	private String accountStatusUrl;

	public String getAccountStatusUrl(String settlementAccountNumber, String currency) {
		return String.format("%s%s/%s/%s", baseUrl, accountStatusUrl, settlementAccountNumber, currency);
	}

	public String getAccountStatusUrl() {
		return accountStatusUrl;
	}

	public String verifyApplicationProperties() {
		StringBuilder builder = new StringBuilder();
		builder.append("CASA API PROPERTY: ").append(getAccountStatusUrl());
		return builder.toString();
	}
}
