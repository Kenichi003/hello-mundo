package ph.com.metrobank.earnest.apigw.model.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesUpdateSuitabilityAssessmentRequest extends CommonAccountDetailRequest {

	private String userId;
	private String signValue;
	private String saltValue;
	private String rmNumber;
	private String questionnaireId;
	private List<Question> questions;
	
	public TfesUpdateSuitabilityAssessmentRequest() {
		// Object creation for JSON serialization.
	}

	public String getQuestionnaireId() {
		return questionnaireId;
	}

	public void setQuestionnaireId(String questionnaireId) {
		this.questionnaireId = questionnaireId;
	}

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	public String getRmNumber() {
		return rmNumber;
	}

	public void setRmNumber(String rmNumber) {
		this.rmNumber = rmNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSaltValue() {
		return saltValue;
	}

	public void setSaltValue(String saltValue) {
		this.saltValue = saltValue;
	}

	public String getSignValue() {
		return signValue;
	}

	public void setSignValue(String signValue) {
		this.signValue = signValue;
	}

}
