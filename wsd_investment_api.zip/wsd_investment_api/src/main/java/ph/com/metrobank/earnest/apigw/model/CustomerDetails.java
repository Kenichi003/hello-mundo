package ph.com.metrobank.earnest.apigw.model;

public class CustomerDetails {
    private String customerNo;

    private String customerName;

    private String birthDate;

    private String tin;

    private String mobileNumber;

    private String emailAddress;

    private String relConnectorCode;

    public CustomerDetails() {
    }

    public CustomerDetails(String customerNo, String customerName, String birthDate, String tin, String mobileNumber, String emailAddress, String relConnectorCode) {
        this.customerNo = customerNo;
        this.customerName = customerName;
        this.birthDate = birthDate;
        this.tin = tin;
        this.mobileNumber = mobileNumber;
        this.emailAddress = emailAddress;
        this.relConnectorCode = relConnectorCode;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getRelConnectorCode() {
        return relConnectorCode;
    }

    public void setRelConnectorCode(String relConnectorCode) {
        this.relConnectorCode = relConnectorCode;
    }
}
