package ph.com.metrobank.earnest.apigw.services;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;

import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.Question;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

public interface ProductRiskService {

	TfesClientProductRiskProfileResponse validateClientProductRiskProfile(DirectLinkRequestCommonModel request,
			String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException;
	
	TfesUpdateSuitabilityAssessmentResponse updateSuitabilityAssessment(DirectLinkRequestCommonModel request,
			String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException;
	
	TfesProductsResponse getSuitabilityAssessmentResults(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException ;
	
	// For other channel
		TfesClientProductRiskProfileResponse validateClientProductRiskProfile(final String rmNumber, final String investmentAccountNumber,
				final String productCode, String uuid) throws IOException, DecoderException;
		
	// For other channel
	TfesUpdateSuitabilityAssessmentResponse updateSuitabilityAssessment(final String rmNumber,
			final String questionnaireId, final List<Question> questions, String uuid)
			throws IOException, DecoderException;
	
	// For other channel
	TfesProductsResponse getSuitabilityAssessmentResults(final String rmNumber,
			final String investmentAccountNumber, final String uuid) throws IOException, DecoderException;
			
}
