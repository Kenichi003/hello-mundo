package ph.com.metrobank.earnest.apigw.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(
        name = "wsStatus",
        propOrder = {"errorMessage", "soaResponseCode", "transactionStatus"}
)
public class WsStatus {
    @XmlElement(
            required = true
    )
    protected String errorMessage;
    @XmlElement(
            name = "SOAResponseCode",
            required = true
    )
    protected String soaResponseCode;
    @XmlElement(
            required = true
    )
    protected String transactionStatus;

    public WsStatus() {
    	// Object creation for JSON serialization.
    }

    public String getErrorMessage() {
        return this.errorMessage;
    }

    public void setErrorMessage(String value) {
        this.errorMessage = value;
    }

    public String getSOAResponseCode() {
        return this.soaResponseCode;
    }

    public void setSOAResponseCode(String value) {
        this.soaResponseCode = value;
    }

    public String getTransactionStatus() {
        return this.transactionStatus;
    }

    public void setTransactionStatus(String value) {
        this.transactionStatus = value;
    }
}
