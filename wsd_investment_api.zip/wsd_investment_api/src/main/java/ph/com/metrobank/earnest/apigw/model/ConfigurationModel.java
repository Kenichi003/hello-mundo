/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.earnest.apigw.model;

public class ConfigurationModel extends Format {

	private int expiryDays;
	private String merchantId;
	private String merchantName;
	private String merchantAlias;
	private int aggregateLimitAccount;
	private int aggregateLimitUser;
	private int maxLinkedAccounts;
	private int txnRenewalCriteria;
	private String bankPublicKey;
	private String bankPrivateKey;
	private String merchantPublicKey;

	public ConfigurationModel() {
		super();
	}

	public int getExpiryDays() {
		return expiryDays;
	}

	public void setExpiryDays(int expiryDays) {
		this.expiryDays = expiryDays;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantAlias() {
		return merchantAlias;
	}

	public void setMerchantAlias(String merchantAlias) {
		this.merchantAlias = merchantAlias;
	}

	public int getAggregateLimitAccount() {
		return aggregateLimitAccount;
	}

	public void setAggregateLimitAccount(int aggregateLimitAccount) {
		this.aggregateLimitAccount = aggregateLimitAccount;
	}

	public int getAggregateLimitUser() {
		return aggregateLimitUser;
	}

	public void setAggregateLimitUser(int aggregateLimitUser) {
		this.aggregateLimitUser = aggregateLimitUser;
	}

	public int getMaxLinkedAccounts() {
		return maxLinkedAccounts;
	}

	public void setMaxLinkedAccounts(int maxLinkedAccounts) {
		this.maxLinkedAccounts = maxLinkedAccounts;
	}

	public int getTxnRenewalCriteria() {
		return txnRenewalCriteria;
	}

	public void setTxnRenewalCriteria(int txnRenewalCriteria) {
		this.txnRenewalCriteria = txnRenewalCriteria;
	}

	public String getBankPublicKey() {
		return bankPublicKey;
	}

	public void setBankPublicKey(String bankPublicKey) {
		this.bankPublicKey = bankPublicKey;
	}

	public String getBankPrivateKey() {
		return bankPrivateKey;
	}

	public void setBankPrivateKey(String bankPrivateKey) {
		this.bankPrivateKey = bankPrivateKey;
	}

	public String getMerchantPublicKey() {
		return merchantPublicKey;
	}

	public void setMerchantPublicKey(String merchantPublicKey) {
		this.merchantPublicKey = merchantPublicKey;
	}

}
