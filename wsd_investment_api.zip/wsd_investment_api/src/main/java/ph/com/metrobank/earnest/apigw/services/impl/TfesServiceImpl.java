package ph.com.metrobank.earnest.apigw.services.impl;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import ph.com.metrobank.earnest.apigw.config.TfesConfig;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.request.*;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.services.TfesService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesClientProductRiskProfileResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesProductsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesTransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesUpdateSuitabilityAssessmentResponse;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.ExecutionException;

@Service
public class TfesServiceImpl implements TfesService {

	private RestTemplate restTemplate;
	private TfesConfig tfesConfig;
	private LoggingService loggingService;

	@Autowired
	public TfesServiceImpl(RestTemplate restTemplate, TfesConfig tfesConfig, LoggingService loggingService) {

		this.restTemplate = restTemplate;
		this.tfesConfig = tfesConfig;
		this.loggingService = loggingService;
	}

	@Override
	public ResponseEntity<EnrollTrustAccountResponse> enrollTrustAccount(String rmNumber,
			String settlementAccountNumber, String uuid) throws UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_ENROLLTRUSTACCOUNT_SERVICE), uuid, settlementAccountNumber);

		EnrollTrustAccountRequest etaRequest = new EnrollTrustAccountRequest();
		etaRequest.setRmNumber(rmNumber);
		etaRequest.setSettlementAccountNumber(settlementAccountNumber);
		etaRequest.setSystemID(tfesConfig.getSystemId());
		etaRequest.setUserId(tfesConfig.getSystemId());
		etaRequest.setSaltValue(tfesConfig.getSaltValue());
		etaRequest.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<EnrollTrustAccountRequest> requestBody = new HttpEntity<>(etaRequest, headers);
		
		try {
			return restTemplate.exchange(tfesConfig.getEnrollTrustAccount(), HttpMethod.POST, requestBody,
					EnrollTrustAccountResponse.class);
		} catch (RestClientException r) {
			loggingService.error(String.format("%s%s", this.getClass().toString(),
					TraceLog.APIGW_TFESSERVICE_ENROLLTRUSTACCOUNT_SERVICE), uuid, r.getMessage(), etaRequest);
			return ResponseEntity.ok(new EnrollTrustAccountResponse());
		}	
	}

	@Override
	public ResponseEntity<TfesCommonTransactionResponse> createSubscription(CreateSubscriptionRequest request,
			String uri, String uuid) {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_CREATESUBSCRIPTION_SERVICE), uuid, request);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<CreateSubscriptionRequest> requestBody = new HttpEntity<>(request, headers);

		return restTemplate.exchange(uri, HttpMethod.POST, requestBody, TfesCommonTransactionResponse.class);
	}

	@Override
	public ResponseEntity<TfesCommonTransactionResponse> createRedemption(CreateRedemptionRequest request,
			String uuid) {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_TFESSERVICE_CREATEREDEMPTION_SERVICE),
				uuid, request);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<CreateRedemptionRequest> requestBody = new HttpEntity<>(request, headers);

		return restTemplate.exchange(tfesConfig.getCreateRedemption(), HttpMethod.POST, requestBody,
				TfesCommonTransactionResponse.class);
	}

	@Override
	public ResponseEntity<TfesInvestmentAccountSummaryDetailResponse> getInvestmentAccountSummaryDetail(InvestmentAccountSummaryDetailRequest request, String uuid)
			throws UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_GET_INVESTMENT_ACCOUNT_SUMMARY_DETAIL_SERVICE), uuid, request);

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<InvestmentAccountSummaryDetailRequest> requestBody = new HttpEntity<>(request, headers);

		return restTemplate.exchange(tfesConfig.getInvestmentAccountSummaryDetailUrl(), HttpMethod.POST, requestBody,
				TfesInvestmentAccountSummaryDetailResponse.class);
	}

	@Override
	public ResponseEntity<TfesTransactionDetailsResponse> getTransactionDetails(TfesTransactionDetailsRequest request,
			String uuid) throws UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_GET_TRANSACTION_DETAIL_SERVICE), uuid, request);

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<TfesTransactionDetailsRequest> requestBody = new HttpEntity<>(request, headers);

		return restTemplate.exchange(tfesConfig.getTransactionDetailUrl(), HttpMethod.POST, requestBody,
				TfesTransactionDetailsResponse.class);
	}

	@Override
	public ResponseEntity<TfesInvestmentAccountDetailsResponse> getInvestmentAccountDetails(
			TfesInvestmentAccountDetailsRequest request, String uuid)
			throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_GET_TRANSACTION_DETAIL_SERVICE), uuid, request);

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<TfesInvestmentAccountDetailsRequest> requestBody = new HttpEntity<>(request, headers);

		return restTemplate.exchange(tfesConfig.getInvestmentAccountDetailsUrl(), HttpMethod.POST, requestBody,
				TfesInvestmentAccountDetailsResponse.class);
	}

	@Override
	public ResponseEntity<TfesProductsResponse> getInvestmentProducts(String uuid)
			throws UnsupportedEncodingException, DecoderException {

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_TFESSERVICE_GET_INVESTMENT_PRODUCTS),
				uuid, "A call to TfesService.getInvestmentProducts() started.");

		TfesCommonRequestModel request = new TfesCommonRequestModel();

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<TfesCommonRequestModel> requestBody = new HttpEntity<>(request, headers);

		try {
			return restTemplate.exchange(tfesConfig.getInvestmentProductsUrl(), HttpMethod.POST, requestBody,
					TfesProductsResponse.class);
		} catch (RestClientException r) {
			loggingService.error(String.format("%s%s", this.getClass().toString(),
					TraceLog.APIGW_TFESSERVICE_GET_INVESTMENT_PRODUCTS), uuid, r.getMessage(), request);
			return ResponseEntity.ok(new TfesProductsResponse());
		}
	}
	
	@Override
	public ResponseEntity<TfesSuitabilityExpirationResponse> getSuitabilityExpirationDate(
			TfesInvestmentAccountDetailsRequest request, String uuid)
			throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT), uuid, request);

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<TfesInvestmentAccountDetailsRequest> requestBody = new HttpEntity<>(request, headers);

		try {
			return restTemplate.exchange(tfesConfig.getSuitabilityExpirationDateUrl(), HttpMethod.POST, requestBody,
					TfesSuitabilityExpirationResponse.class);
		} catch (RestClientException r) {
			loggingService.error(String.format("%s%s", this.getClass().toString(),
					TraceLog.APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT), uuid, r.getMessage(), request);
			return ResponseEntity.ok(new TfesSuitabilityExpirationResponse());
		}
	}
	
	@Override
	public ResponseEntity<TfesClientProductRiskProfileResponse> validateClientProductRiskProfile(
			TfesInvestmentAccountDetailsRequest request, String uuid)
			throws UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_SERVICE_VALIDATE_CLIENT_PRODUCT_RISK_PROFILE), uuid, request);

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<TfesInvestmentAccountDetailsRequest> requestBody = new HttpEntity<>(request, headers);

		try {
			return restTemplate.exchange(tfesConfig.getValidateClientProductRiskProfileUrl(), HttpMethod.POST,
					requestBody, TfesClientProductRiskProfileResponse.class);
		} catch (RestClientException r) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							TraceLog.APIGW_SERVICE_VALIDATE_CLIENT_PRODUCT_RISK_PROFILE),
					uuid, r.getMessage(), request);
			return ResponseEntity.ok(new TfesClientProductRiskProfileResponse());
		}
	}
	
	@Override
	public ResponseEntity<TfesUpdateSuitabilityAssessmentResponse> updateSuitabilityAssessment(
			TfesUpdateSuitabilityAssessmentRequest request, String uuid)
			throws UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_UPDATE_SUITABILITY_ASSESSMENT), uuid, request);

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());
 
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<TfesUpdateSuitabilityAssessmentRequest> requestBody = new HttpEntity<>(request, headers);

		try {
			return restTemplate.exchange(tfesConfig.getUpdateSuitabilityAssessmentFormUrl(), HttpMethod.POST,
					requestBody, TfesUpdateSuitabilityAssessmentResponse.class);
		} catch (RestClientException r) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							TraceLog.APIGW_TFESSERVICE_UPDATE_SUITABILITY_ASSESSMENT),
					uuid, r.getMessage(), request);
			return ResponseEntity.ok(new TfesUpdateSuitabilityAssessmentResponse());
		}
	}
	
	public ResponseEntity<TfesProductsResponse> getSuitabilityAssessmentResults(
			TfesInvestmentAccountDetailsRequest request, String uuid)
			throws UnsupportedEncodingException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(),
				TraceLog.APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT_RESULT), uuid, request);

		request.setUserId(tfesConfig.getSystemId());
		request.setSaltValue(tfesConfig.getSaltValue());
		request.setSignValue(tfesConfig.getSignValue());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<TfesInvestmentAccountDetailsRequest> requestBody = new HttpEntity<>(request, headers);

		try {
			return restTemplate.exchange(tfesConfig.getAssessmentResultPerProductUrl(), HttpMethod.POST,
					requestBody, TfesProductsResponse.class);
		} catch (RestClientException r) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							TraceLog.APIGW_TFESSERVICE_GET_SUITABILITY_ASSESSMENT_RESULT),
					uuid, r.getMessage(), request);
			return ResponseEntity.ok(new TfesProductsResponse());
		}
	}

}
