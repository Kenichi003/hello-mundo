package ph.com.metrobank.earnest.apigw.services;

import org.apache.commons.codec.DecoderException;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.TransactionDetailsResponse;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.response.LinkedAccountResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountDetailsResponse;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesInvestmentAccountSummaryDetailResponse;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutionException;

/**
 * Created by petechungtuyco on 10/21/19.
 */
public interface AccountService {

    LinkedAccountResponse getLinkedAccount(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException, InterruptedException, IOException;

    EnrollTrustAccountResponse getInvestmentAccounts(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException, InterruptedException, IOException, DecoderException;

    TfesInvestmentAccountDetailsResponse getInvestmentAccountDetails(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException, InterruptedException, IOException, DecoderException;

    TransactionDetailsResponse getTransactionDetails(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException, InterruptedException, IOException, DecoderException;

    TfesInvestmentAccountSummaryDetailResponse getInvestmentAccountSummary(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException, InterruptedException, IOException, DecoderException;


}
