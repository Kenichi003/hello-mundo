package ph.com.metrobank.earnest.apigw.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ValidateOrSendOTPResponse extends TranCodesResponse {
    private BigDecimal amount;
    private String referenceNo;
    private String transactionDate;
    private String maskedMobileNumber;
    private String nToken;
    private String otpGenId;

    public ValidateOrSendOTPResponse() {
        super();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getMaskedMobileNumber() {
        return maskedMobileNumber;
    }

    public void setMaskedMobileNumber(String maskedMobileNumber) {
        this.maskedMobileNumber = maskedMobileNumber;
    }

    public String getnToken() {
        return nToken;
    }

    public void setnToken(String nToken) {
        this.nToken = nToken;
    }

    public String getOtpGenId() {
        return otpGenId;
    }

    public void setOtpGenId(String otpGenId) {
        this.otpGenId = otpGenId;
    }
}