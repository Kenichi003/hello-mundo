package ph.com.metrobank.earnest.apigw.services.impl;

import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.UNMAPPED_ERROR;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

@Component
public class TranCodeLogResponseHelper {

	@Autowired
	private LoggingService loggingService;

	public <T extends TranCodesResponse> void setAndLogTranCode(T response, String traceLogComponent, String className,
			String uuid) {
		
		String logComponent = String.format("%s %s", className, traceLogComponent);
 
		Optional<TransactionCode> code = TransactionCode.fromExternalTransactionCode(response.getReturnCode());
		
		TransactionCode tranCodeEnum = code.isPresent() ? code.get() : UNMAPPED_ERROR;
		
		loggingService.log(logComponent, uuid, tranCodeEnum.getTransactionDesc());
		// Update transaction code on response
		response.setTransactionCode(tranCodeEnum.getTransactionCode());
		response.setTransactionDesc(StringUtils.isNotEmpty(response.getReturnDescription()) ?
				response.getReturnDescription() :
				tranCodeEnum.getTransactionDesc());
		// Reset external transaction code
		response.setReturnCode(null); 
		response.setReturnDescription(null);
	}
}
