/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email emmanuel.ombrosa@metrobank.com.ph
 */
package ph.com.metrobank.earnest.apigw.config;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import static org.springframework.beans.factory.config.BeanDefinition.SCOPE_PROTOTYPE;

@Configuration
public class EarnestApigwConfig {

	@Value("${http.read.timeout}")
	private int httpReadTimeout;

	@Value("${http.connection.timeout}")
	private int httpConnectionTimeout;

	@Bean(name = "restTemplate")
	@Scope(SCOPE_PROTOTYPE)
	public RestTemplate restTemplate() {
		ClientHttpRequestFactory requestFactory = this.createSimpleHttpRequestFactory();
		final RestTemplate restTemplate = new RestTemplate(requestFactory);
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
		return restTemplate;
	}

	private ClientHttpRequestFactory createSimpleHttpRequestFactory() {
		SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
		factory.setReadTimeout(httpReadTimeout);
		factory.setConnectTimeout(httpConnectionTimeout);
		return factory;
	}
	
	@Bean(name = "restTemplateApigw")
	public RestTemplate restTemplateApigw() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

		SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy)
				.build();

		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();

		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setReadTimeout(httpReadTimeout);
		requestFactory.setConnectTimeout(httpConnectionTimeout);
		requestFactory.setHttpClient(httpClient);
		return new RestTemplate(requestFactory);
	}

	@Value("${application.isDollarLinkingAllowed}")
	private boolean isDollarLinkingAllowed;

	@Value("${application.tokenExpiryDays}")
	private int tokenExpiryDays;

	public boolean isDollarLinkingAllowed() {
		return isDollarLinkingAllowed;
	}

	public int getTokenExpiryDays() {
		return tokenExpiryDays;
	}
}
