package ph.com.metrobank.earnest.apigw.tfes.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesClientProductRiskProfileResponse extends TranCodesResponse {

	private String riskProfileCode;

	public TfesClientProductRiskProfileResponse() {
		super();
	}

	public TfesClientProductRiskProfileResponse(String transactionCode, String transactionDesc) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
	}

	public TfesClientProductRiskProfileResponse(String transactionCode, String transactionDesc,
			String riskProfileCode) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
		this.riskProfileCode = riskProfileCode;
	}

	public String getRiskProfileCode() {
		return riskProfileCode;
	}

	public void setRiskProfileCode(String riskProfileCode) {
		this.riskProfileCode = riskProfileCode;
	}

	 

}
