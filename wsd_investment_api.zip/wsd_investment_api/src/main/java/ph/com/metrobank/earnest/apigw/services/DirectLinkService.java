package ph.com.metrobank.earnest.apigw.services;

import org.springframework.http.ResponseEntity;

import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.ValidateOrSendOTPResponse;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

public interface DirectLinkService {
    ResponseEntity<ValidateDlsResponse> decryptRequest(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException;

    ResponseEntity<ValidateOrSendOTPResponse> validateOrSendOTP(DirectLinkRequestCommonModel request, String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException;

    AccountsModel getAccountByTokenAndExternalUserId(String token, String externalUserId, String uuid);
}
