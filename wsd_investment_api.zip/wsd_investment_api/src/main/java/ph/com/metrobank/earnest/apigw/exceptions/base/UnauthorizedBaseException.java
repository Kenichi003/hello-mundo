package ph.com.metrobank.earnest.apigw.exceptions.base;

/**
 * Created by petechungtuyco on 10/22/19.
 */
public class UnauthorizedBaseException extends RuntimeException {
    public UnauthorizedBaseException(String message) {
        super(message);
    }
}
