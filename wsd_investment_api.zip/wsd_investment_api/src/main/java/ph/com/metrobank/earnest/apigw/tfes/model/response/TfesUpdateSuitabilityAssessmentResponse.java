package ph.com.metrobank.earnest.apigw.tfes.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesUpdateSuitabilityAssessmentResponse extends TranCodesResponse {

	private String riskProfile;

	public TfesUpdateSuitabilityAssessmentResponse() {
		super();
	}

	public TfesUpdateSuitabilityAssessmentResponse(String transactionCode, String transactionDesc) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
	}

	public TfesUpdateSuitabilityAssessmentResponse(String transactionCode, String transactionDesc,
			String riskProfile) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
		this.riskProfile = riskProfile;
	}

	public String getRiskProfile() {
		return riskProfile;
	}

	public void setRiskProfile(String riskProfile) {
		this.riskProfile = riskProfile;
	}

 

}
