package ph.com.metrobank.earnest.apigw.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ph.com.metrobank.earnest.apigw.services.EncryptionService;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_ENCRYPTION_SERVICE_ENCRYPT_MD5;

@Service
public class EncryptionServiceImpl implements EncryptionService {

    private LoggingService loggingService;

    private static final String MD5 = "MD5";

    @Autowired
    public EncryptionServiceImpl(LoggingService loggingService) {
        this.loggingService = loggingService;
    }

    @Override
    public String encryptMD5(String payload, String uuid) throws NoSuchAlgorithmException {
        loggingService.log(String.format("%s%s", this.getClass().toString(), APIGW_ENCRYPTION_SERVICE_ENCRYPT_MD5), uuid, payload);
        MessageDigest md = MessageDigest.getInstance(MD5);
        byte[] hashInBytes = md.digest(payload.getBytes(StandardCharsets.UTF_8));

        StringBuilder sb = new StringBuilder();
        for (byte b : hashInBytes){
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
