package ph.com.metrobank.earnest.apigw.services;

import java.security.NoSuchAlgorithmException;

public interface EncryptionService {

    String encryptMD5(String payload, String uuid) throws NoSuchAlgorithmException;
}
