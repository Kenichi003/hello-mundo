package ph.com.metrobank.earnest.apigw.tfes.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesSuitabilityExpirationResponse extends TranCodesResponse {

	private String lastSAFUpdateDate;
 

	public TfesSuitabilityExpirationResponse() {
		super();
	}

	public TfesSuitabilityExpirationResponse(String transactionCode, String transactionDesc) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
	}
	
	public TfesSuitabilityExpirationResponse(String transactionCode, String transactionDesc, String lastSAFUpdateDate) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
		this.lastSAFUpdateDate = lastSAFUpdateDate;
	}

	public String getLastSAFUpdateDate() {
		return lastSAFUpdateDate;
	}

	public void setLastSAFUpdateDate(String lastSAFUpdateDate) {
		this.lastSAFUpdateDate = lastSAFUpdateDate;
	}

	

}
