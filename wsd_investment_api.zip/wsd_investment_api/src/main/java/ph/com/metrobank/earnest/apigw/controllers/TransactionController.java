package ph.com.metrobank.earnest.apigw.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ph.com.metrobank.earnest.apigw.model.GenericResponse;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.services.TransactionService;
import ph.com.metrobank.earnest.apigw.services.impl.GenerateUUIDService;
import ph.com.metrobank.earnest.apigw.services.impl.LoggingService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.util.Date;
import java.util.concurrent.ExecutionException;

import static ph.com.metrobank.earnest.apigw.util.Constants.PROGRAM_NAME;

/**
 * Created by petechungtuyco on 10/21/19.
 * Modified by emmanuel.ombrosa on 11/15/19.
 */
@RestController
@RequestMapping("${endpoint.url}")
@Api(value = "Earnest APIGW Controller")
public class TransactionController {

    private GenerateUUIDService generateUUIDService;
    private LoggingService loggingService;
    private TransactionService transactionService;

	@Autowired
	public TransactionController(GenerateUUIDService generateUUIDService, LoggingService loggingService,
			TransactionService transactionService) {
		this.generateUUIDService = generateUUIDService;
		this.loggingService = loggingService;
		this.transactionService = transactionService;
	}

    @PostMapping(value = "/create-subscription")
    @ApiOperation(value = "Create Subscription")
    public ResponseEntity<GenericResponse<TfesCommonTransactionResponse>>  createSubscription(@RequestBody DirectLinkRequestCommonModel request) throws IOException, NoSuchAlgorithmException, DecoderException, ExecutionException, InvalidKeyException, InvalidKeySpecException, NoSuchPaddingException, BadPaddingException, InterruptedException, SignatureException, KeyStoreException, IllegalBlockSizeException, KeyManagementException {
        final String uuid = generateUUIDService.generateUUID();
        loggingService.log(String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CONTROLLER_CREATE_SUBSCRIPTION), uuid, request);
    	GenericResponse<TfesCommonTransactionResponse> response = new GenericResponse<>(
				PROGRAM_NAME, new Date(), "", transactionService.createSubscription(request, uuid)); 
    	return ResponseEntity.ok(response);
    }

	@PostMapping(value = "/create-redemption")
    @ApiOperation(value = "Create Redemption")
    public ResponseEntity<GenericResponse<TfesCommonTransactionResponse>> createRedemption(@RequestBody DirectLinkRequestCommonModel request) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, DecoderException, ExecutionException, InvalidKeyException, InterruptedException, IllegalBlockSizeException, BadPaddingException, SignatureException, KeyStoreException, InvalidKeySpecException, KeyManagementException {

        final String uuid = generateUUIDService.generateUUID();
        loggingService.log(String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CONTROLLER_CREATE_REDEMPTION), uuid, request);
		GenericResponse<TfesCommonTransactionResponse> response = new GenericResponse<>(
				PROGRAM_NAME, new Date(), "", transactionService.createRedemption(request, uuid)); 
        return ResponseEntity.ok(response);
    }

}
