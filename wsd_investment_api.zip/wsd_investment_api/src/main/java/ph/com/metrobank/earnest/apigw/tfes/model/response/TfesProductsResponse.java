package ph.com.metrobank.earnest.apigw.tfes.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import ph.com.metrobank.earnest.apigw.model.response.TranCodesResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TfesProductsResponse extends TranCodesResponse {

	private List<TfesProduct> products;

	public TfesProductsResponse() {
		super();
	}
	
	public TfesProductsResponse(String transactionCode, String transactionDesc) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
	}
	
	public TfesProductsResponse(String transactionCode, String transactionDesc, List<TfesProduct> products) {
		this.setTransactionCode(transactionCode);
		this.setTransactionDesc(transactionDesc);
		this.products = products;
	}

	public List<TfesProduct> getProducts() {
		return products;
	}

	public void setProducts(List<TfesProduct> products) {
		this.products = products;
	}

}
