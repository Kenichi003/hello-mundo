package ph.com.metrobank.earnest.apigw.exceptions.base;

public class InternalServerBaseException extends RuntimeException{
    public InternalServerBaseException(String message) {
        super(message);
    }
}
