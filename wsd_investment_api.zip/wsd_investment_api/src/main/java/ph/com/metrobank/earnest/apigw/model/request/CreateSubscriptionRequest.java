package ph.com.metrobank.earnest.apigw.model.request;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
 

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateSubscriptionRequest extends TfesCommonRequestModel {

    private String settlementAccountNumber;
    private String ptaNumber;
    private BigDecimal amount;
    private BigDecimal rspAmount;
    private int installmentPeriod;
    private int installmentDate;

    public String getSettlementAccountNumber() {
        return settlementAccountNumber;
    }

    public void setSettlementAccountNumber(String settlementAccountNumber) {
        this.settlementAccountNumber = settlementAccountNumber;
    }

    public String getPtaNumber() {
        return ptaNumber;
    }

    public void setPtaNumber(String ptaNumber) {
        this.ptaNumber = ptaNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getRspAmount() {
        return rspAmount;
    }

    public void setRspAmount(BigDecimal rspAmount) {
        this.rspAmount = rspAmount;
    }

    public int getInstallmentPeriod() {
        return installmentPeriod;
    }

    public void setInstallmentPeriod(int installmentPeriod) {
        this.installmentPeriod = installmentPeriod;
    }

    public int getInstallmentDate() {
        return installmentDate;
    }

    public void setInstallmentDate(int installmentDate) {
        this.installmentDate = installmentDate;
    }

}
