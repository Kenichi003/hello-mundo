package ph.com.metrobank.earnest.apigw.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ph.com.metrobank.earnest.apigw.config.DirectLinkServiceConfiguration;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.ValidateOrSendOTPResponse;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.ValidateDlsResponse;
import ph.com.metrobank.earnest.apigw.services.DirectLinkService;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

@Service
public class DirectLinkServiceImpl implements DirectLinkService {

	private DirectLinkServiceConfiguration dlsConfig;
	private LoggingService loggingService;
	private RestTemplate restTemplate;

	@Autowired
	public DirectLinkServiceImpl(@Qualifier("restTemplateApigw") RestTemplate restTemplate,
			DirectLinkServiceConfiguration dlsConfig, LoggingService loggingService) {
		this.restTemplate = restTemplate;
		this.dlsConfig = dlsConfig;
		this.loggingService = loggingService;
	}

	@Override
	public ResponseEntity<ValidateDlsResponse> decryptRequest(DirectLinkRequestCommonModel request, String uuid) {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_DECRYPT_SERVICE),
				uuid, request);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<DirectLinkRequestCommonModel> httpEntity = new HttpEntity<>(request, headers);

		ResponseEntity<ValidateDlsResponse> response = restTemplate.exchange(dlsConfig.getDecryptRequestUrl(),
				HttpMethod.POST, httpEntity, ValidateDlsResponse.class);

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_DECRYPT_SERVICE),
				uuid, response);
		return response;
	}

	@Override
	public ResponseEntity<ValidateOrSendOTPResponse> validateOrSendOTP(DirectLinkRequestCommonModel request,
			String uuid) throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_OTP_SERVICE), uuid,
				request);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<DirectLinkRequestCommonModel> requestBody = new HttpEntity<>(request, headers);

		ResponseEntity<ValidateOrSendOTPResponse> response = restTemplate.exchange(dlsConfig.getValidateOrSendOtpUrl(),
				HttpMethod.POST, requestBody, ValidateOrSendOTPResponse.class);

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_OTP_SERVICE), uuid,
				response);
		return response;
	}

	@Override
	public AccountsModel getAccountByTokenAndExternalUserId(String token, String externalUserId, String uuid) {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(),
						TraceLog.APIGW_DIRECTLINKSERVICE_GET_ACCOUNT_BY_TOKEN_EXTERNAL_USER_ID_SERVICE),
				uuid, "TOKEN: " + token + " EXTERNALUSERID: " + externalUserId);

		AccountsModel response = restTemplate
				.getForObject(dlsConfig.getAccountByTokenAndExternalUserId(token, externalUserId), AccountsModel.class);

		loggingService.log(
				String.format("%s%s", this.getClass().toString(),
						TraceLog.APIGW_DIRECTLINKSERVICE_GET_ACCOUNT_BY_TOKEN_EXTERNAL_USER_ID_SERVICE),
				uuid, response);
		return response;
	}
}
