/*
 *  Copyright (c) 2019 Metropolitan Bank & Trust Company
 *
 *  @author 33460
 *  @date 2019-08-16
 *  @email mark.to@metrobank.com.ph
 */
package ph.com.metrobank.earnest.apigw.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class Format {

	@Override
	public String toString() {
		try {
			return new ObjectMapper().enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS).writeValueAsString(this);
		} catch (JsonProcessingException e) {
			return "";
		}
	}

}
