package ph.com.metrobank.earnest.apigw.services.impl;

import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING;
import static ph.com.metrobank.earnest.apigw.model.TraceLog.APIGW_SUITABILITY_ASSESSMENT_SERVICE_GET_SUITABILITY_ASSESSMENT;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import org.apache.commons.codec.DecoderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.request.InvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.model.request.TfesInvestmentAccountDetailsRequest;
import ph.com.metrobank.earnest.apigw.services.DirectLinkService;
import ph.com.metrobank.earnest.apigw.services.SuitabilityAssessmentService;
import ph.com.metrobank.earnest.apigw.services.TfesService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesSuitabilityExpirationResponse;
import ph.com.metrobank.earnest.apigw.util.JsonUtil;

/**
 * 
 * @author 34785 - emmanuel.b.ombrosa
 *
 */

@Service
public class SuitabilityAssessmentServiceImpl implements SuitabilityAssessmentService {

	private DirectLinkService directLinkService;

	private LoggingService loggingService;

	private TfesService tfesService;

	private TranCodeLogResponseHelper tranCodeLogResponseHelper;

	@Autowired
	public SuitabilityAssessmentServiceImpl(DirectLinkService directLinkService, LoggingService loggingService,
			TfesService tfesService, TranCodeLogResponseHelper tranCodeLogResponseHelper) {
		this.directLinkService = directLinkService;
		this.loggingService = loggingService;
		this.tfesService = tfesService;
		this.tranCodeLogResponseHelper = tranCodeLogResponseHelper;
	}

	@Override
	public TfesSuitabilityExpirationResponse getSuitabilityExpiration(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, DecoderException {

		loggingService.log(String.format("%s%s", this.getClass().toString(),
				APIGW_SUITABILITY_ASSESSMENT_SERVICE_GET_SUITABILITY_ASSESSMENT), uuid, request);

		InvestmentAccountDetailsRequest investmentProductRequest = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(),
				InvestmentAccountDetailsRequest.class);

		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(
				investmentProductRequest.getToken(), investmentProductRequest.getExternalUserId(), uuid);

		if (Objects.isNull(accountsModel)) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(),
							APIGW_SUITABILITY_ASSESSMENT_SERVICE_GET_SUITABILITY_ASSESSMENT),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesSuitabilityExpirationResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		return getSuitabilityExpiration(accountsModel.getRmNumber(),
				investmentProductRequest.getInvestmentAccountNumber(), uuid);
	}

	@Override
	public TfesSuitabilityExpirationResponse getSuitabilityExpiration(final String rmNumber,
			final String investmentAccountNumber, final String uuid)
			throws ExecutionException, InterruptedException, IOException, DecoderException {

		TfesInvestmentAccountDetailsRequest request = new TfesInvestmentAccountDetailsRequest();
		request.setRmNumber(rmNumber);
		request.setInvestmentAccountNumber(investmentAccountNumber);

		TfesSuitabilityExpirationResponse response = tfesService.getSuitabilityExpirationDate(request, uuid).getBody();

		tranCodeLogResponseHelper.setAndLogTranCode(response,
				APIGW_SUITABILITY_ASSESSMENT_SERVICE_GET_SUITABILITY_ASSESSMENT, this.getClass().toString(), uuid);

		return response;
	}

	
}
