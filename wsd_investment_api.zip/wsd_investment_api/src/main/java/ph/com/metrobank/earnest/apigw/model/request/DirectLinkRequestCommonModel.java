package ph.com.metrobank.earnest.apigw.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;

import ph.com.metrobank.earnest.apigw.model.Format;

/**
 * Created by petechungtuyco on 10/21/19.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DirectLinkRequestCommonModel extends Format {
    private String channelId;
    private String data;
    private String signature;

    public DirectLinkRequestCommonModel() {
        super();
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }
}
