package ph.com.metrobank.earnest.apigw.model;

import java.util.Date;

/**
 * Created by petechungtuyco on 10/22/19.
 */
public class GenericResponse<T> {
    private String programName;
    private Date date;
    private String message;
    private T body;

    public GenericResponse(String programName, Date date, String message, T body) {
        this.programName = programName;
        this.date = date;
        this.message = message;
        this.body = body;
    }

    public GenericResponse() {
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getBody() {
        return body;
    }

    public void setBody(T body) {
        this.body = body;
    }
}
