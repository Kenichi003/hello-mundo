package ph.com.metrobank.earnest.apigw.services.impl;

import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.ACCOUNTS_DOES_NOT_MATCH;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_AUTHENTICATION;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_OR_ACCOUNT_NOT_EXISTING;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_OTP;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.INVALID_OTP_REQUEST;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.LINKED_INVESTMENT_ACCOUNT_NOT_FOUND;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.PENDING_INVESTMENT_ACCOUNT_CREATION;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.PENDING_OTP;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.REQUEST_SUCCESSFULLY_PROCESSED;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.SETTLEMENT_ACCOUNT_NOT_FOUND;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.TRANSACTION_SUCCESS;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.UNMAPPED_ERROR;
import static ph.com.metrobank.earnest.apigw.enums.TransactionCode.VALID_OTP;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import ph.com.metrobank.earnest.apigw.config.DirectLinkServiceConfiguration;
import ph.com.metrobank.earnest.apigw.config.TfesConfig;
import ph.com.metrobank.earnest.apigw.enums.TransactionCode;
import ph.com.metrobank.earnest.apigw.exceptions.tfes.InvalidAuthenticationException;
import ph.com.metrobank.earnest.apigw.exceptions.tfes.LinkedInvestmentAccountsNotFoundException;
import ph.com.metrobank.earnest.apigw.exceptions.tfes.SettlementAccountNotFoundException;
import ph.com.metrobank.earnest.apigw.model.AccountsModel;
import ph.com.metrobank.earnest.apigw.model.ConfigurationModel;
import ph.com.metrobank.earnest.apigw.model.TraceLog;
import ph.com.metrobank.earnest.apigw.model.ValidateOrSendOTPResponse;
import ph.com.metrobank.earnest.apigw.model.otp.ValidateOrSendOtpRequest;
import ph.com.metrobank.earnest.apigw.model.request.CreateRedemptionPayload;
import ph.com.metrobank.earnest.apigw.model.request.CreateRedemptionRequest;
import ph.com.metrobank.earnest.apigw.model.request.CreateSubscriptionPayload;
import ph.com.metrobank.earnest.apigw.model.request.CreateSubscriptionRequest;
import ph.com.metrobank.earnest.apigw.model.request.DirectLinkRequestCommonModel;
import ph.com.metrobank.earnest.apigw.model.response.EnrollTrustAccountResponse;
import ph.com.metrobank.earnest.apigw.model.subscription.InvestmentAccount;
import ph.com.metrobank.earnest.apigw.services.DirectLinkService;
import ph.com.metrobank.earnest.apigw.services.TfesService;
import ph.com.metrobank.earnest.apigw.services.TransactionService;
import ph.com.metrobank.earnest.apigw.tfes.model.response.TfesCommonTransactionResponse;
import ph.com.metrobank.earnest.apigw.util.JsonUtil;
import ph.com.metrobank.earnest.apigw.util.RSAUtil;
import ph.com.metrobank.earnest.apigw.util.StringUtil;

/**
 * Created by petechungtuyco on 10/21/19.
 */
@Service
public class TransactionServiceImpl implements TransactionService {

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	private TfesConfig tfesConfig;
	private LoggingService loggingService;
	private DirectLinkService directLinkService;
	private TfesService tfesService;
	private RestTemplate restTemplate;
	private DirectLinkServiceConfiguration directLinkServiceConfiguration;
	
	@Autowired
	public TransactionServiceImpl(TfesService tfesService, DirectLinkService directLinkService, TfesConfig tfesConfig,
			LoggingService loggingService, @Qualifier("restTemplate") RestTemplate restTemplate, DirectLinkServiceConfiguration directLinkServiceConfiguration) {
		this.directLinkService = directLinkService;
		this.tfesService = tfesService;
		this.tfesConfig = tfesConfig;
		this.loggingService = loggingService;
		this.restTemplate = restTemplate;
		this.directLinkServiceConfiguration = directLinkServiceConfiguration;
	}

	private ConfigurationModel getSettings() {
		String url = directLinkServiceConfiguration.getConfiguration();
		return restTemplate.getForObject(url, ConfigurationModel.class);
	}
	
	@Override
	public TfesCommonTransactionResponse createRedemption(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, ExecutionException,
			InterruptedException, IOException, IllegalBlockSizeException, InvalidKeyException, BadPaddingException,
			InvalidKeySpecException, NoSuchPaddingException, SignatureException, DecoderException {
		loggingService.log(String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_REDEMPTION_SERVICE),
				uuid, request);

		CreateRedemptionPayload crpayload = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(), CreateRedemptionPayload.class);

		// get accountsmodel to get AccountNo needed for otp request
		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(crpayload.getToken(),
				crpayload.getExternalUserId(), uuid);

		if (accountsModel == null) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_REDEMPTION_SERVICE), uuid,
					"Accounts model not found", request);

			return new TfesCommonTransactionResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		// create validateOrSendOtpRequest
		ValidateOrSendOtpRequest otpRequest = new ValidateOrSendOtpRequest();
		otpRequest.setAccountNo(accountsModel.getAccountNo());
		otpRequest.setChannelId(request.getChannelId());
		otpRequest.setExternalUserId(accountsModel.getExternalUserId());
		otpRequest.setReferenceNo(accountsModel.getReferenceNo());
		otpRequest.setAuth(crpayload.getAuth());

		// encrypt validateOrSendOtpRequest
		ConfigurationModel config = getSettings();
		DirectLinkRequestCommonModel encryptedOtpRequest = new DirectLinkRequestCommonModel();
		encryptedOtpRequest.setChannelId(request.getChannelId());
		encryptedOtpRequest.setData(RSAUtil.encryptData(JsonUtil.toJson(otpRequest), config.getBankPublicKey()));
		encryptedOtpRequest.setSignature(RSAUtil.signedData(JsonUtil.toJson(otpRequest), config.getBankPrivateKey()));

		// request validateOrSendOtp
		ValidateOrSendOTPResponse validateOrSendOTPResponse = directLinkService
				.validateOrSendOTP(encryptedOtpRequest, uuid).getBody();

		if (validateOrSendOTPResponse.getTransactionCode().equalsIgnoreCase(VALID_OTP.getExternalTransactionCode())) {
			// do existing routine
			boolean isValidInvestmentAccount = false;

			try {
				isValidInvestmentAccount = validateInvestmentAccount(accountsModel.getRmNumber(),
						accountsModel.getAccountNo(), crpayload.getInvestmentAccountNumber(), uuid);

			} catch (InvalidAuthenticationException e) {
				return new TfesCommonTransactionResponse(INVALID_AUTHENTICATION.getTransactionCode(),
						INVALID_AUTHENTICATION.getTransactionDesc());

			} catch (SettlementAccountNotFoundException e) {
				return new TfesCommonTransactionResponse(SETTLEMENT_ACCOUNT_NOT_FOUND.getTransactionCode(),
						SETTLEMENT_ACCOUNT_NOT_FOUND.getTransactionDesc());

			} catch (LinkedInvestmentAccountsNotFoundException e) {
				return new TfesCommonTransactionResponse(LINKED_INVESTMENT_ACCOUNT_NOT_FOUND.getTransactionCode(),
						LINKED_INVESTMENT_ACCOUNT_NOT_FOUND.getTransactionDesc());

			}

			if (isValidInvestmentAccount) {
				CreateRedemptionRequest crRequest = new CreateRedemptionRequest();
				crRequest.setUserId(tfesConfig.getSystemId());
				crRequest.setSignValue(tfesConfig.getSignValue());
				crRequest.setSaltValue(tfesConfig.getSaltValue());
				crRequest.setRmNumber(accountsModel.getRmNumber());
				crRequest.setInvestmentAccountNumber(crpayload.getInvestmentAccountNumber());
				crRequest.setProductCode(crpayload.getProductCode());
				crRequest.setSettlementAccountNumber(accountsModel.getAccountNo());
				crRequest.setTransactionType("Redemption");
				crRequest.setRedemptionType(crpayload.getRedemptionType());
				crRequest.setOrderDate(crpayload.getOrderDate().format(formatter));
				crRequest.setAmountOrUnits(crpayload.getAmountOrUnits());
				crRequest.setRemarks(crpayload.getRemarks());
				crRequest.setIsBeyondCutOff(crpayload.getIsBeyondCutoff());

				TfesCommonTransactionResponse jcrResponse = tfesService.createRedemption(crRequest, uuid).getBody();

				return createTransactionResponse(jcrResponse, uuid, accountsModel.getRmNumber());

			} else {
				return new TfesCommonTransactionResponse(ACCOUNTS_DOES_NOT_MATCH.getTransactionCode(),
						ACCOUNTS_DOES_NOT_MATCH.getTransactionDesc());
			}

		} else {
			return handleValidateOtpResponse(validateOrSendOTPResponse, uuid);
		}
	}
 
	private TfesCommonTransactionResponse handleValidateOtpResponse(ValidateOrSendOTPResponse validateOrSendOTPResponse,
			String uuid) {
		if (validateOrSendOTPResponse.getTransactionCode().equals(INVALID_OTP_REQUEST.getExternalTransactionCode())) {
			// InvalidOTP
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_OTP_SERVICE),
					uuid, INVALID_OTP_REQUEST.getTransactionDesc(), TransactionCode.getAsError(INVALID_OTP_REQUEST));

			return new TfesCommonTransactionResponse(INVALID_OTP_REQUEST.getTransactionCode(),
					INVALID_OTP_REQUEST.getTransactionDesc());

		} else if (validateOrSendOTPResponse.getTransactionCode().equals(INVALID_OTP.getExternalTransactionCode())) {
			// InvalidOTP
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_OTP_SERVICE),
					uuid, INVALID_OTP.getTransactionDesc(), TransactionCode.getAsError(INVALID_OTP));
			return new TfesCommonTransactionResponse(INVALID_OTP.getTransactionCode(),
					INVALID_OTP.getTransactionDesc());

		} else if (validateOrSendOTPResponse.getTransactionCode().equals(PENDING_OTP.getExternalTransactionCode())) {
			// PendingOTP
			validateOrSendOTPResponse.setTransactionCode(PENDING_OTP.getTransactionCode());
			validateOrSendOTPResponse.setTransactionDesc(PENDING_OTP.getTransactionDesc());

			loggingService.log(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_OTP_SERVICE),
					uuid, validateOrSendOTPResponse);
			return new TfesCommonTransactionResponse(validateOrSendOTPResponse);

		} else if (validateOrSendOTPResponse.getTransactionCode()
				.equals(INVALID_OR_ACCOUNT_NOT_EXISTING.getExternalTransactionCode())) {
			// INVALID OR ACCOUNT NOT EXISTING
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_OTP_SERVICE),
					uuid, INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc(),
					TransactionCode.getAsError(INVALID_OR_ACCOUNT_NOT_EXISTING));
			return new TfesCommonTransactionResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());

		} else {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_DIRECTLINKSERVICE_OTP_SERVICE),
					uuid, UNMAPPED_ERROR.getTransactionDesc(), TransactionCode.getAsError(UNMAPPED_ERROR));
			return new TfesCommonTransactionResponse(UNMAPPED_ERROR.getTransactionCode(),
					UNMAPPED_ERROR.getTransactionDesc());

		}
	}

	private TfesCommonTransactionResponse createTransactionResponse(TfesCommonTransactionResponse jcrResponse,
			String uuid, String customerNumber) {
		if (jcrResponse.getReturnCode().equals(TRANSACTION_SUCCESS.getExternalTransactionCode())) {
			loggingService.log(String.format("%s%s", this.getClass().toString(),
					TraceLog.APIGW_TXNSERVICE_CREATE_TRANSACTION_RESPONSE), uuid, jcrResponse);
			jcrResponse.setCustomerNumber(customerNumber); // REQUESTED 11/22
			return jcrResponse;
		} else {
			return createTransactionErrorResponse(jcrResponse, TraceLog.APIGW_TXNSERVICE_CREATE_TRANSACTION_RESPONSE,
					this.getClass().toString(), uuid);
		}
	}
	
	// Fix cognitive function length on  createTransactionResponse()
	public TfesCommonTransactionResponse createTransactionErrorResponse(TfesCommonTransactionResponse jcrResponse, String traceLogComponent, String className,
			String uuid) {
		String logComponent = String.format("%s %s", className, traceLogComponent);
		Optional<TransactionCode> code = TransactionCode.fromExternalTransactionCode(jcrResponse.getReturnCode());
		TransactionCode tranCodeEnum = code.isPresent() ? code.get() : UNMAPPED_ERROR;
		loggingService.error(logComponent, uuid, tranCodeEnum.getTransactionDesc(), TransactionCode.getAsError(tranCodeEnum));		
		return new TfesCommonTransactionResponse(tranCodeEnum.getTransactionCode(), StringUtils.isNotEmpty(jcrResponse.getReturnDescription()) ?
				jcrResponse.getReturnDescription() :
				tranCodeEnum.getTransactionDesc());
	}

	@Override
	public TfesCommonTransactionResponse createSubscription(DirectLinkRequestCommonModel request, String uuid)
			throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException,
			NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
			InvalidKeySpecException, SignatureException, InterruptedException, ExecutionException, DecoderException {
		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
				request);

		// decrypt CreateSubscriptionPayload data
		CreateSubscriptionPayload cspayload = JsonUtil.mapFromJson(
				directLinkService.decryptRequest(request, uuid).getBody().getData(), CreateSubscriptionPayload.class);

		// get accountsmodel to get AccountNo needed for otp request
		AccountsModel accountsModel = directLinkService.getAccountByTokenAndExternalUserId(cspayload.getToken(),
				cspayload.getExternalUserId(), uuid);

		if (accountsModel == null) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
					"Accounts model not found", request);
			return new TfesCommonTransactionResponse(INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionCode(),
					INVALID_OR_ACCOUNT_NOT_EXISTING.getTransactionDesc());
		}

		// create validateOrSendOtpRequest
		ValidateOrSendOtpRequest otpRequest = new ValidateOrSendOtpRequest();
		otpRequest.setAccountNo(accountsModel.getAccountNo());
		otpRequest.setChannelId(request.getChannelId());
		otpRequest.setExternalUserId(accountsModel.getExternalUserId());
		otpRequest.setReferenceNo(accountsModel.getReferenceNo());
		otpRequest.setAuth(cspayload.getAuth());

		// encrypt validateOrSendOtpRequest
		ConfigurationModel config = getSettings();
		DirectLinkRequestCommonModel encryptedOtpRequest = new DirectLinkRequestCommonModel();
		encryptedOtpRequest.setChannelId(request.getChannelId());
		encryptedOtpRequest.setData(RSAUtil.encryptData(JsonUtil.toJson(otpRequest), config.getBankPublicKey()));
		encryptedOtpRequest.setSignature(RSAUtil.signedData(JsonUtil.toJson(otpRequest), config.getBankPrivateKey()));

		// request validateOrSendOtp
		ValidateOrSendOTPResponse validateOrSendOTPResponse = directLinkService
				.validateOrSendOTP(encryptedOtpRequest, uuid).getBody();

		if (validateOrSendOTPResponse.getTransactionCode().equalsIgnoreCase(VALID_OTP.getExternalTransactionCode())) {
			String investmentAccountNumber = cspayload.getInvestmentAccountNumber();
			boolean initialAccountCreation = cspayload.getInitial();

			if (initialAccountCreation && StringUtils.isEmpty(investmentAccountNumber)) {
				loggingService.log(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE),
					uuid, TransactionCode.getAsError(PENDING_INVESTMENT_ACCOUNT_CREATION));
				return new TfesCommonTransactionResponse(PENDING_INVESTMENT_ACCOUNT_CREATION.getTransactionCode(),
					PENDING_INVESTMENT_ACCOUNT_CREATION.getTransactionDesc(), accountsModel.getRmNumber(),
					StringUtil.getLastChars(accountsModel.getAccountNo(), 6));
			}

			return doCreateSubscriptionRoutine(accountsModel, cspayload, request, uuid);

		} else {
			return handleValidateOtpResponse(validateOrSendOTPResponse, uuid);

		}
	}

	private TfesCommonTransactionResponse doCreateSubscriptionRoutine(AccountsModel accountsModel,
			CreateSubscriptionPayload cspayload, DirectLinkRequestCommonModel request, String uuid)
			throws InterruptedException, ExecutionException, UnsupportedEncodingException, DecoderException {

		// do existing routine
		boolean isValidInvestmentAccount = false;

		try {
			isValidInvestmentAccount = validateInvestmentAccount(accountsModel.getRmNumber(),
					accountsModel.getAccountNo(), cspayload.getInvestmentAccountNumber(), uuid);

		} catch (InvalidAuthenticationException e) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
					INVALID_AUTHENTICATION.getTransactionDesc(), request);
			return new TfesCommonTransactionResponse(INVALID_AUTHENTICATION.getTransactionCode(),
					INVALID_AUTHENTICATION.getTransactionDesc());

		} catch (SettlementAccountNotFoundException e) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
					SETTLEMENT_ACCOUNT_NOT_FOUND.getTransactionDesc(), request);
			return new TfesCommonTransactionResponse(SETTLEMENT_ACCOUNT_NOT_FOUND.getTransactionCode(),
					SETTLEMENT_ACCOUNT_NOT_FOUND.getTransactionDesc());

		} catch (LinkedInvestmentAccountsNotFoundException e) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
					LINKED_INVESTMENT_ACCOUNT_NOT_FOUND.getTransactionDesc(), request);
			return new TfesCommonTransactionResponse(LINKED_INVESTMENT_ACCOUNT_NOT_FOUND.getTransactionCode(),
					LINKED_INVESTMENT_ACCOUNT_NOT_FOUND.getTransactionDesc());

		}

		if (isValidInvestmentAccount) {
			return requestCreateSubscription(accountsModel, cspayload, uuid);

		} else {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
					ACCOUNTS_DOES_NOT_MATCH.getTransactionDesc(), request);
			return new TfesCommonTransactionResponse(ACCOUNTS_DOES_NOT_MATCH.getTransactionCode(),
					ACCOUNTS_DOES_NOT_MATCH.getTransactionDesc());

		}
	}

	public TfesCommonTransactionResponse requestCreateSubscription(AccountsModel accountsModel,
			CreateSubscriptionPayload cspayload, String uuid)
			throws ExecutionException, InterruptedException, UnsupportedEncodingException, DecoderException {

		CreateSubscriptionRequest csRequest = new CreateSubscriptionRequest();
		csRequest.setRmNumber(accountsModel.getRmNumber());
		csRequest.setInvestmentAccountNumber(cspayload.getInvestmentAccountNumber());
		csRequest.setSettlementAccountNumber(accountsModel.getAccountNo());
		csRequest.setProductCode(cspayload.getProductCode());
		csRequest.setAmount(cspayload.getAmount());
		csRequest.setIsBeyondCutOff(cspayload.getIsBeyondCutoff());
		csRequest.setRemarks(cspayload.getRemarks());
		csRequest.setOrderDate(cspayload.getOrderDate().format(formatter));
		csRequest.setPtaNumber(cspayload.getPtaNumber());
		csRequest.setRspAmount(cspayload.getRspAmount());
		csRequest.setInstallmentDate(cspayload.getInstallmentDate());
		csRequest.setInstallmentPeriod(cspayload.getInstallmentPeriod());
		csRequest.setTransactionType("Subscription");
		csRequest.setUserId(tfesConfig.getSystemId());
		csRequest.setSaltValue(tfesConfig.getSaltValue());
		csRequest.setSignValue(tfesConfig.getSignValue());

		String subscriptionUri = cspayload.getInitial() ? tfesConfig.getCreateInitialSubscription()
				: tfesConfig.getCreateAdditionalSubscription();

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
				csRequest);
		TfesCommonTransactionResponse jcsResponse = tfesService.createSubscription(csRequest, subscriptionUri, uuid)
				.getBody();

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
				jcsResponse);
		return createTransactionResponse(jcsResponse, uuid, accountsModel.getRmNumber());
	}

	public boolean validateInvestmentAccount(String cif, String settlementAccountId, String investmentAccountId,
			String uuid)
			throws InterruptedException, ExecutionException, DecoderException, UnsupportedEncodingException {

		boolean found = false;
		EnrollTrustAccountResponse response = tfesService.enrollTrustAccount(cif, settlementAccountId, uuid).getBody();

		loggingService.log(String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_REDEMPTION_SERVICE),
				uuid, response);

		if (response.getReturnCode().equalsIgnoreCase(INVALID_AUTHENTICATION.getExternalTransactionCode())) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_REDEMPTION_SERVICE), uuid,
					INVALID_AUTHENTICATION.getTransactionDesc(), investmentAccountId);
			throw new InvalidAuthenticationException();

		} else if (response.getReturnCode()
				.equalsIgnoreCase(SETTLEMENT_ACCOUNT_NOT_FOUND.getExternalTransactionCode())) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_REDEMPTION_SERVICE), uuid,
					SETTLEMENT_ACCOUNT_NOT_FOUND.getTransactionDesc(), investmentAccountId);
			throw new SettlementAccountNotFoundException();

		} else if (response.getReturnCode()
				.equalsIgnoreCase(LINKED_INVESTMENT_ACCOUNT_NOT_FOUND.getExternalTransactionCode())) {
			loggingService.error(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_REDEMPTION_SERVICE), uuid,
					LINKED_INVESTMENT_ACCOUNT_NOT_FOUND.getTransactionDesc(), investmentAccountId);
			throw new LinkedInvestmentAccountsNotFoundException();

		} else if (response.getReturnCode()
				.equalsIgnoreCase(REQUEST_SUCCESSFULLY_PROCESSED.getExternalTransactionCode())) {
			loggingService.log(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
					investmentAccountId);

			List<InvestmentAccount> investmentAccounts = response.getInvestmentAccounts();
			if (investmentAccounts == null) {
				return false;
			}

			for (int a = 0; a < investmentAccounts.size(); a++) {
				if (investmentAccountId.equals(investmentAccounts.get(a).getInvestmentAccountNumber())) {
					found = true;
					break;
				}
			}

			loggingService.log(
					String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
					found);
			return found;
		}

		loggingService.log(
				String.format("%s%s", this.getClass().toString(), TraceLog.APIGW_CREATE_SUBSCRIPTION_SERVICE), uuid,
				false);
		return false;
	}
}
