package ph.com.metrobank.earnest.apigw.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DirectLinkServiceConfiguration {

    @Value("${directlink.base.endpoint}")
    private String baseUrl;

    @Value("${directlink.decrypt.endpoint}")
    private String decryptRequestUrl;

    @Value("${directlink.validateorsendotp.endpoint}")
    private String validateOrSendOtpUrl;
    
    @Value("${directlink.accountbytokenandexternaluserid.endpoint}")
    private String accountByTokenAndExternalUserId;
    
    @Value("${directlink.configuration.settings.endpoint}")
    private String configuration;
    
    private static final String ERN_CHANNEL_ID = "ERN";

    public String getBaseUrl() {
        return baseUrl;
    }

    public String getDecryptRequestUrl() {
        return String.format("%s%s", baseUrl, decryptRequestUrl);
    }

    public String getValidateOrSendOtpUrl() {
        return  String.format("%s%s", baseUrl, validateOrSendOtpUrl);
    }
    
    public String getAccountByTokenAndExternalUserId(String token, String externalUserId) {
    	return String.format("%s%s/%s/%s", baseUrl, accountByTokenAndExternalUserId, token, externalUserId);
    }
 
	public String getConfiguration() {
		return String.format("%s%s/%s", baseUrl, configuration, ERN_CHANNEL_ID);
	}
    
	public String verifyApplicationProperties() {
		StringBuilder builder = new StringBuilder();
		builder.append("DIRECTLINK API PROPERTY: ").append(getBaseUrl());
		return builder.toString();
	}
    
}
