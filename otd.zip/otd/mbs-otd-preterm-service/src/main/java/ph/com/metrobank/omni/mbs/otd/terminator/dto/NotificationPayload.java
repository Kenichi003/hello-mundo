package ph.com.metrobank.omni.mbs.otd.terminator.dto;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class NotificationPayload implements Serializable {

  private static final long serialVersionUID = 8407601507520790433L;
  private Map<String, String> smsTokens;
  private Map<String, String> emailTokens;
  private Map<String, String> notificationTitleTokens;
  private Map<String, String> notificationBodyTokens;

  private String referenceNo;
  private String type;
  private String status;
  
  private Map<String, String> meta;

  public Map<String, String> getSmsTokens() {
    return smsTokens;
  }

  public void setSmsTokens(Map<String, String> smsTokens) {
    this.smsTokens = smsTokens;
  }

  public Map<String, String> getEmailTokens() {
    return emailTokens;
  }

  public void setEmailTokens(Map<String, String> emailTokens) {
    this.emailTokens = emailTokens;
  }

  public Map<String, String> getNotificationTitleTokens() {
    return notificationTitleTokens;
  }

  public void setNotificationTitleTokens(Map<String, String> notificationTitleTokens) {
    this.notificationTitleTokens = notificationTitleTokens;
  }

  public Map<String, String> getNotificationBodyTokens() {
    return notificationBodyTokens;
  }

  public void setNotificationBodyTokens(Map<String, String> notificationBodyTokens) {
    this.notificationBodyTokens = notificationBodyTokens;
  }

  public String getReferenceNo() {
    return referenceNo;
  }

  public void setReferenceNo(String referenceNo) {
    this.referenceNo = referenceNo;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }



  @Override
  public String toString() {
    final int maxLen = 5;
    StringBuilder builder = new StringBuilder();
    builder.append("{ \"NotificationPayloadDto\": { \"smsTokens\": \"")
        .append(smsTokens != null ? toString(smsTokens.entrySet(), maxLen) : null)
        .append("\", \"emailTokens\": \"")
        .append(emailTokens != null ? toString(emailTokens.entrySet(), maxLen) : null)
        .append("\", \"notificationTitleTokens\": \"")
        .append(
            notificationTitleTokens != null ? toString(notificationTitleTokens.entrySet(), maxLen)
                : null)
        .append("\", \"notificationBodyTokens\": \"")
        .append(notificationBodyTokens != null ? toString(notificationBodyTokens.entrySet(), maxLen)
            : null)
        .append("\", \"referenceNo\": \"").append(referenceNo).append("\", \"type\": \"")
        .append(type).append("\", \"status\": \"").append(status).append("\", \"meta\": \"")
        .append(meta).append("\" } }");
    return builder.toString();
  }

  public Map<String, String> getMeta() {
	return meta;
}

public void setMeta(Map<String, String> meta) {
	this.meta = meta;
}

private String toString(Collection<?> collection, int maxLen) {
    StringBuilder builder = new StringBuilder();
    builder.append("[");
    int i = 0;
    for (Iterator<?> iterator = collection.iterator(); iterator.hasNext() && i < maxLen; i++) {
      if (i > 0)
        builder.append(", ");
      builder.append(iterator.next());
    }
    builder.append("]");
    return builder.toString();
  }

}
