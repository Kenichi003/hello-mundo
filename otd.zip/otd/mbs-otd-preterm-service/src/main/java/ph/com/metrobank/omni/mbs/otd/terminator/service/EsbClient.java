package ph.com.metrobank.omni.mbs.otd.terminator.service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.Credentials;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.InquireTDClosingBalanceInput;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.InquireTDClosingBalanceOutput;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.OtdDetailsResponse;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TDClosingInput;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TerminationRequest;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TerminationResponse;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TimeDepositClosingBalanceRequest;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TimeDepositClosingBalanceResponse;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TransactionInformation;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.WSStatus;
import ph.com.metrobank.omni.mbs.otd.terminator.model.OtdRequest;
import ph.com.metrobank.omni.mbs.otd.terminator.model.OtdTermination;
import ph.com.metrobank.omni.mbs.otd.terminator.repository.OtdTerminationRepository;
import ph.com.metrobank.omni.mbs.otd.terminator.util.ProcessingUtils;


@Service
public class EsbClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(EsbClient.class);

	@Autowired
	private Environment env;

//	@Autowired
//	private RestTemplateService restTemplateService;

	@Autowired
	private HttpRequestService httpService; 

	@Autowired
	private TerminationSequenceService sequencer;

	@Autowired
	private OtdTerminationRepository terminationRepo;

	private static String otdCurrencyCode;

	private static Credentials credentials;
	private static String esbDate;
	private static String esbTime;

	private static String terminateTimeDepositUri;
	private static String inquireTimeDepositBalanceUri;	
	private static String docStampDebitSTUserTranCodeSameYear;
	private static String docStampDebitSTUserTranCodeDifferentYear;
	private static String closingSTUserTranCodeSavingsAccount;
	private static String closingSTUserTranCodeCheckingAccount;
	private static String creditSTUserTranCodeSavingsAccount;
	private static String creditSTUserTranCodeCheckingAccount;
//	private static String casaUri;

//	@Value("${mbs.casa.details.url}")
//	private String casaDetailsUri;

	@PostConstruct
	private void initialize() {
		credentials = new Credentials(env.getProperty("value.esbSystemId"), env.getProperty("value.esbPassword"));
		terminateTimeDepositUri = env.getProperty("mbs.esb.otdTermination.url");
		inquireTimeDepositBalanceUri = env.getProperty("mbs.esb.inquireClosingBalance.url");
		docStampDebitSTUserTranCodeSameYear = env.getProperty("value.docStampDebitSTUserTranCodeSameYear");
		docStampDebitSTUserTranCodeDifferentYear = env.getProperty("value.docStampDebitSTUserTranCodeDifferentYear");
		closingSTUserTranCodeSavingsAccount = env.getProperty("value.closingSTUserTranCodeSavingsAccount");
		closingSTUserTranCodeCheckingAccount = env.getProperty("value.closingSTUserTranCodeCheckingAccount");
		creditSTUserTranCodeSavingsAccount =  env.getProperty("value.creditSTUserTranCodeSavingsAccount");
		creditSTUserTranCodeCheckingAccount =  env.getProperty("value.creditSTUserTranCodeCheckingAccount");
		esbDate = env.getProperty("value.esbDate");
		esbTime = env.getProperty("value.esbTime");
		otdCurrencyCode = env.getProperty("value.otdCurrencyCode");
//		casaDetailsUri = env.getProperty("mbs.casa.details.url");
//		casaUri = env.getProperty("mbs.casa.account.url");
	}

	public TerminationResponse terminateTimeDeposit(OtdRequest otd, JsonObject access) throws IOException {
		LocalDateTime transactionStamp = LocalDateTime.now();
		LOGGER.info("Server date: {}", transactionStamp.toLocalDate().toString());
		String sequence = sequencer.generateNumber();
		TimeDepositClosingBalanceRequest closingBalanceRequest = new TimeDepositClosingBalanceRequest();
		closingBalanceRequest.setCredentials(credentials);

		String otdAccountId = otd.getOtdAccountId();
		String otdBranchCode = StringUtils.substring(otdAccountId, 0, 3);
		String tenDigitOtdAccountId = StringUtils.substring(otdAccountId, 3);

		TransactionInformation closingBalanceTransactionInformation = closingBalanceRequest.getTransactionInformation();
		closingBalanceTransactionInformation.setTimeStamp(esbTime);
		closingBalanceTransactionInformation.setDateStamp(esbDate);
		closingBalanceTransactionInformation.setChannelTransaction(AppConstants.CHANNEL_INDICATOR);
		closingBalanceTransactionInformation.setProcessingBranch(otdBranchCode);
		closingBalanceTransactionInformation.setSequenceNumber(sequence);
		closingBalanceTransactionInformation.setSourceProductCode(AppConstants.MBOS);

		InquireTDClosingBalanceInput closingBalanceInput = closingBalanceRequest.getInquireTimeDepositClosingBalanceInput();
		closingBalanceInput.setAccountNumber(tenDigitOtdAccountId);
		closingBalanceInput.setBranchOfAccount(otdBranchCode);
		closingBalanceInput.setCurrencyOfAccount(otdCurrencyCode);
		closingBalanceInput.setSequenceNumber(sequence);
		closingBalanceInput.setServicingBranch(otdBranchCode);

		JsonElement esbResponse = httpService.post(inquireTimeDepositBalanceUri, ProcessingUtils.toJson(closingBalanceRequest, TimeDepositClosingBalanceRequest.class));
		TimeDepositClosingBalanceResponse closingBalanceResponse = (TimeDepositClosingBalanceResponse) ProcessingUtils.fromJson(esbResponse, TimeDepositClosingBalanceResponse.class);

		InquireTDClosingBalanceOutput out = closingBalanceResponse.getInquireTimeDepositClosingBalanceOutput();
		sequence = sequencer.generateNumber();
		TerminationRequest request = new TerminationRequest();
		request.setCredentials(credentials);

		TDClosingInput input = request.getTDClosingInput();
		input.setSequenceumber(sequence);
		input.setServicingBranch(otdBranchCode);
		input.setTdAccountCurrencyCode(out.getCurrencyOfAccount());
		input.setTdAccountBranchCode(otdBranchCode);
		input.setTdAccountNumber(tenDigitOtdAccountId);
		input.setDocStampAmount(out.getDocStampAmount());
		input.setClosingAmount(out.getClosingBalanceAmount());
		input.setSettlementAccountCurrencyCode(out.getCurrencyOfAccount());
		input.setSettlementAccountBranchCode(otd.getBranchCode());
		input.setSettlementAccountNumber(otd.getAccountId());
		input.setCreditAmount(out.getClosingBalanceAmount());

		String docStampDebitSTUserTranCode = transactionStamp.getYear() == otd.getTransactionDate().toLocalDateTime().getYear() ? docStampDebitSTUserTranCodeSameYear : docStampDebitSTUserTranCodeDifferentYear;
		String closingSTUserTranCode;
		String creditSTUserTranCode;

//		String toCasa = ProcessingUtils.append(casaUri, otd.getInternalAccountId());
//		JsonElement casaResponse = httpService.get(toCasa, access);
//		CasaDto settlementAccount = (CasaDto) ProcessingUtils.fromJson(casaResponse.getAsJsonObject().get(AppConstants.DATA), CasaDto.class);

		if(StringUtils.equalsIgnoreCase(otd.getAccountType(), AppConstants.SAVINGS_APP_ID)) {
			closingSTUserTranCode = closingSTUserTranCodeSavingsAccount; 
			creditSTUserTranCode = 	creditSTUserTranCodeSavingsAccount;
			input.setSettlementAccountAppID(AppConstants.SAVINGS_APP_ID);
		} else {
			closingSTUserTranCode = closingSTUserTranCodeCheckingAccount;
			creditSTUserTranCode = creditSTUserTranCodeCheckingAccount;
			input.setSettlementAccountAppID(AppConstants.CHECKING_APP_ID);
		}

		input.setDocStampDebitSTUserTranCode(docStampDebitSTUserTranCode);
		input.setClosingAmountSTUserTranCode(closingSTUserTranCode);
		input.setCreditSTUserTranCode(creditSTUserTranCode);

		input.setChannelIndicator(AppConstants.CHANNEL_INDICATOR);
		input.setSourceChannel(AppConstants.MBX);

		boolean before = transactionStamp.toLocalDate().isBefore(LocalDate.parse(out.getMaturityDate()));
		input.setProductCode(before ? AppConstants.OTDP : AppConstants.OTDT);
		input.setTdClosingType(AppConstants.TIME_DEPOSIT_ACCOUNT_TYPE);

		TransactionInformation info = request.getTransactionInformation();
		info.setDateStamp(esbDate);
		info.setTimeStamp(esbTime);
		info.setSourceProductCode(AppConstants.MBOS);
		info.setSequenceNumber(sequence);
		info.setServicingBranch(otdBranchCode);
		info.setProcessingBranch(otdBranchCode);
		info.setChannelTransaction(AppConstants.CHANNEL_INDICATOR);
		info.setSourceIdentifier(AppConstants.OTD);

		String terminate = ProcessingUtils.toJson(request, TerminationRequest.class);
		LOGGER.info("Termination request:\n{}", ProcessingUtils.prettyJson(terminate));
		JsonElement terminationResponse = httpService.post(terminateTimeDepositUri, terminate);
		LOGGER.info("Termination response:\n{}", ProcessingUtils.prettyJson(terminationResponse));
		TerminationResponse response = (TerminationResponse) ProcessingUtils.fromJson(terminationResponse, TerminationResponse.class);
		Optional<OtdTermination> find = terminationRepo.findByOtdAccountId(otdAccountId);

		OtdTermination save;
		if(find.isPresent()) {
			save = find.get();
		} else {
			save = new OtdTermination();
			save.setOtdAccountId(otdAccountId);
			save.setCustomerId(otd.getCustomerId());
		}

		WSStatus status = response.getWSStatus(); 
		if(StringUtils.equals(status.getTransactionStatus(), AppConstants.ZERO)) {
			save.setInquiryResponse(esbResponse.toString());
		} else {
			save.setInquiryResponse(terminationResponse.toString());
		}

		save.setUpdatedBy(AppConstants.OTD_TERMINATOR_SERVICE);
		terminationRepo.saveAndFlush(save);
		//(TerminationResponse) restTemplateService.postForObject(terminateTimeDepositUri, request);
		return response;
	}

	public OtdDetailsResponse queryHostForTerminationComputation(OtdRequest otd, OtdDetailsResponse toClient, boolean sameDay) throws Exception {
		String sequence = sequencer.generateNumber();
		TimeDepositClosingBalanceRequest request = new TimeDepositClosingBalanceRequest();
		request.setCredentials(credentials);
		TransactionInformation transactionInformation = request.getTransactionInformation();
		transactionInformation.setSequenceNumber(sequence);
		//TODO: branches and other info may be subject to future change based on AMLA or similar policies.
		transactionInformation.setDateStamp(esbDate);
		transactionInformation.setTimeStamp(esbTime);
		transactionInformation.setProcessingBranch(otd.getBranchCode());
		transactionInformation.setChannelTransaction(AppConstants.CHANNEL_INDICATOR);
		transactionInformation.setServicingBranch(otd.getBranchCode());
		transactionInformation.setSourceProductCode(AppConstants.MBOS);
		transactionInformation.setSourceIdentifier(AppConstants.OTD);

		InquireTDClosingBalanceInput input = request.getInquireTimeDepositClosingBalanceInput();
		input.setAccountNumber(otd.getOtdAccountId());
		input.setBranchOfAccount(otd.getBranchCode());
		input.setCurrencyOfAccount(otdCurrencyCode);
		input.setSequenceNumber(sequence);
		input.setServicingBranch(otd.getBranchCode());

		String payload = ProcessingUtils.toJson(request, TimeDepositClosingBalanceRequest.class);
		LOGGER.info("request: {}", payload);
		JsonElement inquiryResponse = httpService.post(inquireTimeDepositBalanceUri, ProcessingUtils.toJson(request, TimeDepositClosingBalanceRequest.class));
		TimeDepositClosingBalanceResponse response = (TimeDepositClosingBalanceResponse) ProcessingUtils.fromJson(inquiryResponse, TimeDepositClosingBalanceResponse.class);
		//		TimeDepositClosingBalanceResponse response = (TimeDepositClosingBalanceResponse) restTemplateService.postForObject(inquireTimeDepositBalanceUri, request);
		InquireTDClosingBalanceOutput forDetails = response.getInquireTimeDepositClosingBalanceOutput();

		if(sameDay) {
			toClient.setEarnedInterest(NumberUtils.createBigDecimal(forDetails.getAnnualInterestRate()));
			toClient.setWithHeldTaxAmount(NumberUtils.createBigDecimal(forDetails.getWithholdingTaxAmount()));
		} else {
			toClient.setPreTerminationPenalties(NumberUtils.createBigDecimal(forDetails.getPenaltyAmount()));
			toClient.setDocumentaryStampTax(NumberUtils.createBigDecimal(forDetails.getDocStampAmount()));
		}

		LOGGER.info("response: {}", ProcessingUtils.toJson(response));
		toClient.setNetCredits(NumberUtils.createBigDecimal(forDetails.getClosingBalanceAmount()));
		return toClient;

	}
}
