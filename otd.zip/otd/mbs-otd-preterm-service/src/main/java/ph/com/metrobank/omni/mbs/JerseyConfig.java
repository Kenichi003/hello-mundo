package ph.com.metrobank.omni.mbs;

import javax.annotation.PostConstruct;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;
import ph.com.metrobank.omni.mbs.common.exception.handler.GenericExceptionMapper;
import ph.com.metrobank.omni.mbs.otd.terminator.endpoint.TerminationEndpoint;

@Component
public class JerseyConfig extends ResourceConfig {

  @Value("${spring.jersey.application-path}")
  private String basePath;

  public JerseyConfig() {
    register(TerminationEndpoint.class);
    register(GenericExceptionMapper.class);
  }

  @PostConstruct
  public void init() {
    this.configureSwagger();
  }

  private void configureSwagger() {
    this.register(ApiListingResource.class);
    this.register(SwaggerSerializers.class);

    BeanConfig config = new BeanConfig();
    config.setTitle("MBS 3.0 - MBS OTD Termination Service API");
    config.setDescription("This is a swagger for the OTD termination entity. This is based on jersey endpoints");
    config.setVersion("v1");
    config.setSchemes(new String[] {"http"});
    config.setResourcePackage("ph.com.metrobank.omni.mbs.otd.terminator.endpoint");
    config.setPrettyPrint(true);
    config.setScan(true);
    config.setBasePath(basePath);
  }
}
