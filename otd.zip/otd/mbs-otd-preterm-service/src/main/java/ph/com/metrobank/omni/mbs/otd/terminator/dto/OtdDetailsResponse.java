
package ph.com.metrobank.omni.mbs.otd.terminator.dto;

import java.math.BigDecimal;

import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;

public class OtdDetailsResponse {
	
	private Long otdRequestId;
	private String otdAccountId;
	private String currency = AppConstants.PESO;
	private BigDecimal principalAmount;	
	private Integer term;
	private BigDecimal interestRate;			
	private String maturityDate;		
	private String settlementAccount;
	private BigDecimal netCredits;
	private BigDecimal preTerminationPenalties;
	private BigDecimal documentaryStampTax;
	private BigDecimal earnedInterest;
	private BigDecimal withHeldTaxAmount;
	private boolean settlementAccountActive;
	private boolean terminable;
	
	private String terminationTransactionDate;
		
	public OtdDetailsResponse(Long otdRequestId, String otdAccountId, String currency, BigDecimal principalAmount,
			Integer term, BigDecimal interestRate, String maturityDate, String settlementAccount, String terminationTransactionDate) {
		super();		
		this.otdRequestId = otdRequestId;
		this.otdAccountId = otdAccountId;
		this.currency = currency;
		this.principalAmount=principalAmount;
		this.term=term;
		this.interestRate=interestRate;
		this.maturityDate=maturityDate;		
		this.settlementAccount = settlementAccount;
		this.terminationTransactionDate = terminationTransactionDate;
	}
	
	public String getSettlementAccount() {
		return settlementAccount;
	}

	public void setSettlementAccount(String settlementAccount) {
		this.settlementAccount = settlementAccount;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	
	public Long getOtdRequestId() {
		return otdRequestId;
	}
	public void setOtdRequestId(Long otdRequestId) {
		this.otdRequestId = otdRequestId;
	}
	public String getOtdAccountId() {
		return otdAccountId;
	}
	public void setOtdAccountId(String otdAccountId) {
		this.otdAccountId = otdAccountId;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public BigDecimal getPrincipalAmount() {
		return principalAmount;
	}
	public void setPrincipalAmount(BigDecimal principalAmount) {
		this.principalAmount = principalAmount;
	}
	public Integer getTerm() {
		return term;
	}
	public void setTerm(Integer term) {
		this.term = term;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getTerminationTransactionDate() {
		return terminationTransactionDate;
	}
	public void setTerminationTransactionDate(String terminationTransactionDate) {
		this.terminationTransactionDate = terminationTransactionDate;
	}


	public BigDecimal getNetCredits() {
		return netCredits;
	}


	public void setNetCredits(BigDecimal netCredits) {
		this.netCredits = netCredits;
	}


	public BigDecimal getPreTerminationPenalties() {
		return preTerminationPenalties;
	}


	public void setPreTerminationPenalties(BigDecimal preTerminationPenalties) {
		this.preTerminationPenalties = preTerminationPenalties;
	}

	public BigDecimal getDocumentaryStampTax() {
		return documentaryStampTax;
	}


	public void setDocumentaryStampTax(BigDecimal documentaryStampTax) {
		this.documentaryStampTax = documentaryStampTax;
	}


	public BigDecimal getEarnedInterest() {
		return earnedInterest;
	}


	public void setEarnedInterest(BigDecimal earnedInterest) {
		this.earnedInterest = earnedInterest;
	}


	public BigDecimal getWithHeldTaxAmount() {
		return withHeldTaxAmount;
	}


	public void setWithHeldTaxAmount(BigDecimal withHeldTaxAmount) {
		this.withHeldTaxAmount =withHeldTaxAmount;
	}

	public boolean isTerminable() {
		return terminable;
	}

	public void setTerminable(boolean terminable) {
		this.terminable = terminable;
	}

	public boolean isSettlementAccountActive() {
		return settlementAccountActive;
	}

	public void setSettlementAccountActive(boolean settlementAccountActive) {
		this.settlementAccountActive = settlementAccountActive;
	}
}

