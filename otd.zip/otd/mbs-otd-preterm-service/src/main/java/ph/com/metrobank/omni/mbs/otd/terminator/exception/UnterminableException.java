package ph.com.metrobank.omni.mbs.otd.terminator.exception;

import javax.ws.rs.ForbiddenException;

public class UnterminableException extends ForbiddenException {

  private static final long serialVersionUID = 1L;

  private String messageKey;
  private String field;
  private String errorMessage; // formerly errorCode
  private Object data;
  private Object[] messageParam;

  public UnterminableException(String messageKey) {
    this.messageKey = messageKey;
  }

  public UnterminableException(String messageKey, String field) {
    this.messageKey = messageKey;
    this.field = field;
  }

  public UnterminableException(String messageKey, String field, Object... messageParam) {
    this(messageKey, field);
    this.messageParam = messageParam;
  }

  public UnterminableException(String messageKey, Object... messageParam) {
    this(messageKey);
    this.messageParam = messageParam;
  }

  public UnterminableException(Object data) {
    this.data = data;
  }

  public UnterminableException(String messageKey, Object data) {
    this(data);
    this.messageKey = messageKey;
  }

  public UnterminableException(Throwable e) {
    super(e);
  }

  public UnterminableException(String errorMessage, Throwable e) {
    this(e);
    this.errorMessage = errorMessage;
  }

  public String getMessageKey() {
    return messageKey;
  }

  public void setMessageKey(String messageKey) {
    this.messageKey = messageKey;
  }

  public String getField() {
    return field;
  }

  public void setField(String field) {
    this.field = field;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public Object getData() {
    return data;
  }

  public void setData(Object data) {
    this.data = data;
  }

  public Object[] getMessageParam() {
    return messageParam;
  }

  public void setMessageParam(Object[] messageParam) {
    this.messageParam = messageParam;
  }
}
