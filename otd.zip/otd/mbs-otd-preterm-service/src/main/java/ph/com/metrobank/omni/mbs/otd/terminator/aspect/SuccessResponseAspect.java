package ph.com.metrobank.omni.mbs.otd.terminator.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ph.com.metrobank.omni.mbs.common.dto.SuccessResponse;

@Aspect
@Component
public class SuccessResponseAspect {

  private final Logger LOGGER = LoggerFactory.getLogger(SuccessResponseAspect.class);

  @Value("${app.name}")
  private String appName;

  @Value("${app.version}")
  private String appVersion;

  @Around(value = "execution(* ph.com.metrobank.omni.mbs.otd.terminator.endpoint..*.*(..))")
  public Object createSuccessResponse(ProceedingJoinPoint joinPoint) throws Throwable {
    LOGGER.info("Starting method execution for {}", joinPoint.getSignature().getName());
    Object result = joinPoint.proceed();
    LOGGER.info("Finished execution of {}", joinPoint.getSignature().getName());
    
    return new SuccessResponse(result, appName, appVersion);
  }

}
