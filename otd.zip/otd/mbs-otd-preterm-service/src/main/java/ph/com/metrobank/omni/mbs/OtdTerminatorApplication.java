package ph.com.metrobank.omni.mbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtdTerminatorApplication {
    public static void main( String[] args ) {
		SpringApplication.run(OtdTerminatorApplication.class);
    }
}
