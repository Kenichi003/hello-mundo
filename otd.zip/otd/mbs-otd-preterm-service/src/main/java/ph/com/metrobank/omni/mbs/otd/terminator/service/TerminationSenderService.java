package ph.com.metrobank.omni.mbs.otd.terminator.service;

import java.time.LocalDate;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;

import ph.com.metrobank.omni.mbs.common.dto.casa.CasaDto;
import ph.com.metrobank.omni.mbs.common.dto.customer.CustomerDto;
import ph.com.metrobank.omni.mbs.common.exception.ValidationException;
import ph.com.metrobank.omni.mbs.common.services.RestTemplateService;
import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.InquireTDClosingBalanceOutput;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TerminationDetails;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TimeDepositClosingBalanceResponse;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TimeDepositDetails;
import ph.com.metrobank.omni.mbs.otd.terminator.model.OtdRequest;
import ph.com.metrobank.omni.mbs.otd.terminator.model.OtdTermination;
import ph.com.metrobank.omni.mbs.otd.terminator.repository.OtdTerminationRepository;
import ph.com.metrobank.omni.mbs.otd.terminator.util.ProcessingUtils;

@Service
public class TerminationSenderService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TerminationSenderService.class); 
	
	@Value("${mbs.customer.url}")
	private String customerInfoUrl;
	
	@Value("${mbs.email.url}")
	private String emailUrl;
	
	@Value("${mbs.casa.td.url}")
	private String casaTDUrl;
	
	@Value("${mbs.casa.details.url}")
	private String casaAccountDetailsUrl;

	@Value("${value.daysBeforeMaturity}")
	int daysBeforeMaturity;

	@Autowired
	private RestTemplateService restTemplateService;
		
	@Autowired
	private TerminationNotificationService notificationService;
	
	@Autowired
	private OtdTerminationRepository terminationRepo;

	public void send(OtdRequest req, CasaDto casa) throws Exception {
		LocalDate now = LocalDate.now();	
		
		CustomerDto customer = getCustomerInformation(req.getCustomerId());				
		if(customer == null) {
			throw new ResourceNotFoundException();
		}
		
		Optional<OtdTermination> findTerm = terminationRepo.findByOtdAccountId(req.getOtdAccountId());
		if(!findTerm.isPresent()) {
			throw new ResourceNotFoundException();
		}
		
		OtdTermination termination = findTerm.get();
		JsonElement convert = ProcessingUtils.parseJson(termination.getInquiryResponse());
		TimeDepositClosingBalanceResponse lastResponse = (TimeDepositClosingBalanceResponse) ProcessingUtils.fromJson(convert, TimeDepositClosingBalanceResponse.class);
		InquireTDClosingBalanceOutput output = lastResponse.getInquireTimeDepositClosingBalanceOutput();

		String currencyPrefix;
		switch(req.getCurrencyCode()) {
		case AppConstants.USD_CODE:
			currencyPrefix = AppConstants.USD;
			break;
		default:
		case AppConstants.PHP_CODE:
			currencyPrefix = AppConstants.PHP;
		}

		TerminationDetails terminationDto = new TerminationDetails(
				req.getOtdAccountId(), 
				req.getAccountName(),
				req.getBranchCode(),
				StringUtils.upperCase(currencyPrefix),
				casa.getCurrencyCode(),				
				customer.getEmail(),
				customer.getMobile(),
				ProcessingUtils.append(currencyPrefix, StringUtils.SPACE, ProcessingUtils.formatPlacementAmount(output.getCurrentBalance())),
 				NumberUtils.createInteger(StringUtils.stripStart(output.getNumberOfTerm(), AppConstants.ZERO)),
				ProcessingUtils.append(ProcessingUtils.formatInterestRate(output.getAnnualInterestRate()), AppConstants.PERCENT),
				LocalDate.parse(output.getMaturityDate()).format(AppConstants.MMMMddyyyy),
				ProcessingUtils.append(req.getBranchCode(), req.getAccountId()), 
				req.getTerminationReferenceId(), 
				AppConstants.MMMMddyyyy.format(LocalDate.now()), 
				req.terminated());
		
		//newly added for Release 4
		boolean sameDay = now.isEqual(LocalDate.parse(output.getMaturityDate()));
		if(sameDay) {
			terminationDto.setWithHoldingTax(ProcessingUtils.append(currencyPrefix, StringUtils.SPACE, output.getWithholdingTaxAmount()));
			terminationDto.setEarnedInterest(ProcessingUtils.append(currencyPrefix, StringUtils.SPACE, output.getAccruedInterestAmount()));
		} else {
			terminationDto.setPreTermPenalties(ProcessingUtils.append(currencyPrefix, StringUtils.SPACE, output.getPenaltyAmount()));
			terminationDto.setDocumentaryStampTax(ProcessingUtils.append(currencyPrefix, StringUtils.SPACE, output.getDocStampAmount()));
		}
		
		terminationDto.setNetCredits(ProcessingUtils.append(currencyPrefix, StringUtils.SPACE, ProcessingUtils.formatNetCredits(output.getClosingBalanceAmount())));

		LOGGER.info("\nTermination details:\n {}", ProcessingUtils.prettyJson(ProcessingUtils.toJson(terminationDto, TerminationDetails.class)));
		//TODO: does same-day behavior hold on roll-over type maturities in this next step?
		try {												
			notificationService.sendNotification(customer, terminationDto, sameDay);
		}catch (Exception e) {
			//changed since more than ResourceNotFoundException can happen here
			LOGGER.error("Error during notification creation.");
			throw e;
		}
	}
	
	public CasaDto getCasaByOtdAccountId(String accountId) {
		String cUrl = ProcessingUtils.append(casaAccountDetailsUrl, accountId);
		CasaDto casaDtO = restTemplateService.getForObject(cUrl, CasaDto.class);
		if(casaDtO == null) {
			throw new ResourceNotFoundException();
		}
		return casaDtO;
	}
	
	public TimeDepositDetails getTimeDepositDetails(String otdAccountId) {	
		String tds = String.format(casaTDUrl, otdAccountId);	
		TimeDepositDetails tdDTO = restTemplateService.getForObject(tds, TimeDepositDetails.class);
		if (tdDTO == null || tdDTO.getCustomerId() == null) {
			throw new ResourceNotFoundException();
		}
		return tdDTO;		
	}
	
	public CustomerDto getCustomerInformation(String customerId) throws ValidationException {
	    try {
	      LOGGER.info("Getting customer details, customerId={{}}", customerId);
	      String customerUrl = ProcessingUtils.append(customerInfoUrl, customerId);
	      return restTemplateService.getForObject(customerUrl, CustomerDto.class);
	    } catch (Exception e) {
	      LOGGER.error("Encountered error while getting customer information, customerId = {{}}",
	          customerId, e);
	    }
	    throw new ValidationException("mbs.enrollment.failed.invalid_customer_data");
	}
}
