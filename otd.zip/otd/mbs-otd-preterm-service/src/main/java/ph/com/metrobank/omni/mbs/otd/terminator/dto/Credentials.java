package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class Credentials {
	private String systemID;
	private String password;
	
	public Credentials(String id, String esbPassword) {
		systemID = id;
		password = esbPassword;
	}
	
	public String getSystemId() {
		return systemID;
	}
	public void setSystemId(String systemId) {
		this.systemID = systemId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
