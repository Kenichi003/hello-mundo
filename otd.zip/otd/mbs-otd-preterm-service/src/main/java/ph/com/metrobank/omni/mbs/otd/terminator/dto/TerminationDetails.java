package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class TerminationDetails {
	private String otdAccountId;		
	private String accountName;
	private String branchCode;
	private String currency;
	private String currencyCode;
	private String email;
	private String mobile;
	private String principalAmount;
	private Integer term;	
	private String interestRate;
	private String maturityDate;
	private String settlementAccount;
	private String terminationReferenceId;
	private String terminationTransactionDate;	
	private String preTermPenalties;
	private String documentaryStampTax;
	private String netCredits;
	private String earnedInterest;
	private String withHoldingTax;
	private boolean terminationFlag;
	
	public TerminationDetails() {
		super();
	}


	public TerminationDetails(
			String otdAccountId, 
			String accountName, 
			String branchCode, 
			String currency, 
			String currencyCode, 
			String email, 
			String mobile, 
			String principalAmount,
			Integer term, 
			String interestRate, 
			String maturityDate, 
			String settlementAccount, 
			String terminationReferenceId,
			String terminationTransactionDate, 
			boolean terminationFlag) {
		super();
		this.otdAccountId = otdAccountId;
		this.accountName = accountName;
		this.branchCode = branchCode;
		this.currency = currency;
		this.currencyCode = currencyCode;
		this.email = email;
		this.mobile = mobile;
		this.principalAmount = principalAmount;
		this.term = term;
		this.interestRate = interestRate;
		this.maturityDate = maturityDate;
		this.settlementAccount = settlementAccount;
		this.terminationReferenceId = terminationReferenceId;
		this.terminationTransactionDate = terminationTransactionDate;
		this.terminationFlag = terminationFlag;
	}


	
	public String getCurrencyCode() {
		return currencyCode;
	}


	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}


	public String getBranchCode() {
		return branchCode;
	}


	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getOtdAccountId() {
		return otdAccountId;
	}

	public void setOtdAccountId(String otdAccountId) {
		this.otdAccountId = otdAccountId;
	}

	public String getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(String principalAmount) {
		this.principalAmount = principalAmount;
	}

	public Integer getTerm() {
		return term;
	}

	public void setTerm(Integer term) {
		this.term = term;
	}

	public String getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}



	public String getSettlementAccount() {
		return settlementAccount;
	}

	public void setSettlementAccount(String settlementAccount) {
		this.settlementAccount = settlementAccount;
	}

	public String getTerminationReferenceId() {
		return terminationReferenceId;
	}

	public void setTerminationReferenceId(String terminationReferenceId) {
		this.terminationReferenceId = terminationReferenceId;
	}



	public String getMaturityDate() {
		return maturityDate;
	}



	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}



	public String getTerminationTransactionDate() {
		return terminationTransactionDate;
	}



	public void setTerminationTransactionDate(String terminationTransactionDate) {
		this.terminationTransactionDate = terminationTransactionDate;
	}

	public boolean isTerminationFlag() {
		return terminationFlag;
	}

	public void setTerminationFlag(boolean terminationFlag) {
		this.terminationFlag = terminationFlag;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getPreTermPenalties() {
		return preTermPenalties;
	}


	public void setPreTermPenalties(String preTermPenalties) {
		this.preTermPenalties = preTermPenalties;
	}


	public String getDocumentaryStampTax() {
		return documentaryStampTax;
	}


	public void setDocumentaryStampTax(String documentaryStampTax) {
		this.documentaryStampTax = documentaryStampTax;
	}


	public String getNetCredits() {
		return netCredits;
	}


	public void setNetCredits(String netCredits) {
		this.netCredits = netCredits;
	}


	public String getEarnedInterest() {
		return earnedInterest;
	}


	public void setEarnedInterest(String earnedInterest) {
		this.earnedInterest = earnedInterest;
	}


	public String getWithHoldingTax() {
		return withHoldingTax;
	}


	public void setWithHoldingTax(String withHoldingTax) {
		this.withHoldingTax = withHoldingTax;
	}



	


}
