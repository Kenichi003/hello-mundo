package ph.com.metrobank.omni.mbs.otd.terminator.dto;

import java.io.Serializable;
import java.util.Date;

import ph.com.metrobank.omni.mbs.common.dto.NotificationBodyDto;
import ph.com.metrobank.omni.mbs.common.dto.NotificationFilterDto;

public class NotificationDetails implements Serializable {

  private static final long serialVersionUID = 1L;
  private String title;
  private NotificationBodyDto body;
  private NotificationFilterDto filter;
  private Date notificationDate;
  private Date expirationDate;
  private NotificationPayload payload;

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public NotificationBodyDto getBody() {
    return body;
  }

  public void setBody(NotificationBodyDto body) {
    this.body = body;
  }

  public NotificationFilterDto getFilter() {
    return filter;
  }

  public void setFilter(NotificationFilterDto filter) {
    this.filter = filter;
  }

  public Date getNotificationDate() {
    return notificationDate;
  }

  public void setNotificationDate(Date notificationDate) {
    this.notificationDate = notificationDate;
  }

  public Date getExpirationDate() {
    return expirationDate;
  }

  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  


public NotificationPayload getPayload() {
	return payload;
}

public void setPayload(NotificationPayload payload) {
	this.payload = payload;
}

@Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("{ \"NotificationDto\": { \"title\": \"").append(title)
        .append("\", \"body\": \"").append(body).append("\", \"filter\": \"").append(filter)
        .append("\", \"notificationDate\": \"").append(notificationDate)
        .append("\", \"expirationDate\": \"").append(expirationDate).append("\", \"payload\": \"")
        .append(payload).append("\" } }");
    return builder.toString();
  }

}
