package ph.com.metrobank.omni.mbs.otd.terminator.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ph.com.metrobank.omni.mbs.common.dto.KafkaMessage;
import ph.com.metrobank.omni.mbs.common.dto.NotificationBodyDto;
import ph.com.metrobank.omni.mbs.common.dto.NotificationFilterDto;
import ph.com.metrobank.omni.mbs.common.dto.customer.CustomerDto;
import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.NotificationDetails;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.NotificationPayload;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TerminationDetails;
import ph.com.metrobank.omni.mbs.otd.terminator.util.ProcessingUtils;

@Service
public class TerminationNotificationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TerminationNotificationService.class);

	@Autowired
	private KafkaSenderService kafkaSenderService;

	@Value("${spring.kafka.topic.notificationSent}")
	private String notificationSentTopic;

	public void sendNotification(CustomerDto customer, TerminationDetails terminationDto, boolean sameDay) {
		NotificationDetails notification = createNotification(customer, terminationDto, sameDay);
		try {
			sendKafkaMessage(notificationSentTopic, notification);
			LOGGER.info("\nPayload sent to MBS Notications: \n{}", ProcessingUtils.prettyJson(ProcessingUtils.toJson(notification, NotificationDetails.class)));
		} catch (Exception e) {
			LOGGER.error("Sending notification, customer username = {{}}}, TerminationReferenceNum = {{}}",
					customer.getUsername(), terminationDto.getTerminationReferenceId(), e);
		}
	}


	private NotificationDetails createNotification(CustomerDto customer, TerminationDetails terminationDto, boolean sameDay) {
		NotificationDetails notification = new NotificationDetails();
		notification.setTitle(sameDay ? AppConstants.TERMINATION_TITLE  : AppConstants.PRE_TERMINATION_TITLE);
		NotificationBodyDto notificationBody = createNotificationBody(sameDay);

		notification.setBody(notificationBody);
		notification.setFilter(createNotificationFilter(customer, notificationBody));
		notification.setPayload(createNotificationPayload(customer, terminationDto, sameDay));
		return notification;
	}


	private NotificationPayload createNotificationPayload(CustomerDto customer, TerminationDetails terminationDto, boolean sameDay) {
		String term = ProcessingUtils.append(String.valueOf(terminationDto.getTerm()), terminationDto.getTerm() > 1 ? " Months" : " Month");
		Map<String, String> notificationBodyTokens = new HashMap<String, String>();
		notificationBodyTokens.put("tdAccountNo", terminationDto.getOtdAccountId());
		notificationBodyTokens.put("currency", terminationDto.getCurrency());
		notificationBodyTokens.put("principalAmount", terminationDto.getPrincipalAmount());
		notificationBodyTokens.put("term", term);
		notificationBodyTokens.put("interestRate", terminationDto.getInterestRate());
		notificationBodyTokens.put("maturityDate", terminationDto.getMaturityDate());
		notificationBodyTokens.put("settlementAccount", terminationDto.getSettlementAccount());
		notificationBodyTokens.put("transactionDate", terminationDto.getTerminationTransactionDate());
		notificationBodyTokens.put("referenceNo", terminationDto.getTerminationReferenceId());

		//TODO: double-check
		if(sameDay) {
			notificationBodyTokens.put("earnedInterest", terminationDto.getEarnedInterest());
			notificationBodyTokens.put("withHeldTaxAmount", terminationDto.getWithHoldingTax());
		} else {
			notificationBodyTokens.put("preTerminationPenalties", terminationDto.getPreTermPenalties());
			notificationBodyTokens.put("documentaryStampTax", terminationDto.getDocumentaryStampTax());
		}
		
		notificationBodyTokens.put("netCredits", terminationDto.getNetCredits());
		
		NotificationPayload payload = new NotificationPayload();

		Map<String, String> smsTokenMap = new HashMap<String, String>();
//		smsTokenMap.put("lastFourDigits", StringUtils.substring(terminationDto.getOtdAccountId(), terminationDto.getOtdAccountId().length()-4));		
		smsTokenMap.put("referenceId", terminationDto.getTerminationReferenceId());

		Map<String, String> emailTokens = new HashMap<String, String>();
		emailTokens.put("accountName", terminationDto.getAccountName());
		emailTokens.put("otdAccountId", ProcessingUtils.maskAccount(terminationDto.getOtdAccountId()));
		emailTokens.put("currency", terminationDto.getCurrency());
		emailTokens.put("principalAmount", terminationDto.getPrincipalAmount());
		emailTokens.put("term", term);
		emailTokens.put("interestRate", terminationDto.getInterestRate());
		emailTokens.put("maturityDate", terminationDto.getMaturityDate());
		if(sameDay) {
			emailTokens.put("earnedInterest", terminationDto.getEarnedInterest());
			emailTokens.put("withHeldTax", terminationDto.getWithHoldingTax());
		} else {
			emailTokens.put("preTermPenalties", terminationDto.getPreTermPenalties());
			emailTokens.put("documentaryStampTax", terminationDto.getDocumentaryStampTax());
		}


		emailTokens.put("netCredits", terminationDto.getNetCredits());
		emailTokens.put("settlementAccountId", ProcessingUtils.maskAccount(terminationDto.getSettlementAccount()));
		emailTokens.put("transactionDate", terminationDto.getTerminationTransactionDate());
//		smpTokenEmail.put("referenceNo", terminationDto.getTerminationReferenceId());

		payload.setSmsTokens(smsTokenMap);
		payload.setEmailTokens(emailTokens);
		payload.setNotificationTitleTokens(new HashMap<>());
		payload.setNotificationBodyTokens(notificationBodyTokens);
		payload.setReferenceNo(terminationDto.getTerminationReferenceId());
		payload.setStatus("INFO");
//		payload.setType(sameDay ? "OTD_PRE_TERM" : "OTD_TERM");	 	    	    
		payload.setType(AppConstants.OTD_PRE_TERM);	 	    	    
		payload.setMeta(notificationBodyTokens);
		return payload;	
	}

	private NotificationFilterDto createNotificationFilter(CustomerDto customer, NotificationBodyDto notificationBody) {
		NotificationFilterDto filter = new NotificationFilterDto();
		if (notificationBody != null) {
			if (StringUtils.isNotBlank(notificationBody.getNotificationCode())) {
				filter.setId(customer.getId().toString());
			}
			if (StringUtils.isNotBlank(notificationBody.getSmsCode())) {
				filter.setMobile(customer.getMobile());
			}
			if (StringUtils.isNotBlank(notificationBody.getEmailCode())) {
				filter.setEmail(customer.getEmail());
			}
		}
		return filter;
	}

	private NotificationBodyDto createNotificationBody(boolean sameDay) {
		NotificationBodyDto body = new NotificationBodyDto();
		String code = sameDay ? AppConstants.TERMINATION_CODE : AppConstants.PRE_TERM_CODE;
		body.setSmsCode(code);
		body.setEmailCode(code);
		body.setNotificationCode(code);
		return body;
	}


	private void sendKafkaMessage(String topic, Object data) throws Exception {
		KafkaMessage kafkaMessage = KafkaMessage.createInstance(topic, data);
		kafkaSenderService.send(kafkaMessage);
	}
}
