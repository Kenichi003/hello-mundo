package ph.com.metrobank.omni.mbs.otd.terminator.dto;
public class InquireTDClosingBalanceInput {
    private String servicingBranch;
    private String sequenceNumber;
    private String currencyOfAccount;
    private String branchOfAccount;
    private String accountNumber;
    
	public String getServicingBranch() {
		return servicingBranch;
	}
	public void setServicingBranch(String servicingBranch) {
		this.servicingBranch = servicingBranch;
	}
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getCurrencyOfAccount() {
		return currencyOfAccount;
	}
	public void setCurrencyOfAccount(String currencyOfAccount) {
		this.currencyOfAccount = currencyOfAccount;
	}
	public String getBranchOfAccount() {
		return branchOfAccount;
	}
	public void setBranchOfAccount(String branchOfAccount) {
		this.branchOfAccount = branchOfAccount;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
}