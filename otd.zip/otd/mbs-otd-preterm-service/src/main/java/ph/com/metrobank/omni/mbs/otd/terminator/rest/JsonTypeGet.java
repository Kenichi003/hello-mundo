package ph.com.metrobank.omni.mbs.otd.terminator.rest;

import java.io.UnsupportedEncodingException;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.client.methods.HttpGet;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;

public class JsonTypeGet extends HttpGet {

	public JsonTypeGet(String uri, JsonObject headers) throws UnsupportedEncodingException {
		super(uri);
		setHeader(AppConstants.ACCEPT_PARAMETER, AppConstants.APPLICATION_JSON_TYPE);
		setHeader(AppConstants.CONTENT_TYPE_PARAMETER, AppConstants.APPLICATION_JSON_TYPE);
		Set<Entry<String, JsonElement>> entries = headers.entrySet();
		for(Entry<String, JsonElement> header : entries) {
			setHeader(header.getKey(), header.getValue().getAsString());
		}
	}
}
