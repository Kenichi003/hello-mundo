package ph.com.metrobank.omni.mbs.otd.terminator.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;

@Component
public class ProcessingUtils {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessingUtils.class); 

	public static final Gson GSON;
	public static final Gson PRETTIFIER;
	private static final ObjectMapper MAPPER = new ObjectMapper();
	private static final JsonParser PARSER = new JsonParser();

	static {
		GsonBuilder builder = new GsonBuilder();
		GSON = builder.disableHtmlEscaping().create();
		PRETTIFIER = builder.setPrettyPrinting().create();	
	}
	
	public static String append(String...strings) {
		StringBuilder sb = new StringBuilder();
		for(String string : strings) {
			sb.append(string);
		}

		return sb.toString();
	}

	public static boolean isJson(String value) { 
		if(!StringUtils.isBlank(value)) {
			try {
				MAPPER.readTree(value);
				return true;
			} catch (IOException e) {
				return false;
			}
		}
		
		return false;
	}
	
	public static void writeToFile(String path, String json) throws IOException {
		try (PrintWriter writer = new PrintWriter(new FileWriter(path.toString()))) {
			writer.write(json.toString());
		}		
	}

	public static <T> String toJson(Object convert, Class<T> from) {
		return GSON.toJson(convert, from);
	}
	
	public static Object fromJson(JsonElement convert, Class<?> to) {
		return GSON.fromJson(convert, to);
	}

	public static JsonElement toJson(String value) {
		return PARSER.parse(value);
	}

	public static LocalDateTime toLocalDateTime(LocalDate date) {
		return LocalDateTime.of(date, LocalTime.now());
	}

	public static String remove(String string, String... remove) {
		for(String item : remove) {
			string = StringUtils.remove(string, item);
		}
		
		return string;
	}

	public static JsonElement parseJson(String value) {
		return PARSER.parse(value);
	}

	public static int getDaysOfMonth(LocalDate now) {
		YearMonth ym = YearMonth.of(now.getYear(), now.getMonth());
		return ym.lengthOfMonth();
	}
	
	public static String insertIntoString(String base, String insert, int position) {
		StringBuilder sb = new StringBuilder(base);
		sb.insert(position, insert);
		return sb.toString();
	}

	public static JsonElement parseJson(Object convert, Class<?> from) {
		return PARSER.parse(GSON.toJson(convert, from));
	}

	public static Object toJson(Object source) {
		return GSON.toJson(source);
	}
	
	public static String getTerminationRefererenceId(String branchCode) {
		String refNum = "";
		ZonedDateTime now = ZonedDateTime.now();
		refNum = StringUtils.rightPad(append(AppConstants.MM_DD_YY.format(now), branchCode, String.valueOf(now.toInstant().toEpochMilli())), 24, '0');
		LOGGER.info("Generated termination referenceid = {{}}", refNum);
		return refNum;
	}
	
	
	public static String shuffleString(String string) {
		List<String> alpha = Arrays.asList(string.split(""));
		Collections.shuffle(alpha);
		return alpha.stream().collect(Collectors.joining());
		
	}
	
	public static String maskAccount(String account) {
		String maskAccount = "";
		maskAccount = StringUtils.overlay(account, StringUtils.repeat("X", account.length()-4), 0, account.length()-4);				
		return maskAccount;
	}
	
	public static String[] toStrArray(String str){
		String[] x = StringUtils.split(str, ',');
		return x;
	}

	public static String formatPlacementAmount(String value) {
		return AppConstants.DECIMAL_FORMAT.format(NumberUtils.createBigDecimal(value));
	}

	public static String formatNetCredits(String value) {
		return AppConstants.DECIMAL_FORMAT.format(NumberUtils.createBigDecimal(value));
	}

	public static String formatInterestRate(String rate) {
		return AppConstants.INTEREST_RATE_FORMAT.format(NumberUtils.createBigDecimal(rate));
	}

	public static String prettyJson(String from) {
		return PRETTIFIER.toJson(parseJson(from));
	}

	public static Object prettyJson(JsonElement from) {
		return PRETTIFIER.toJson(from);
	}
}
