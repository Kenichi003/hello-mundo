package ph.com.metrobank.omni.mbs.otd.terminator.constant;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;

import ph.com.metrobank.omni.mbs.common.exception.ValidationException;

public class AppConstants{
	public static final String APPLICATION_JSON_TYPE = "application/json";

	public static final String OTD_PRE_TERM = "OTD_PRE_TERM";
	public static final String PRE_TERM_CODE = "OTD_PRE_TERMINATION_SUCCESS";
	public static final String TERMINATION_CODE = "OTD_TERMINATION_SUCCESS";

	public static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#,###.00");
	public static final DecimalFormat THREE_SIGNIFICANT_NUMBERS_DECIMAL_FORMAT = new DecimalFormat("#,###.000");
	public static final DecimalFormat INTEREST_RATE_FORMAT = new DecimalFormat("###.000");

	public static final DateTimeFormatter MM_DD_YY = DateTimeFormatter.ofPattern("MMddyy");
	public static final DateTimeFormatter MMddyyyy = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	public static final DateTimeFormatter ESB_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	public static final DateTimeFormatter ESB_TIME_FORMATTER = DateTimeFormatter.ofPattern("hh:mm:ss");
	public static final DateTimeFormatter MMMMddyyyy = DateTimeFormatter.ofPattern("MMMM dd, yyyy");
	
	public static final Integer PASSWORD_LENGTH = 8;
	public static final String CURRENT_PATH = System.getProperty("user.dir");
	public static final String MBOS = "MBOS";
	public static final String OTD = "OTD";
	public static final String MBX = "MBX";
	public static final CharSequence SOA_SUCCESS_CODE = "SOA-000";
	public static final CharSequence SAVINGS = "Savings";
	public static final CharSequence IM = "IM";
	public static final String OTDT = "OTDT";
	public static final String OTDP = "OTDP";
	public static final String ENCLOSED_ID_PARAMETER = "{id}";

	public static final String CODE = "code";
	public static final String MESSAGE = "message";

	public static final CharSequence INVALID_SOURCE = "invalid_source";

	public static final String DATA = "data";
	public static final String ZERO = "0";


	public static final String BEARER = "Bearer ";
	public static final String AUTHORIZATION_PARAMETER = "Authorization";
	public static final String ACCEPT_PARAMETER = "accept";
	public static final String CONTENT_TYPE_PARAMETER = "Content-Type";

	public static final String PHP = "Php";
	public static final String TERMINATION_TITLE = "OTD Termination";
	public static final String PRE_TERMINATION_TITLE = "OTD Pre-termination";
	public static final String PESO = "PESO";

	public static final String X_DEVICE_ID = "X-DEVICE-ID";
	public static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
	public static final String OTD_TERMINATOR_SERVICE = "OTD Terminator Service";
	public static final String CHANNEL_INDICATOR = "BS";
	public static final String USD = "Usd";

	public static final CharSequence GOOD_SOA_RESPONSE = "SOA-000";

	public static final ValidationException INVALID_SETTLEMENT_ACCOUNT = new ValidationException("mbs.terminator.settlementaccount.invalid_settlement_account");;
	public static final BigDecimal MONEY_MULTIPLIER = BigDecimal.ONE.divide(BigDecimal.TEN.multiply(BigDecimal.TEN));

	public static final String PERCENT = "%";
	public static final String USD_CODE = "002";
	public static final String PHP_CODE = "001";

	public static final String X_DEVICE = "X-DEVICE";
	public static final String X_OS = "X-OS";

	public static final String TIME_DEPOSIT_ACCOUNT_TYPE = "Time Deposit";

	public static final String SAVINGS_APP_ID = "S";
	public static final String CHECKING_APP_ID = "I";
}
