package ph.com.metrobank.omni.mbs.otd.terminator.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class TimeDepositDetails implements Serializable {

  private static final long serialVersionUID = -6173008769862156094L;
  private BigDecimal currentBalance;
  private BigDecimal availableBalance;
  
  private String maturityDate;
  private Integer term;
  private String period;
  private BigDecimal placementAmount;
  private BigDecimal interestRate;
  private String customerId;

  public BigDecimal getCurrentBalance() {
    return currentBalance;
  }

  public void setCurrentBalance(BigDecimal currentBalance) {
    this.currentBalance = currentBalance;
  }

  public BigDecimal getAvailableBalance() {
    return availableBalance;
  }

  public void setAvailableBalance(BigDecimal availableBalance) {
    this.availableBalance = availableBalance;
  }

  public String getMaturityDate() {
    return maturityDate;
  }

  public void setMaturityDate(String maturityDate) {
    this.maturityDate = maturityDate;
  }

  public Integer getTerm() {
    return term;
  }

  public void setTerm(Integer term) {
    this.term = term;
  }

  public String getPeriod() {
    return period;
  }

  public void setPeriod(String period) {
    this.period = period;
  }

  public BigDecimal getPlacementAmount() {
    return placementAmount;
  }

  public void setPlacementAmount(BigDecimal placementAmount) {
    this.placementAmount = placementAmount;
  }

  public BigDecimal getInterestRate() {
    return interestRate;
  }

  public void setInterestRate(BigDecimal interestRate) {
    this.interestRate = interestRate;
  }

  public String getCustomerId() {
    return customerId;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("{\"currentBalance\":\"");
    builder.append(currentBalance);
    builder.append("\", \"availableBalance\":\"");
    builder.append(availableBalance);
    builder.append("\", \"maturityDate\":\"");
    builder.append(maturityDate);
    builder.append("\", \"term\":\"");
    builder.append(term);
    builder.append("\", \"period\":\"");
    builder.append(period);
    builder.append("\", \"placementAmount\":\"");
    builder.append(placementAmount);
    builder.append("\", \"interestRate\":\"");
    builder.append(interestRate);
    builder.append("\", \"customerId\":\"");
    builder.append(customerId);
    builder.append("\"}");
    return builder.toString();
  }
}
