package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class TimeDepositClosingBalanceResponse extends EsbBaseRequest {
	private TransactionInformation TransactionInformation = new TransactionInformation();
	private InquireTDClosingBalanceOutput InquireTDClosingBalanceOutput = new InquireTDClosingBalanceOutput();
	private WSStatus WSStatus = new WSStatus();
	
	public TransactionInformation getTransactionInformation() {
		return TransactionInformation;
	}

	public void setTransactionInformation(TransactionInformation transactionInformation) {
		this.TransactionInformation = transactionInformation;
	}

	public InquireTDClosingBalanceOutput getInquireTimeDepositClosingBalanceOutput() {
		return InquireTDClosingBalanceOutput;
	}

	public void setInquireTimeDepositClosingBalanceOutput(InquireTDClosingBalanceOutput inquireTimeDepositClosingBalanceOutput) {
		InquireTDClosingBalanceOutput = inquireTimeDepositClosingBalanceOutput;
	}

	public WSStatus getWSStatus() {
		return WSStatus;
	}

	public void setWSStatus(WSStatus wSStatus) {
		WSStatus = wSStatus;
	}
}
