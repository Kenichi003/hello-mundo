package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class TerminationRequest extends EsbBaseRequest {
	private TDClosingInput TDClosingInput = new TDClosingInput();
	private TransactionInformation TransactionInformation = new TransactionInformation();
	
	public TDClosingInput getTDClosingInput() {
		return TDClosingInput;
	}
	public void setTDClosingInput(TDClosingInput tDClosingInput) {
		TDClosingInput = tDClosingInput;
	}
	public TransactionInformation getTransactionInformation() {
		return TransactionInformation;
	}
	public void setTransactionInformation(TransactionInformation transactionInformation) {
		TransactionInformation = transactionInformation;
	}
}
