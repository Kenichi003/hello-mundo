package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class WSStatus {
    private String errorMessage;
    private String SOAResponseCode;
    private String transactionStatus;
    
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getSOAResponseCode() {
		return SOAResponseCode;
	}
	public void setSOAResponseCode(String soaResponseCode) {
		this.SOAResponseCode = soaResponseCode;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

}
