package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class TDClosingInput extends EsbBaseRequest {
	private String sequenceNumber;
	private String servicingBranch;
	private String tdAccountCurrencyCode;
	private String tdAccountBranchCode;
	private String tdAccountNumber;
	private String docStampAmount;
	private String closingAmount;
	private String settlementAccountAppID;
	private String settlementAccountCurrencyCode;
	private String settlementAccountBranchCode;
	private String settlementAccountNumber;
	private String creditAmount;
	private String docStampDebitSTUserTranCode;
	private String closingAmountSTUserTranCode;
	private String creditSTUserTranCode;
	private String channelIndicator;
	private String sourceChannel;
	private String productCode;	
	private String tdClosingType;
	
	public String getSequenceumber() {
		return sequenceNumber;
	}
	public void setSequenceumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getServicingBranch() {
		return servicingBranch;
	}
	public void setServicingBranch(String servicingBranch) {
		this.servicingBranch = servicingBranch;
	}
	public String getTdAccountCurrencyCode() {
		return tdAccountCurrencyCode;
	}
	public void setTdAccountCurrencyCode(String tdAccountCurrencyCode) {
		this.tdAccountCurrencyCode = tdAccountCurrencyCode;
	}
	public String getTdAccountBranchCode() {
		return tdAccountBranchCode;
	}
	public void setTdAccountBranchCode(String tdAccountBranchCode) {
		this.tdAccountBranchCode = tdAccountBranchCode;
	}
	public String getTdAccountNumber() {
		return tdAccountNumber;
	}
	public void setTdAccountNumber(String tdAccountNumber) {
		this.tdAccountNumber = tdAccountNumber;
	}
	public String getDocStampAmount() {
		return docStampAmount;
	}
	public void setDocStampAmount(String docStampAmount) {
		this.docStampAmount = docStampAmount;
	}
	public String getClosingAmount() {
		return closingAmount;
	}
	public void setClosingAmount(String closingAmount) {
		this.closingAmount = closingAmount;
	}
	public String getSettlementAccountAppID() {
		return settlementAccountAppID;
	}
	public void setSettlementAccountAppID(String settlementAccountAppID) {
		this.settlementAccountAppID = settlementAccountAppID;
	}
	public String getSettlementAccountCurrencyCode() {
		return settlementAccountCurrencyCode;
	}
	public void setSettlementAccountCurrencyCode(String settlementAccountCurrencyCode) {
		this.settlementAccountCurrencyCode = settlementAccountCurrencyCode;
	}
	public String getSettlementAccountBranchCode() {
		return settlementAccountBranchCode;
	}
	public void setSettlementAccountBranchCode(String settelementAccountBranchCode) {
		this.settlementAccountBranchCode = settelementAccountBranchCode;
	}
	public String getSettlementAccountNumber() {
		return settlementAccountNumber;
	}
	public void setSettlementAccountNumber(String settlementAccountNumber) {
		this.settlementAccountNumber = settlementAccountNumber;
	}
	public String getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(String creditAmount) {
		this.creditAmount = creditAmount;
	}
	public String getDocStampDebitSTUserTranCode() {
		return docStampDebitSTUserTranCode;
	}
	public void setDocStampDebitSTUserTranCode(String docStampDebitSTUserTranCode) {
		this.docStampDebitSTUserTranCode = docStampDebitSTUserTranCode;
	}
	public String getCreditSTUserTranCode() {
		return creditSTUserTranCode;
	}
	public void setCreditSTUserTranCode(String creditSTUserTranCode) {
		this.creditSTUserTranCode = creditSTUserTranCode;
	}
	public String getChannelIndicator() {
		return channelIndicator;
	}
	public void setChannelIndicator(String channelIndicator) {
		this.channelIndicator = channelIndicator;
	}
	public String getSourceChannel() {
		return sourceChannel;
	}
	public void setSourceChannel(String sourceChannel) {
		this.sourceChannel = sourceChannel;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getTdClosingType() {
		return tdClosingType;
	}
	public void setTdClosingType(String tdClosingType) {
		this.tdClosingType = tdClosingType;
	}
	
	public String getClosingAmountSTUserTranCode() {
		return closingAmountSTUserTranCode;
	}
	public void setClosingAmountSTUserTranCode(String closingAmountSTUserTranCode) {
		this.closingAmountSTUserTranCode = closingAmountSTUserTranCode;
	}

}
