package ph.com.metrobank.omni.mbs.otd.terminator.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import ph.com.metrobank.omni.mbs.common.dto.KafkaMessage;

@Service
public class KafkaSenderService {

  private static final Logger LOGGER = LoggerFactory.getLogger(KafkaSenderService.class);

  @Autowired
  private KafkaTemplate<String, String> kafkaTemplate;

  public void send(KafkaMessage kafkaMessage) throws Exception {
    ObjectMapper mapper = new ObjectMapper();
    String jsonInString = mapper.writeValueAsString(kafkaMessage.getMessage());
    kafkaTemplate.send(kafkaMessage.getTopic(), jsonInString);
    LOGGER.info("Successfully queued kafka message, topic={{}}, payload={{}}",
        kafkaMessage.getTopic(), jsonInString);
  }

  public void send(String topic, Object message) throws Exception {
    KafkaMessage kafkaMessage = KafkaMessage.createInstance(topic, message);
    send(kafkaMessage);
  }
}
