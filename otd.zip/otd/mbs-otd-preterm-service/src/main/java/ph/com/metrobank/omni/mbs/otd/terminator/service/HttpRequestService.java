package ph.com.metrobank.omni.mbs.otd.terminator.service;

import java.io.IOException;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.terminator.factory.HttpClientFactory;
import ph.com.metrobank.omni.mbs.otd.terminator.rest.JsonTypeGet;
import ph.com.metrobank.omni.mbs.otd.terminator.rest.JsonTypePost;
import ph.com.metrobank.omni.mbs.otd.terminator.util.ProcessingUtils;

@Component
public class HttpRequestService {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpRequestService.class);
	
	@Autowired
	private HttpClientFactory factory;
	
	public JsonElement post(String to, String payload) throws IOException {
		LOGGER.info("request:\n{}", ProcessingUtils.prettyJson(payload));
		try(CloseableHttpClient client = factory.createClient()) {
			JsonTypePost post = new JsonTypePost(to, payload);
			CloseableHttpResponse response = client.execute(post);
			String entity = EntityUtils.toString(response.getEntity());
			LOGGER.info("response:\n{}", entity);
			return ProcessingUtils.parseJson(entity);
		}
	}
	
	public JsonElement get(String uri, JsonObject auth) throws IOException {
		LOGGER.info("\nrequest: {}", uri);
		LOGGER.info("access:\n {}", ProcessingUtils.prettyJson(auth));
		
		try(CloseableHttpClient client = factory.createClient()) {
			JsonTypeGet get = new JsonTypeGet(uri, auth);
			CloseableHttpResponse response = client.execute(get);
			String entity = EntityUtils.toString(response.getEntity());
			LOGGER.info("response:\n{}", entity);
			return ProcessingUtils.parseJson(entity);
		}
	}
}
