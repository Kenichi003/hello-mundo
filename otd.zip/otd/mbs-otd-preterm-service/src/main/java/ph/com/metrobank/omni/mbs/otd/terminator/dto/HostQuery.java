package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class HostQuery {

}
