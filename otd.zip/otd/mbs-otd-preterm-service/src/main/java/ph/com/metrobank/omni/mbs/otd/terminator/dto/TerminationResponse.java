package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class TerminationResponse {
	private TDClosingOutput TDClosingOutput = new TDClosingOutput();
	private TransactionInformation TransactionInformation = new TransactionInformation();
	private WSStatus WSStatus = new WSStatus();
	

	public TDClosingOutput getTDClosingOutput() {
		return TDClosingOutput;
	}
	public void setTDClosingOutput(TDClosingOutput tDClosingOutput) {
		TDClosingOutput = tDClosingOutput;
	}
	public TransactionInformation getTransactionInformation() {
		return TransactionInformation;
	}
	public void setTransactionInformation(TransactionInformation transactionInformation) {
		TransactionInformation = transactionInformation;
	}

	public WSStatus getWSStatus() {
		return WSStatus;
	}
	public void setWSStatus(WSStatus wSStatus) {
		WSStatus = wSStatus;
	}
}
