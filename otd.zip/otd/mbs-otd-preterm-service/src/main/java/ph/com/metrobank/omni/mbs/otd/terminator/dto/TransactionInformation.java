package ph.com.metrobank.omni.mbs.otd.terminator.dto;
public class TransactionInformation {
	private String dateStamp;
    private String timeStamp;
    private String sourceProductCode;
    private String sequenceNumber;
    private String servicingBranch;
    private String processingBranch;
    private String channelTransaction;
    private String sourceIdentifier;
	
    public String getDateStamp() {
		return dateStamp;
	}
	public void setDateStamp(String dateStamp) {
		this.dateStamp = dateStamp;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getSourceProductCode() {
		return sourceProductCode;
	}
	public void setSourceProductCode(String sourceProductCode) {
		this.sourceProductCode = sourceProductCode;
	}
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getServicingBranch() {
		return servicingBranch;
	}
	public void setServicingBranch(String servicingBranch) {
		this.servicingBranch = servicingBranch;
	}
	public String getProcessingBranch() {
		return processingBranch;
	}
	public void setProcessingBranch(String processingBranch) {
		this.processingBranch = processingBranch;
	}
	public String getChannelTransaction() {
		return channelTransaction;
	}
	public void setChannelTransaction(String channelTransaction) {
		this.channelTransaction = channelTransaction;
	}
	public String getSourceIdentifier() {
		return sourceIdentifier;
	}
	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}
}