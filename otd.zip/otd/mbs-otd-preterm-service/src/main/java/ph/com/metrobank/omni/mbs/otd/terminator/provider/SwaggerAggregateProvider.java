package ph.com.metrobank.omni.mbs.otd.terminator.provider;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Controller;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

@Controller
@Primary
public class SwaggerAggregateProvider implements SwaggerResourcesProvider {

  @Value("${spring.jersey.application-path}")
  private String basePath;

  @Override
  public List<SwaggerResource> get() {
    ArrayList<SwaggerResource> resources = new ArrayList<SwaggerResource>();

    SwaggerResource dataRestApi = new SwaggerResource();
    dataRestApi.setName("Spring Data Rest Endpoints");
    dataRestApi.setUrl("/v2/api-docs");
    dataRestApi.setLocation("/v2/api-docs");
    dataRestApi.setSwaggerVersion("2.0");

    SwaggerResource mbsJerseyApi = new SwaggerResource();
    mbsJerseyApi.setName("Custom Jersey Endpoints");
    mbsJerseyApi.setUrl(basePath + "/swagger.json");
    mbsJerseyApi.setLocation(basePath + "/swagger.json");
    mbsJerseyApi.setSwaggerVersion("2.0");

    resources.add(mbsJerseyApi);
    resources.add(dataRestApi);

    return resources;
  }
}
