package ph.com.metrobank.omni.mbs.otd.terminator.service;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TerminationSequenceService {
	@PersistenceContext
	@Autowired
	private EntityManager em;
	
	public synchronized String generateNumber() {
		Query q = em.createNativeQuery("select otd_terminator_seq.nextval from dual");
		BigDecimal value = (BigDecimal) q.getSingleResult();
		String toClient = value.toBigInteger().toString();
		return StringUtils.leftPad(toClient, 6, "0");
	}
}
