package ph.com.metrobank.omni.mbs.otd.terminator.dto;

import ph.com.metrobank.omni.mbs.otd.terminator.dto.Credentials;

public class EsbBaseRequest {
	private Credentials Credentials;
	
	public Credentials getCredentials() {
		return Credentials;
	}

	public void setCredentials(Credentials credentials) {
		this.Credentials = credentials;
	}
}
