package ph.com.metrobank.omni.mbs.otd.terminator.dto;

import java.util.Optional;

public class ValidationRequest {
	private String sourceAccountId;
	private String otdAccountId; 
	private String username;
	private Optional<String> authType = Optional.empty();
	private Optional<String> authValue = Optional.empty();
	
	public String getOtdAccountId() {
		return otdAccountId;
	}
	public void setOtdAccountId(String otdAccountId) {
		this.otdAccountId = otdAccountId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Optional<String> getAuthType() {
		return authType;
	}
	public void setAuthType(String authType) {
		this.authType = Optional.ofNullable(authType);
	}
	public Optional<String> getAuthValue() {
		return authValue;
	}
	public void setAuthValue(String authValue) {
		this.authValue = Optional.ofNullable(authValue);
	}
	public String getSourceAccountId() {
		return sourceAccountId;
	}
	public void setSourceAccountId(String sourceAccountId) {
		this.sourceAccountId = sourceAccountId;
	}
	
	
		
	
	
}
