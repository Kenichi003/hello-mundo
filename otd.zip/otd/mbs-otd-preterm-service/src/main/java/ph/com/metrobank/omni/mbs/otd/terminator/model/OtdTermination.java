package ph.com.metrobank.omni.mbs.otd.terminator.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@Entity
@Table(name = "otd_terminations")
@PositionalRecord
public class OtdTermination implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5041691928595184654L;

	@Id
	@SequenceGenerator(name = "otd_termination_id_gen", sequenceName = "otd_termination_id_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "otd_termination_id_gen")
	@Column(unique = true, nullable = false)
	private Long id;
	
	@Column(name = "otd_account_id", unique = true, nullable = false)
	private String otdAccountId;
	
	@Column(name = "customer_id", nullable = false)
	private String customerId;
	
	@Column(name = "inquiry_response")
	private String inquiryResponse;

	@Column()
	private Timestamp created;

	@Column()
	private Timestamp updated;

	@Column(name = "updated_by")
	private String updatedBy;

	public OtdTermination() {
		created = Timestamp.valueOf(LocalDateTime.now());
	}
	
	@PreUpdate
	void preUpdate() {
		updated = Timestamp.valueOf(LocalDateTime.now());
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOtdAccountId() {
		return otdAccountId;
	}

	public void setOtdAccountId(String otdAccountId) {
		this.otdAccountId = otdAccountId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public Timestamp getUpdated() {
		return updated;
	}

	public void setUpdated(Timestamp updated) {
		this.updated = updated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getInquiryResponse() {
		return inquiryResponse;
	}

	public void setInquiryResponse(String inquiryResponse) {
		this.inquiryResponse = inquiryResponse;
	}
}

