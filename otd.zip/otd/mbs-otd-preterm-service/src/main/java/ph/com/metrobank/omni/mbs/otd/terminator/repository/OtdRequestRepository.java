package ph.com.metrobank.omni.mbs.otd.terminator.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.omni.mbs.otd.terminator.model.OtdRequest;

public interface OtdRequestRepository extends JpaRepository<OtdRequest, Long> {
	
	OtdRequest findByOtdAccountId (@Param("otdAccountId") String otdAccountId);
	
}
