package ph.com.metrobank.omni.mbs.otd.terminator.endpoint;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.ValidationRequest;
import ph.com.metrobank.omni.mbs.otd.terminator.service.TerminationSequenceService;
import ph.com.metrobank.omni.mbs.otd.terminator.service.TerminationService;

@Path("/terminator")
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Component
@Api(value = "Pre Termination Endpoints", produces = "application/json")
public class TerminationEndpoint {
	
	@Autowired
	private TerminationService terminationService;

	@Autowired
	private TerminationSequenceService terminationSequenceService;

	@POST
	@Path("/terminate")
	@ApiOperation(value ="Validates submitted customer information.", response = Object.class)	
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Resource found"), 
			@ApiResponse(code = 400, message = "Invalid credentials."),
			@ApiResponse(code = 401, message = "Unauthorized access."),
			@ApiResponse(code = 404, message = "Resource not found")})			
	public Object validate(ValidationRequest request) throws Exception {
		return terminationService.terminate(request); 
	}
	
	@GET
	@Path("/seq")
	@ApiOperation(value ="Generates the next sequence number for OTD terminations.", response = Object.class)	
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Resource found"), 
			@ApiResponse(code = 401, message = "Unauthorized access.")})			
	public Object getSequenceNumber() throws Exception {
		return terminationSequenceService.generateNumber(); 
	}
}
