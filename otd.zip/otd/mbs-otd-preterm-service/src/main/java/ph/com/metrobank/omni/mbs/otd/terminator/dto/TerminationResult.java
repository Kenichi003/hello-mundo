package ph.com.metrobank.omni.mbs.otd.terminator.dto;

public class TerminationResult {
	private String terminationReferenceId;
	private String transactionDate;
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTerminationReferenceId() {
		return terminationReferenceId;
	}
	public void setTerminationReferenceId(String terminationReferenceId) {
		this.terminationReferenceId = terminationReferenceId;
	}
}
