package ph.com.metrobank.omni.mbs.otd.terminator.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.omni.mbs.otd.terminator.model.OtdTermination;

public interface OtdTerminationRepository extends JpaRepository<OtdTermination, Long> {

  @Override
  Optional<OtdTermination> findById(Long id);

  @Query(value = "SELECT * from OTD_TERMINATIONS r where r.created >= :stamp and r.updated is not null", nativeQuery=true)
  List<OtdTermination> findByCreated(@Param("stamp") Date stamp);

  @Query(value = "SELECT * from OTD_TERMINATIONS r where r.updated is not null and r.updated >= :stamp", nativeQuery=true)
  List<OtdTermination> findByUpdated(@Param("stamp") Date stamp);

  void deleteByCreated(@Param("stamp") Date stamp);

  Optional<OtdTermination> findByOtdAccountId(String otdAccountId);
}
