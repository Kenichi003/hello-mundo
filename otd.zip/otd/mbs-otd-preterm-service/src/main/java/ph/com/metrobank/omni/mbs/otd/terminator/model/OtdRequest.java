package ph.com.metrobank.omni.mbs.otd.terminator.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "otd_requests")
public class OtdRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "otd_request_id_gen", sequenceName = "otd_request_id_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "otd_request_id_gen")
	@Column(unique = true, nullable = false)
	private Long id;
	
	
	/*
	@Column(name="otd_account_id", unique = true, nullable=false)      	        
	private String otdAccountId;
	
	@Column(name="currency")
	private String currency;
	
	
	
	@Column(name="customer_id")    
	private String customerId;
	
	@Column(name="branch_code")
	private String branchCode;
	
	@Column(name="account_id")
	private String accountId;
	
	@Column(name="placement_amount")
	private String placement_Amount;
	
	@Column(name="base_rate")
	private String baseRate;
	
	@Column(name="add_on_rate")
	private String addOnRate;
	
	@Column(name="tenor")
	private String tenor;
		
	@Column(name="account_name")
	private String accountName;
	
	@Column(name="depository_branch")
	private String depositoryBranch;
	
	@Column(name="transaction_date")
	private String transactionDate;
	
	@Column(name="maturity_date")
	private String maturityDate;
	
	@Column(name="created")
	private String created;
	
	@Column(name="updated")
	private String updated;
	
	@Column(name="updated_by")
	private String updatedBy;
	
	@Column(name="internal_account_id")
	private String internalAccountId;
	
	
	     
	 
	  

	@Column(name="pre_term_reference_id")
	private String preTermReferenceId;

	

	@Column(name="pre_term_transaction_date")	
	private Timestamp preTermTransactionDate;
	
	
	@Column(name="pre_term_flag")
	private boolean preTermFlag;
	
	*/
	                   
	@Column(name="reference_id")
	private String referenceId;

	@Column(name="customer_id")                
	private String customerId;

	@Column(name="cif")                        
	private String cif;

	@Column(name="currency_code")              
	private String currencyCode;

	@Column(name="branch_code")                
	private String branchCode;

	@Column(name="account_id")                 
	private String accountId;

	@Column(name="product_type")               
	private String productType;

	@Column(name="placement_amount")
	private String placementAmount;
	           
	@Column(name="base_rate")                  
	private String baseRate;

	@Column(name="add_on_rate")                
	private String addOnRate;

	@Column(name="term")                       
	private String term;

	@Column(name="tenor")                      
	private String tenor;

	@Column(name="rollover_instruction")       
	private String rolloverInstruction;

	@Column(name="tax_flag")                   
	private String taxFlag;

	@Column(name="opening_status_flag")        
	private String openingStatusFlag;

	@Column(name="remarks")                    
	private String remarks;

	@Column(name="account_name")               
	private String accountName;

	@Column(name="confirmation_advice_number") 
	private String confirmationAdviceNumber;

	@Column(name="depository_branch")          
	private String depositoryBranch;

	@Column(name="otd_account_id")             
	private String otdAccountId;

	@Column(name="currency")                   
	private String currency;

	@Column(name="transaction_date")           
	private Timestamp transactionDate;

	@Column(name="maturity_date")              
	private Timestamp maturityDate;

	@Column(name="created")                    
	private Timestamp created;

	@Column(name="updated")                    
	private Timestamp updated;

	@Column(name="updated_by")                 
	private String updatedBy;

	@Column(name="internal_account_id")        
	private String internalAccountId;

	@Column(name="termination_reference_id")      
	private String terminationReferenceId;

	@Column(name="termination_transaction_date")  
	private Timestamp terminationTransactionDate;

	@Column(name="terminated")              
	private boolean terminated;

	@Column(name="account_type")              
	private String accountType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getPlacementAmount() {
		return placementAmount;
	}

	public void setPlacementAmount(String placementAmount) {
		this.placementAmount = placementAmount;
	}

	public String getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(String baseRate) {
		this.baseRate = baseRate;
	}

	public String getAddOnRate() {
		return addOnRate;
	}

	public void setAddOnRate(String addOnRate) {
		this.addOnRate = addOnRate;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getTenor() {
		return tenor;
	}

	public void setTenor(String tenor) {
		this.tenor = tenor;
	}

	public String getRolloverInstruction() {
		return rolloverInstruction;
	}

	public void setRolloverInstruction(String rolloverInstruction) {
		this.rolloverInstruction = rolloverInstruction;
	}

	public String getTaxFlag() {
		return taxFlag;
	}

	public void setTaxFlag(String taxFlag) {
		this.taxFlag = taxFlag;
	}

	public String getOpeningStatusFlag() {
		return openingStatusFlag;
	}

	public void setOpeningStatusFlag(String openingStatusFlag) {
		this.openingStatusFlag = openingStatusFlag;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getConfirmationAdviceNumber() {
		return confirmationAdviceNumber;
	}

	public void setConfirmationAdviceNumber(String confirmationAdviceNumber) {
		this.confirmationAdviceNumber = confirmationAdviceNumber;
	}

	public String getDepositoryBranch() {
		return depositoryBranch;
	}

	public void setDepositoryBranch(String depositoryBranch) {
		this.depositoryBranch = depositoryBranch;
	}

	public String getOtdAccountId() {
		return otdAccountId;
	}

	public void setOtdAccountId(String otdAccountId) {
		this.otdAccountId = otdAccountId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Timestamp getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Timestamp transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Timestamp getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Timestamp maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public Timestamp getUpdated() {
		return updated;
	}

	public void setUpdated(Timestamp updated) {
		this.updated = updated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getInternalAccountId() {
		return internalAccountId;
	}

	public void setInternalAccountId(String internalAccountId) {
		this.internalAccountId = internalAccountId;
	}

	public String getTerminationReferenceId() {
		return terminationReferenceId;
	}

	public void setTerminationReferenceId(String terminationReferenceId) {
		this.terminationReferenceId = terminationReferenceId;
	}

	public Timestamp getTerminationTransactionDate() {
		return terminationTransactionDate;
	}

	public void setTerminationTransactionDate(Timestamp terminationTransactionDate) {
		this.terminationTransactionDate = terminationTransactionDate;
	}

	public boolean terminated() {
		return terminated;
	}

	public void setTerminated(boolean terminated) {
		this.terminated = terminated;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountType() {
		return accountType;
	}
}