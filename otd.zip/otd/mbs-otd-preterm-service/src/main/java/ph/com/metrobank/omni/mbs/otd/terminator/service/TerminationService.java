package ph.com.metrobank.omni.mbs.otd.terminator.service;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

import javax.ws.rs.ServerErrorException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import ph.com.metrobank.omni.mbs.common.dto.casa.CasaBalanceDto;
import ph.com.metrobank.omni.mbs.common.dto.casa.CasaDto;
import ph.com.metrobank.omni.mbs.common.dto.customer.ValidatePinRequest;
import ph.com.metrobank.omni.mbs.common.exception.ValidationException;
import ph.com.metrobank.omni.mbs.common.services.RestTemplateService;
import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TerminationResponse;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.TerminationResult;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.ValidationRequest;
import ph.com.metrobank.omni.mbs.otd.terminator.dto.WSStatus;
import ph.com.metrobank.omni.mbs.otd.terminator.model.OtdRequest;
import ph.com.metrobank.omni.mbs.otd.terminator.repository.OtdRequestRepository;
import ph.com.metrobank.omni.mbs.otd.terminator.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.terminator.util.ProcessingUtils;

@Service
public class TerminationService extends AbstractEnd {

	private static final Logger LOGGER = LoggerFactory.getLogger(TerminationService.class);
	private static final String TRANSACTION = "TIME_DEPOSIT_PRETERMINATION";

	@Value("${mbs.mpin.url}")
	private String mpinValidationUrl;

	@Value("${mbs.esb.otdtermination.url}")
	private String terminationUri;

	@Value("${mbs.casa.balance.url}")
	private String casaAccountBalanceUri;

	@Value("${mbs.casa.details.url}")
	private String casaDetailsUri;

	@Autowired
	private RestTemplateService restTemplateService;

	@Autowired
	private TerminationSenderService senderService;

	@Autowired
	private EsbClient esbClient;

	@Autowired
	private OtdRequestRepository otdRepo;

	public Object terminate(ValidationRequest request) throws Exception {
		OtdRequest oldOtd = otdRepo.findByOtdAccountId(request.getOtdAccountId());		
		if(oldOtd == null) {
			throw new ResourceNotFoundException();
		}

		if(request.getAuthType().isPresent() && request.getAuthValue().isPresent()) {
			validateMPIN(request);
			OtdRequest newOtd = null;
			TerminationResult toClient = new TerminationResult();
			try {
				TerminationResponse result = terminate(oldOtd);
				WSStatus status = result.getWSStatus();
				if(StringUtils.equals(status.getSOAResponseCode(), AppConstants.GOOD_SOA_RESPONSE) && StringUtils.equals(status.getTransactionStatus(), AppConstants.ZERO)) {
					String otdAccountId = oldOtd.getOtdAccountId();
					newOtd = updateTerminationRequest(oldOtd);
					CasaDto casa = getCasaByOtdAccountId(otdAccountId);
					senderService.send(newOtd, casa);
					toClient.setTerminationReferenceId(newOtd.getTerminationReferenceId());
					toClient.setTransactionDate(newOtd.getTerminationTransactionDate().toLocalDateTime().format(AppConstants.MMMMddyyyy));
				} else {
					throw new ServerErrorException("Transaction failed with host response.", 500);	
				}
			} catch (SQLException e1) {
				LOGGER.error("Error on updating otd_request table = {{}}", e1.getMessage());
				throw new ResourceNotFoundException();
			}

			return toClient;
			
		} else {
			boolean triggeredInactiveSettlementAccountPath = false;
			String internalAccountId = request.getSourceAccountId();
			if(StringUtils.isBlank(internalAccountId)) {
				internalAccountId = oldOtd.getInternalAccountId();
			} else {
				triggeredInactiveSettlementAccountPath = true;
			}
			
			CasaBalanceDto casaResponse = getSettlementAccountByAccountId(internalAccountId);
			CasaDto depositAccount = casaResponse.getDepositAccount();
			
			if(!casaResponse.getActive()) {
				LOGGER.info("{}: This settlement account is inactive.", internalAccountId);
				throw AppConstants.INVALID_SETTLEMENT_ACCOUNT;
			}			
	
			if(triggeredInactiveSettlementAccountPath) {
				//updating records to point to the actual settlement account credited.
				String settlementAccountId = depositAccount.getAccountNo();
				String accountId = StringUtils.substring(settlementAccountId, 3);
				oldOtd.setBranchCode(StringUtils.substring(settlementAccountId, 0, 3));
				oldOtd.setAccountId(accountId);
				oldOtd.setInternalAccountId(internalAccountId);
				oldOtd.setAccountType(StringUtils.equalsIgnoreCase(depositAccount.getAccountType(), AppConstants.SAVINGS) ? AppConstants.SAVINGS_APP_ID : AppConstants.CHECKING_APP_ID);
				otdRepo.saveAndFlush(oldOtd);
				LOGGER.info("Previously set settlement account is inactive. New settlement account ID for OTD {} is {}.", oldOtd.getOtdAccountId(), accountId);
			} else {
				//update pre-Release 4 records that do not have this information. 
				//No easier way right now, unfortunately, not even a stored procedure (ENUM-based information in CasaAccountType).
				//We'd need a table to store equivalent info to make a stored procedure work.
				if(StringUtils.isBlank(oldOtd.getAccountType())) {
					//TODO: will there be more types in the future?
					oldOtd.setAccountType(StringUtils.equalsIgnoreCase(depositAccount.getAccountType(), AppConstants.SAVINGS) ? AppConstants.SAVINGS_APP_ID : AppConstants.CHECKING_APP_ID);
					otdRepo.saveAndFlush(oldOtd);
				}
			}
			
			validateMPIN(request);
		}

		return StringUtils.EMPTY;
	}

	private CasaDto getCasaByOtdAccountId(String otdAccountId) {
		String uri = ProcessingUtils.append(casaDetailsUri, otdAccountId);
		LOGGER.info("casa details uri: {}", uri);
		CasaDto response = restTemplateService.getForObject(uri, CasaDto.class);
		LOGGER.info("casa response: {}", ProcessingUtils.toJson(response, CasaDto.class));
		return response;
	}

	private CasaBalanceDto getSettlementAccountByAccountId(String accountId) throws Exception {
		String uri = StringUtils.replace(casaAccountBalanceUri, AppConstants.ENCLOSED_ID_PARAMETER, accountId);
		LOGGER.info("casa balance uri: {}", uri);
		CasaBalanceDto response = restTemplateService.getForObject(uri, CasaBalanceDto.class);
		LOGGER.info("casa balance response: {}", ProcessingUtils.toJson(response, CasaBalanceDto.class));
		return response;
	}


	private OtdRequest updateTerminationRequest(OtdRequest request) throws SQLException {
		OtdRequest otd = request;
		otd.setTerminationReferenceId(ProcessingUtils.getTerminationRefererenceId(otd.getBranchCode()));
		otd.setTerminationTransactionDate(Timestamp.valueOf(LocalDateTime.now()));
		otd.setTerminated(true);
		OtdRequest newOTD = otdRepo.saveAndFlush(otd);
		return newOTD;
	}

	public Object validateMPIN(ValidationRequest request) {
		ValidatePinRequest mpinRequest = new ValidatePinRequest();
		mpinRequest.setUsername(request.getUsername());
		mpinRequest.setTransaction(TRANSACTION);

		Optional<String> authCheck = request.getAuthValue();
		if(authCheck.isPresent()) {
			mpinRequest.setMpin(authCheck.get());
		}

		try {
			return restTemplateService.postForObject(mpinValidationUrl, mpinRequest);
		} catch (ValidationException ve) {
			throw ve;
		}

	}

	private TerminationResponse terminate(OtdRequest otd) throws IOException {
		return esbClient.terminateTimeDeposit(otd, extractAccessObject());
	}
}
