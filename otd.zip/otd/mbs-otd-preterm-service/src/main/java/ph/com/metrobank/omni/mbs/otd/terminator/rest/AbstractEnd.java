package ph.com.metrobank.omni.mbs.otd.terminator.rest;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.terminator.constant.AppConstants;

public abstract class AbstractEnd {
	@Autowired
	protected Environment env;
	
	protected JsonObject extractAccessObject() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		JsonObject accessObject = new JsonObject();
		accessObject.addProperty(AppConstants.AUTHORIZATION_PARAMETER, request.getHeader(AppConstants.AUTHORIZATION_PARAMETER));
		accessObject.addProperty(AppConstants.X_DEVICE_ID, request.getHeader(AppConstants.X_DEVICE_ID));
		accessObject.addProperty(AppConstants.X_FORWARDED_FOR, request.getHeader(AppConstants.X_FORWARDED_FOR));
		accessObject.addProperty(AppConstants.X_DEVICE , request.getHeader(AppConstants.X_DEVICE));
		accessObject.addProperty(AppConstants.X_OS , request.getHeader(AppConstants.X_OS));
		return accessObject;
	}

}
