package ph.com.metrobank.omni.mbs.otd.core.dto;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;

public class MaturationNotification extends NotificationTemplateDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1598766264271338229L;
	public MaturationNotification() {
		super();
		title = AppConstants.OTD_MATURATION_NOTIFICATION_TITLE;
		payload.setType(AppConstants.OTD_MATURITY_TEMPLATE_KEY);
	}
}
