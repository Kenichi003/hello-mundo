package ph.com.metrobank.omni.mbs.otd.core.reader;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.dto.FrontRateTier;
import ph.com.metrobank.omni.mbs.otd.core.dto.RatePeriod;
import ph.com.metrobank.omni.mbs.otd.core.dto.RateTier;
import ph.com.metrobank.omni.mbs.otd.core.service.OtdDataService;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;

@Component
public class OtdRatesFileReader {
	private static final Logger LOGGER = LoggerFactory.getLogger(OtdRatesFileReader.class);

	@Autowired
	private Environment env;

	@Autowired
	private OtdDataService otdData;

	private BigDecimal addOnRate;
	
	private Path backupPath;

	private FlatFileReaderDefinition ffDefinition;

	private Short yearDivision;
	private Short februaryOneMonthPeriodIndex;
	
	@PostConstruct
	private void initialize() throws FFPojoException, IOException {
		Path dropFolder = Paths.get(env.getProperty("path.dropFolder"));
		
		if(Files.exists(dropFolder)) {
			Path actualSource = dropFolder.resolve(env.getProperty("path.hostRatesFile"));
			if(Files.exists(actualSource)) {
				backupPath = actualSource;
			} else {
				backupPath = Paths.get(AppConstants.RELATIVE_PATH_BASE, env.getProperty("path.resources"), env.getProperty("path.hostRatesFile"));
			}
		} else {
			backupPath = Paths.get(AppConstants.RELATIVE_PATH_BASE, env.getProperty("path.resources"), env.getProperty("path.hostRatesFile"));
		}
		
		ffDefinition = new FlatFileReaderDefinition(DetailRecord.class);
		ffDefinition.setHeader(Header.class);
		ffDefinition.setTrailer(Trailer.class);
		yearDivision = Short.valueOf(env.getProperty("value.yearDivision"));
		februaryOneMonthPeriodIndex = Short.valueOf(env.getProperty("value.februaryOneMonthPeriodIndex"));
		addOnRate = NumberUtils.createBigDecimal(env.getProperty("value.addOnRate"));
		processRates(backupPath);
	}

	@PositionalRecord
	public static class Header {

		private String indicator;
		private String prefix;
		private String name;
		private String dateTime;

		@PositionalField(initialPosition = 1, finalPosition = 1)
		public String getIndicator() {
			return indicator;
		}

		public void setIndicator(String indicator) {
			this.indicator = indicator;
		}

		@PositionalField(initialPosition = 2, finalPosition = 4)
		public String getPrefix() {
			return prefix;
		}

		public void setPrefix(String prefix) {
			this.prefix = prefix;
		}

		@PositionalField(initialPosition = 5, finalPosition = 35)
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		@PositionalField(initialPosition = 36, finalPosition = 63)
		public String getDateTime() {
			return dateTime;
		}

		public void setDateTime(String dateTime) {
			this.dateTime = dateTime;
		}
	}

	@PositionalRecord
	public static class DetailRecord {

		private String indicator;
		private String placementFrom;
		private String placementTo;
		private String termFrom;
		private String termTo;
		private String termType;
		private String interestRate;

		@PositionalField(initialPosition = 1, finalPosition = 1)
		public String getIndicator() {
			return indicator;
		}

		public void setIndicator(String indicator) {
			this.indicator = indicator;
		}

		@PositionalField(initialPosition = 2, finalPosition = 16)
		public String getPlacementFrom() {
			return placementFrom;
		}

		public void setPlacementFrom(String placementFrom) {
			this.placementFrom = placementFrom;
		}

		@PositionalField(initialPosition = 17, finalPosition = 31)
		public String getPlacementTo() {
			return placementTo;
		}

		public void setPlacementTo(String placementTo) {
			this.placementTo = placementTo;
		}


		@PositionalField(initialPosition = 32, finalPosition = 34)
		public String getTermFrom() {
			return termFrom;
		}

		public void setTermFrom(String termFrom) {
			this.termFrom = termFrom;
		}

		@PositionalField(initialPosition = 35, finalPosition = 37)
		public String getTermTo() {
			return termTo;

		}

		public void setTermTo(String termTo) {
			this.termTo = termTo;
		}

		@PositionalField(initialPosition = 38, finalPosition = 38)
		public String getTermType() {
			return termType;
		}

		public void setTermType(String termType) {
			this.termType = termType;
		}

		@PositionalField(initialPosition = 39, finalPosition = 46)
		public String getInterestRate() {
			return interestRate;
		}

		public void setInterestRate(String rate) {
			interestRate = rate;
		}

	}

	@PositionalRecord
	public static class Trailer {

		private String indicator;
		private String notes;

		@PositionalField(initialPosition = 1, finalPosition = 1)
		public String getIndicator() {
			return indicator;
		}

		@PositionalField(initialPosition = 2, finalPosition = 225)
		public String getNotes() {
			return notes;
		}

		public void setIndicator(String indicator) {
			this.indicator = indicator;
		}

		public void setNotes(String notes) {
			this.notes = notes;
		}
	}

	public void processRates(Path fromPath) throws IOException, FFPojoException {
		LOGGER.info("Rates path: {}", fromPath.toString());
		
		if (Files.exists(fromPath)) {
			FlatFileReader ffReader = null;
			try {
				File inputFile = fromPath.toFile();
				ffDefinition.setHeader(Header.class);
				ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
				DetailRecord rate = null;
				RateTier tier = new RateTier();
				FrontRateTier frontTier = new FrontRateTier();

				String[] tierNames = otdData.getTierNames();
				int tierNameCount = tierNames.length;
				int tierNameCounter = 0;
				String[] periodNames = otdData.getPeriodNames();
				int periodNameCount = periodNames.length;
				short periodNameCounter = 0;
				int periodCounter = 0;

				Map<String, RateTier> newTierMap = new LinkedHashMap<>();
				List<FrontRateTier> newTierList = new ArrayList<>();

				HashMap<String, Integer> monthStart = new HashMap<>();
				monthStart.put(periodNames[0], 1);
				monthStart.put(periodNames[1], 2);
				monthStart.put(periodNames[2], 6);

				HashMap<String, Integer> monthEnd = new HashMap<>();
				monthEnd.put(periodNames[0], 1);
				monthEnd.put(periodNames[1], 5);
				monthEnd.put(periodNames[2], 12);

				for (Object record : ffReader) {
					if(record instanceof DetailRecord) {
						rate = (DetailRecord) record;
						BigDecimal check = BigDecimal.ZERO;

						try {
							check = NumberUtils.createBigDecimal(rate.getInterestRate());
						} catch(Exception e) {
							LOGGER.error("Error during rates files processing:", e);
							continue;
						}

						String computedRate = AppConstants.THREE_DECIMAL_FORMATTER.format(check.add(addOnRate));
						String fromString = rate.getTermFrom();
						String toString = rate.getTermTo();
						String periodName = periodNames[periodNameCounter];
						RatePeriod period = new RatePeriod();
						Short from = Short.valueOf(fromString);
						Short to = Short.valueOf(toString);
						period.setId(periodName);
						period.setStart(from);
						period.setEnd(to);
						period.setRate(computedRate);
						period.setMonthStart(monthStart.get(period.getId()).shortValue());
						period.setMonthEnd(monthEnd.get(period.getId()).shortValue());
						tier.addPeriod(period);

						Month currentMonth = LocalDate.now().getMonth();
						if(currentMonth.equals(Month.FEBRUARY)) {
							//This to take the rate that falls within the 29-day period, to be the 1-month rate for February, 
							//instead of the usual rate found under the 30-59-day range
							if(periodCounter >= februaryOneMonthPeriodIndex && periodCounter != februaryOneMonthPeriodIndex + 1) {
								frontTier.addPeriod(period);
								periodNameCounter += 1;
								LOGGER.info("{} rate for the {} period: Using the value from days {} - {} = {}.", currentMonth.toString(), periodName, fromString, toString, computedRate);
							} 
						} else {
							if(periodCounter > februaryOneMonthPeriodIndex) {
								frontTier.addPeriod(period);
								periodNameCounter += 1;
								LOGGER.info("{} rate for the {} period: Using the value from days {} - {} = {}.", currentMonth.toString(), periodName, fromString, toString, computedRate);
							} 
						}

						periodCounter += 1;
						if(periodCounter == yearDivision) {
							periodCounter = 0;
						}

						if(periodNameCounter > periodNameCount - 1) {
							String tierId = tierNames[tierNameCounter];
							LOGGER.info("Those are the rates for the {} deposit range (Add-on rate + Base rate).", tierId);
							String[] minMaxSplit = StringUtils.split(tierId, AppConstants.SPACED_DASH);
							
							tier.setMin(NumberUtils.createBigDecimal(StringUtils.trim(StringUtils.remove(minMaxSplit[0], AppConstants.COMMA))));
							tier.setMax(NumberUtils.createBigDecimal(StringUtils.trim(StringUtils.remove(minMaxSplit[1], AppConstants.COMMA))));
							tier.setId(tierId);
							frontTier.setId(tierId);

							newTierMap.put(tierId, tier);
							newTierList.add(frontTier);
							tier = new RateTier();
							frontTier = new FrontRateTier();

							periodNameCounter = 0;
							tierNameCounter += 1;
							if(tierNameCounter > tierNameCount - 1) {
								break;
							}
						}
					}
				}

				String toJson = ProcessingUtils.toJson(newTierList, List.class);
				LOGGER.info("Displayed rates: {}", toJson);
				otdData.setDisplayRates(ProcessingUtils.parseJson(toJson));
				toJson = ProcessingUtils.toJson(newTierMap, Map.class);
				LOGGER.info("Mapped rates: {}", toJson);
				otdData.setTrueRatesMap(newTierMap);
				if(!fromPath.equals(fromPath)) {
					Files.copy(fromPath, backupPath, StandardCopyOption.REPLACE_EXISTING);
				}
			} finally {
				if(ffReader != null)
					ffReader.close();
			}
		}
	}
}