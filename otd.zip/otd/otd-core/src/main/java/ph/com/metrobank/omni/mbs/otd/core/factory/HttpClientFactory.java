package ph.com.metrobank.omni.mbs.otd.core.factory;

import java.security.cert.X509Certificate;

import javax.annotation.PostConstruct;
import javax.net.ssl.SSLContext;

import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.nio.conn.NoopIOSessionStrategy;
import org.apache.http.nio.conn.SchemeIOSessionStrategy;
import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.stereotype.Component;

@Component
public class HttpClientFactory {
	private static SSLContext asyncSslContext;
	
	private static SSLConnectionSocketFactory sslFactory;

	private Registry<ConnectionSocketFactory> socketFactoryRegistry;

	private Registry<SchemeIOSessionStrategy> getSSLRegistryAsync(SSLContext sslContext) {
		return RegistryBuilder.<SchemeIOSessionStrategy> create()
				.register("http", NoopIOSessionStrategy.INSTANCE)
				.register("https", new SSLIOSessionStrategy(sslContext, NoopHostnameVerifier.INSTANCE))
				.build();

	}

	private SSLContext getSSLContext() throws Exception {
		final TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
			final SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
					.loadTrustMaterial(null, acceptingTrustStrategy)
					.build();
			sslContext.getServerSessionContext().setSessionCacheSize(1000);
			return sslContext;
	}

	@PostConstruct
	public void initialize() throws Exception {
		asyncSslContext = getSSLContext();

        final SSLContextBuilder builder = new SSLContextBuilder();
        builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
        final SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build());
        socketFactoryRegistry = RegistryBuilder
                .<ConnectionSocketFactory>create().register("https", sslsf)
                .register("http", new PlainConnectionSocketFactory())
                .build();
	}

	public CloseableHttpClient createClient() throws IOReactorException {
		return HttpClients.custom()
				.setDefaultRequestConfig(
						RequestConfig.custom()
						.setCookieSpec(CookieSpecs.STANDARD)
						.build())
				.setConnectionManagerShared(true).
				setConnectionManager(this.getPoolingHttpClientConnectionManager()).
				setSSLSocketFactory(sslFactory)
				.build();
	}

	public CloseableHttpAsyncClient createAsyncClient() throws IOReactorException {
		CloseableHttpAsyncClient client = HttpAsyncClients.custom()
				.setDefaultRequestConfig(
						RequestConfig.custom()
						.setCookieSpec(CookieSpecs.STANDARD)
						.build())
				.setConnectionManager(getPoolingNHttpClientConnectionManager(asyncSslContext, 200, 200))
				.build();
		client.start();
		return client;
	}

	private PoolingNHttpClientConnectionManager getPoolingNHttpClientConnectionManager(SSLContext sslContext, int connectionPoolMax, int connectionPoolMaxPerRoute) throws IOReactorException {
			PoolingNHttpClientConnectionManager connectionManager =
					new PoolingNHttpClientConnectionManager(new DefaultConnectingIOReactor(IOReactorConfig.DEFAULT), getSSLRegistryAsync(sslContext));
			connectionManager.setMaxTotal(connectionPoolMax);
			connectionManager.setDefaultMaxPerRoute(connectionPoolMaxPerRoute);
			return connectionManager;
	}
	
	private PoolingHttpClientConnectionManager getPoolingHttpClientConnectionManager() throws IOReactorException {
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
		connectionManager.setMaxTotal(200);
		connectionManager.setDefaultMaxPerRoute(200);
		return connectionManager;
}
}
