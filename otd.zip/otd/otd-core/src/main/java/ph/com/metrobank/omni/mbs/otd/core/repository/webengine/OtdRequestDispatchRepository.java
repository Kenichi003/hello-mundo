package ph.com.metrobank.omni.mbs.otd.core.repository.webengine;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.omni.mbs.otd.core.model.OtdRequest;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdRequestDispatch;

public interface OtdRequestDispatchRepository extends JpaRepository<OtdRequestDispatch, Long> {

  @Override
  Optional<OtdRequestDispatch> findById(Long id);

  @Query(value = "SELECT * from OTD_REQUEST_DISPATCH_LOG r where r.created = :stamp", nativeQuery=true)
  List<OtdRequest> findByCreated(@Param("stamp") Date stamp);

//  @Query(value = "SELECT * from OTD_REQUEST_DISPATCH_LOG r where r.updated = :stamp", nativeQuery=true)
//  List<OtdRequest> findByUpdated(@Param("stamp") Date stamp);

//  @Query(value = "DELETE from OTD_REQUEST_DISPATCH_LOG r where r.created = :stamp")
  void deleteByCreated(@Param("stamp") Date stamp);
  
//  @Query(value = "DELETE from OTD_REQUEST_DISPATCH_LOG r where r.updated = :stamp")
//  void deleteByUpdated(@Param("stamp") Date stamp);
}
