package ph.com.metrobank.omni.mbs.otd.core.repository.webengine;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import ph.com.metrobank.omni.mbs.otd.core.model.NotificationTemplate;

public interface NotificationTemplateRepository extends JpaRepository<NotificationTemplate, Long> {

  @Override
  Optional<NotificationTemplate> findById(Long id);

  Optional<NotificationTemplate> findByCode(String code);
}
