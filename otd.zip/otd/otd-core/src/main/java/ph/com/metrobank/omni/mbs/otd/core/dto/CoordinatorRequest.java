package ph.com.metrobank.omni.mbs.otd.core.dto;

public class CoordinatorRequest {
	private String request;

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}
}
