package ph.com.metrobank.omni.mbs.otd.core.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.EnumSet;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.dto.Customer;

@Component
public class ProcessingUtils {
	public static final Gson GSON;
	public static final JsonParser PARSER = new JsonParser(); 
	private static final ObjectMapper MAPPER = new ObjectMapper();
	private static Gson PRETTIFIER;
	private static EnumSet<DayOfWeek> WEEKENDS = EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);

	static {
		GSON = new GsonBuilder().disableHtmlEscaping().create();
		PRETTIFIER = new GsonBuilder().setPrettyPrinting().create();
	}
	
	public static String append(String...strings) {
		StringBuilder sb = new StringBuilder();
		for(String string : strings) {
			sb.append(string);
		}

		return sb.toString();
	}

	public static boolean isJson(String value) { 
		if(!StringUtils.isBlank(value)) {
			try {
				MAPPER.readTree(value);
				return true;
			} catch (IOException e) {
				return false;
			}
		}
		
		return false;
	}
	
	public static void writeToFile(String path, String json) throws IOException {
		try (PrintWriter writer = new PrintWriter(new FileWriter(path.toString()))) {
			writer.write(json.toString());
		}		
	}

	public static String getStackTrace(Throwable t) {
		StackTraceElement[] elements = t.getStackTrace();
		StringBuilder sb = new StringBuilder();
		sb.append(AppConstants.NEXT_LINE_PARAMETER).append(t.getMessage());
		for(StackTraceElement element : elements) {
			sb.append(AppConstants.NEXT_LINE_PARAMETER).append(AppConstants.INDENT).append(element.toString());
		}

		return sb.toString();
	}

	public static Object toJson(Object source) {
		return GSON.toJson(source);
	}
	
	public static <T> String toJson(Object convert, Class<T> from) {
		return GSON.toJson(convert, from);
	}
	
	public static <T> String toPrettyJson(Object convert, Class<T> from) {
		return prettify(toJson(convert, from));
	}
	
	public static Object fromJson(JsonElement convert, Class<?> to) {
		return GSON.fromJson(convert, to);
	}

	public static JsonElement toJson(String value) {
		return PARSER.parse(value);
	}

	public static LocalDateTime toLocalDateTime(LocalDate date) {
		return LocalDateTime.of(date, LocalTime.now());
	}

	public static String remove(String string, String... remove) {
		for(String item : remove) {
			string = StringUtils.remove(string, item);
		}
		
		return string;
	}

	public static JsonElement parseJson(String value) {
		return PARSER.parse(value);
	}

	public static int getDaysOfMonth(LocalDate now) {
		YearMonth ym = YearMonth.of(now.getYear(), now.getMonth());
		return ym.lengthOfMonth();
	}
	
	public static String insertIntoString(String base, String insert, int position) {
		StringBuilder sb = new StringBuilder(base);
		sb.insert(position, insert);
		return sb.toString();
	}

	//TODO: externalize
	private static final String[] SURNAME_CHECK = new String[] {"de ", "dela ", "de la ", "de los "};
	public static String normalizeFullName(Customer customer) {
		String middleCheck = customer.getMiddleName();
		return append(StringUtils.capitalize(StringUtils.lowerCase(StringUtils.trim(customer.getFirstName()))), AppConstants.SPACE, 
				StringUtils.isBlank(middleCheck) || middleCheck == null ? "" : StringUtils.capitalize(StringUtils.lowerCase(StringUtils.trim(customer.getMiddleName()))), AppConstants.SPACE, 
						normalizeLastName(customer.getLastName()));
	}
	
	private static String normalizeLastName(String surName) {
		surName = StringUtils.lowerCase(StringUtils.trim(surName));

		if(!StringUtils.startsWithAny(surName, SURNAME_CHECK)) {
			surName = StringUtils.capitalize(surName);
		} else {
			int length = SURNAME_CHECK.length;
			for(int i = 0; i < length; i++) {
				String check = SURNAME_CHECK[i];
				if(StringUtils.startsWith(surName, check)) {
					surName = StringUtils.capitalize(StringUtils.removeStart(surName, check));
					surName = append(check, surName);
					break;
				}
			}
		}
		
		return surName;
	}

	public static String normalizeName(Customer customer) {
		return append(StringUtils.capitalize(StringUtils.lowerCase(StringUtils.trim(customer.getFirstName()))), AppConstants.SPACE,	normalizeLastName(customer.getLastName()));
	}

	public static String prettify(String string) {
		return PRETTIFIER.toJson(PARSER.parse(string));
	}

	public static DayOfWeek getDayOfWeek() {
		LocalDate today = LocalDate.now(ZoneId.systemDefault());
		return today.getDayOfWeek();
	
	}

	public static boolean checkWeekday() {
		return !WEEKENDS.contains(getDayOfWeek());
	}
	
	public static boolean checkWeekend() {
		return WEEKENDS.contains(getDayOfWeek());
	}
}
