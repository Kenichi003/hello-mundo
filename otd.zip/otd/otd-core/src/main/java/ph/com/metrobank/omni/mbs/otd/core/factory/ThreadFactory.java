package ph.com.metrobank.omni.mbs.otd.core.factory;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;

import org.apache.http.HttpResponse;

import ph.com.metrobank.omni.mbs.otd.core.rest.GetCall;
import ph.com.metrobank.omni.mbs.otd.core.rest.PostCall;

public class ThreadFactory {
	public static final ExecutorService POOL = Executors.newFixedThreadPool(10, Executors.defaultThreadFactory());

	@PostConstruct
	public void initialize() {
		Runtime.getRuntime().addShutdownHook(new Thread(() -> POOL.shutdown()));
	}

	public static void invokeGets(List<GetCall> calls) throws InterruptedException {
		POOL.invokeAll(calls);
	}

	public static void invokePosts(List<PostCall> calls) throws InterruptedException {
		POOL.invokeAll(calls);
	}

	public static HttpResponse postForResponse(Callable<HttpResponse> post) throws InterruptedException, ExecutionException {
		return POOL.submit(post).get();
	}
}
