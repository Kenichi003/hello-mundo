package ph.com.metrobank.omni.mbs.otd.core.dto;

public class AccountInformationRequest extends EsbBaseRequest {
	private String originatingBranch;
	private String currencyCode;
	private String branchCode;
	private String accountNumber;

	public AccountInformationRequest(EsbCredentials credentials) {
		setCredentials(credentials);
	}
	
	public String getOriginatingBranch() {
		return originatingBranch;
	}
	public void setOriginatingBranch(String originatingBranch) {
		this.originatingBranch = originatingBranch;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

}
