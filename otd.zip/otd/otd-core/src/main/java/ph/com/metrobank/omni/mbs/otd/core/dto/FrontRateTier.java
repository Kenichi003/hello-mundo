package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.util.LinkedList;
import java.util.List;

public class FrontRateTier {
	private String tier;
//	private String addOnRate;
	private List<RatePeriod> periods = new LinkedList<>();
	
	public String getId() {
		return tier;
	}
	public void setId(String tier) {
		this.tier = tier;
	}
	public List<RatePeriod> getPeriods() {
		return periods;
	}
	public void setPeriods(List<RatePeriod> periods) {
		this.periods = periods;
	}
	
	public void addPeriod(RatePeriod period) {
		periods.add(period);
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
//	public String getAddOnRate() {
//		return addOnRate;
//	}
//	public void setAddOnRate(String addOnRate) {
//		this.addOnRate = addOnRate;
//	}
}
