package ph.com.metrobank.omni.mbs.otd.core.rest;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.dto.EsbCredentials;
import ph.com.metrobank.omni.mbs.otd.core.dto.InquireTDClosingBalanceInput;
import ph.com.metrobank.omni.mbs.otd.core.dto.InquireTDClosingBalanceOutput;
import ph.com.metrobank.omni.mbs.otd.core.dto.OtdDetailsResponse;
import ph.com.metrobank.omni.mbs.otd.core.dto.TimeDepositClosingBalanceRequest;
import ph.com.metrobank.omni.mbs.otd.core.dto.TimeDepositClosingBalanceResponse;
import ph.com.metrobank.omni.mbs.otd.core.dto.TransactionInformation;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdFedbackRequest;
import ph.com.metrobank.omni.mbs.otd.core.service.HttpRequestService;
import ph.com.metrobank.omni.mbs.otd.core.service.TerminationSequenceService;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;
@Service
public class EsbClient {
	private static final Logger LOGGER = LoggerFactory.getLogger(EsbClient.class);
	
	@Autowired
	private Environment env;
	
	private EsbCredentials credentials;

	@Autowired
	private HttpRequestService httpService;
	
	@Autowired
	private TerminationSequenceService sequencer;
	
	private static String otdCurrencyCode;
	private static String systemId;
	private static String esbPassword;
	private static String esbTime;
	private static String esbDate;
	private static String terminationCostsUri;

	@PostConstruct
	private void initialize() {	
		esbPassword = env.getProperty("value.esbPassword");
		systemId = env.getProperty("value.esbSystemId");
		esbDate = env.getProperty("value.esbDate");
		esbTime = env.getProperty("value.esbTime");
		otdCurrencyCode = env.getProperty("value.otdCurrencyCode");
		
		credentials = new EsbCredentials(systemId, esbPassword);
		terminationCostsUri = env.getProperty("uri.esb.host.computeTermination");
	}
	
	
	public OtdDetailsResponse queryHostForTerminationComputation(OtdFedbackRequest otd, OtdDetailsResponse toClient) throws Exception {
		LocalDateTime now = LocalDateTime.now();
		LocalDate dateNow = now.toLocalDate();
		boolean same = dateNow.isEqual(LocalDate.parse(toClient.getMaturityDate(), AppConstants.FROM_HOST_FILE_FORMATTER));

		String sequence = sequencer.generateNumber();

		TimeDepositClosingBalanceRequest closingBalanceRequest = new TimeDepositClosingBalanceRequest();
		closingBalanceRequest.setCredentials(credentials);

		String otdAccountId = otd.getOtdAccountId();
		LOGGER.info("debug 1: {}", otdAccountId);
		String otdBranchCode = StringUtils.substring(otdAccountId, 0, 3);
		LOGGER.info("debug 2: {}", otdBranchCode);
		String tenDigitOtdAccountId = StringUtils.substring(otdAccountId, 3);
		LOGGER.info("debug 3: {}", tenDigitOtdAccountId);

		TransactionInformation closingBalanceTransactionInformation = closingBalanceRequest.getTransactionInformation();
		closingBalanceTransactionInformation.setTimeStamp(esbTime);
		closingBalanceTransactionInformation.setDateStamp(esbDate);
		closingBalanceTransactionInformation.setChannelTransaction(AppConstants.CHANNEL_INDICATOR);
		closingBalanceTransactionInformation.setProcessingBranch(otdBranchCode);
		closingBalanceTransactionInformation.setSequenceNumber(sequence);
		closingBalanceTransactionInformation.setSourceProductCode(AppConstants.MBOS);

		InquireTDClosingBalanceInput closingBalanceInput = closingBalanceRequest.getInquireTimeDepositClosingBalanceInput();
		closingBalanceInput.setAccountNumber(tenDigitOtdAccountId);
		closingBalanceInput.setBranchOfAccount(otdBranchCode);
		closingBalanceInput.setCurrencyOfAccount(otdCurrencyCode);
		closingBalanceInput.setSequenceNumber(sequence);
		closingBalanceInput.setServicingBranch(otdBranchCode);
		LOGGER.info("debug 4: {}", ProcessingUtils.toPrettyJson(closingBalanceInput, InquireTDClosingBalanceInput.class));
		
		String payload = ProcessingUtils.toJson(closingBalanceRequest, TimeDepositClosingBalanceRequest.class);
		LOGGER.info("request: {}", ProcessingUtils.prettify(payload));
		JsonElement inquiryResponse = httpService.post(terminationCostsUri, ProcessingUtils.toJson(closingBalanceRequest, TimeDepositClosingBalanceRequest.class));
		TimeDepositClosingBalanceResponse response = (TimeDepositClosingBalanceResponse) ProcessingUtils.fromJson(inquiryResponse, TimeDepositClosingBalanceResponse.class);
//		TimeDepositClosingBalanceResponse response = (TimeDepositClosingBalanceResponse) restTemplateService.postForObject(inquireTimeDepositBalanceUri, request);
		InquireTDClosingBalanceOutput forDetails = response.getInquireTimeDepositClosingBalanceOutput();
		
		if(same) {
			toClient.setEarnedInterest(forDetails.getAccruedInterestAmount());
			toClient.setWithHeldTaxAmount(forDetails.getWithholdingTaxAmount());
		} else {
			toClient.setPreTerminationPenalties(forDetails.getPenaltyAmount());
			toClient.setDocumentaryStampTax(forDetails.getDocStampAmount());
		}
		
		LOGGER.info("response: {}", ProcessingUtils.toJson(response));
		toClient.setNetCredits(forDetails.getClosingBalanceAmount());
		return toClient;
	}
}
