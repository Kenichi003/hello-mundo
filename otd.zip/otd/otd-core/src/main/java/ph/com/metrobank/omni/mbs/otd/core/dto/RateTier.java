package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class RateTier {
	private String tier;
	private String addOnRate;
	private BigDecimal min;
	private BigDecimal max;
	private Map<String, RatePeriod> periods = new HashMap<>();
	
	public String getId() {
		return tier;
	}
	public void setId(String tier) {
		this.tier = tier;
	}
	public Map<String, RatePeriod> getPeriods() {
		return periods;
	}
	public void setPeriods(Map<String, RatePeriod> periods) {
		this.periods = periods;
	}
	
	public void addPeriod(RatePeriod period) {
		periods.put(period.getId(), period);
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	public String getAddOnRate() {
		return addOnRate;
	}
	public void setAddOnRate(String addOnRate) {
		this.addOnRate = addOnRate;
	}
	
	public BigDecimal getMin() {
		return min;
	}
	public void setMin(BigDecimal min) {
		this.min = min;
	}
	public BigDecimal getMax() {
		return max;
	}
	public void setMax(BigDecimal max) {
		this.max = max;
	}

}
