package ph.com.metrobank.omni.mbs.otd.core.endpoint;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import ph.com.metrobank.omni.mbs.otd.core.dto.JSendResponse;
import ph.com.metrobank.omni.mbs.otd.core.dto.ValidationRequest;
import ph.com.metrobank.omni.mbs.otd.core.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.core.service.OtdDataService;

@Path("/data")
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Component
@Api(value = "Data-related Endpoints", produces = "application/json")
public class OtdDataEndpoint extends AbstractEnd {

	@Autowired
	private OtdDataService dataService;

	@GET
	@Path("/terms-and-conditions")
	@ApiOperation(value = "OTD Terms and Conditions for front-end display.", response = JSendResponse.class)
	public Object tos() {
		return dataService.getToc();
	}
	
	@GET
	@Path("/rates")
	@ApiOperation(value = "Returns the latest time deposit rates.", response = JSendResponse.class)
	public Object rates() {

		return dataService.rates();
	}

	@POST
	@Path("/validate")
	@ApiOperation(value = "Validates submitted customer information.", response = JSendResponse.class)
	@ApiResponses(value = { 
			@ApiResponse(code = 400, message = "Errors during validation."),
			@ApiResponse(code = 401, message = "Unauthorized access."),
			@ApiResponse(code = 503, message = "Call to other services failed.")})
	public Object validate(ValidationRequest request) throws Exception {
		if(securityEnabled) {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			if (StringUtils.equals(authentication.getName(), request.getUserName())) {
				return dataService.validate(request);
			}
		}

		return Response.status(401).build();
	}
	
	@GET
	@Path("/{otdAccountId}")
	@ApiOperation(value = "Returns the details of the queried OTD account.", response = JSendResponse.class)
	public Object details(@PathParam("otdAccountId") String id) throws Exception {
		return dataService.details(id, true);
	}
	
	@GET
	@Path("/compute-termination/{otdAccountId}")
	@ApiOperation(value = "Requests a termination breakdown for the OTD account in question.", response = JSendResponse.class)
	public Object computeTerminationCosts(@PathParam("otdAccountId") String id) throws Exception {
		return dataService.computeTerminationCosts(id);
	}
	
	@Override
	protected void initialize() throws Throwable {
	}
}
