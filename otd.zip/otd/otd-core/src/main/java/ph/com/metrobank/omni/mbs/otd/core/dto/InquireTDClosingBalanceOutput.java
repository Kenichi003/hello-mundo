package ph.com.metrobank.omni.mbs.otd.core.dto;

public class InquireTDClosingBalanceOutput {
    private String sequenceNumber; // = "000001";
    private String currencyOfAccount; //"001";
    private String branchOfAccount; //"288";
    private String accountNumber; //"1288012421";
    private String currentBalance;// "0000000061360.01 ";
    private String availableBalance; //"0000000061360.01 ";
    private String productType;// "901";
    private String currencyOfSettlementAccount;// "000";
    private String branchOfSettlementAccount;// "000";
    private String settlementAccountNumber;//"0000000000";
    private String appTypeOfSettlementAccount;// " ";
    private String statusOfSettlementAccount; //"  ";
    private String tdTerm;// "D";
    private String numberOfTerm; //"036";
    private String accountOpeningDate;//"002.000000";
    private String lastRenewalDate;// "20200213";
    private String maturityDate; //"20200320";
    private String annualInterestRate; //"002.000000";
    private String projectedInterestPayment; //"0000000000.00 ";
    private String projectedPrincipalMaturityPaymentAmount; //"0000000000000.00";
    private String accruedInterestAmount;// "0000000003.41 ";
    private String withholdingTaxAmount;// "0000000000.17 ";
    private String penaltyAmount; // "0000000002.56 ";
    private String docStampAmount; //0000000044.13 ";
    private String closingBalanceAmount; //: "0000000061316.56 ";
    
    private TransactionInformation TransactionInformation;
    private WSStatus WSStatus;
    
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getCurrencyOfAccount() {
		return currencyOfAccount;
	}
	public void setCurrencyOfAccount(String currencyOfAccount) {
		this.currencyOfAccount = currencyOfAccount;
	}
	public String getBranchOfAccount() {
		return branchOfAccount;
	}
	public void setBranchOfAccount(String branchOfAccount) {
		this.branchOfAccount = branchOfAccount;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}
	public String getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getCurrencyOfSettlementAccount() {
		return currencyOfSettlementAccount;
	}
	public void setCurrencyOfSettlementAccount(String currencyOfSettlementAccount) {
		this.currencyOfSettlementAccount = currencyOfSettlementAccount;
	}
	public String getBranchOfSettlementAccount() {
		return branchOfSettlementAccount;
	}
	public void setBranchOfSettlementAccount(String branchOfSettlementAccount) {
		this.branchOfSettlementAccount = branchOfSettlementAccount;
	}
	public String getSettlementAccountNumber() {
		return settlementAccountNumber;
	}
	public void setSettlementAccountNumber(String settlementAccountNumber) {
		this.settlementAccountNumber = settlementAccountNumber;
	}
	public String getAppTypeOfSettlementAccount() {
		return appTypeOfSettlementAccount;
	}
	public void setAppTypeOfSettlementAccount(String appTypeOfSettlementAccount) {
		this.appTypeOfSettlementAccount = appTypeOfSettlementAccount;
	}
	public String getStatusOfSettlementAccount() {
		return statusOfSettlementAccount;
	}
	public void setStatusOfSettlementAccount(String statusOfSettlementAccount) {
		this.statusOfSettlementAccount = statusOfSettlementAccount;
	}
	public String getTdTerm() {
		return tdTerm;
	}
	public void setTdTerm(String tdTerm) {
		this.tdTerm = tdTerm;
	}
	public String getNumberOfTerm() {
		return numberOfTerm;
	}
	public void setNumberOfTerm(String numberOfTerm) {
		this.numberOfTerm = numberOfTerm;
	}
	public String getAccountOpeningDate() {
		return accountOpeningDate;
	}
	public void setAccountOpeningDate(String accountOpeningDate) {
		this.accountOpeningDate = accountOpeningDate;
	}
	public String getLastRenewalDate() {
		return lastRenewalDate;
	}
	public void setLastRenewalDate(String lastRenewalDate) {
		this.lastRenewalDate = lastRenewalDate;
	}
	public String getMaturityDate() {
		return maturityDate;
	}
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}
	public String getAnnualInterestRate() {
		return annualInterestRate;
	}
	public void setAnnualInterestRate(String annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	public String getProjectedInterestPayment() {
		return projectedInterestPayment;
	}
	public void setProjectedInterestPayment(String projectedInterestPayment) {
		this.projectedInterestPayment = projectedInterestPayment;
	}
	public String getProjectedPrincipalMaturityPaymentAmount() {
		return projectedPrincipalMaturityPaymentAmount;
	}
	public void setProjectedPrincipalMaturityPaymentAmount(String projectedPrincipalMaturityPaymentAmount) {
		this.projectedPrincipalMaturityPaymentAmount = projectedPrincipalMaturityPaymentAmount;
	}
	public String getAccruedInterestAmount() {
		return accruedInterestAmount;
	}
	public void setAccruedInterestAmount(String accruedInterestAmount) {
		this.accruedInterestAmount = accruedInterestAmount;
	}
	public String getWithholdingTaxAmount() {
		return withholdingTaxAmount;
	}
	public void setWithholdingTaxAmount(String withholdingTaxAmount) {
		this.withholdingTaxAmount = withholdingTaxAmount;
	}
	public String getPenaltyAmount() {
		return penaltyAmount;
	}
	public void setPenaltyAmount(String penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}
	public String getDocStampAmount() {
		return docStampAmount;
	}
	public void setDocStampAmount(String docStampAmount) {
		this.docStampAmount = docStampAmount;
	}
	public String getClosingBalanceAmount() {
		return closingBalanceAmount;
	}
	public void setClosingBalanceAmount(String closingBalanceAmount) {
		this.closingBalanceAmount = closingBalanceAmount;
	}
	public TransactionInformation getTransactionInformation() {
		return TransactionInformation;
	}
	public void setTransactionInformation(TransactionInformation transactionInformation) {
		TransactionInformation = transactionInformation;
	}
	public WSStatus getWSStatus() {
		return WSStatus;
	}
	public void setWSStatus(WSStatus wSStatus) {
		WSStatus = wSStatus;
	}

}
