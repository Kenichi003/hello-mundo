
package ph.com.metrobank.omni.mbs.otd.core.dto;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;

public class OtdDetailsResponse {
	
	private Long otdRequestId;
	private String otdAccountId;
	private String currency = AppConstants.PESO;
	private String principalAmount;	
	private String term;
	private String interestRate;			
	private String maturityDate;		
	private String settlementAccount;
	private String netCredits;
	private String preTerminationPenalties;
	private String documentaryStampTax;
	private String earnedInterest;
	private String withHeldTaxAmount;
	private boolean settlementAccountActive;
	private boolean terminable;
	private boolean weekday;

	private String terminationTransactionDate;
		
	public OtdDetailsResponse(Long otdRequestId, String otdAccountId, String currency, String principalAmount,
			String term, String interestRate, String maturityDate, String settlementAccount, String terminationTransactionDate) {
		super();		
		this.otdRequestId = otdRequestId;
		this.otdAccountId = otdAccountId;
		this.currency = currency;
		this.principalAmount = principalAmount;
		this.term=term;
		this.interestRate=interestRate;
		this.maturityDate=maturityDate;		
		this.settlementAccount = settlementAccount;
		this.terminationTransactionDate = terminationTransactionDate;;
	}
	
	public String getSettlementAccount() {
		return settlementAccount;
	}

	public void setSettlementAccount(String settlementAccount) {
		this.settlementAccount = settlementAccount;
	}

	public String getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	
	public Long getOtdRequestId() {
		return otdRequestId;
	}
	public void setOtdRequestId(Long otdRequestId) {
		this.otdRequestId = otdRequestId;
	}
	public String getOtdAccountId() {
		return otdAccountId;
	}
	public void setOtdAccountId(String otdAccountId) {
		this.otdAccountId = otdAccountId;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPrincipalAmount() {
		return principalAmount;
	}
	public void setPrincipalAmount(String principalAmount) {
		this.principalAmount = principalAmount;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getPreTermTransactionDate() {
		return terminationTransactionDate;
	}
	public void setTerminationTransactionDate(String terminationTransactionDate) {
		this.terminationTransactionDate = terminationTransactionDate;
	}


	public String getNetCredits() {
		return netCredits;
	}


	public void setNetCredits(String netCredits) {
		this.netCredits = netCredits;
	}


	public String getPreTerminationPenalties() {
		return preTerminationPenalties;
	}


	public void setPreTerminationPenalties(String preTerminationPenalties) {
		this.preTerminationPenalties = preTerminationPenalties;
	}

	public String getDocumentaryStampTax() {
		return documentaryStampTax;
	}


	public void setDocumentaryStampTax(String documentaryStampTax) {
		this.documentaryStampTax = documentaryStampTax;
	}


	public String getEarnedInterest() {
		return earnedInterest;
	}


	public void setEarnedInterest(String earnedInterest) {
		this.earnedInterest = earnedInterest;
	}


	public String getWithHeldTaxAmount() {
		return withHeldTaxAmount;
	}


	public void setWithHeldTaxAmount(String withHeldTaxAmount) {
		this.withHeldTaxAmount = withHeldTaxAmount;
	}

	public boolean isTerminable() {
		return terminable;
	}

	public void setTerminable(boolean terminable) {
		this.terminable = terminable;
	}

	public String getTerminationTransactionDate() {
		return terminationTransactionDate;
	}

	public boolean isSettlementAccountActive() {
		return settlementAccountActive;
	}

	public void setSettlementAccountActive(boolean settlementAccountActive) {
		this.settlementAccountActive = settlementAccountActive;
	}
	
	public boolean isWeekday() {
		return weekday;
	}

	public void setWeekday(boolean weekday) {
		this.weekday = weekday;
	}
}

