package ph.com.metrobank.omni.mbs.otd.core.writer;

import java.io.File;
import java.math.BigDecimal;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.github.ffpojo.file.writer.FileSystemFlatFileWriter;
import com.github.ffpojo.file.writer.FlatFileWriter;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdRequest;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdSuccessfulDispatchDetails;
import ph.com.metrobank.omni.mbs.otd.core.repository.webengine.OtdRequestRepository;
import ph.com.metrobank.omni.mbs.otd.core.repository.webengine.OtdSuccessfulDispatchTimeRepository;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;

@Component
public class OtdRequestDispatchFileWriter {
	private static final Logger LOGGER = LoggerFactory.getLogger(OtdRequestDispatchFileWriter.class);

	private String dispatchFileName;

	@Autowired
	private Environment env;

	@Autowired
	private OtdRequestRepository requestsRepository;

	@Autowired
	private OtdSuccessfulDispatchTimeRepository dispatchTimeDetailsRepository;

	private Path outputPath;

	@PostConstruct
	private void initialize() {
		dispatchFileName = env.getProperty("path.uploadFile");
		outputPath = Paths.get(env.getProperty("path.dropFolder"), dispatchFileName);
		long count = dispatchTimeDetailsRepository.count();
		if(count == 0) {
			List<OtdSuccessfulDispatchDetails> stamps = new LinkedList<>();
			LocalDateTime now = LocalDateTime.now();
			OtdSuccessfulDispatchDetails stamp = new OtdSuccessfulDispatchDetails();
			stamp.setId(1);
			stamp.setUpdated(now);
			stamps.add(stamp);
			OtdSuccessfulDispatchDetails tempStamp = new OtdSuccessfulDispatchDetails();
			tempStamp.setId(2);
			tempStamp.setUpdated(now);
			stamps.add(tempStamp);
			dispatchTimeDetailsRepository.saveAll(stamps);
		} else if(count == 1) {
			Optional<OtdSuccessfulDispatchDetails> original = dispatchTimeDetailsRepository.findById(Long.valueOf(1));
			if(original.isPresent()) {
				OtdSuccessfulDispatchDetails base = original.get();
				OtdSuccessfulDispatchDetails tempStamp = new OtdSuccessfulDispatchDetails();
				tempStamp.setId(2);
				tempStamp.setUpdated(base.getUpdated());
				dispatchTimeDetailsRepository.save(tempStamp);
			}
		}
	}

	public int createDispatchFile(LocalDateTime now) throws Exception {
		File file = outputPath.toFile();
		FlatFileWriter ffWriter = new FileSystemFlatFileWriter(file, true);
		Optional<OtdSuccessfulDispatchDetails> check = dispatchTimeDetailsRepository.findById(Long.valueOf(1));
		if(check.isPresent()) {
			OtdSuccessfulDispatchDetails timeStamp = check.get();
			List<OtdRequest> customers = requestsRepository.findByCreated(timeStamp.getUpdated());

			if(!customers.isEmpty()) {
				BigDecimal total = BigDecimal.ZERO;
				for(OtdRequest customer : customers) {
					LOGGER.info("\nIncluding OTD request into the file:\n{}", ProcessingUtils.toJson(customer));
					total = total.add(NumberUtils.createBigDecimal(customer.getTransformedPlacementAmount()));
				}
				ffWriter.writeRecordList(customers);
				ffWriter.close();
				List<String> lines = Files.readAllLines(outputPath);
				lines.add(ProcessingUtils.append(AppConstants.T, StringUtils.leftPad(String.valueOf(lines.size()), 10, AppConstants.ZERO_CHARACTER), StringUtils.leftPad(StringUtils.remove(total.toPlainString(), AppConstants.PERIOD), 16, AppConstants.ZERO_CHARACTER)));
				lines.add(0, ProcessingUtils.append(AppConstants.H, AppConstants.NOTIFICATION_DATE_FORMATTER.format(now)));
				
				LOGGER.info("Preparing output file. Truncating, if necessary.");
				FileChannel.open(outputPath, StandardOpenOption.WRITE).truncate(0).close();
				LOGGER.info("Writing OTD records into file.");
				Files.write(outputPath, lines);
				LOGGER.info("Done.");
			}

			Optional<OtdSuccessfulDispatchDetails> generationCheck = dispatchTimeDetailsRepository.findById(Long.valueOf(2));
			if (generationCheck.isPresent()) {
				LOGGER.info("Updating dispatch timestamp to {}", now.toString());
				OtdSuccessfulDispatchDetails generationTimeStamp = generationCheck.get();
				generationTimeStamp.setUpdated(now);
				dispatchTimeDetailsRepository.save(generationTimeStamp);
				LOGGER.info("Done.");
			}

			return customers.size();
		}

		return 0;
	}
}