package ph.com.metrobank.omni.mbs.otd.core.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "notification_templates")
public class NotificationTemplate {

	@Id
	@Column(unique = true, nullable = false)
	private Long id;
	
	@Column(unique = true, nullable = false)
	private String code;
	
	@Column(nullable = false)
	private String name;

	@Column(nullable = false)
	private String description;

	@Column(nullable = false)
	private String title;
	
	@Column(nullable = false)
	private String body;
	
	@Column(name="title_tokens", nullable = false)
	private String titleTokens;
	
	@Column(name="body_tokens", nullable = false)
	private String bodyTokens;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column()
	private Timestamp created;

	@Column()
	private Timestamp updated;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getTitleTokens() {
		return titleTokens;
	}

	public void setTitleTokens(String titleTokens) {
		this.titleTokens = titleTokens;
	}

	public String getBodyTokens() {
		return bodyTokens;
	}

	public void setBodyTokens(String bodyTokens) {
		this.bodyTokens = bodyTokens;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public Timestamp getUpdated() {
		return updated;
	}

	public void setUpdated(Timestamp updated) {
		this.updated = updated;
	}
	
//	@PrePersist
//	void preInsert() {
//		created = Timestamp.valueOf(LocalDateTime.now());
//	}
//
//	@PreUpdate
//	void preUpdate() {
//		updated = Timestamp.valueOf(LocalDateTime.now());
//	}

}
