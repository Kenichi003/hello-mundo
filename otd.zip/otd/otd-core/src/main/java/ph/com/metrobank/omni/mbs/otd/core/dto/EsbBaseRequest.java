package ph.com.metrobank.omni.mbs.otd.core.dto;

public class EsbBaseRequest {
	private EsbCredentials Credentials;
	
	public EsbBaseRequest() {
	}

	public EsbCredentials getCredentials() {
		return Credentials;
	}

	public void setCredentials(EsbCredentials credentials) {
		this.Credentials = credentials;
	}
}
