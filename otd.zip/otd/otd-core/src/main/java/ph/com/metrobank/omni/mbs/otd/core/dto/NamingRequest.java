package ph.com.metrobank.omni.mbs.otd.core.dto;

public class NamingRequest extends CoordinatorRequest {
	private String base;

	public String getBase() {
		return base;
	}

	public void setBase(String base) {
		this.base = base;
	}
}
