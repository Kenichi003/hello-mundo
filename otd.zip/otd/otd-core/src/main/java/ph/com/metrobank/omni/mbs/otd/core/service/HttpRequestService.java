package ph.com.metrobank.omni.mbs.otd.core.service;

import java.io.IOException;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.core.factory.HttpClientFactory;
import ph.com.metrobank.omni.mbs.otd.core.rest.JsonTypeGet;
import ph.com.metrobank.omni.mbs.otd.core.rest.JsonTypePost;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;

@Component
public class HttpRequestService {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpRequestService.class);
	
	@Autowired
	private HttpClientFactory factory;
	
//	public JsonElement post(String to, String payload, Optional<String> authHeader) throws IOException {
//		try(CloseableHttpClient client = factory.createClient()) {
//			JsonTypePost post = new JsonTypePost(to, payload, authHeader);
//			CloseableHttpResponse response = client.execute(post);
//			String entity = EntityUtils.toString(response.getEntity());
//			LOGGER.info("entity: {}", entity);
//			return ProcessingUtils.parseJson(entity);
//		}
//	}
	
	public JsonElement post(String to, String payload, JsonObject auth) throws IOException {
		try(CloseableHttpClient client = factory.createClient()) {
			JsonTypePost post = new JsonTypePost(to, payload, auth);
			CloseableHttpResponse response = client.execute(post);
			String entity = EntityUtils.toString(response.getEntity());
			LOGGER.info("entity: {}", entity);
			return ProcessingUtils.parseJson(entity);
		}
	}
	
	
	public JsonElement post(String to, String payload) throws IOException {
		try(CloseableHttpClient client = factory.createClient()) {
			JsonTypePost post = new JsonTypePost(to, payload, Optional.empty());
			CloseableHttpResponse response = client.execute(post);
			String entity = EntityUtils.toString(response.getEntity());
			LOGGER.info("entity: {}", entity);
			return ProcessingUtils.parseJson(entity);
		}
	}
	
	public String get(String base, String replace, String replacement, JsonObject auth) throws IOException {
		try(CloseableHttpClient client = factory.createClient()) {
			JsonTypeGet get = new JsonTypeGet(StringUtils.replace(base, replace, replacement), auth);
			CloseableHttpResponse response = client.execute(get);
			return EntityUtils.toString(response.getEntity());
		}
	}

	public JsonElement get(String uri, JsonObject auth) throws IOException {
		try(CloseableHttpClient client = factory.createClient()) {
			JsonTypeGet get = new JsonTypeGet(uri, auth);
			CloseableHttpResponse response = client.execute(get);
			return ProcessingUtils.parseJson(EntityUtils.toString(response.getEntity()));
		}
	}
}
