package ph.com.metrobank.omni.mbs.otd.core.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import ph.com.metrobank.omni.mbs.otd.core.filter.SecurityRoleFilter;

@Configuration
public class Oauth2ServerConfiguration {

	@Configuration
	@EnableResourceServer
	protected static class ResourceServer extends ResourceServerConfigurerAdapter {

		@Value("${security.oauth2.enabled}")
		private boolean securityEnabled;

		@Override
		public void configure(HttpSecurity http) throws Exception {
			if (securityEnabled)  {
				http
				.addFilterBefore(new SecurityRoleFilter(), UsernamePasswordAuthenticationFilter.class)
	            .authorizeRequests().antMatchers("/**/**/back-office/**").permitAll().and()
				.authorizeRequests().antMatchers("/**/*swagger*/**").permitAll().and()
				.authorizeRequests().antMatchers("/actuator/**").permitAll().and()
				.authorizeRequests().anyRequest().authenticated();
			} else {
				http
					.addFilterBefore(new SecurityRoleFilter(), UsernamePasswordAuthenticationFilter.class)
					.authorizeRequests().anyRequest().permitAll();
			}
		}
	}

}
