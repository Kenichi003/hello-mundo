package ph.com.metrobank.omni.mbs.otd.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ph.com.metrobank.omni.mbs.otd.core.service.OtdFirstFileWatcherService;

@SpringBootApplication
public class OtdCoreApplication {

  @Autowired
  protected OtdFirstFileWatcherService watcher;
  
  public static void main(String[] args) {
    SpringApplication.run(OtdCoreApplication.class, args);
  }

}
