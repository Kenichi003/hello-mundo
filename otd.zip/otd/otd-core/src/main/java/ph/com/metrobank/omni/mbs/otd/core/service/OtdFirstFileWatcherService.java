package ph.com.metrobank.omni.mbs.otd.core.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdSuccessfulDispatchDetails;
import ph.com.metrobank.omni.mbs.otd.core.reader.FirstHostFeedbackFileReader;
import ph.com.metrobank.omni.mbs.otd.core.reader.OtdRatesFileReader;
import ph.com.metrobank.omni.mbs.otd.core.repository.webengine.OtdSuccessfulDispatchTimeRepository;

@Service
public class OtdFirstFileWatcherService implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(OtdFirstFileWatcherService.class);

	@Autowired
	private Environment env;

	@Autowired
	private OtdRatesFileReader ratesReader;

	@Autowired
	private FirstHostFeedbackFileReader firstFeedbackReader;

	@Autowired
	private OtdSuccessfulDispatchTimeRepository timeStampRepository;

	private static Path parent;
	private static Path firstFileComparisonSource;
	private static Path ratesComparisonSource;

	private static String firstFeedbackFile;
	private static String otdRatesFile;

//	private ByteSource currentFirstFeedback = null; 
//	private ByteSource currentRates = null; 

	private static boolean watch = true;

	@PostConstruct
	private void initialize() throws IOException {
		if(Boolean.valueOf(env.getProperty("toggle.watch"))) {
			otdRatesFile = env.getProperty("path.hostRatesFile");
			firstFeedbackFile = env.getProperty("path.firstFeedbackFile");
			parent = Paths.get(env.getProperty("path.dropFolder"));
			Path resourceBase = Paths.get(AppConstants.RELATIVE_PATH_BASE, env.getProperty("path.resources"));
			firstFileComparisonSource = resourceBase.resolve(firstFeedbackFile);
			ratesComparisonSource = resourceBase.resolve(otdRatesFile);

			if(!Files.exists(firstFileComparisonSource)) {
				Files.createFile(firstFileComparisonSource);
			}

			if(!Files.exists(ratesComparisonSource)) {
				Files.createFile(ratesComparisonSource);
			}

//			currentFirstFeedback = com.google.common.io.Files.asByteSource(firstFileComparisonSource.toFile());
//			currentRates = com.google.common.io.Files.asByteSource(ratesComparisonSource.toFile());

			begin();
		}
	}

	public void begin() {
		ExecutorService runner = Executors.newSingleThreadExecutor();
		runner.execute(this);
		runner.shutdown();
		try {
			runner.awaitTermination(20, TimeUnit.SECONDS);
		} catch(Exception e) {
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void run() {
		LOGGER.info("Starting watch for otd files @ {}", parent.toString());
		WatchService watcher;
		try {
			watcher = parent.getFileSystem().newWatchService();
			parent.register(watcher, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY);

			WatchKey watchKey = null;

			while (watch) {
				try {
					watchKey = watcher.take(); 
					if(watchKey != null) {
						watchKey.pollEvents().stream().forEach(event -> {
							WatchEvent.Kind<Path> kind = (Kind<Path>) event.kind();
							Path name = ((WatchEvent<Path>) event).context();

							if(Files.isDirectory(name)) {
								return;
							}

							if(kind == StandardWatchEventKinds.ENTRY_MODIFY || kind == StandardWatchEventKinds.ENTRY_CREATE) {
								Path path = parent.resolve(name);
								try {
									String fileName = name.getFileName().toString();
									if(StringUtils.equalsIgnoreCase(fileName, otdRatesFile)) {
										if(Files.size(path) > 0) {
											LOGGER.info("otd rates file dropped, updating...");
											//											ByteSource maybeNew = com.google.common.io.Files.asByteSource(path.toFile());
											//											if(!maybeNew.contentEquals(currentRates)) {
											ratesReader.processRates(path);
											Files.copy(path, ratesComparisonSource, StandardCopyOption.REPLACE_EXISTING);
											LOGGER.info("Successful rates file backup.");
											//											}
										} 
									} else if(StringUtils.equalsIgnoreCase(fileName, firstFeedbackFile)) {
										if(Files.size(path) > 0) {
											LOGGER.info("1st feedback file dropped, processing...");
											//											ByteSource maybeNew = com.google.common.io.Files.asByteSource(path.toFile());
											//											if(!maybeNew.contentEquals(currentFirstFeedback)) {
											processFirstFeedback(path);
											//												Files.copy(path, firstFileComparisonSource, StandardCopyOption.REPLACE_EXISTING);
											//											}
										}
									}
								} catch (Exception e) {
									LOGGER.error("Error during file review: ", e);
								}
							}
						});
						
						watchKey.reset();
					}

				} catch(Exception e) {
					LOGGER.error("Error during file watch: ", e);
					continue;
				}
			}
		} catch(Exception e) {
			LOGGER.error("Error during file watch creation: ", e);
		}

	}

	public void processFirstFeedback(Path path) throws Exception {
		LocalDateTime now = LocalDateTime.now();
		Optional<OtdSuccessfulDispatchDetails> check = timeStampRepository.findById(Long.valueOf(1));
		if(check.isPresent()) {
			OtdSuccessfulDispatchDetails currentStamp = check.get();
			if(firstFeedbackReader.read(path)) {
				Optional<OtdSuccessfulDispatchDetails> tempStamp = timeStampRepository.findById(Long.valueOf(2));
				if(tempStamp.isPresent()) {
					Timestamp tempTime = tempStamp.get().getUpdated();
					currentStamp.setUpdated(tempTime);
					LOGGER.info("Setting timestamp to {}", tempTime);
				} else {
					LOGGER.info("Setting timestamp to {}", now);
					currentStamp.setUpdated(now);
				}
				timeStampRepository.save(currentStamp);
			} else {
				LOGGER.info("Error in processing acknowledgment file for updating of successful dispatch timestamp. Either the file is one that was previously delivered and processed, or the host rejected the file.");
			}
		}
	}
}
