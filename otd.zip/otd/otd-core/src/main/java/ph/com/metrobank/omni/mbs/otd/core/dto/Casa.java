package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class Casa implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3331720054996765758L;
	private String id;
	private String branch;
	private String accountNo;
	private String customerId;
	private String productType;
	private String alias;
	private String currencyCode;
	private String currencyHostCode;
	private String initialAccount;
	private String accountType;
	private String accountTypeDescription;
	private String mobile;
	private List<Map<String, Object>> allowedTransactions;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getCurrencyHostCode() {
		return currencyHostCode;
	}
	public void setCurrencyHostCode(String currencyHostCode) {
		this.currencyHostCode = currencyHostCode;
	}
	public String getInitialAccount() {
		return initialAccount;
	}
	public void setInitialAccount(String initialAccount) {
		this.initialAccount = initialAccount;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountTypeDescription() {
		return accountTypeDescription;
	}
	public void setAccountTypeDescription(String accountTypeDescription) {
		this.accountTypeDescription = accountTypeDescription;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public List<Map<String, Object>> getAllowedTransactions() {
		return allowedTransactions;
	}
	public void setAllowedTransactions(List<Map<String, Object>> allowedTransactions) {
		this.allowedTransactions = allowedTransactions;
	}
}
