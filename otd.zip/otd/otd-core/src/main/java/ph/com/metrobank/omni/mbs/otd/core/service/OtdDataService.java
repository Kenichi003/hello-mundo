package ph.com.metrobank.omni.mbs.otd.core.service;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.HttpResponse;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.common.constant.CasaAccountType;
import ph.com.metrobank.omni.mbs.common.dto.casa.CasaDto;
import ph.com.metrobank.omni.mbs.common.dto.customer.CustomerDto;
import ph.com.metrobank.omni.mbs.common.exception.ValidationException;
import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.dto.Casa;
import ph.com.metrobank.omni.mbs.otd.core.dto.ContactDto;
import ph.com.metrobank.omni.mbs.otd.core.dto.Customer;
import ph.com.metrobank.omni.mbs.otd.core.dto.EulaDetails;
import ph.com.metrobank.omni.mbs.otd.core.dto.MpinServiceTransactionRequest;
import ph.com.metrobank.omni.mbs.otd.core.dto.OtdDetailsResponse;
import ph.com.metrobank.omni.mbs.otd.core.dto.RateMinMax;
import ph.com.metrobank.omni.mbs.otd.core.dto.RatePeriod;
import ph.com.metrobank.omni.mbs.otd.core.dto.RateTier;
import ph.com.metrobank.omni.mbs.otd.core.dto.TimeDepositDetails;
import ph.com.metrobank.omni.mbs.otd.core.dto.ValidationRequest;
import ph.com.metrobank.omni.mbs.otd.core.dto.ValidationResponse;
import ph.com.metrobank.omni.mbs.otd.core.factory.HttpClientFactory;
import ph.com.metrobank.omni.mbs.otd.core.factory.ThreadFactory;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdFedbackRequest;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdRequest;
import ph.com.metrobank.omni.mbs.otd.core.repository.webengine.OtdFedbackRequestRepository;
import ph.com.metrobank.omni.mbs.otd.core.repository.webengine.OtdRequestRepository;
import ph.com.metrobank.omni.mbs.otd.core.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.core.rest.EsbClient;
import ph.com.metrobank.omni.mbs.otd.core.rest.GetCall;
import ph.com.metrobank.omni.mbs.otd.core.rest.JsonTypeGet;
import ph.com.metrobank.omni.mbs.otd.core.rest.JsonTypePost;
import ph.com.metrobank.omni.mbs.otd.core.rest.PostCall;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;

@Service
public class OtdDataService extends AbstractEnd {
	private static final Logger LOGGER = LoggerFactory.getLogger(OtdDataService.class);

	@Autowired
	private Environment env;

	@Autowired
	private GenerationService gen;

	@Autowired
	private HttpClientFactory clientFactory;

	@Autowired
	private HttpRequestService httpService;

	@Autowired
	private EsbClient esbClient;

	@Autowired
	private OtdRequestRepository requestRepository;

	@Autowired
	private OtdFedbackRequestRepository fedBackedRequestRepository;

	private static Map<String, RateMinMax> minMaxMap;
	private static Map<String, RateTier> trueRatesMap;

	private static String eulaUri;
	private static String acknowledgeUri;
	private static String casaTimeDepositUri;
	private static String customerInfoUri;
	private static String casaAccountUri;

	private static JsonElement termsAndConditions;
	private static JsonElement displayRates;

	private static String customerIdSearchBase;
	private static String customerNameSearchBase;

	private static String casaAccountIdSearchBase;
	private static String taxFlagDefault;
	private static String otdTransactionCode;
	private static String mpinValidationUrl;

	private static String[] tierNames;
	private static String[] periodNames;
	private static String[] rolloverInstructions;

	private static BigDecimal actualAddOnRate;
	private static Short rollOverInstructionCount;

	private static boolean enforceAllowedTransactions;

	@Override
	protected void initialize() throws Throwable {
		String resourceFolder = env.getProperty("path.resources");

		Path resources = Paths.get(AppConstants.RELATIVE_PATH_BASE, resourceFolder);
		termsAndConditions = ProcessingUtils.parseJson(new String(Files.readAllBytes(resources.resolve(env.getProperty("path.casaTermsAndConditions")))));
		customerNameSearchBase = env.getProperty("uri.mbs.customer.searchByName");
		customerIdSearchBase = env.getProperty("uri.mbs.customer.searchById");
		casaAccountIdSearchBase = env.getProperty("uri.mbs.casas.searchByAccountId");
		acknowledgeUri = env.getProperty("uri.otd.notification.acknowledge");
		mpinValidationUrl = env.getProperty("uri.mbs.service.mpinValidationUrl");

		actualAddOnRate = NumberUtils.createBigDecimal(env.getProperty("value.addOnRate"));
		minMaxMap = new HashMap<>();
		String[] minimumValues = StringUtils.split(env.getProperty("value.minimums"), ",");
		String[] maximumValues = StringUtils.split(env.getProperty("value.maximums"), ",");
		tierNames = StringUtils.split(env.getProperty("value.tiers"), ";");
		periodNames = StringUtils.split(env.getProperty("value.periods"), ";");
		rolloverInstructions = StringUtils.split(env.getProperty("value.rolloverInstructions"), ";");
		enforceAllowedTransactions = Boolean.valueOf(env.getProperty("toggle.enforceAllowedTransactions"));
		int length = minimumValues.length;
		for(int i = 0; i < length; i++) {
			RateMinMax rmm = new RateMinMax();
			rmm.setMin(NumberUtils.createBigDecimal(minimumValues[i]));
			rmm.setMax(NumberUtils.createBigDecimal(maximumValues[i]));
			minMaxMap.put(tierNames[i], rmm);
		}

		eulaUri = env.getProperty("uri.eulaAcceptance");
		taxFlagDefault = env.getProperty("value.defaultTaxFlag");
		rollOverInstructionCount = Short.valueOf(env.getProperty("value.rollOverInstructionsCount"));
		otdTransactionCode = env.getProperty("value.otdTransactionCode");

		casaTimeDepositUri = env.getProperty("uri.mbs.casa.otd");
		customerInfoUri = env.getProperty("uri.mbs.customer");
		casaAccountUri = env.getProperty("uri.mbs.casa.account");
	}

	public Object rates() {
		return Response.ok(displayRates).build();
	}

	private Object mpin(ValidationRequest validate, JsonObject access) throws Exception {
		MpinServiceTransactionRequest request = new MpinServiceTransactionRequest();
		request.setUserName(validate.getUserName());
		request.setTransaction(AppConstants.TRANSACTION);

		Optional<String> authCheck = validate.getAuthValue();
		if(authCheck.isPresent()) {
			request.setMpin(authCheck.get());
		}

		String convert = ProcessingUtils.toJson(request, MpinServiceTransactionRequest.class);
		JsonObject json = httpService.post(mpinValidationUrl, convert, access).getAsJsonObject();
		short check = json.get(AppConstants.CODE_PARAMETER).getAsShort();
		if(check != 200) {
			LOGGER.error("Error during mpin validation. MPIN service response: {}" , json.toString());
			return Response
					.accepted(json.get(AppConstants.DATA_PARAMETER)) 
					.status(400)
					.build();
		}

		Optional<OtdRequest> lookup = requestRepository.findByReferenceId(validate.getReferenceId().get());
		if(lookup.isPresent()) {
			OtdRequest record = lookup.get();

			List<PostCall> parallel = new ArrayList<>();
			try(CloseableHttpAsyncClient asyncClient = clientFactory.createAsyncClient()) {
				String customerId = record.getCustomerId();
				Customer customer = customer(customerId, access);

				String name = ProcessingUtils.normalizeName(customer);
				record.setAccountName(name);
				record.setUpdated(Timestamp.valueOf(LocalDateTime.now()));
				requestRepository.save(record);

				EulaDetails eulaDetails = new EulaDetails();
				eulaDetails.setCustomerId(customerId);
				eulaDetails.setEulaVersionIdList(validate.getEulaVersionIdList());
				JsonTypePost eulaPost = new JsonTypePost(eulaUri, Optional.ofNullable(ProcessingUtils.toJson(eulaDetails, EulaDetails.class)), access);
				PostCall eulaCall = new PostCall(asyncClient, customer.getId(), eulaPost);
				ContactDto notify = new ContactDto();
				notify.setReferenceId(record.getReferenceId());
				notify.setCustomerId(customerId);
				notify.setName(name);
				notify.setEmail(customer.getEmail());
				notify.setMobile(customer.getMobile());
				notify.setCurrency(StringUtils.equals(record.getCurrencyCode(), AppConstants.PHP_HOST_CURRENCY_CODE) ? AppConstants.PHP : AppConstants.USD);
				notify.setRolloverInstruction(rolloverInstructions[NumberUtils.createInteger(record.getRolloverInstruction())]);
				notify.setPrincipalAmount(AppConstants.TWO_DECIMAL_FORMATTER.format(NumberUtils.createBigDecimal(record.getPlacementAmount()).divide(AppConstants.PLACEMENT_AMOUNT_REDUCER)));

				String tenorValue = record.getTenor();
				Byte tenor = Byte.valueOf(tenorValue);
				if(tenor == 1) {
					notify.setTerm(ProcessingUtils.append(String.valueOf(tenor), AppConstants.SPACE, AppConstants.MONTH));
				} else {
					notify.setTerm(ProcessingUtils.append(String.valueOf(tenor), AppConstants.SPACE, AppConstants.MONTHS));
				}


				String baseRate = ProcessingUtils.insertIntoString(record.getBaseRate(), AppConstants.DOT, 3);
				String addOnRate = ProcessingUtils.insertIntoString(record.getAddOnRate(), AppConstants.DOT, 3);
				BigDecimal computedRate = NumberUtils.createBigDecimal(baseRate).add(NumberUtils.createBigDecimal(addOnRate));
				notify.setInterestRate(AppConstants.THREE_DECIMAL_FORMATTER.format(computedRate));

				notify.setMaturityDate(validate.getMaturityDate());

				String toNote = ProcessingUtils.toJson(notify, ContactDto.class);
				LOGGER.info("Sending to OTD Notification Service @ {}: {}", acknowledgeUri, ProcessingUtils.prettify(toNote));

				JsonTypePost toNotifier = new JsonTypePost(acknowledgeUri, Optional.of(toNote), access);
				PostCall contactCall = new PostCall(asyncClient, customer.getId(), toNotifier);
				Collections.addAll(parallel, contactCall, eulaCall);
				ThreadFactory.invokePosts(parallel);
				JsonObject referenceResponse = new JsonObject();
				referenceResponse.addProperty(AppConstants.REFERENCE_ID_PARAMETER, record.getReferenceId());
				return Response.ok(referenceResponse.toString()).build();
			}
		} else {
			ValidationResponse validationResponse = new ValidationResponse();
			validationResponse.addError(AppConstants.MISSING_OTD_REQUEST_RECORD);
			return Response
					.accepted(ProcessingUtils.toJson(validationResponse.getErrors(), List.class))
					.status(400)
					.build();
		}
	}

	public Object validate(ValidationRequest request) throws Exception {
		JsonObject access = extractAccessObject();
		Optional<String> typeCheck = request.getAuthType();
		Optional<String> valueCheck = request.getAuthValue();
		if(typeCheck.isPresent() && valueCheck.isPresent()) {
			return mpin(request, access);
		}

		LOGGER.info("MPIN excess check.");
		try(CloseableHttpAsyncClient client = clientFactory.createAsyncClient()) {
			String customerName = request.getUserName();
			MpinServiceTransactionRequest lockedPasscodeCheck = new MpinServiceTransactionRequest();
			lockedPasscodeCheck.setUserName(customerName);
			lockedPasscodeCheck.setTransaction(AppConstants.TRANSACTION);
			String to = ProcessingUtils.toJson(lockedPasscodeCheck, MpinServiceTransactionRequest.class);

			JsonTypePost post = new JsonTypePost(mpinValidationUrl, Optional.of(to), access);
			PostCall lockedCheckPost=  new PostCall(client, customerName, post);
			HttpResponse lockedPasscodeCheckResponse = ThreadFactory.postForResponse(lockedCheckPost);

			String lockedReturn = EntityUtils.toString(lockedPasscodeCheckResponse.getEntity());
			JsonObject lockedCheckResponseEntity = ProcessingUtils.toJson(lockedReturn).getAsJsonObject();
			String lockedCheckCode = lockedCheckResponseEntity.get(AppConstants.DATA_PARAMETER).getAsJsonObject().get(AppConstants.ERRORS_PARAMETER).getAsJsonArray().get(0).getAsJsonObject().get(AppConstants.CODE_PARAMETER).getAsString();
			switch(lockedCheckCode) {
			case AppConstants.INVALID_MPIN_EXCEEDED:
				LOGGER.error("MPIN lock check response: {}" , lockedCheckResponseEntity.toString());
				return Response
						.accepted(lockedCheckResponseEntity.get(AppConstants.DATA_PARAMETER)) 
						.status(400)
						.build();
			default:
				short flag = 1;
				ValidationResponse payload = new ValidationResponse();

				Optional<Short> taxFlagCheck = request.getTaxFlag();
				Optional<String> termCheck = request.getTerm();

				String term = termCheck.isPresent() ? StringUtils.upperCase(termCheck.get()) : AppConstants.M;
				if(termCheck.isPresent()) {
					term = AppConstants.UPPER_M;
				} else {
					term = AppConstants.M;
				}

				boolean valid = StringUtils.equalsAnyIgnoreCase(term, AppConstants.D, AppConstants.M);
				flag *= valid ? 1 : 0;
				payload.setTerm(valid);
				if(!valid) {
					return returnErrorReport(payload); 
				}

				String placementAmount = request.getPlacementAmount();
				valid = validatePlacementAmount(placementAmount);
				flag *= valid ? 1 : 0;
				payload.setPlacementAmount(valid);
				if(!valid) {
					return returnErrorReport(payload);
				}

				Short tenor = request.getTenor();
				valid = validateTenorLength(term, tenor);
				flag *= valid ? 1 : 0;
				payload.setTenor(valid);
				if(!valid) {
					return returnErrorReport(payload); 
				}

				valid = validateBaseRate(request.getBaseRate(), placementAmount, tenor);
				flag *= valid ? 1 : 0;
				payload.setBaseRate(valid);
				if(!valid) {
					return returnErrorReport(payload); 
				}

				valid = request.getRolloverInstruction() < rollOverInstructionCount;
				flag *= valid ? 1 : 0;
				payload.setRollOverInstructions(valid);
				if(!valid) {
					return returnErrorReport(payload); 
				}

				String accountId = request.getAccountId();
				valid = accountId != null && !StringUtils.isBlank(accountId);
				payload.setAccountId(valid);
				if(!valid) {
					return returnErrorReport(payload);
				}

				JsonObject accessObject = extractAccessObject();

				JsonTypeGet fromCustomersDataSourceGet = new JsonTypeGet(StringUtils.replace(customerNameSearchBase, AppConstants.ENCLOSED_CUSTOMER_NAME_PARAMETER, customerName), accessObject);
				JsonTypeGet fromCasasDataSourceGet = new JsonTypeGet(StringUtils.replace(casaAccountIdSearchBase, AppConstants.ENCLOSED_ID_PARAMETER, accountId), accessObject);
				GetCall casasCall = new GetCall(client, AppConstants.CASAS, fromCasasDataSourceGet);
				GetCall customerCall = new GetCall(client, AppConstants.CUSTOMER, fromCustomersDataSourceGet);
				List<GetCall> getCalls = new ArrayList<>(2);
				Collections.addAll(getCalls, casasCall, customerCall);

				ThreadFactory.invokeGets(getCalls);
				JsonElement parsed;
				Customer customer = new Customer();

				String referenceId = StringUtils.EMPTY;
				String settlementAccountNumber = StringUtils.EMPTY; 
				String settlementInternalAccountId = StringUtils.EMPTY; 
				String branchCode = StringUtils.EMPTY;
				String productType = StringUtils.EMPTY;
				String currencyCode = StringUtils.EMPTY;
				payload.setCurrencyCode(true);

				for(GetCall call : getCalls) {
					String callId = call.getRequestId();
					HttpResponse httpResponse = call.getResponse();
					String convert = EntityUtils.toString(httpResponse.getEntity());
					parsed = ProcessingUtils.parseJson(convert);
					switch(callId) {
					case AppConstants.CASAS:
						if(parsed.isJsonObject()) {
							JsonObject json = parsed.getAsJsonObject();
							if(json.get(AppConstants.CODE_PARAMETER).getAsShort() == 200) {
								boolean found = false;
								JsonElement casaResponse = json.get(AppConstants.DATA_PARAMETER);
								Casa casa =  (Casa) ProcessingUtils.fromJson(casaResponse, Casa.class);
								settlementAccountNumber = casa.getAccountNo();
								settlementInternalAccountId = casa.getId();
								branchCode = StringUtils.substring(settlementAccountNumber, 0, 3);
								referenceId = gen.transactionReferenceId(branchCode);

								settlementAccountNumber = StringUtils.substring(settlementAccountNumber, 3);

								Optional<String> productTypeCheck = request.getProductType();
								productType = productTypeCheck.isPresent() ? productTypeCheck.get() : AppConstants.OTD_PRODUCT_TYPE_CODE;
								currencyCode = casa.getCurrencyHostCode();
								payload.setCurrencyCode(StringUtils.equalsAny(currencyCode, AppConstants.PHP_HOST_CURRENCY_CODE, AppConstants.USD_HOST_CURRENCY_CODE));

								if(enforceAllowedTransactions) {
									List<Map<String, Object>> allowed = casa.getAllowedTransactions();
									if(LOGGER.isDebugEnabled()) {
										LOGGER.debug("Allowed transactions on this account: {}", ProcessingUtils.toJson(allowed, Map.class));
									}

									for(Map<String, Object> entry : allowed) {
										String code = entry.get(AppConstants.CODE_PARAMETER).toString();
										if(StringUtils.equalsIgnoreCase(code, otdTransactionCode)) {
											LOGGER.debug("Allowed transaction match for code {}. Code on account is {}.", otdTransactionCode, code);
											found = true;
											break;
										}
									}

									if(!found) {
										payload.setSettlementAccount(false);
										return returnErrorReport(payload); 
									} else {
										payload.setSettlementAccount(true);
									}
								} else {
									payload.setSettlementAccount(true);
								}
							} else {
								payload.setSettlementAccount(false);
								return returnErrorReport(payload); 
							}
						} else {
							payload.setSettlementAccount(false);
							return returnErrorReport(payload); 
						}
						break;
					case AppConstants.CUSTOMER:
						if(parsed.isJsonObject()) {
							JsonObject json = parsed.getAsJsonObject();
							LOGGER.info("Customer service response: {}", ProcessingUtils.prettify(json.toString()));
							customer = (Customer) ProcessingUtils.fromJson(json.getAsJsonObject(AppConstants.DATA_PARAMETER), Customer.class); 
							if(customer.getCif() != null) {
								payload.setCustomerName(true);
							} else {
								payload.setCustomerName(false);
								return returnErrorReport(payload); 
							}
						} else {
							payload.setCustomerName(false);
							return returnErrorReport(payload); 
						}
						break;
					}
				}

				if(flag == 1) {
					payload.addError(AppConstants.AUTH_CODE_ERROR_TRIGGER);
					payload.setErrors(lockedCheckResponseEntity.get(AppConstants.DATA_PARAMETER).getAsJsonObject().getAsJsonArray(AppConstants.ERRORS_PARAMETER));

					OtdRequest save = new OtdRequest();
					save.setAccountId(settlementAccountNumber);
					save.setInternalAccountId(settlementInternalAccountId);
					save.setAddOnRate(AppConstants.THREE_DECIMAL_FORMATTER.format(actualAddOnRate));
					save.setBaseRate(request.getBaseRate());
					save.setCurrencyCode(currencyCode);
					save.setPlacementAmount(request.getPlacementAmount());
					save.setRolloverInstruction(String.valueOf(request.getRolloverInstruction()));
					save.setTaxFlag(String.valueOf(taxFlagCheck.isPresent() ? taxFlagCheck.get() : taxFlagDefault));
					save.setProductType(productType);
					save.setBranchCode(branchCode);
					save.setReferenceId(referenceId);				
					save.setTerm(term);
					save.setCif(customer.getCif());
					save.setCustomerId(customer.getId());
					save.setTenor(String.valueOf(tenor));

					//new in R4
					String type = getCasaAccountType(settlementAccountNumber);
					save.setAccountType(type);
					LOGGER.info("The following OTD record was saved: {}", ProcessingUtils.toPrettyJson(save, OtdRequest.class));
					requestRepository.save(save);
					payload.setReferenceId(referenceId);

					return Response
							.accepted(ProcessingUtils.parseJson(ProcessingUtils.toJson(payload, ValidationResponse.class)).getAsJsonObject())
							.status(400)
							.build();
				} else {
					return returnErrorReport(payload);
				}
			}			

		}
	}


	private String getCasaAccountType(String settlementAccountNumber) {
		CasaAccountType casaAccountType = CasaAccountType.getType(StringUtils.substring(settlementAccountNumber, 0, 1));
		switch(casaAccountType) {
		case CURRENT_FOREIGN:
		case CURRENT_PESO:
			return AppConstants.CHECKING_APP_ID;
		case SAVINGS_FOREIGN:
		case SAVINGS_PESO:
			return AppConstants.SAVINGS_APP_ID;
		case TIME_DEPOSIT_FOREIGN:
		case TIME_DEPOSIT_PESO:
			//TODO: placeholder until replaced with official type code
			return AppConstants.TD_APP_ID;
		default:
			throw new ValidationException("mbs.validation.account.type.unknown");
		}
	}

	private Response returnErrorReport(ValidationResponse payload) {
		payload.createErrorReport();
		return Response
				.accepted(ProcessingUtils.toJson(payload, ValidationResponse.class))
				.status(400)
				.build();
	}

	private boolean validateBaseRate(String baseRate, String placementAmount, Short tenor) {
		if(NumberUtils.isCreatable(baseRate)) {
			BigDecimal compare = NumberUtils.createBigDecimal(StringUtils.remove(placementAmount, AppConstants.COMMA));
			Set<Entry<String, RateTier>> entries = trueRatesMap.entrySet();

			for(Entry<String, RateTier> entry : entries) {
				RateTier tier = entry.getValue();
				if(tier.getMin().compareTo(compare) <= 0 && tier.getMax().compareTo(compare) >= 0) {
					Set<Entry<String, RatePeriod>> periodEntries = tier.getPeriods().entrySet();
					for(Entry<String, RatePeriod> periodEntry : periodEntries) {
						RatePeriod period = periodEntry.getValue();
						if(period.getMonthStart() <= tenor && period.getMonthEnd() >= tenor) {
							if(NumberUtils.createBigDecimal(period.getRate()).compareTo(NumberUtils.createBigDecimal(baseRate)) == 0) {
								return true;
							} else continue;
						}
					}
				}
			}
		}

		return false;
	}

	private boolean validatePlacementAmount(String placementAmount) {
		String cleaned = StringUtils.remove(placementAmount, AppConstants.COMMA);
		boolean creatable = NumberUtils.isCreatable(cleaned);
		if(creatable) {
			BigDecimal value = NumberUtils.createBigDecimal(cleaned);
			return value.compareTo(AppConstants.OTD_MINIMUM_AMOUNT) >= 0 && value.compareTo(BigDecimal.valueOf(9999999999999.0)) <= 0; 
		}

		return false;
	}

	private boolean validateTenorLength(String term, Short tenor) {
		switch(term) {
		case AppConstants.D:
			return tenor > 0 && tenor < 365;
		case AppConstants.M:
		default:
			return tenor > 0 && tenor < 13;
		}
	}

	public Customer customer(String id, JsonObject accessObject) throws Exception {
		JsonElement response = httpService.get(StringUtils.replace(customerIdSearchBase, AppConstants.ENCLOSED_ID_PARAMETER, id), accessObject);
		Customer customer = (Customer) ProcessingUtils.fromJson(response.getAsJsonObject().get(AppConstants.DATA_PARAMETER), Customer.class);
		return customer;
	}

	public Object getToc() {
		return Response.ok(termsAndConditions).build();
	}

	protected void setToc(JsonElement set) {
		termsAndConditions = set;
	}

	public synchronized void setDisplayRates(JsonElement rates) {
		displayRates = rates;
	}

	public synchronized void setTrueRatesMap(Map<String, RateTier> newMap) {
		trueRatesMap = newMap;
	}

	public RatePeriod getRate(String tier, String period) {
		return trueRatesMap.get(tier).getPeriods().get(period);
	}

	public String[] getTierNames() {
		return tierNames;
	}

	public String[] getPeriodNames() {
		return periodNames;
	}

	public Object details(String id, boolean convert) throws Exception {
		Optional<OtdFedbackRequest> find = fedBackedRequestRepository.findByOtdAccountId(id);

		if(!find.isPresent() || find == null) {
			throw new ResourceNotFoundException();
		}

		OtdFedbackRequest otd = find.get();
		if(otd.terminated()) {
			throw new ValidationException("otd.account.terminated");
		}

		CasaDto casa = getCasaByOtdAccountId(id);
		JsonObject details = getTimeDepositDetails(String.valueOf(casa.getId()));
		LOGGER.info("Time deposit details: {}", details.toString());
		int code = details.get(AppConstants.CODE_PARAMETER).getAsInt();

		if(code != 200) {
			throw new ResourceNotFoundException();
		}

		TimeDepositDetails tdDTO = (TimeDepositDetails) ProcessingUtils.fromJson(details.get(AppConstants.DATA_PARAMETER), TimeDepositDetails.class);
		String settlementAccount = ProcessingUtils.append(otd.getBranchCode(), otd.getAccountId());
		boolean terminable = !tdDTO.getDisableClosingFlag(); 

		String currencyCode;
		switch(otd.getCurrencyCode()) {
		case AppConstants.USD_CURRENCY_CODE:
			currencyCode = AppConstants.USD;
			break;
		case AppConstants.PESO_CURRENCY_CODE:
		default:
			currencyCode = AppConstants.PHP;
		}

		OtdDetailsResponse otdDetails = new OtdDetailsResponse(
				otd.getId(),
				otd.getOtdAccountId(),
				currencyCode,
				AppConstants.TWO_DECIMAL_FORMATTER.format(tdDTO.getPlacementAmount()),
				String.valueOf(tdDTO.getTerm()),
				AppConstants.THREE_DECIMAL_FORMATTER.format(tdDTO.getInterestRate()),
				tdDTO.getMaturityDate(),
				settlementAccount,			
				LocalDate.now().format(AppConstants.MMMMddyyyy));

		otdDetails.setWeekday(ProcessingUtils.checkWeekday());
		otdDetails.setTerminable(terminable);
		return convert ?  Response.ok(ProcessingUtils.toJson(otdDetails, OtdDetailsResponse.class)).build() : otdDetails;
	}

	public Object computeTerminationCosts(String id) throws Exception {
		Optional<OtdFedbackRequest> record = fedBackedRequestRepository.findByOtdAccountId(id);
		if(record.isPresent()) {
			OtdFedbackRequest otd = record.get();
			OtdDetailsResponse response = (OtdDetailsResponse) details(id, false);
			response = esbClient.queryHostForTerminationComputation(otd, response);
			return Response.ok(ProcessingUtils.toJson(response, OtdDetailsResponse.class)).allow().build();
		}

		return Response.serverError().entity(new ResourceNotFoundException()).build();
	}

	public CasaDto getCasaByOtdAccountId(String id) throws Exception {
		String uri = ProcessingUtils.append(casaAccountUri, id);
		LOGGER.info("uri: {}", uri);
		JsonElement response = httpService.get(uri, extractAccessObject());
		LOGGER.info("casa response: {}", ProcessingUtils.prettify(response.toString()));
		JsonObject json = response.getAsJsonObject().getAsJsonObject(AppConstants.DATA_PARAMETER);
		CasaDto casa = (CasaDto) ProcessingUtils.fromJson(json, CasaDto.class);
		return casa;
	}

	public JsonObject getTimeDepositDetails(String accountId) throws Exception {
		String uri = StringUtils.replace(casaTimeDepositUri, AppConstants.ENCLOSED_ID_PARAMETER, accountId);
		LOGGER.info("time deposit uri: {}", uri);
		JsonElement response = httpService.get(uri, extractAccessObject());
		LOGGER.info("response: {}", ProcessingUtils.prettify(response.toString()));
		return response.getAsJsonObject();		
	}

	public CustomerDto getCustomerInformation(String customerId) throws Exception {
		String uri = String.format(customerInfoUri, customerId);
		JsonElement entity = httpService.get(uri, extractAccessObject());
		JsonObject json = entity.getAsJsonObject().getAsJsonObject(AppConstants.DATA_PARAMETER);
		return (CustomerDto) ProcessingUtils.fromJson(json, CustomerDto.class);
	}
}