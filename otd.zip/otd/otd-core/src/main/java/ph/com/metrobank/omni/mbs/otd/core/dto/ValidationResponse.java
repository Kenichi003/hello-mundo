package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;

public class ValidationResponse {
	private String referenceId;
	private transient boolean accountId = true;
	private transient boolean settlementAccount = true;
	private transient boolean placementAmount = true;
	private transient boolean baseRate = true;
//	private transient boolean addOnRate = true;
	private transient boolean term = true;
	private transient boolean rollOverInstructions = true;
	private transient boolean customerName = true;
	private transient boolean currencyCode = true;
	private transient boolean tenor;
	
	private List<ValidationError> errors = new ArrayList<>();
	Map<String, List<ValidationError>> forReturn;
	
	public boolean isSettlementAccount() {
		return settlementAccount;
	}
	
	public void setSettlementAccount(boolean settlementAccount) {
		this.settlementAccount = settlementAccount;
	}
	
	public boolean placementAmount() {
		return placementAmount;
	}
	
	public void setPlacementAmount(boolean placementAmount) {
		this.placementAmount = placementAmount;
	}
	public boolean isBaseRate() {
		return baseRate;
	}
	public void setBaseRate(boolean baseRate) {
		this.baseRate = baseRate;
	}
	
//	public boolean isAddOnRate() {
//		return addOnRate;
//	}
//	
//	public void setAddOnRate(boolean addOnRate) {
//		this.addOnRate = addOnRate;
//	}
	
	public boolean isTerm() {
		return term;
	}
	
	public void setTerm(boolean term) {
		this.term = term;
	}

	public boolean isRollOverInstructions() {
		return rollOverInstructions;
	}
	
	public void setRollOverInstructions(boolean rollOverInstructions) {
		this.rollOverInstructions = rollOverInstructions;
	}

	public void setReferenceId(String id) {
		referenceId = id;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public boolean isCustomerName() {
		return customerName;
	}

	public void setCustomerName(boolean customerName) {
		this.customerName = customerName;
	}
	
	public void addError(ValidationError error) {
		errors.add(error);
	}

	public boolean isPlacementAmount() {
		return placementAmount;
	}

	public boolean isCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(boolean currencyCode) {
		this.currencyCode = currencyCode;
	}
	
	public void createErrorReport() {
		if(!accountId) {
			errors.add(AppConstants.INVALID_ACCOUNT_ID);
		}
		
		if(!settlementAccount) {
			errors.add(AppConstants.INVALID_SETTLEMENT_ACCOUNT);
		}
		
		if(!placementAmount) {
			errors.add(AppConstants.INVALID_PLACEMENT_AMOUNT);
		}
		
		if(!baseRate) {
			errors.add(AppConstants.INVALID_BASE_RATE);
		}
		
//		if(!addOnRate) {
//			errors.add(AppConstants.INVALID_ADD_ON_RATE);
//		}
		
		if(!term) {
			errors.add(AppConstants.INVALID_TERM);
		}
		
		if(!rollOverInstructions) {
			errors.add(AppConstants.INVALID_ROLLOVER_INSTRUCTION);
		}
		
		if(!customerName) {
			errors.add(AppConstants.UNKNOWN_USER_NAME);
		}
		
		if(!currencyCode) {
			errors.add(AppConstants.INVALID_CURRENCY_CODE);
		}
		
		if(!tenor) {
			errors.add(AppConstants.INVALID_TENOR);
		}
	}

	public List<ValidationError> getErrors() {
		return errors;
	}

	public Map<String, List<ValidationError>> getErrorsForReturn() {
		if(forReturn == null) {
			forReturn= new HashMap<>();
			forReturn.put(AppConstants.ERRORS_PARAMETER, errors);
		}
		
		return forReturn;
	}
	
	public void setErrors(List<ValidationError> errors) {
		this.errors = errors;
	}

	public void setTenor(boolean valid) {
		tenor = valid;
	}

	public boolean isAccountId() {
		return accountId;
	}

	public void setAccountId(boolean accountId) {
		this.accountId = accountId;
	}

	public void setErrors(JsonArray json) {
		for(JsonElement entry : json) {	
			errors.add((ValidationError) ProcessingUtils.fromJson(entry, ValidationError.class));
		}
	}
}
