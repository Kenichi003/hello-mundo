package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.util.List;
import java.util.Optional;

public class ValidationRequest {
	private Optional<String> authType = Optional.empty();
	private Optional<String> authValue = Optional.empty();
	private Optional<String> productType = Optional.empty();

	private Optional<String> referenceId;
	private String userName;
	private String accountId;
	private String internalAccountId;
	private String currencyCode;
	private String placementAmount;
	private String tier;
	private String baseRate;
	private String period;
	private String maturityDate;
	private Optional<String> term;
	private Optional<Short> taxFlag;
	private Short tenor;
	private Short rolloverInstruction;
	private List<Short> eulaVersionIdList;
	
	public Optional<String> getAuthType() {
		return authType;
	}

	public void setAuthType(Optional<String> authType) {
		this.authType = authType;
	}

	public Optional<String> getAuthValue() {
		return authValue;
	}

	public void setAuthValue(Optional<String> authValue) {
		this.authValue = authValue;
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Optional<String> getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(Optional<String> referenceId) {
		this.referenceId = referenceId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getPlacementAmount() {
		return placementAmount;
	}

	public void setPlacementAmount(String placementAmount) {
		this.placementAmount = placementAmount;
	}

	public String getBaseRate() {
		return baseRate;
	}

	public void setBaseRate(String baseRate) {
		this.baseRate = baseRate;
	}

//	public String getAddOnRate() {
//		return addOnRate;
//	}
//
//	public void setAddOnRate(String addOnRate) {
//		this.addOnRate = addOnRate;
//	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public Optional<String> getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = Optional.ofNullable(term);
	}

	public Optional<Short> getTaxFlag() {
		return taxFlag;
	}

	public void setTaxFlag(short taxFlag) {
		this.taxFlag = Optional.ofNullable(taxFlag);
	}

	public Short getTenor() {
		return tenor;
	}

	public void setTenor(Short tenor) {
		this.tenor = tenor;
	}

	public Short getRolloverInstruction() {
		return rolloverInstruction;
	}

	public void setRolloverInstruction(Short rolloverInstruction) {
		this.rolloverInstruction = rolloverInstruction;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public void setTerm(Optional<String> term) {
		this.term = term;
	}

	public void setTaxFlag(Optional<Short> taxFlag) {
		this.taxFlag = taxFlag;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public List<Short> getEulaVersionIdList() {
		return eulaVersionIdList;
	}
	
	public void setEulaVersionIdList(List<Short> list) {
		eulaVersionIdList = list;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Optional<String> getProductType() {
		return productType;
	}

	public void setProductType(Optional<String> productType) {
		this.productType = productType;
	}

	public String getInternalAccountId() {
		return internalAccountId;
	}

	public void setInternalAccountId(String internalAccountId) {
		this.internalAccountId = internalAccountId;
	}
}
