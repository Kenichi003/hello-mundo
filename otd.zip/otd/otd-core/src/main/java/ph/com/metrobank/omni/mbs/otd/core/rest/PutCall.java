package ph.com.metrobank.omni.mbs.otd.core.rest;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.http.HttpResponse;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PutCall implements Callable<HttpResponse> {
	private static final Logger LOGGER = LoggerFactory.getLogger(PutCall.class);

	private String id;
	private CloseableHttpAsyncClient client;
	private HttpContext context;
	private JsonTypePut request;
	private HttpResponse response;

	public PutCall(CloseableHttpAsyncClient client, String id, JsonTypePut req){
		this.id = id;
		this.client = client;
		context = HttpClientContext.create();
		request = req;
	}

	public HttpResponse getResponse() {
		return response;
	}

	public String getRequestId() {
		return id;
	}

	@Override
	public HttpResponse call() throws InterruptedException, ExecutionException, TimeoutException {
		Future<HttpResponse> future = client.execute(request, context, null);
		if(future != null) {
			response = future.get(120000, TimeUnit.MILLISECONDS);
		} else {
			LOGGER.info("{}: Request timeout.", id);
		}

		return response;
	}
}