package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.io.Serializable;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;

public class NotificationTemplateDto implements Serializable {

	private static final long serialVersionUID = 6723699681391546848L;
	protected String title;
	private String notificationDate;
	private String expirationDate;
	
	protected NotificationBody body = new NotificationBody();
	protected NotificationPayload payload = new NotificationPayload();
	protected NotificationFilter filter = new NotificationFilter();
	
	public NotificationTemplateDto() {
//		payload.setStatus(AppConstants.SUCCESS);
		payload.setMeta(AppConstants.JSON_ENCLOSED);
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(String notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public NotificationBody getBody() {
		return body;
	}

	public void setBody(NotificationBody body) {
		this.body = body;
	}

	public NotificationPayload getPayload() {
		return payload;
	}

	public void setPayload(NotificationPayload payload) {
		this.payload = payload;
	}

	public NotificationFilter getFilter() {
		return filter;
	}

	public void setFilter(NotificationFilter filter) {
		this.filter = filter;
	}
}
