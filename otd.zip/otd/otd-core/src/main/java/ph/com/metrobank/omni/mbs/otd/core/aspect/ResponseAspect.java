package ph.com.metrobank.omni.mbs.otd.core.aspect;

import javax.ws.rs.core.Response;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.glassfish.jersey.message.internal.OutboundJaxrsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.gson.JsonElement;

import ph.com.metrobank.omni.mbs.otd.core.dto.ServerErrorResponse;
import ph.com.metrobank.omni.mbs.otd.core.dto.SpecialSuccessResponse;
import ph.com.metrobank.omni.mbs.otd.core.dto.SuccessResponse;
import ph.com.metrobank.omni.mbs.otd.core.dto.UnauthorizedResponse;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;

@Aspect
@Component
public class ResponseAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseAspect.class);

	@Value("${app.name}")
	private String appName;

	@Value("${app.version}")
	private String appVersion;

	@Around(value = "execution(* ph.com.metrobank.omni.mbs.otd.core.endpoint..*.*(..))")
	public Object createResponse(ProceedingJoinPoint joinPoint) throws Throwable {
		String method = joinPoint.getSignature().getName();
		LOGGER.info("Starting method execution for {}", method);
		Object result = joinPoint.proceed();
		LOGGER.info("Finished execution of {}.", method);

		try(OutboundJaxrsResponse out = (OutboundJaxrsResponse) result; ) {
			switch(out.getStatus()) {
			case 400:
				return Response
						.accepted(ProcessingUtils.toJson(new SpecialSuccessResponse(out.getEntity(), appName, appVersion), SpecialSuccessResponse.class))
						.status(400)
						.build();
			case 401:
				return Response
						.accepted(ProcessingUtils.toJson(new UnauthorizedResponse(out.getEntity(), appName, appVersion), UnauthorizedResponse.class))
						.status(401)
						.build();
			case 500:
				return Response
						.serverError()
						.entity(ProcessingUtils.toJson(new ServerErrorResponse(out.getEntity(), appName, appVersion), ServerErrorResponse.class))
						.build();
			case 200:
			default:
				JsonElement convertToWorkAroundGsonVsJacksonJsonAsStringLiteralIssue = ProcessingUtils.parseJson(out.getEntity().toString());
				return Response
						.ok(ProcessingUtils.toJson(new SuccessResponse(convertToWorkAroundGsonVsJacksonJsonAsStringLiteralIssue, appName, appVersion), SuccessResponse.class))
						.build();
			}
		} catch(Exception e ) {
			LOGGER.error("Error:", e);
			throw e;
		}
		
	}
}
