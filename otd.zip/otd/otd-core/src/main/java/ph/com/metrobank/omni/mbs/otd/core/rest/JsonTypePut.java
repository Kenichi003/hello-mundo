package ph.com.metrobank.omni.mbs.otd.core.rest;

import java.io.UnsupportedEncodingException;
import java.util.Optional;

import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;

public class JsonTypePut extends HttpPut {

	public JsonTypePut(String uri, Optional<String> entityValue, Optional<String> authHeader) throws UnsupportedEncodingException {
		super(uri);
		setHeader("Accept", AppConstants.APPLICATION_JSON_TYPE);
		setHeader("Content-type", AppConstants.APPLICATION_JSON_TYPE);
		
		if(entityValue.isPresent()) {
			setEntity(new StringEntity(entityValue.get()));
		}
		
		if(authHeader.isPresent()) {
			setHeader("Authorization", authHeader.get());
		}

	}
}
