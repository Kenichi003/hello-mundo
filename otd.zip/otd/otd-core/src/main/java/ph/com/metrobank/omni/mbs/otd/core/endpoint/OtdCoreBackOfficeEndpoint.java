package ph.com.metrobank.omni.mbs.otd.core.endpoint;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.model.OtdSuccessfulDispatchDetails;
import ph.com.metrobank.omni.mbs.otd.core.repository.webengine.OtdSuccessfulDispatchTimeRepository;
import ph.com.metrobank.omni.mbs.otd.core.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.core.service.GenerationService;

@Path("/back-office")
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Component
@Api(value = "Back-office Endpoints", produces = "application/json")
public class OtdCoreBackOfficeEndpoint extends AbstractEnd {

	@Autowired
	private GenerationService gen;

	@Autowired
	OtdSuccessfulDispatchTimeRepository timeKeeper;
	
	private java.nio.file.Path hostAcknowledegmentPath;
	private java.nio.file.Path ratesPath;
	private java.nio.file.Path uploadFilePath;
	
	@Override
	protected void initialize() throws Throwable {
		java.nio.file.Path parent = Paths.get(env.getProperty("path.dropFolder"));
		hostAcknowledegmentPath = parent.resolve(env.getProperty("path.firstFeedbackFile")); 
		ratesPath = parent.resolve(env.getProperty("path.hostRatesFile")); 
		uploadFilePath = parent.resolve(env.getProperty("path.uploadFile")); 
	}
	
	
	@GET
	@Path("/reset-dispatch-date-lock/{date}")
	@ApiOperation(value = "This resets the timestamp of the last successful dispatch. Format will be ddMMMyyyy (day, month, and year e.g. 18062019 for June 18, 2019). Time will be set to midnight (00:00)", response = Object.class)
	public Object resetDispatchDateLock(@PathParam("date") String date) {
		Optional<OtdSuccessfulDispatchDetails> find = timeKeeper.findById(AppConstants.LONG_ONE);
		if(find.isPresent()) {
			OtdSuccessfulDispatchDetails time = find.get();
			time.setUpdated(LocalDate.parse(date, AppConstants.TIMESTAMP_RESET_FORMATTER).atStartOfDay());
			timeKeeper.save(time);
			return AppConstants.SUCCESS_MESSAGE;
		}
		
		return AppConstants.INVALID_MESSAGE;
	}
	
	@GET
	@Path("/dispatch")
	@ApiOperation(value = "Manual creation of OTD requests dispatch file.", response = Object.class)
	public Object dispatch() {
 		return gen.dispatch(LocalDateTime.now());
	}
	
	@GET
	@Path("/last-dispatch-timestamp")
	@ApiOperation(value = "Gets the last recorded dispatch timestamp.", response = Object.class)
	public Object lastDispatchTimestamp() {
		 Optional<OtdSuccessfulDispatchDetails> last = timeKeeper.findById(AppConstants.LONG_ONE);
		 if(last.isPresent()) {
			 OtdSuccessfulDispatchDetails timestamp = last.get();
			 return timestamp.toString();
		 }
 		return "{}";
	}
	
	@GET	
	@Path("/read-first")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object readFirstFeedback() throws Exception {
		return new String(Files.readAllBytes(hostAcknowledegmentPath));
	}
	
	@GET	
	@Path("/read-rates")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object readRates() throws Exception {
		return new String(Files.readAllBytes(ratesPath));
	}
	
	@GET	
	@Path("/read-dispatch")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object readDispatch() throws Exception {
		return new String(Files.readAllBytes(uploadFilePath));
	}
}
