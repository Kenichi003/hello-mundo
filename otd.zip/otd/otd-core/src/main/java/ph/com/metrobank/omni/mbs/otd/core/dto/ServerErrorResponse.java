package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.util.Date;

public class ServerErrorResponse extends JSendResponse {

  /**
   * 
   * @param data
   * @param appName
   * @param appVersion
   */
  public ServerErrorResponse(Object data, String appName, String appVersion) {
    init();
    this.setProgramName(appName);
    this.setVersion(appVersion);
    this.setData(data);
  }

  private void init() {
    this.setStatus(JSendResponse.ResponseStatus.FAIL.name());
    this.setDatetime(new Date());
    this.setCode(500);
  }

}
