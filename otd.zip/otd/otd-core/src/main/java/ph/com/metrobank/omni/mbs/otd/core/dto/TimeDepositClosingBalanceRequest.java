package ph.com.metrobank.omni.mbs.otd.core.dto;

public class TimeDepositClosingBalanceRequest extends EsbBaseRequest {
	private InquireTDClosingBalanceInput InquireTDClosingBalanceInput = new InquireTDClosingBalanceInput(); //inquireTimeDepositClosingBalanceInput;
	private TransactionInformation TransactionInformation = new TransactionInformation();
	
	public TransactionInformation getTransactionInformation() {
		return TransactionInformation;
	}

	public void setTransactionInformation(TransactionInformation transactionInformation) {
		this.TransactionInformation = transactionInformation;
	}

	public InquireTDClosingBalanceInput getInquireTimeDepositClosingBalanceInput() {
		return InquireTDClosingBalanceInput;
	}

	public void setInquireTimeDepositClosingBalanceInput(InquireTDClosingBalanceInput inquireTimeDepositClosingBalanceInput) {
		InquireTDClosingBalanceInput = inquireTimeDepositClosingBalanceInput;
	}
}
