package ph.com.metrobank.omni.mbs.otd.core.exception;

import javax.ws.rs.BadRequestException;
import javax.ws.rs.core.Response;

public class ValidationException extends BadRequestException {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  public ValidationException(String message) {
    super(message);
  }

  public ValidationException(String message, Throwable e) {
    super(message, e);
  }
  
  public ValidationException(Response response) {
	    super(response);
 }
}
