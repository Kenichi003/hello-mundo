package ph.com.metrobank.omni.mbs.otd.core.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;

@Entity
@Table(name = "otd_successful_dispatch_time")
public class OtdSuccessfulDispatchDetails {

	@Id
	@Column(unique = true, nullable = false)
	private Long id;

	@Column(nullable = false)
	private Timestamp created;

	@Column(unique = true)
	private Timestamp updated;

	public Long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@PrePersist
	void preInsert() {
		created = Timestamp.valueOf(LocalDateTime.now());
	}

	//	@PreUpdate
	//	void preUpdate() {
	//		updated = Timestamp.valueOf(LocalDateTime.now());
	//	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public Timestamp getUpdated() {
		return updated;
	}

	public void setUpdated(Timestamp updated) {
		this.updated = updated;
	}

	public void setUpdated(LocalDateTime updated) {
		this.updated = Timestamp.valueOf(updated);
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return AppConstants.FOR_QUERYING_LAST_SUCCESSFUL_DISPATCH_TIMESTAMP.format(updated.toLocalDateTime());
	}
}
