package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.util.Date;
import javax.ws.rs.core.Response;

public class UnauthorizedResponse extends JSendResponse {

  /**
   * 
   * @param data
   * @param appName
   * @param appVersion
   */
  public UnauthorizedResponse(Object data, String appName, String appVersion) {
    init();
    this.setProgramName(appName);
    this.setVersion(appVersion);
    this.setData(data);
  }

  private void init() {
    this.setStatus(JSendResponse.ResponseStatus.FAIL.name());
    this.setDatetime(new Date());
    this.setCode(Response.Status.UNAUTHORIZED.getStatusCode());
  }

}
