
package ph.com.metrobank.omni.mbs.otd.core.soap;
import java.io.IOException;
import java.io.StringReader;
import java.util.concurrent.Callable;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SoapClient implements Callable<SOAPMessage>{
	private static final Logger LOGGER = LoggerFactory.getLogger(SoapClient.class);
	
	private static SOAPConnectionFactory soapConnectionFactory;	
	static {
        try {
			soapConnectionFactory = SOAPConnectionFactory.newInstance();
		} catch (Exception e) {
        	LOGGER.error("Error while creating SOAP factory:", e);
		}
	}
	private String url;
	private String input;
	private SOAPMessage response;
	
    public SoapClient(String service, String input) {
    	url = service;
    	this.input = input;
	}

    public String getCall() {
    	return url;
    }
    
    private void createSoapEnvelope(SOAPMessage soapMessage, String input) throws SOAPException, IOException {
        SOAPPart soapPart = soapMessage.getSOAPPart();
		soapPart.setContent(new StreamSource(new StringReader(input)));
    }

    private SOAPMessage createSOAPRequest(String content) throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();

        createSoapEnvelope(soapMessage, content);
        soapMessage.saveChanges();

        return soapMessage;
    }

	@Override
	public SOAPMessage call() throws Exception {
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();
        try {
            response = soapConnection.call(createSOAPRequest(input), url);
        } catch (Exception x) {
        	LOGGER.error("Error while processing SOAP request:", x);
        	throw x;
        } finally {
        	soapConnection.close();
        }
        
        return response; 
	}

	public SOAPMessage getResponse() {
		return response;
	}
}	