package ph.com.metrobank.omni.mbs.otd.core.dto;

public class MpinServiceTransactionRequest extends MpinServiceRequest {

	private String transaction;

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
}
