package ph.com.metrobank.omni.mbs.otd.core.dto;

import org.springframework.stereotype.Component;

@Component
public class EsbCredentials {
	private String systemID;
	private String password;
	
	public EsbCredentials() {
	}
	
	public EsbCredentials(String id, String esbPassword) {
		systemID = id;
		password = esbPassword;
	}
	
	public String getSystemId() {
		return systemID;
	}
	public void setSystemId(String systemId) {
		this.systemID = systemId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
