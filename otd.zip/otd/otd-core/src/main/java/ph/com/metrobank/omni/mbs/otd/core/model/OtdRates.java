package ph.com.metrobank.omni.mbs.otd.core.model;

import java.math.BigDecimal;

import com.google.common.collect.ListMultimap;

public class OtdRates {

	private int tier;
	private ListMultimap<String, BigDecimal> periods;

	public OtdRates() {
		
	}
	
	public int getTier() {
		return tier;
	}
	public void setTier(int tier) {
		this.tier = tier;
	}
	
	public ListMultimap<String, BigDecimal> getPeriods() {
		return periods;
	}
	public void setPeriods(ListMultimap<String, BigDecimal> periods) {
		this.periods = periods;
	}
}
