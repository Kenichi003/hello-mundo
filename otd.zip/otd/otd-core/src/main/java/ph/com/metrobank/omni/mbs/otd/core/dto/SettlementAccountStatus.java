package ph.com.metrobank.omni.mbs.otd.core.dto;

public class SettlementAccountStatus {
	private boolean active;

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
}
