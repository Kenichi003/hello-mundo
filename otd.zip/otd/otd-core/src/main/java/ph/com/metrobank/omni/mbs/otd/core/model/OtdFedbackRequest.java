package ph.com.metrobank.omni.mbs.otd.core.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;

@Entity
@Table(name = "otd_requests")
@PositionalRecord
public class OtdFedbackRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4312733753422742508L;

	@Id
	@SequenceGenerator(name = "otd_request_id_gen", sequenceName = "otd_request_id_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "otd_request_id_gen")
	@Column(unique = true, nullable = false)
	private Long id;

	@Column(name = "reference_id", unique = true, nullable = false)
	private String referenceId;

	@Column(name = "customer_id", unique = true, nullable = false)
	private String customerId;
	
	@Column(unique = true, nullable = false)
	private String cif;

	@Column(name = "currency_code", nullable = false)
	private String currencyCode;
	
	@Column(name = "branch_code", nullable = false)
	private String branchCode;
	
	//settlement account number
	@Column(name = "account_id", nullable = false)
	private String accountId;

	@Column(name = "product_type", nullable = false)
	private String productType;
	
	@Column(name = "placement_amount", nullable = false)
	private String placementAmount;

	@Column(name = "base_rate", nullable = false)
	private String baseRate;
	
	@Column(name = "add_on_rate", nullable = false)
	private String addOnRate;
	
	@Column(name = "term", nullable = false)
	private String term;
	
	@Column(name = "tax_flag", nullable = false)
	private String taxFlag;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column()
	private Timestamp created;

	@Column()
	private Timestamp updated;

	@Column()
	private String tenor;

	@Column(name="rollover_instruction")
	private String rolloverInstruction;

	@Column(name="opening_status_flag")
	private String openingStatusFlag;

	@Column()
	private String remarks;

	@Column(name="account_name")
	private String accountName;

	@Column(name="confirmation_advice_number")
	private String confirmationAdviceNumber;
	
	@Column(name="depository_branch")
	private String depositoryBranch;
	
	@Column(name="otd_account_id")
	private String otdAccountId;
	
	@Column()
	private String currency;

	@Column(name="transaction_date")
	private Timestamp transactionDate;

	@Column(name="maturity_date")
	private Timestamp maturityDate;

	@Column(name="otd_account_name")
	private String otdAccountName;
	
	@Column(name="termination_reference_id")      
	private String terminationReferenceId;

	@Column(name="termination_transaction_date")  
	private Timestamp terminationTransactionDate;

	@Column(name="terminated")              
	private boolean terminated;
	
	//MBO settlement account id
	@Column(name="internal_account_id")
	private String internalAccountId;
	
	@Column(name="account_type")
	private String accountType;

	private transient String maturityDateFromFile;
	private transient String transactionDateFromFile;

	
	public String getOtdAccountName() {
		return otdAccountName;
	}

	public void setOtdAccountName(String otdAccountName) {
		this.otdAccountName = otdAccountName;
	}
	
	@PrePersist
	void preInsert() {
		created = Timestamp.valueOf(LocalDateTime.now());
	}

	@PreUpdate
	void preUpdate() {
		updated = Timestamp.valueOf(LocalDateTime.now());
	}

	@PositionalField(initialPosition = 1, finalPosition = 24)
	public String getReferenceId() {
		return referenceId;
	}
	
	public void setReferenceId(String id) {
		this.referenceId = id;
	}

	@PositionalField(initialPosition = 25, finalPosition = 38)
	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}
	
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@PositionalField(initialPosition = 39, finalPosition = 41)
	public String getCurrencyCode() {
		return currencyCode;
	}
	
	public void setCurrencyCode(String code) {
		currencyCode = code;
	}

	
	@PositionalField(initialPosition = 42, finalPosition = 44)
	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	@PositionalField(initialPosition = 45, finalPosition = 54)
	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	@PositionalField(initialPosition = 55, finalPosition = 57)
	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	@PositionalField(initialPosition = 58, finalPosition = 72)
	public String getPlacementAmount() {
		return placementAmount;
	}

	public String getTransformedPlacementAmount() {
		return ProcessingUtils.append(StringUtils.substring(placementAmount, 0, StringUtils.length(placementAmount) -  2), ".", StringUtils.substring(placementAmount, StringUtils.length(placementAmount) -  2));
	}
	
	public void setPlacementAmount(String placementAmount) {
		this.placementAmount = placementAmount;
	}

	@PositionalField(initialPosition = 73, finalPosition = 81)
	public String getBaseRate() {
		return baseRate;
	}

	public String getTransformedBaseRate() {
		return ProcessingUtils.append(StringUtils.substring(baseRate, 0, StringUtils.length(baseRate) -  8), ".", StringUtils.substring(placementAmount, StringUtils.length(baseRate) -  8));
	}
	
	public void setBaseRate(String baseRate) {
		this.baseRate = baseRate;
	}

	@PositionalField(initialPosition = 82, finalPosition = 90)
	public String getAddOnRate() {
		return addOnRate;
	}

	public String getTransformedAddOnRate() {
		return ProcessingUtils.append(StringUtils.substring(addOnRate, 0, StringUtils.length(addOnRate) -  8), ".", StringUtils.substring(placementAmount, StringUtils.length(addOnRate) -  8));
	}
	public void setAddOnRate(String addOnRate) {
		this.addOnRate = addOnRate;
	}

	@PositionalField(initialPosition = 91, finalPosition = 91)
	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	@PositionalField(initialPosition = 92, finalPosition = 94)
	public String getTenor() {
		return tenor;
	}

	public void setTenor(String tenor) {
		this.tenor = StringUtils.leftPad(tenor, 3, '0');
	}

	@PositionalField(initialPosition = 95, finalPosition = 95)
	public String getRolloverInstruction() {
		return rolloverInstruction;
	}

	public void setRolloverInstruction(String rolloverInstruction) {
		this.rolloverInstruction = rolloverInstruction;
	}

	@PositionalField(initialPosition = 96, finalPosition = 96)
	public String getTaxFlag() {
		return taxFlag;
	}

	public void setTaxFlag(String taxFlag) {
		this.taxFlag = taxFlag;
	}

	@PositionalField(initialPosition = 97, finalPosition = 97)
	public String getOpeningStatusFlag() {
		return openingStatusFlag;
	}

	public void setOpeningStatusFlag(String openingStatusFlag) {
		this.openingStatusFlag = openingStatusFlag;
	}

	@PositionalField(initialPosition = 98, finalPosition = 117)
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@PositionalField(initialPosition = 118, finalPosition = 277)
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@PositionalField(initialPosition = 278, finalPosition = 297)
	public String getConfirmationAdviceNumber() {
		return confirmationAdviceNumber;
	}

	public void setConfirmationAdviceNumber(String confirmationAdviceNumber) {
		this.confirmationAdviceNumber = confirmationAdviceNumber;
	}

	@PositionalField(initialPosition = 298, finalPosition = 331)
	public String getDepositoryBranch() {
		return depositoryBranch;
	}

	public void setDepositoryBranch(String depositoryBranch) {
		this.depositoryBranch = depositoryBranch;
	}

	@PositionalField(initialPosition = 332, finalPosition = 345)
	public String getOtdAccountId() {
		return otdAccountId;
	}

	public void setOtdAccountId(String accountId) {
		otdAccountId = accountId;
	}

	@PositionalField(initialPosition = 346, finalPosition = 375)
	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	@PositionalField(initialPosition = 376, finalPosition = 383)
	public String getTransactionDateFromFile() {
		return transactionDateFromFile;
	}

	public void setTransactionDateFromFile(String transactionDate) {
		this.transactionDateFromFile = transactionDate;
	}

	@PositionalField(initialPosition = 384, finalPosition = 391)
	public String getMaturityDateFromFile() {
		return maturityDateFromFile;
	}

	public void setMaturityDateFromFile(String maturityDate) {
		this.maturityDateFromFile = maturityDate;
	}
	
	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public Timestamp getUpdated() {
		return updated;
	}

	public void setUpdated(Timestamp updated) {
		this.updated = updated;
	}

	public Timestamp getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Timestamp transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Timestamp getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Timestamp maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getTerminationReferenceId() {
		return terminationReferenceId;
	}

	public void setTerminationReferenceId(String terminationReferenceId) {
		this.terminationReferenceId = terminationReferenceId;
	}

	public Timestamp getTerminationTransactionDate() {
		return terminationTransactionDate;
	}

	public void setTerminationTransactionDate(Timestamp terminationTransactionDate) {
		this.terminationTransactionDate = terminationTransactionDate;
	}

	public boolean terminated() {
		return terminated;
	}

	public void setTerminated(boolean terminated) {
		this.terminated = terminated;
	}

	public String getInternalAccountId() {
		return internalAccountId;
	}

	public void setInternalAccountId(String internalAccountId) {
		this.internalAccountId = internalAccountId;
	}

	public boolean isTerminated() {
		return terminated;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountType() {
		return accountType;
	}
}
