package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.util.Date;

public class SpecialSuccessResponse extends JSendResponse {

  /**
   * 
   * @param data
   * @param appName
   * @param appVersion
   */
  public SpecialSuccessResponse(Object data, String appName, String appVersion) {
    init();
    this.setProgramName(appName);
    this.setVersion(appVersion);
    this.setData(data);
  }

  private void init() {
    this.setStatus(JSendResponse.ResponseStatus.SUCCESS.name());
    this.setDatetime(new Date());
    this.setCode(400);
  }

}
