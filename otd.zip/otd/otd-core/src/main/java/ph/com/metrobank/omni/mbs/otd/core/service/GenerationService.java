package ph.com.metrobank.omni.mbs.otd.core.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;
import ph.com.metrobank.omni.mbs.otd.core.factory.ThreadFactory;
import ph.com.metrobank.omni.mbs.otd.core.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.core.util.ProcessingUtils;
import ph.com.metrobank.omni.mbs.otd.core.writer.OtdRequestDispatchFileWriter;

@Service
public class GenerationService extends AbstractEnd {
	public enum When {
		DAY,
		NIGHT,
		STARTUP;
	}
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GenerationService.class);

	@PersistenceContext
	@Autowired
	private EntityManager em;
	
	@Autowired
	private OtdRequestDispatchFileWriter requestDispatchWriter;

	@Value("${toggle.dispatcher}")
	private String dispatcherValue;

	@Value("${value.generateUploadTime}")
	private String generateUploadTime;

	@Override
	protected void initialize() throws Throwable {
		if(Boolean.valueOf(dispatcherValue)) {
			DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");

			RefreshTask tenTask = new RefreshTask(generateUploadTime, When.NIGHT);
			LocalTime ten = LocalTime.from(timeFormatter.parse(generateUploadTime));
			LocalTime now = LocalTime.now();
			long tenStart = 0;

			final ScheduledExecutorService tenScheduler = Executors.newScheduledThreadPool(1);

			if(now.isBefore(ten)) {
				tenStart = ChronoUnit.SECONDS.between(now, ten);
				tenScheduler.scheduleAtFixedRate(tenTask, tenStart, 86400, TimeUnit.SECONDS);
			} else {
				tenStart = 86400 - ChronoUnit.SECONDS.between(ten, now);
				tenScheduler.scheduleAtFixedRate(tenTask, tenStart, 86400, TimeUnit.SECONDS);
			}			

			LOGGER.info("Minutes before {} launch {}. Time breakdown is {} hours and {} minutes ", generateUploadTime,
					tenStart / 60, tenStart /
					3600, (tenStart % 3600)/60);
		}
	}

	public Object cycle() {
		LocalDateTime now = LocalDateTime.now();
		switch(now.getDayOfWeek()) {
		case SATURDAY:
		case SUNDAY:
			if(LOGGER.isInfoEnabled())
				LOGGER.info("{}: Weekend, skipping generation of upload file...", now);
			break;
		default:
			LOGGER.info("{}: Generating OTD request file...", now);
			dispatch(now);
		}
		
		return null;
	}

	public Object dispatch(LocalDateTime now) {
		try {
			LOGGER.info("Customer record count: {}.", requestDispatchWriter.createDispatchFile(now));
		} catch (Exception e) {
			LOGGER.error("Error creating OTD dispatch file:", e);
			return AppConstants.FAILURE_MESSAGE;
		} 

		return AppConstants.SUCCESS_MESSAGE;
	}

	public String transactionReferenceId(String branchCode) {
		ZonedDateTime now = ZonedDateTime.now();
		return StringUtils.rightPad(ProcessingUtils.append(AppConstants.TRANSACTION_REFERENCE_ID_DATE_FORMATTER.format(now), branchCode, String.valueOf(now.toInstant().toEpochMilli())), 24, '0');
	}

	public class RefreshTask implements Runnable {
		
		private CharSequence schedule;
		private When when;
		
		public RefreshTask(CharSequence time, When when) {
			schedule = time;
			this.when = when;
		}

		public When when() {
			return when;
		}

		@Override
		public void run() {
			LocalDateTime now = LocalDateTime.now();
			LOGGER.info("Creating upload file @ {}.", schedule, now.toString());

			Future<Void> future = ThreadFactory.POOL.submit(() -> {
				cycle();
				return null;
			});

			try {
				future.get();
			} catch (Exception e) {
				LOGGER.error("Error during refresh cycle:", e);
				return;
			}

			LOGGER.info("Successfully created upload file...");
		}

	}
}