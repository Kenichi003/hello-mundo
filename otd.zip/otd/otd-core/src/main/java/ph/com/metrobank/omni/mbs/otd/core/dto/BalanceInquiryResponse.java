package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.io.Serializable;
import java.util.Date;

public class BalanceInquiryResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9133452319721836712L;
	private Double currentBalance;
	private Double availableBalance;
	private Date maturityDate;
	private Double principalAmount;
	private Integer term;
	private Double interestRate;
	private String period;
	private Boolean disableClosingFlag;

	public Double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(Double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public Double getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(Double availableBalance) {
		this.availableBalance = availableBalance;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Double getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(Double principalAmount) {
		this.principalAmount = principalAmount;
	}

	public Integer getTerm() {
		return term;
	}

	public void setTerm(Integer term) {
		this.term = term;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public Boolean getDisableClosingFlag() {
		return disableClosingFlag;
	}

	public void setDisableClosingFlag(Boolean disableClosingFlag) {
		this.disableClosingFlag = disableClosingFlag;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("{\"currentBalance\":\"");
		builder.append(currentBalance);
		builder.append("\", \"availableBalance\":\"");
		builder.append(availableBalance);
		builder.append("\", \"maturityDate\":\"");
		builder.append(maturityDate);
		builder.append("\", \"principalAmount\":\"");
		builder.append(principalAmount);
		builder.append("\", \"term\":\"");
		builder.append(term);
		builder.append("\", \"interestRate\":\"");
		builder.append(interestRate);
		builder.append("\", \"period\":\"");
		builder.append(period);
		builder.append("\", \"disableClosingFlag\":\"");
		builder.append(disableClosingFlag);
		builder.append("\"}");
		return builder.toString();
	}
}
