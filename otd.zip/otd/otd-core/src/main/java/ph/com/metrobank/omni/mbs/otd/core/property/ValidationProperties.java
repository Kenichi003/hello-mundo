package ph.com.metrobank.omni.mbs.otd.core.property;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;

//@Configuration
//@PropertySource("classpath:validation-values.otd")
//@ConfigurationProperties(prefix = "prop.otd")
public class ValidationProperties { 	
	private static Logger LOGGER = LoggerFactory.getLogger(ValidationProperties.class);

	@Value("${path.validationValues}")
	private String path;

	@Value("${path.resources}")
	private String resourceFolder;
	String userName;
	String referenceIdLength;
	String accountTypes;
	String checkDigits;
	String reservedProductTypes;
	String rolloverInstructions;
	String maturityValue;
	
	List<String> accountTypesList;
	List<String> checkDigitsList;
	List<String> rolloverInstructionsList;
//	List<String> taxFlagsList;

	byte maturityIndicator;
	byte referenceIdLengthValue;


	public List<String> getAccountTypesList() {
		return accountTypesList;
	}

//	public List<String> getBranchCodesList() {
//		return branchCodesList;
//	}

	public List<String> getCheckDigitsList() {
		return checkDigitsList;
	}

//	public List<String> getProductTypesList() {
//		return productTypesList;
//	}

	public List<String> getRolloverInstructionsList() {
		return rolloverInstructionsList;
	}

	@PostConstruct
	public void updateFromFile() throws IOException {
		Path file = Paths.get(AppConstants.RELATIVE_PATH_BASE, resourceFolder, path);
		if(Files.exists(file)) {
			LOGGER.info("Attempting properties update from file...");
	        try (InputStream input = new FileInputStream(file.toFile())) {
	            Properties prop = new Properties();
	            prop.load(input);

	        	maturityValue = prop.getProperty("prop.otd.maturityValue", "2");
	        	referenceIdLength = prop.getProperty("prop.otd.referenceIdLength", "24");
	            maturityIndicator = Byte.valueOf(maturityValue);
	            accountTypesList = new ArrayList<>();
	        	checkDigitsList = new ArrayList<>();
	        	rolloverInstructionsList = new ArrayList<>();

	            Collections.addAll(accountTypesList, StringUtils.split(prop.getProperty("prop.otd.accountTypes", ",")));
	            Collections.addAll(checkDigitsList, StringUtils.split(prop.getProperty("prop.otd.checkDigits", ",")));
	            Collections.addAll(rolloverInstructionsList, StringUtils.split(prop.getProperty("prop.otd.rolloverInstructions", ",")));
	        }
	        
			LOGGER.info("Update complete...");
		}
	}

	public byte getMaturityIndicator() {
		return maturityIndicator;
	}

	public void setMaturityIndicator(byte maturityIndicator) {
		this.maturityIndicator = maturityIndicator;
	}

	public String getReferenceIdLength() {
		return referenceIdLength;
	}

	public void setReferenceIdLength(String referenceIdLength) {
		this.referenceIdLength = referenceIdLength;
	}

	public byte getReferenceIdLengthValue() {
		return referenceIdLengthValue;
	}

	public void setReferenceIdLengthValue(byte referenceIdLengthValue) {
		this.referenceIdLengthValue = referenceIdLengthValue;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
}