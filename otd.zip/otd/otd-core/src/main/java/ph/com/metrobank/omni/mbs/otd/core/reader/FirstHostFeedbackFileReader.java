package ph.com.metrobank.omni.mbs.otd.core.reader;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

import ph.com.metrobank.omni.mbs.otd.core.AppConstants;

@Component
public class FirstHostFeedbackFileReader {
	private static final Logger LOGGER = LoggerFactory.getLogger(FirstHostFeedbackFileReader.class);

	private FlatFileReaderDefinition ffDefinition;

	@PostConstruct
	private void initialize() throws FFPojoException {
		ffDefinition = new FlatFileReaderDefinition(FirstFeedback.class);
	}

	@PositionalRecord
	public static class FirstFeedback {
		private String code;
		private String date;
		private String processFlag;

		@PositionalField(initialPosition = 2, finalPosition = 9)
		public String getDate() {
			return date;
		}
		
		public void setDate(String date) {
			this.date = date;
		}

		@PositionalField(initialPosition = 10, finalPosition = 10)
		public String getProcessFlag() {
			return processFlag;
		}
		public void setProcessFlag(String flag) {
			processFlag = flag;
		}

		@PositionalField(initialPosition = 1, finalPosition = 1)
		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

	}

	public boolean read(Path inputPath) throws Exception {
		if (Files.exists(inputPath)) {
			FlatFileReader ffReader = null;
			try {
				File inputFile = inputPath.toFile();
				ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
				FirstFeedback feedback = null;
				for (Object record : ffReader) {
					if(record instanceof FirstFeedback)
						feedback = (FirstFeedback) record;
				}

				if(feedback != null) {
					String headerDate = feedback.getDate();
					LOGGER.info("Header date on file: {}", headerDate);
					LocalDate compare = LocalDate.parse(headerDate, AppConstants.NOTIFICATION_DATE_FORMATTER);
					if(!compare.isBefore(LocalDate.now())) {
						switch(feedback.getProcessFlag()) {
						case AppConstants.ZERO_STRING:
							LOGGER.info("The host responded that there were errors in the upload for {}.", headerDate);
							return false;
						case AppConstants.ONE_STRING:
							LOGGER.info("The host acknowledges that the upload for {} is good.", headerDate);
	 						return true;
						}
					}
				}
			} catch(Exception e) {
				LOGGER.error("Error processing first host feedback file:", e);
				throw e;
			} finally {
				if(ffReader != null)
					ffReader.close();
			}
		}
	
		return false;
	}
}