package ph.com.metrobank.omni.mbs.otd.core.dto;

public class MpinServiceRequest {

	private String username;
	private String mpin;

	public String getUserName() {
		return username;
	}
	
	public void setUserName(String username) {
		this.username = username;
	}
	
	public String getMpin() {
		return mpin;
	}
	
	public void setMpin(String mpin) {
		this.mpin = mpin;
	}
}
