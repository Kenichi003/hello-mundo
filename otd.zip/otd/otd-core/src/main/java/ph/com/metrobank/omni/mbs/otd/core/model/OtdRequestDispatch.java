package ph.com.metrobank.omni.mbs.otd.core.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "otd_request_dispatch_log")
public class OtdRequestDispatch implements Serializable {

	private static final long serialVersionUID = 8169140130447504829L;

	@Id
	@SequenceGenerator(name = "otd_request_dispatch_log_id_gen", sequenceName = "otd_request_dispatch_log_id_seq", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "otd_request_dispatch_log_id_gen")
	@Column(unique = true, nullable = false)
	private Long id;

	@Column(name="request_count", nullable = false)
	private Integer requestCount;
	
	@Column(nullable = false)
	private Timestamp created;

	@Column()
	private boolean accepted;

	@PrePersist
	void preInsert() {
		created = Timestamp.valueOf(LocalDateTime.now());
	}

	public Long getId() {
		return id;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public Integer getRequestCount() {
		return requestCount;
	}

	public void setRequestCount(Integer count) {
		this.requestCount = count;
	}
}