package ph.com.metrobank.omni.mbs.otd.core.dto;

public class WSStatus {
    private String errorMessage;
    private String soaResponseCode;
    private byte transcationStatus;
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getSoaResponseCode() {
		return soaResponseCode;
	}
	public void setSoaResponseCode(String soaResponseCode) {
		this.soaResponseCode = soaResponseCode;
	}
	public byte getTranscationStatus() {
		return transcationStatus;
	}
	public void setTranscationStatus(byte transcationStatus) {
		this.transcationStatus = transcationStatus;
	}

}
