package ph.com.metrobank.omni.mbs.otd.core.dto;
public class ValidationError {
	protected String code;
	protected String message;
	
	public ValidationError(String code, String name) {
		this.code = code;
		this.message = name;
	}
}