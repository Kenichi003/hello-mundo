package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.util.List;

public class EulaDetails {
	private String customerId;
	private List<Short> eulaVersionIdList;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public List<Short> getEulaVersionIdList() {
		return eulaVersionIdList;
	}
	public void setEulaVersionIdList(List<Short> eulaVersionIdList) {
		this.eulaVersionIdList = eulaVersionIdList;
	}
}
