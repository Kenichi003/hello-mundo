package ph.com.metrobank.omni.mbs.otd.core.dto;

public class RatePeriod {
	private String id;
	private short start;
	private short end;
	private String rate;
	private short monthStart;
	private short monthEnd;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public short getStart() {
		return start;
	}
	public void setStart(short start) {
		this.start = start;
	}
	public short getEnd() {
		return end;
	}
	public void setEnd(short end) {
		this.end = end;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public short getMonthStart() {
		return monthStart;
	}
	public void setMonthStart(short monthStart) {
		this.monthStart = monthStart;
	}
	public short getMonthEnd() {
		return monthEnd;
	}
	public void setMonthEnd(short monthEnd) {
		this.monthEnd = monthEnd;
	}
}
