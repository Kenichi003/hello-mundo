package ph.com.metrobank.omni.mbs.otd.core.dto;

import java.math.BigDecimal;

public class OtdAccountBalance {
	private BigDecimal currentBalance;
	private BigDecimal availableBalance;
	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}
	public BigDecimal getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(BigDecimal availableBalance) {
		this.availableBalance = availableBalance;
	}
}
