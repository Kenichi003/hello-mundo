# otd-core

Online Time Deposit Core