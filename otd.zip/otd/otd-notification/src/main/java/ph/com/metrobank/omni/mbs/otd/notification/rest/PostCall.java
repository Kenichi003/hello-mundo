package ph.com.metrobank.omni.mbs.otd.notification.rest;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.http.HttpResponse;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class PostCall implements Callable<HttpResponse> {
	private static final Logger LOGGER = LoggerFactory.getLogger(PostCall.class);

	private String id;
	private CloseableHttpAsyncClient client;
	private HttpContext context;
	private JsonTypePost request;
	private HttpResponse response;

	public PostCall(CloseableHttpAsyncClient client, String id, JsonTypePost req){
		this.id = id;
		this.client = client;
		context = HttpClientContext.create();
		request = req;
	}

	public HttpResponse getResponse() {
		return response;
	}

	public String getRequestId() {
		return id;
	}

	@Override
	public HttpResponse call() throws InterruptedException, ExecutionException, TimeoutException {
    	MDC.put("job-id", id);
    	try {
    		Future<HttpResponse> future = client.execute(request, context, null);
    		if(future != null) {
    			response = future.get(30000, TimeUnit.MILLISECONDS);
    		} else {
    			LOGGER.info("{}: Request timeout.", id);
    		}

    		return response;
    	} finally {
    	    MDC.remove("job-id");
    	}
	}
}