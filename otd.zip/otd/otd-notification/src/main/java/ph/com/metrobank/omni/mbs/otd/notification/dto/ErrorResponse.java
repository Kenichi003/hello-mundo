package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.util.Date;

public class ErrorResponse extends JSendResponse {

  public ErrorResponse(String appName, String appVersion) {
    init();
    this.setProgramName(appName);
    this.setVersion(appVersion);
  }

  private void init() {
    this.setStatus(JSendResponse.ResponseStatus.ERROR.name());
    this.setDatetime(new Date());
  }
}
