package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.util.List;
import java.util.Map;

public class PreTerminationEmail {
	
	private String from;
	private List<String> to;
	private String subject;
	private String body;
	private List<String> cc;
	private List<String> bcc;
	private String attachment;
	private String attachmentName;
	private String templateName;
	private Map<String, String> templateTokens;
	
	public String getFrom() {
		return from;
	}
	
	public void setFrom(String from) {
		this.from = from;
	}
	public List<String> getTo() {
		return to;
	}
	public void setTo(List<String> to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public List<String> getCc() {
		return cc;
	}
	public void setCc(List<String> cc) {
		this.cc = cc;
	}
	public List<String> getBcc() {
		return bcc;
	}
	public void setBcc(List<String> bcc) {
		this.bcc = bcc;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getAttachmentName() {
		return attachmentName;
	}
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public Map<String, String> getTemplateTokens() {
		return templateTokens;
	}
	public void setTemplateTokens(Map<String, String> templateTokens) {
		this.templateTokens = templateTokens;
	}
}
