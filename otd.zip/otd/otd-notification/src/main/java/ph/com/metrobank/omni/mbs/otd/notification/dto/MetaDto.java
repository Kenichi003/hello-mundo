package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.io.Serializable;

public class MetaDto implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String currency;
	private String principalAmount;
	private String term;
	private String interestRate;
	private String payoutOption;
	private String settlementAccount;
	private String transactionDate;
	private String referenceId;
	
	public MetaDto() {
		
	}
	
	public MetaDto(String currency, String principalAmount, String term, String interestRate, String payoutOption,
			String settlementAccount, String transactionDate, String referenceId) {
		super();
		this.currency = currency;
		this.principalAmount = principalAmount;
		this.term = term;
		this.interestRate = interestRate;
		this.payoutOption = payoutOption;
		this.settlementAccount = settlementAccount;
		this.transactionDate = transactionDate;
		this.referenceId = referenceId;
	}

	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPrincipalAmount() {
		return principalAmount;
	}
	public void setPrincipalAmount(String principalAmount) {
		this.principalAmount = principalAmount;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	public String getPayoutOption() {
		return payoutOption;
	}
	public void setPayoutOption(String payoutOption) {
		this.payoutOption = payoutOption;
	}
	public String getSettlementAccount() {
		return settlementAccount;
	}
	public void setSettlementAccount(String settlementAccount) {
		this.settlementAccount = settlementAccount;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	@Override
	public String toString() {
		return "MetaDto [currency=" + currency + ", principalAmount=" + principalAmount + ", term=" + term
				+ ", interestRate=" + interestRate + ", payoutOption=" + payoutOption + ", settlementAccount="
				+ settlementAccount + ", transactionDate=" + transactionDate + ", referenceId=" + referenceId + "]";
	}
	
	
	
	
}
