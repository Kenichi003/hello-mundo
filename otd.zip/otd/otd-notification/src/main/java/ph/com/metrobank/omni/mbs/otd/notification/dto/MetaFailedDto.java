package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.io.Serializable;

public class MetaFailedDto implements Serializable{

	private static final long serialVersionUID = 1L;
	private String currency;
	private String principalAmount;
	private String settlementAccount;
	private String transactionDate;
	private String referenceId;
	private MetaReasonFailedDto reasons;
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPrincipalAmount() {
		return principalAmount;
	}
	public void setPrincipalAmount(String principalAmount) {
		this.principalAmount = principalAmount;
	}
	public String getSettlementAccount() {
		return settlementAccount;
	}
	public void setSettlementAccount(String settlementAccount) {
		this.settlementAccount = settlementAccount;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	public MetaReasonFailedDto getReasons() {
		return reasons;
	}
	public void setReasons(MetaReasonFailedDto reasons) {
		this.reasons = reasons;
	}
	
	@Override
	public String toString() {
		return "MetaFailedDto [currency=" + currency + ", principalAmount=" + principalAmount + ", settlementAccount="
				+ settlementAccount + ", transactionDate=" + transactionDate + ", referenceId=" + referenceId
				+ ", reasons=" + reasons + "]";
	}



}
