package ph.com.metrobank.omni.mbs.otd.notification.rest;

import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.keycloak.representations.AccessTokenResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.util.ProcessingUtils;

public abstract class AbstractEnd {
	protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractEnd.class);
	private static String accessToken = "";

	@Autowired
	protected Environment env;
	
	protected boolean injectAccessToken;
	protected boolean securityEnabled;

	private String authServer;
	private String authServerRealm;
	private String authServerClientId;
	private String authServerClientSecret;
	private String tokenValidityInSeconds;

	private long lastGenerationTime;

	@PostConstruct
	abstract protected void initialize() throws Throwable;

	@PostConstruct
	protected void initializeSecurity() {
		injectAccessToken = Boolean.valueOf(env.getProperty("security.injectAccessToken"));
		securityEnabled = Boolean.valueOf(env.getProperty("security.oauth2.enabled"));
	}
	
	@PostConstruct
	private void setupRealm() {
		authServer = env.getProperty("auth.server.url");
		authServerRealm = env.getProperty("auth.server.realm");
		authServerClientId = env.getProperty("auth.server.client-id");
		authServerClientSecret = env.getProperty("auth.server.client-secret");
		tokenValidityInSeconds = env.getProperty("auth.token.validity.seconds");
	}

	protected JsonObject extractAccessObject() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		JsonObject accessObject = new JsonObject();
		accessObject.addProperty("Authorization", request.getHeader("Authorization"));
		accessObject.addProperty("X-DEVICE-ID", request.getHeader("X-DEVICE-ID"));
		accessObject.addProperty("X-FORWARDED-FOR", request.getHeader("X-FORWARDED-FOR"));
		return accessObject;
	}
	
	protected String extractRequestOrigin() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		return ProcessingUtils.append("remote address: ", request.getRemoteAddr(), ", xff: ", request.getHeader("X-FORWARDED-FOR"));
	}

	protected JsonObject obtainAccessObject() {
		JsonObject accessObject = new JsonObject();
		accessObject.addProperty("Authorization", obtainAccessToken());
		accessObject.addProperty("X-DEVICE-ID", " ");
		accessObject.addProperty("X-FORWARDED-FOR", " ");
		return accessObject;
	}
	
	private String obtainAccessToken() {
		if (!isTokenValid()) {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("grant_type", "client_credentials");
			map.add("client_id", authServerClientId);
			map.add("client_secret", authServerClientSecret);

			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
			String url = ProcessingUtils.append(authServer, "/realms/", authServerRealm, "/protocol/openid-connect/token");
			ResponseEntity<AccessTokenResponse> response = new RestTemplate().postForEntity(url, request, AccessTokenResponse.class);

			accessToken = ProcessingUtils.append(AppConstants.BEARER, response.getBody().getToken());
		}

		return accessToken;
	}

	private boolean isTokenValid() {
		long now = System.nanoTime();

		if (lastGenerationTime == 0L) {
			lastGenerationTime = now;
			return false;
		}

		try {
			long validity = Long.parseLong(tokenValidityInSeconds);
			long elapsedTime = now - lastGenerationTime;
			long elapsedTimeInSeconds = TimeUnit.SECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);

			return elapsedTimeInSeconds < validity;
		} catch (NumberFormatException | NullPointerException e) {
			return false;
		}
	}

}
