package ph.com.metrobank.omni.mbs.otd.notification.endpoint;

import java.nio.file.Files;
import java.nio.file.Paths;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.dto.AutoEnrollAttempt;
import ph.com.metrobank.omni.mbs.otd.notification.reader.SecondHostFeedbackFileReader;
import ph.com.metrobank.omni.mbs.otd.notification.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.notification.service.OtdNotificationService;

@Path("/back-office")
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Component
@Api(value = "Back-office Endpoints", produces = "application/json")
public class OtdNotificationsBackOfficeEndpoint extends AbstractEnd {

	@Autowired
	private OtdNotificationService notify;

	@Autowired
	private SecondHostFeedbackFileReader secondReader;

	private java.nio.file.Path secondFeedbackPath;
	private java.nio.file.Path maturityPath;
	
	@Override
	protected void initialize() throws Throwable {
		java.nio.file.Path parent = Paths.get(env.getProperty("path.dropFolder"));
		secondFeedbackPath = parent.resolve(env.getProperty("path.secondHostFeedbackFile"));
		maturityPath = parent.resolve(env.getProperty("path.maturationFile"));
	}
	
	@POST
	@Path("/auto-enroll")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object autoEnroll(AutoEnrollAttempt attempt) throws Exception {
		LOGGER.info("Auto-enroll: {}", attempt.getCustomerId());
		return notify.callAutoEnroll(attempt);
	}

	@GET	
	@Path("/process-second-feedback")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object processSecondFeedback() throws Exception {
		LOGGER.info("Re-processing 2nd feedback file.");
		secondReader.readFeedback(secondFeedbackPath);
		return AppConstants.SUCCESS_MESSAGE;
	}
	
	@GET	
	@Path("/read-maturity")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object readMaturity() throws Exception {
		return new String(Files.readAllBytes(maturityPath));
	}
	
	@GET	
	@Path("/read-second")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object readSecondFeedback() throws Exception {
		return new String(Files.readAllBytes(secondFeedbackPath));
	}
}
