package ph.com.metrobank.omni.mbs.otd.notification.factory;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.net.ssl.SSLContext;

import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.nio.conn.NHttpClientConnectionManager;
import org.apache.http.nio.conn.NoopIOSessionStrategy;
import org.apache.http.nio.conn.SchemeIOSessionStrategy;
import org.apache.http.nio.conn.ssl.SSLIOSessionStrategy;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;

@Component
public class HttpClientFactory {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpClientFactory.class);
	
	@Autowired
	private ThreadFactory threadFactory;
	private static ConnectionKeepAliveStrategy keepAliveStrategy;

	private static RequestConfig config;

	private static int maxConnections = 200;
	private static int maxPerRouTe = 200;
	private static int timeout = 15;

	private Registry<SchemeIOSessionStrategy> getSSLRegistryAsync(SSLContext sslContext) {
		return RegistryBuilder.<SchemeIOSessionStrategy> create()
				.register(AppConstants.HTTP, NoopIOSessionStrategy.INSTANCE)
				.register(AppConstants.HTTPS, new SSLIOSessionStrategy(sslContext, NoopHostnameVerifier.INSTANCE))
				.build();

	}	

	private SSLContext getSSLContext() throws Exception {
		final TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
		final SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
				.loadTrustMaterial(null, acceptingTrustStrategy)
				.build();
		sslContext.getServerSessionContext().setSessionCacheSize(1000);
		return sslContext;
	}

	@PostConstruct
	public void initialize() throws Exception {
		keepAliveStrategy = new ConnectionKeepAliveStrategy() {
			@Override
			public long getKeepAliveDuration(HttpResponse response, HttpContext context) {
				HeaderElementIterator it = new BasicHeaderElementIterator(response.headerIterator(HTTP.CONN_KEEP_ALIVE));
				while (it.hasNext()) {
					HeaderElement headerElement = it.nextElement();
					String param = headerElement.getName();
					String value = headerElement.getValue();
					if (value != null && param.equalsIgnoreCase("timeout")) {
						return Long.parseLong(value) * 1000;
					}
				}
				return timeout;
			}
		};
		
		config = RequestConfig.custom()
				.setCookieSpec(CookieSpecs.STANDARD)
				.setConnectTimeout(timeout)
				.setConnectionRequestTimeout(timeout)
				.setSocketTimeout(timeout).build();
	}

	public CloseableHttpClient createClient() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		final SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());

		final SSLConnectionSocketFactory sslFactory = new SSLConnectionSocketFactory(builder.build());
		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
				.<ConnectionSocketFactory>create().register(AppConstants.HTTPS, sslFactory)
				.register(AppConstants.HTTP, new PlainConnectionSocketFactory())
				.build();

		final PoolingHttpClientConnectionManager synchronousClientManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
		synchronousClientManager.setMaxTotal(maxConnections);
		synchronousClientManager.setDefaultMaxPerRoute(maxPerRouTe);

		CloseableHttpClient newClient = HttpClients.custom()
				.setKeepAliveStrategy(keepAliveStrategy)
				.setDefaultRequestConfig(config)
				.setConnectionManagerShared(true).
				setConnectionManager(getSynchronousConnectionManager()).
				setSSLSocketFactory(sslFactory)
				.build();
		
		IdleConnectionMonitorThread staleConnectionsMonitorForSynchronousManager= new IdleConnectionMonitorThread(synchronousClientManager);
		threadFactory.execute(staleConnectionsMonitorForSynchronousManager);

		return newClient;
	}

	private HttpClientConnectionManager getSynchronousConnectionManager() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
		final SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());

		final SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(builder.build());
		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
				.<ConnectionSocketFactory>create().register(AppConstants.HTTPS, sslConnectionSocketFactory)
				.register(AppConstants.HTTP, new PlainConnectionSocketFactory())
				.build();

		final PoolingHttpClientConnectionManager synchronousClientManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
		synchronousClientManager.setMaxTotal(maxConnections);
		synchronousClientManager.setDefaultMaxPerRoute(maxPerRouTe);
		return synchronousClientManager;
	}

	public CloseableHttpAsyncClient createAsyncClient() throws Exception {
		PoolingNHttpClientConnectionManager asynchronousClientManager = getPoolingNHttpClientConnectionManager(getSSLContext(), maxConnections, maxPerRouTe);
		CloseableHttpAsyncClient client = HttpAsyncClients.custom()
				.setKeepAliveStrategy(keepAliveStrategy)
				.setDefaultRequestConfig(config)
				.setConnectionManager(asynchronousClientManager)
				.build();
		client.start();
		
		AsynchronousConnectionManagerMonitorThread staleConnectionsMonitorForAsynchronousManager= new AsynchronousConnectionManagerMonitorThread(asynchronousClientManager);
		threadFactory.execute(staleConnectionsMonitorForAsynchronousManager);
		return client;
	}

	private PoolingNHttpClientConnectionManager getPoolingNHttpClientConnectionManager(SSLContext sslContext, int connectionPoolMax, int connectionPoolMaxPerRoute) throws IOReactorException {
		PoolingNHttpClientConnectionManager connectionManager =
				new PoolingNHttpClientConnectionManager(new DefaultConnectingIOReactor(IOReactorConfig.DEFAULT), getSSLRegistryAsync(sslContext));
		connectionManager.setMaxTotal(connectionPoolMax);
		connectionManager.setDefaultMaxPerRoute(connectionPoolMaxPerRoute);
		return connectionManager;
	}

	public class IdleConnectionMonitorThread implements Runnable {
		private final HttpClientConnectionManager connMgr;
		private volatile boolean shutdown;

		public IdleConnectionMonitorThread(HttpClientConnectionManager connMgr) {
			super();
			this.connMgr = connMgr;
		}
		@Override
		public void run() {
			try {
				while (!shutdown) {
					synchronized (this) {
						wait(1000);
						connMgr.closeExpiredConnections();
						connMgr.closeIdleConnections(30, TimeUnit.SECONDS);
					}
				}
			} catch (InterruptedException e) {
				LOGGER.error("Error during synchronous connection reaping:", e);
				shutdown();
			}
		}
		public void shutdown() {
			shutdown = true;
			synchronized (this) {
				notifyAll();
			}
		}
	}

	private class AsynchronousConnectionManagerMonitorThread implements Runnable {
		private final NHttpClientConnectionManager connMgr;
		private volatile boolean shutdown;

		public AsynchronousConnectionManagerMonitorThread(NHttpClientConnectionManager connMgr) {
			super();
			this.connMgr = connMgr;
		}
		@Override
		public void run() {
			try {
				while (!shutdown) {
					synchronized (this) {
						wait(1000);
						connMgr.closeExpiredConnections();
						connMgr.closeIdleConnections(30, TimeUnit.SECONDS);
					}
				}
			} catch (InterruptedException e) {
				LOGGER.error("Error during asynchronous connection reaping:", e);
				shutdown();
			}
		}
		public void shutdown() {
			shutdown = true;
			synchronized (this) {
				notifyAll();
			}
		}
	}
}
