package ph.com.metrobank.omni.mbs.otd.notification.rest;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.http.client.methods.HttpGet;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;

public class JsonTypeGet extends HttpGet {

	public JsonTypeGet(String uri, Optional<String> authHeader) throws UnsupportedEncodingException {
		super(uri);
		setHeader("Accept", AppConstants.APPLICATION_JSON_TYPE);
		setHeader("Content-type", AppConstants.APPLICATION_JSON_TYPE);

		if(authHeader.isPresent()) {
			setHeader("Authorization", authHeader.get());
		}

	}
	
	public JsonTypeGet(URI uri, Optional<String> authHeader) throws UnsupportedEncodingException {
		super(uri);
		setHeader("Accept", AppConstants.APPLICATION_JSON_TYPE);
		setHeader("Content-type", AppConstants.APPLICATION_JSON_TYPE);
		if(authHeader.isPresent()) {
			setHeader("Authorization", authHeader.get());
		}

	}

	public JsonTypeGet(String uri, JsonObject headers) throws UnsupportedEncodingException {
		super(uri);
		setHeader("Accept", AppConstants.APPLICATION_JSON_TYPE);
		setHeader("Content-type", AppConstants.APPLICATION_JSON_TYPE);

		Set<Entry<String, JsonElement>> entries = headers.entrySet();
		for(Entry<String, JsonElement> header : entries) {
			setHeader(header.getKey(), header.getValue() != JsonNull.INSTANCE ? header.getValue().getAsString() : "");
		}
	}
}
