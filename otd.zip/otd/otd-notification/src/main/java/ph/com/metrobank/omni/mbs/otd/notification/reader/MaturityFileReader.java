package ph.com.metrobank.omni.mbs.otd.notification.reader;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
import com.google.common.base.CharMatcher;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.dto.KafkaMessage;
import ph.com.metrobank.omni.mbs.otd.notification.dto.MaturityNotification;
import ph.com.metrobank.omni.mbs.otd.notification.dto.MetaSuccessDto;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationBody;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationFilter;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationPayload;
import ph.com.metrobank.omni.mbs.otd.notification.model.OtdCustomer;
import ph.com.metrobank.omni.mbs.otd.notification.model.OtdFedbackRequest;
import ph.com.metrobank.omni.mbs.otd.notification.repository.webengine.CustomerRepository;
import ph.com.metrobank.omni.mbs.otd.notification.repository.webengine.OtdFedbackRequestRepository;
import ph.com.metrobank.omni.mbs.otd.notification.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.notification.rest.ForNotification;
import ph.com.metrobank.omni.mbs.otd.notification.service.KafkaSenderService;
import ph.com.metrobank.omni.mbs.otd.notification.util.ProcessingUtils;

@Component
public class MaturityFileReader extends AbstractEnd {
	private static final Logger LOGGER = LoggerFactory.getLogger(MaturityFileReader.class);

	@Autowired
	private Environment env;

	@Autowired
	private KafkaSenderService sender;

	@Autowired
	private OtdFedbackRequestRepository requestRepository;

	@Autowired
	private CustomerRepository customerRepository;

	private String mbsNotificationTopic;
	private String[] rolloverInstructions;

	private FlatFileReaderDefinition ffDefinition;
	private byte maturityIndicator;
	private int batchSize;

	@PostConstruct
	protected void initialize() throws Exception {
		mbsNotificationTopic = env.getProperty("topic.notification.mbs");
		maturityIndicator = Byte.valueOf(env.getProperty("value.maturityIndicator"));
		rolloverInstructions = StringUtils.split(env.getProperty("value.rolloverInstructions"), ";");
		ffDefinition = new FlatFileReaderDefinition(MaturityRecord.class);
		ffDefinition.setHeader(Header.class);
		batchSize = env.getProperty("spring.jpa.properties.hibernate.jdbc.batch_size", Integer.class);
	}

	@PositionalRecord
	public static class Header {

		private String code;
		private String date;

		@PositionalField(initialPosition = 1, finalPosition = 1)
		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		@PositionalField(initialPosition = 2, finalPosition = 9)
		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}
	}

	@PositionalRecord
	public static class MaturityRecord {
		private String bankCode;
		private String currencyCode;
		private String branchCode;
		private String control;
		private String accountId;
		private String date;
		private String currentBalance;
		private BigDecimal numericalBalance;
		private String rolledOverFlag;

		@PositionalField(initialPosition = 1, finalPosition = 2)
		public String getBankCode() {
			return bankCode;
		}

		public void setBankCode(String code) {
			this.bankCode = code;
		}

		@PositionalField(initialPosition = 3, finalPosition = 5)
		public String getCurrencyCode() {
			return currencyCode;
		}

		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}

		@PositionalField(initialPosition = 6, finalPosition = 8)
		public String getBranchCode() {
			return branchCode;
		}

		public void setBranchCode(String branchCode) {
			this.branchCode = branchCode;
		}

		@PositionalField(initialPosition = 9, finalPosition = 11)
		public String getControl() {
			return control;
		}

		public void setControl(String control) {
			this.control = control;
		}

		@PositionalField(initialPosition = 16, finalPosition = 25)
		public String getAccountId() {
			return accountId;
		}

		public void setAccountId(String accountId) {
			this.accountId = accountId;
		}

		@PositionalField(initialPosition = 26, finalPosition = 33)
		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}

		@PositionalField(initialPosition = 34, finalPosition = 50)
		public String getCurrentBalance() {
			return currentBalance;
		}

		public void setCurrentBalance(String currentBalance) {
			this.currentBalance = currentBalance;
		}

		public BigDecimal getNumericalBalance() {
			if(numericalBalance == null) {
				numericalBalance = NumberUtils.createBigDecimal(StringUtils.remove(currentBalance, "+"));
			}
			return numericalBalance;
		}

		@PositionalField(initialPosition = 51, finalPosition = 51)
		public String getRolledOverFlag() {
			return rolledOverFlag;
		}

		public void setRolledOverFlag(String rolledOverFlag) {
			this.rolledOverFlag = rolledOverFlag;
		}
	}

	public boolean readMaturityRecords(Path inputPath, LocalDate date) throws Exception {
		File inputFile = inputPath.toFile();
		FlatFileReader ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);
		try {
			MaturityRecord record = null;
			LocalDate dateOnFile = null;
			List<ForNotification> notifications = new LinkedList<>();
			List<OtdFedbackRequest> rolloverMaintenance = new LinkedList<>();

			for (Object entry : ffReader) {
				if(entry instanceof MaturityRecord) {
					record = (MaturityRecord) entry;
					String id = ProcessingUtils.append(record.getBranchCode(), record.getAccountId());
					Optional<OtdFedbackRequest> check = requestRepository.findByOtdAccountId(id);
					if(check.isPresent()) {																
						OtdFedbackRequest fromDb = check.get();
						if(fromDb.getTerminated()) {
							LocalDateTime terminationTimestamp = fromDb.getTerminationTransactionDate().toLocalDateTime();
							LOGGER.info("{}: this time deposit was already terminated on {}. Skipping and proceeding with next record", id, terminationTimestamp.format(AppConstants.NOTIFICATION_DATE_FORMATTER));
							continue;
						}

						LOGGER.info("Matured OTD Account ID: {}. Creating customer notification...", id);
						String cid = fromDb.getCustomerId();

						boolean autoClosing = Byte.valueOf(record.getRolledOverFlag()) == maturityIndicator;
						String formattedMaturityDate = ProcessingUtils.formatMaturityDate(record.getDate());
						String formattedTransactionDate = ProcessingUtils.formatTransactionDate(autoClosing ? fromDb.getCreated() : fromDb.getTransactionDate());

						ForNotification notification = new ForNotification();
						notification.setCustomerId(cid);
						notification.setName(fromDb.getAccountName());
						notification.setOtdAccountId(id);
						notification.setMatured(autoClosing);								
						notification.setNotifDate(record.getDate());	
						notification.setCurrency(getCurrency(record.getCurrencyCode()));
						notification.setPrincipalAmount(getAmount(record.getCurrentBalance()));

						//TODO: align with host once rate info is added to the maturity file
						notification.setInterestRate(getRate(fromDb.getBaseRate(), fromDb.getAddOnRate()));

						notification.setTerm(getTerm(fromDb.getTenor()));								
						notification.setMaturityDate(formattedMaturityDate);								
						notification.setRolloverInstruction(rolloverInstructions[NumberUtils.createInteger(fromDb.getRolloverInstruction())]);
						notification.setSettlementAccount(fromDb.getAccountId());
						notification.setTransactionDate(formattedTransactionDate);
						notification.setReferenceId(fromDb.getReferenceId());
						notification.setFlag(record.getRolledOverFlag());

						notifications.add(notification);

						//anchor for rollover maintenance
						if(!autoClosing) {
							rolloverMaintenance.add(updateOtdRecord(fromDb, record, formattedMaturityDate));
						}

					} else {
						LOGGER.error("No database record found for OTD #{}.", id);
					}
				} else if(entry instanceof Header) {
					Header header = (Header) entry;
					LOGGER.info("Header date: {}", header.getDate());
					dateOnFile = LocalDate.parse(header.getDate(), AppConstants.HEADER_FORMATTER);
					if(dateOnFile.isEqual(date)) {
						LOGGER.info("Header date match. This file was already processed today. Ignoring...", dateOnFile);
						return false;
					} else if(dateOnFile.isBefore(date)) {
						LOGGER.info("Header date {} comes before today ({}). Ignoring...", dateOnFile, date);
						return false;
					} else {
						LOGGER.info("Valid header date: {}. Begin processing...", dateOnFile);
					}
				}
			}

			LOGGER.info("Saving updated OTDs.");
			save(rolloverMaintenance);
			LOGGER.info("OTD saving done.");

			sendToMbsNotificationService(notifications);
			return true;
		} catch(Exception e) {
			LOGGER.error("\nError while processing maturity file:\n", e);
			throw e;
		} finally {
			if(ffReader != null)
				ffReader.close();
		}
	}

	private void save(List<OtdFedbackRequest> updates) {
		int count = updates.size();
		List<OtdFedbackRequest> batch = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			batch.add(updates.get(i));
			if (i % batchSize == 0 && i > 0) {
				requestRepository.saveAll(batch);
				batch.clear();
			}
		}

		if (batch.size() > 0) {
			requestRepository.saveAll(batch);
			batch.clear();
		}
	}

	private OtdFedbackRequest updateOtdRecord(OtdFedbackRequest fromDb, MaturityRecord record, String formattedMaturityDate) {
		LOGGER.info("OTD {} has rolled over. Updating record...", fromDb.getOtdAccountId());
		LocalDate now = LocalDate.now();
		ZonedDateTime thisDay = now.atStartOfDay(ZoneId.systemDefault());
		Timestamp renewalTimeStamp = Timestamp.from(thisDay.toInstant());
		Timestamp maturityTimeStamp = ProcessingUtils.timeStampFromDate(formattedMaturityDate);

		fromDb.setPlacementAmount(CharMatcher.inRange('0', '9').retainFrom(record.getCurrentBalance()));
		fromDb.setMaturityDate(maturityTimeStamp);
		fromDb.setTransactionDate(renewalTimeStamp);
		fromDb.setUpdatedBy(AppConstants.UPDATED_BY_ROLLOVER_MAINTENANCE);
		LOGGER.info("\nSaving:\n{}", ProcessingUtils.forLogging(fromDb));
		return fromDb;
	}

	private String getCurrency(String code) {
		return StringUtils.equalsIgnoreCase(code, AppConstants.PESO_CODE) ? AppConstants.PHP_UPPERCASE : AppConstants.USD_UPPERCASE;		
	}

	private String getAmount(String amount) {
		//TODO: code utilizes slow and expensive ways of producing output. refactor to something better.
		DecimalFormat df = new DecimalFormat("###,###.00");
		String clean = amount.replaceAll("[^\\d.]", "" );
		amount = String.format("%.3f", Double.parseDouble(clean));
		String principalAmount = df.format(Double.parseDouble(amount)); 
		return principalAmount;
	}

	private String getTerm(String tenor) {
		String term = String.format("%s", Integer.valueOf(tenor));			
		term = Integer.parseInt(term) > 1 ? term + " Months" : term + " Month";	
		return term; 
	}

	private String getRate(String baseRate, String addOnRate) {
		double x = (Integer.valueOf(baseRate)+Integer.valueOf(addOnRate)) / 10000d;
		Double y =  x / 100d;
		String rate = String.format("%.3f", y);
		return ProcessingUtils.append(rate, "%");
	}

	private void sendToMbsNotificationService(List<ForNotification> notes) throws Exception {
		KafkaMessage message = new KafkaMessage();
		message.setTopic(mbsNotificationTopic);
		LOGGER.info("Relaying to MBS Notification Service...");
		for(ForNotification note : notes) {
			String otdAccountId = note.getOtdAccountId();
			int length = StringUtils.length(otdAccountId);
			String maskedOtdAccountId = StringUtils.substring(otdAccountId, length - 4, length);

			MaturityNotification notification = new MaturityNotification();
			notification.setNotificationDate(null);
			notification.setExpirationDate(null);

			NotificationFilter filter = notification.getFilter();

			String customerId = note.getCustomerId();
			Optional<OtdCustomer> findCustomer = customerRepository.findById(Long.valueOf(customerId));

			if(!findCustomer.isPresent()) {
				LOGGER.error("No customer record found with I.D. # {} associated with {}.", customerId, note.getName(), note.getOtdAccountId());
				continue;
			}

			OtdCustomer customer = findCustomer.get();
			filter.setId(customerId);			
			filter.setEmail(customer.getEmail());
			filter.setMobile(customer.getMobile());

			NotificationBody notificationBody = notification.getBody();

			boolean matured = note.matured();
			String transDate = AppConstants.MATURITY_FORMATTER.format(LocalDate.parse(note.getNotifDate(), AppConstants.SDF)); 								
			NotificationPayload payload = notification.getPayload();

			payload.addEmailToken(AppConstants.ACCOUNT_NAME, note.getName());
			payload.addEmailToken(AppConstants.OTD_ACCOUNT_ID, maskedOtdAccountId);
			payload.addEmailToken(AppConstants.DATE, transDate);

			payload.addNotificationBodyToken(AppConstants.OTD_ACCOUNT_ID, maskedOtdAccountId);
			payload.addNotificationBodyToken(AppConstants.DATE, transDate);

			payload.addSmsToken(AppConstants.OTD_ACCOUNT_ID, StringUtils.substring(otdAccountId, otdAccountId.length()-4));
			payload.addSmsToken(AppConstants.DATE, transDate);
			payload.setSourceAccountId(otdAccountId);
			payload.setMeta(getMeta(otdAccountId, note.getCurrency(), note.getPrincipalAmount(), 
					note.getInterestRate(), note.getTerm(), note.getRolloverInstruction(), 
					note.getMaturityDate(), note.getSettlementAccount(), note.getTransactionDate(), note.getReferenceId()));
			payload.setStatus(AppConstants.INFO_STATUS);
			payload.setTransactionStatus(AppConstants.INFO_STATUS);

			String code;
			if(matured) {
				code = AppConstants.OTD_MATURITY_TEMPLATE_KEY;
			} else {
				code = AppConstants.OTD_ROLLED_OVER_MATURITY_TEMPLATE_KEY;

				LOGGER.info("Proceeds note for SMS flag value = {}", note.getFlag());

				if(StringUtils.equals(note.getFlag(), AppConstants.ZERO)) {
					payload.addSmsToken(AppConstants.P_MSG, StringUtils.EMPTY);
				}else {
					payload.addSmsToken(AppConstants.P_MSG, AppConstants.PROCEED_MSG);
				}
			}

			notificationBody.setEmailCode(code);
			notificationBody.setSmsCode(code);			
			notificationBody.setNotificationCode(code);

			payload.setReferenceNo(otdAccountId);
			String load = ProcessingUtils.toJson(notification, MaturityNotification.class);
			LOGGER.info("Sending to via Kafka to MBS Notifications. Notification payload for Matured OTD #{}:\n{}", otdAccountId, ProcessingUtils.prettyJson(load));
			message.setMessage(load);
			sender.send(message);
		}

		notes.clear();
	}


	private MetaSuccessDto getMeta(String tdAccountNumber, String currency, String principalAmount, String interestRate,
			String term, String payoutOption, String maturityDate, String settlementAccount, String transactionDate, String referenceId) {
		MetaSuccessDto meta = null;		
		meta = new MetaSuccessDto(tdAccountNumber, 
				currency, principalAmount, interestRate, term, payoutOption, maturityDate, settlementAccount, transactionDate, referenceId);		
		return meta;
	}
}


