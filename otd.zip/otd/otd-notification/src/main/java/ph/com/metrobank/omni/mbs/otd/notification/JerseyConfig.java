package ph.com.metrobank.omni.mbs.otd.notification;

import javax.annotation.PostConstruct;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;
import ph.com.metrobank.omni.mbs.otd.notification.endpoint.OtdNotificationEndpoint;
import ph.com.metrobank.omni.mbs.otd.notification.endpoint.OtdNotificationsBackOfficeEndpoint;
import ph.com.metrobank.omni.mbs.otd.notification.exception.GenericExceptionMapper;

@Component
public class JerseyConfig extends ResourceConfig {

  @Value("${spring.jersey.application-path}")
  private String basePath;

  public JerseyConfig() {
    register(GenericExceptionMapper.class);
    register(OtdNotificationsBackOfficeEndpoint.class);
    register(OtdNotificationEndpoint.class);
  }

  @PostConstruct
  public void init() {
    this.configureSwagger();
  }

  private void configureSwagger() {
    this.register(ApiListingResource.class);
    this.register(SwaggerSerializers.class);

    BeanConfig config = new BeanConfig();
    config.setTitle("MBS 3.0 - Online Time Deposit API");
    config.setDescription("This is the Swagger View for the Online Time Deposit Project's Notification Service");
    config.setVersion("v1");
    config.setSchemes(new String[] {"http"});
    config.setResourcePackage("ph.com.metrobank.omni.mbs.otd.notification.endpoint");
    config.setPrettyPrint(true);
    config.setScan(true);
    config.setBasePath(basePath);
  }
}
