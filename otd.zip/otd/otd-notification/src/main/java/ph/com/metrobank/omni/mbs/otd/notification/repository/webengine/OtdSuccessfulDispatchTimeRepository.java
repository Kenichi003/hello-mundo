package ph.com.metrobank.omni.mbs.otd.notification.repository.webengine;

import java.util.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.omni.mbs.otd.notification.model.OtdSuccessfulDispatchDetails;

public interface OtdSuccessfulDispatchTimeRepository extends JpaRepository<OtdSuccessfulDispatchDetails, Long> {

  @Override
  Optional<OtdSuccessfulDispatchDetails> findById(Long i);

  @Query(value = "SELECT * from OTD_SUCCESSFUL_REQUEST_DISPATCH_TIME r where r.updated = :stamp", nativeQuery=true)
  Optional<OtdSuccessfulDispatchDetails> findByUpdated(@Param("stamp") Date stamp);
}
