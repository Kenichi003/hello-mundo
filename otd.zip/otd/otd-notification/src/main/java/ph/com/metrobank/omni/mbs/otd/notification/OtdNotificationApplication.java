package ph.com.metrobank.omni.mbs.otd.notification;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ph.com.metrobank.omni.mbs.otd.notification.service.OtdSecondFileWatcherService;

@SpringBootApplication
public class OtdNotificationApplication {

	@Autowired
	protected OtdSecondFileWatcherService watcher;

	public static void main(String[] args) {
		SpringApplication.run(OtdNotificationApplication.class, args);
	}

}
