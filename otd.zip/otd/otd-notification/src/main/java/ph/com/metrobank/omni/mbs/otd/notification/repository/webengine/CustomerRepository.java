package ph.com.metrobank.omni.mbs.otd.notification.repository.webengine;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import ph.com.metrobank.omni.mbs.otd.notification.model.OtdCustomer;

public interface CustomerRepository extends JpaRepository<OtdCustomer, Long> {

  @Override
  Optional<OtdCustomer> findById(Long i);
}
