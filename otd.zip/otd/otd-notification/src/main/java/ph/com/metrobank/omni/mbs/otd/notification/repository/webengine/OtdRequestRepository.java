package ph.com.metrobank.omni.mbs.otd.notification.repository.webengine;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.omni.mbs.otd.notification.model.OtdRequest;

public interface OtdRequestRepository extends JpaRepository<OtdRequest, Long> {

  @Override
  Optional<OtdRequest> findById(Long id);

  Optional<OtdRequest> findByReferenceId(String id);
  
  @Query(value = "SELECT * from OTD_REQUESTS r where r.created >= :stamp", nativeQuery=true)
  List<OtdRequest> findByCreated(@Param("stamp") String stamp);

  @Query(value = "SELECT * from OTD_REQUESTS r where r.updated >= :stamp", nativeQuery=true)
  List<OtdRequest> findByUpdated(@Param("stamp") String stamp);

//  @Query(value = "DELETE from OTD_REQUESTS r where r.created = :stamp")
  void deleteByCreated(@Param("stamp") Date stamp);

  Optional<OtdRequest> findByAccountId(String accountId);
  Optional<OtdRequest> findByOtdAccountId(String otdAccountId);
}
