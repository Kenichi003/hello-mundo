package ph.com.metrobank.omni.mbs.otd.notification.rest;

public class ForNotification { //extends GetCall {
	private transient String customerId;
	private String name;
	private String accountId; 
	private String notifDate;
	private String currency;
	private String principalAmount;
	private String term;
	private String interestRate;
	private String maturityDate;
	private String rolloverInstruction;
	private String settlementAccount;
	private String transactionDate;
	private String flag;
	private String referenceId;
	private boolean matured;
	
//	public ForNotification(CloseableHttpAsyncClient client, String id, HttpGet req) {
//		super(client, id, req);
//	}

	public boolean matured() {
		return matured;
	}
	
	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public void setMatured(boolean matured) {
		this.matured = matured;
	}

	public String getOtdAccountId() {
		return accountId;
	}

	public void setOtdAccountId(String accountId) {
		this.accountId = accountId;
	}
	
	public void setNotifDate(String date) {
		notifDate = date;
	}
	
	public String getNotifDate() {
		return notifDate;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(String principalAmount) {
		this.principalAmount = principalAmount;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getRolloverInstruction() {
		return rolloverInstruction;
	}

	public void setRolloverInstruction(String rolloverInstruction) {
		this.rolloverInstruction = rolloverInstruction;
	}


	public String getSettlementAccount() {
		return settlementAccount;
	}

	public void setSettlementAccount(String settlementAccount) {
		this.settlementAccount = settlementAccount;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
}