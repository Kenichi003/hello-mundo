package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.io.Serializable;

public class TimeDepositDetailsDto implements Serializable {

	  private static final long serialVersionUID = -6173008769862156094L;
	  private Double currentBalance;
	  private Double availableBalance;
	  private String maturityDate;
	  private Integer term;
	  private String period;
	  private Double placementAmount;
	  private Double interestRate;
	  private String customerId;

	  public Double getCurrentBalance() {
	    return currentBalance;
	  }
	
	  public void setCurrentBalance(Double currentBalance) {
	    this.currentBalance = currentBalance;
	  }
	
	  public Double getAvailableBalance() {
	    return availableBalance;
	  }
	
	  public void setAvailableBalance(Double availableBalance) {
	    this.availableBalance = availableBalance;
	  }
	
	
	  public String getMaturityDate() {
		return maturityDate;
	  }
	
	  public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	  }
	
	  public Integer getTerm() {
	    return term;
	  }
	
	  public void setTerm(Integer term) {
	    this.term = term;
	  }
	
	  public String getPeriod() {
	    return period;
	  }
	
	  public void setPeriod(String period) {
	    this.period = period;
	  }
	
	  public Double getPlacementAmount() {
	    return placementAmount;
	  }
	
	  public void setPlacementAmount(Double placementAmount) {
	    this.placementAmount = placementAmount;
	  }
	
	  public Double getInterestRate() {
	    return interestRate;
	  }
	
	  public void setInterestRate(Double interestRate) {
	    this.interestRate = interestRate;
	  }
	
	  public String getCustomerId() {
	    return customerId;
	  }
	
	  public void setCustomerId(String customerId) {
	    this.customerId = customerId;
	  }

	@Override
	public String toString() {
		return "TimeDepositDetailsDto [currentBalance=" + currentBalance + ", availableBalance=" + availableBalance
				+ ", maturityDate=" + maturityDate + ", term=" + term + ", period=" + period + ", placementAmount="
				+ placementAmount + ", interestRate=" + interestRate + ", customerId=" + customerId + "]";
	}

 
}
