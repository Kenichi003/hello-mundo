package ph.com.metrobank.omni.mbs.otd.notification.service;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.dto.KafkaMessage;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NamingRequest;
import ph.com.metrobank.omni.mbs.otd.notification.util.ProcessingUtils;

@Service
public class KafkaSenderService {

  @Autowired
  private KafkaTemplate<String, String> kafkaTemplate;

  @Value("${topic.coordinator}")
  private String coordinatorTopic;
  
  @PostConstruct
  private void setup() {
	  NamingRequest request = new NamingRequest();
	  request.setBase(AppConstants.OTD_CORE_SERVICE_ID_BASE);
	  request.setRequest(AppConstants.ID_PARAMETER);
	  KafkaMessage to = new KafkaMessage();
	  to.setTopic(coordinatorTopic);
	  to.setMessage(ProcessingUtils.toJson(request, NamingRequest.class));
	  send(to);
  }
  
  public void send(KafkaMessage message) {
    kafkaTemplate.send(message.getTopic(), message.getMessage());
  }
}
