package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.util.Date;
import javax.ws.rs.core.Response;

public class SuccessResponse extends JSendResponse {

  /**
   * 
   * @param data
   * @param appName
   * @param appVersion
   */
  public SuccessResponse(Object data, String appName, String appVersion) {
    init();
    this.setProgramName(appName);
    this.setVersion(appVersion);
    this.setData(data);
  }

  private void init() {
    this.setStatus(JSendResponse.ResponseStatus.SUCCESS.name());
    this.setDatetime(new Date());
    this.setCode(Response.Status.OK.getStatusCode());
  }

}
