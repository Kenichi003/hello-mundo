package ph.com.metrobank.omni.mbs.otd.notification.endpoint;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import ph.com.metrobank.omni.mbs.otd.notification.dto.ContactDto;
import ph.com.metrobank.omni.mbs.otd.notification.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.notification.service.OtdNotificationService;

@Path("/notify")
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@Component
@Api(value = "OTD Notification Endpoints", produces = "application/json")
public class OtdNotificationEndpoint extends AbstractEnd {
	private static final Logger LOGGER = LoggerFactory.getLogger(OtdNotificationEndpoint.class);

	@Autowired
	private OtdNotificationService notify;

	@Override
	protected void initialize() throws Throwable {	
	}
	
	@POST
	@Path("/acknowledge")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object acknowledge(ContactDto reference) throws Exception {
		LOGGER.info("Acknowledging: {}", reference.getReferenceId());
		return notify.acknowledge(reference);
	}	
	
	
	@POST
	@Path("/termination")
	@ApiOperation(value = "Validates submitted customer information.", response = Object.class)
	public Object termination(ContactDto reference) throws Exception {
		LOGGER.info("Notifying of pre-termination: {}", reference.getReferenceId());
		return notify.termination(reference);
	}	
}
