package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.io.Serializable;

public class MetaReasonFailedDto implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String title;
	private String subtitle;
	private Object data;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubtitle() {
		return subtitle;
	}
	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	
	@Override
	public String toString() {
		return "SubMetaFailedDto [title=" + title + ", subtitle=" + subtitle + ", data=" + data + "]";
	}
	
	

}
