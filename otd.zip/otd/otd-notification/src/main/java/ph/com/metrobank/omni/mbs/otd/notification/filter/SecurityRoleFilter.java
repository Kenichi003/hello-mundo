package ph.com.metrobank.omni.mbs.otd.notification.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Order(Ordered.HIGHEST_PRECEDENCE)
public class SecurityRoleFilter implements Filter {
	@Autowired
	private Environment env;
	
	private static final Base64 BASE_64_UNIT = new Base64(true);

	private String client;

	@Value("${security.roles}")
	private String[] fromProps;
	
	private List<String> roles;


	private boolean securityEnabled;
	private boolean checkRole;
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		boolean authorized = false;
		if(securityEnabled) {
			if(checkRole) {
				HttpServletRequest request = (HttpServletRequest) req;
				String accessToken = StringUtils.removeStart(request.getHeader("Authorization"), "Bearer ");
				String[] split = StringUtils.split(accessToken, ".");
				String decodedBody = new String(BASE_64_UNIT.decode(split[1]));
				JsonObject json = new JsonParser().parse(decodedBody).getAsJsonObject();
				JsonArray validate = json.get("resource_access").getAsJsonObject().get(client).getAsJsonObject().get("roles").getAsJsonArray();
				for(JsonElement role : validate) {
					if(roles.contains(role.getAsString())) {
						authorized = true;
					}
				}
			} else authorized = true; 
		} else authorized = true; 
			
        if(authorized) {
        	chain.doFilter(req, response);
        }
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		client = env.getProperty("security.client");
		roles = Arrays.asList(fromProps);
		securityEnabled = Boolean.valueOf(env.getProperty("security.oauth2.enabled"));
		checkRole = Boolean.valueOf(env.getProperty("security.roles.enabled"));
	}

	@Override
	public void destroy() {
	}
}