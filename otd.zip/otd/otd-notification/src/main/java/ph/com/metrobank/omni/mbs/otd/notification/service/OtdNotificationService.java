package ph.com.metrobank.omni.mbs.otd.notification.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.dto.AutoEnrollAttempt;
import ph.com.metrobank.omni.mbs.otd.notification.dto.ContactDto;
import ph.com.metrobank.omni.mbs.otd.notification.dto.KafkaMessage;
import ph.com.metrobank.omni.mbs.otd.notification.dto.MetaDto;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationBody;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationFilter;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationPayload;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationTemplateDto;
import ph.com.metrobank.omni.mbs.otd.notification.factory.HttpClientFactory;
import ph.com.metrobank.omni.mbs.otd.notification.model.OtdFedbackRequest;
import ph.com.metrobank.omni.mbs.otd.notification.repository.webengine.OtdFedbackRequestRepository;
import ph.com.metrobank.omni.mbs.otd.notification.rest.AbstractEnd;
import ph.com.metrobank.omni.mbs.otd.notification.rest.JsonTypePost;
import ph.com.metrobank.omni.mbs.otd.notification.util.ProcessingUtils;

@Service
public class OtdNotificationService extends AbstractEnd {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OtdNotificationService.class);

	@Autowired
	private HttpClientFactory clientFactory;

	@Autowired
	private KafkaSenderService kafka;

	@Autowired
	private OtdFedbackRequestRepository transactions;

	private CloseableHttpClient client;	

	private static String notificationTopic;
	private static String autoEnrollUri;
//	private String emailServiceUri;
	
	
	@Override
	protected void initialize() throws Throwable {
		notificationTopic = env.getProperty("topic.notification.mbs");
		autoEnrollUri = env.getProperty("uri.mbs.otd.autoEnroll");
		client = clientFactory.createClient();
		LOGGER.info("MBS Kafka Topic: {}", notificationTopic);
	}
	
	public Object acknowledge(ContactDto dto) throws IOException  {
						
		//start added by rlbautista 09-30-2019
		MetaDto meta = null;
		Optional<OtdFedbackRequest> or = transactions.findByReferenceId(dto.getReferenceId());	
		if(or.isPresent()) {
			OtdFedbackRequest otdreq = or.get();						
			meta = new MetaDto(dto.getCurrency(), dto.getPrincipalAmount(), dto.getTerm(), dto.getInterestRate(), dto.getRolloverInstruction(),
					otdreq.getAccountId(), AppConstants.MATURITY_FORMATTER.format(otdreq.getCreated().toLocalDateTime()), dto.getReferenceId());
			LOGGER.info("META DTO = {}",meta.toString());
		}
		//end
		
		NotificationTemplateDto notification = new NotificationTemplateDto();
		NotificationFilter filter = notification.getFilter();
		filter.setId(dto.getCustomerId());
		filter.setEmail(dto.getEmail());
		filter.setMobile(dto.getMobile());

		NotificationBody notificationBody = notification.getBody();
		NotificationPayload payload = notification.getPayload();

		String code = AppConstants.OTD_RECEIPT_TEMPLATE_KEY;
		payload.addEmailToken(AppConstants.TRANSACTION_REFEFERENCE_ID, dto.getReferenceId());
		String name = dto.getName();
		payload.addEmailToken(AppConstants.ACCOUNT_NAME, StringUtils.isBlank(name) || name == null ? AppConstants.VALUED_CLIENT : name);
		payload.addEmailToken(AppConstants.CURRENCY_PARAMETER, StringUtils.equalsIgnoreCase(dto.getCurrency(), AppConstants.PHP) ? AppConstants.PESO : AppConstants.DOLLAR);
		payload.addEmailToken(AppConstants.PRINCIPAL_AMOUNT, dto.getPrincipalAmount());
		payload.addEmailToken(AppConstants.TERM, dto.getTerm());
		payload.addEmailToken(AppConstants.PAYOUT, dto.getRolloverInstruction());
		payload.addEmailToken(AppConstants.INTEREST_RATE, dto.getInterestRate());	
		//payload.setMeta(dto.getReferenceId());
		payload.setMeta(meta);
		payload.addSmsToken(AppConstants.TRANSACTION_REFEFERENCE_ID, dto.getReferenceId());
		payload.setStatus(AppConstants.INFO_STATUS);
		payload.setTransactionStatus(AppConstants.INFO_STATUS);
		notificationBody.setEmailCode(code);
		notificationBody.setSmsCode(code);
		notificationBody.setNotificationCode(code);
		
		payload.setReferenceNo(dto.getReferenceId());
		notification.setTitle(AppConstants.OTD_RECEIPT_TITLE);

		KafkaMessage message = new KafkaMessage();
		message.setTopic(notificationTopic);
		String pass = ProcessingUtils.toJson(notification, NotificationTemplateDto.class);
		message.setMessage(pass);
		kafka.send(message);
		return AppConstants.SUCCESS_MESSAGE.toString();
	}

	public Object callAutoEnroll(AutoEnrollAttempt enroll) throws Exception {
		JsonTypePost forPost = new JsonTypePost(autoEnrollUri, Optional.ofNullable(ProcessingUtils.toJson(enroll, AutoEnrollAttempt.class)), obtainAccessObject());
		CloseableHttpResponse response = client.execute(forPost);
		return EntityUtils.toString(response.getEntity());
	}
	

	//TODO: fill in with updated process and link for use after R4
	public Object termination(ContactDto dto) {
		Optional<OtdFedbackRequest> find = transactions.findByReferenceId(dto.getReferenceId());
		if(find.isPresent()) {
			LocalDateTime now = LocalDateTime.now();
			OtdFedbackRequest transaction = find.get();
			transaction.setUpdated(Timestamp.valueOf(now));
			
			NotificationTemplateDto notification = new NotificationTemplateDto();
			NotificationFilter filter = notification.getFilter();
			filter.setId(dto.getCustomerId());
			filter.setEmail(dto.getEmail());
			filter.setMobile(dto.getMobile());

			NotificationBody notificationBody = notification.getBody();
			NotificationPayload payload = notification.getPayload();
			
			String code = AppConstants.OTD_PRE_TERMINATION_TEMPLATE_KEY;
			payload.addEmailToken(AppConstants.TRANSACTION_REFEFERENCE_ID, dto.getReferenceId());
			String name = dto.getName();
			payload.addEmailToken(AppConstants.ACCOUNT_NAME, StringUtils.isBlank(name) || name == null ? AppConstants.VALUED_CLIENT : name);
			payload.addEmailToken(AppConstants.CURRENCY_PARAMETER, dto.getCurrency());
			payload.addEmailToken(AppConstants.PRINCIPAL_AMOUNT, dto.getPrincipalAmount());
			payload.addEmailToken(AppConstants.TERM, dto.getTerm());
			payload.addEmailToken(AppConstants.PAYOUT, dto.getRolloverInstruction());
			payload.addEmailToken(AppConstants.INTEREST_RATE, dto.getInterestRate());
			payload.setMeta(dto.getReferenceId());
			payload.addSmsToken(AppConstants.TRANSACTION_REFEFERENCE_ID, dto.getReferenceId());
			payload.setStatus(AppConstants.INFO_STATUS);
			payload.setTransactionStatus(AppConstants.INFO_STATUS);
			notificationBody.setEmailCode(code);
			notificationBody.setSmsCode(code);
			notificationBody.setNotificationCode(code);
			
			payload.setReferenceNo(dto.getReferenceId());
			notification.setTitle(AppConstants.OTD_PRE_TERMINATION_TITLE);

			KafkaMessage message = new KafkaMessage();
			message.setTopic(notificationTopic);
			String pass = ProcessingUtils.toJson(notification, NotificationTemplateDto.class);
			message.setMessage(pass);
			kafka.send(message);
			
			transactions.save(transaction);
		}
		return AppConstants.SUCCESS_MESSAGE.toString();
	}

}
