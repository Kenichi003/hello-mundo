package ph.com.metrobank.omni.mbs.otd.notification.dto;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;

public class RolledOverMaturationNotification extends NotificationTemplateDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1598766264271338229L;
	public RolledOverMaturationNotification() {
		super();
		title = AppConstants.OTD_ROLLED_OVER_MATURATION_NOTIFICATION_TITLE;
	}
}
