package ph.com.metrobank.omni.mbs.otd.notification.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchEvent.Kind;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.reader.MaturityFileReader;
import ph.com.metrobank.omni.mbs.otd.notification.reader.SecondHostFeedbackFileReader;

@Service
public class OtdSecondFileWatcherService implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(OtdSecondFileWatcherService.class);

	@Autowired
	private Environment env;

	@Autowired
	private SecondHostFeedbackFileReader secondFeedbackReader;

	@Autowired
	private MaturityFileReader maturation;

	private static Path parent;
	private static Path maturityComaparisonSource;
	private static Path secondHostFileComparisonSource;
	private static String maturityFile;
	private static String secondHostFeedbackFile;
	private static LocalDate processFlag;
	private static boolean watch = true;
	
	@PostConstruct
	private void initialize() throws Exception {
		watch = Boolean.valueOf(env.getProperty("toggle.watch"));
		if(watch) {
			processFlag = LocalDate.now();
			Path resourceBase = Paths.get(AppConstants.RELATIVE_PATH_BASE, env.getProperty("path.resources"));
			if(!Files.exists(resourceBase)) {
				Files.createDirectory(resourceBase);
			}

			maturityFile = env.getProperty("path.maturationFile");
			secondHostFeedbackFile = env.getProperty("path.secondHostFeedbackFile");
			parent = Paths.get(env.getProperty("path.dropFolder"));
			maturityComaparisonSource = resourceBase.resolve(maturityFile);
			secondHostFileComparisonSource = resourceBase.resolve(secondHostFeedbackFile);

			if(!Files.exists(maturityComaparisonSource)) {
				Files.createFile(maturityComaparisonSource);
			}

			if(!Files.exists(secondHostFileComparisonSource)) {
				Files.createFile(secondHostFileComparisonSource);
			}

			begin();
		}
	}

	public void begin() throws InterruptedException {
		ExecutorService runner = Executors.newSingleThreadExecutor();
		runner.execute(this);
		runner.shutdown();
		runner.awaitTermination(20, TimeUnit.SECONDS);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void run() {
		LOGGER.info("Starting watch for the otd files from host @ {}", parent.toString());
		WatchService watcher;
		try {
			watcher = parent.getFileSystem().newWatchService();
			parent.register(watcher, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY);

			WatchKey watchKey = null;

			while (watch) {
				try {
					watchKey = watcher.take(); 
					if(watchKey != null) {
						watchKey.pollEvents().stream().forEach(event -> {
							WatchEvent.Kind<Path> kind = (Kind<Path>) event.kind();
							Path name = ((WatchEvent<Path>) event).context();

							if(Files.isDirectory(name)) {
								return;
							}

							if(kind == StandardWatchEventKinds.ENTRY_MODIFY || kind == StandardWatchEventKinds.ENTRY_CREATE) {
								Path path = parent.resolve(name);
								try {
									String fileName = name.getFileName().toString();
									if(StringUtils.equalsIgnoreCase(fileName, maturityFile)) {
										if(Files.size(path) > 0) {
											LOGGER.info("Maturity file dropped, processing...");
											if(maturation.readMaturityRecords(path, processFlag)) {
												processFlag = LocalDate.now();
											}
										}
									} else if(StringUtils.equalsIgnoreCase(fileName, secondHostFeedbackFile)) {
										if(Files.size(path) > 0) {
											LOGGER.info("Second host feedback file dropped @{}, processing...", path.toString());
											List<String> lineCheck = Files.readAllLines(path);
											int size = lineCheck.size();
											boolean padded = false;
											for(int i = 1; i < size; i++) {
												String line = lineCheck.get(i);
												if(StringUtils.length(line) != 391) {
													line = StringUtils.rightPad(line, 391, AppConstants.SPACE);
													lineCheck.set(i, line);
													padded = true;
												}
											}

											if(!padded) {
												LOGGER.info("All lines valid. No need for padding...");
												secondFeedbackReader.readFeedback(path);
											} else {
												StringBuilder sb = new StringBuilder();
												for(String line : lineCheck) {
													sb.append(line).append(AppConstants.NEXT_LINE_PARAMETER);
												}
												Files.write(path, sb.toString().getBytes(), StandardOpenOption.TRUNCATE_EXISTING);
												LOGGER.info("Padding done. Proceeding...");
											}
										}
									}
								} catch (Exception e) {
									LOGGER.error("\nError during file processing:\n{}", e);
								}
							}
						});
						
						watchKey.reset();
					}
				} catch(Exception e) {
					LOGGER.error("\nError during file watch:\n{}", e);
					continue;
				}
			}
		} catch(Exception e) {
			LOGGER.error("\nError during file watch registration:\n{}", e);
		}

	}
}
