package ph.com.metrobank.omni.mbs.otd.notification.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.model.OtdFedbackRequest;

@Component
public class ProcessingUtils {
	public static final Gson GSON;
	public static final Gson PRETTIFIER;
	private static final ObjectMapper MAPPER = new ObjectMapper();
	private static final JsonParser PARSER = new JsonParser();

	static {
		GsonBuilder builder = new GsonBuilder();
		GSON = builder.disableHtmlEscaping().create();
		PRETTIFIER = builder.setPrettyPrinting().create();	
	}
	
	public static String append(String...strings) {
		StringBuilder sb = new StringBuilder();
		for(String string : strings) {
			sb.append(string);
		}

		return sb.toString();
	}

	public static boolean isJson(String value) { 
		if(!StringUtils.isBlank(value)) {
			try {
				MAPPER.readTree(value);
				return true;
			} catch (IOException e) {
				return false;
			}
		}
		
		return false;
	}
	
	public static void writeToFile(String path, String json) throws IOException {
		try (PrintWriter writer = new PrintWriter(new FileWriter(path.toString()))) {
			writer.write(json.toString());
		}		
	}

	public static String getStackTrace(Throwable t) {
		StackTraceElement[] elements = t.getStackTrace();
		StringBuilder sb = new StringBuilder();
		sb.append(AppConstants.NEXT_LINE_PARAMETER).append(t.getMessage());
		for(StackTraceElement element : elements) {
			sb.append(AppConstants.NEXT_LINE_PARAMETER).append(element.toString());
		}

		return sb.toString();
	}

	public static <T> String toJson(Object convert, Class<T> from) {
		return GSON.toJson(convert, from);
	}
	
	public static Object fromJson(JsonElement convert, Class<?> to) {
		return GSON.fromJson(convert, to);
	}

	public static JsonElement toJson(String value) {
		return new JsonParser().parse(value);
	}

	public static LocalDateTime toLocalDateTime(LocalDate date) {
		return LocalDateTime.of(date, LocalTime.now());
	}

	public static String insertIntoString(String base, String insert, int position) {
		StringBuilder sb = new StringBuilder(base);
		sb.insert(position, insert);
		return sb.toString();
	}

	public static JsonElement parseJson(String value) {
		return PARSER.parse(value);
	}
	
	public static JsonElement parseJson(Object convert, Class<?> from) {
		return PARSER.parse(GSON.toJson(convert, from));
	}
	
	public static String prettyJson(String from) {
		return PRETTIFIER.toJson(parseJson(from));
	}

	public static String prettyJson(JsonElement from) {
		return PRETTIFIER.toJson(from);
	}

	public static String formatMaturityDate(String date) {
		return AppConstants.MATURITY_FORMATTER.format(LocalDate.parse(date, AppConstants.SDF));
	}

	public static String formatTransactionDate(Timestamp timestamp) {
		return AppConstants.MATURITY_FORMATTER.format(timestamp.toLocalDateTime());
	}

	public static Timestamp timeStampFromDate(String formattedMaturityDate) {
		LocalDate formattedDate = LocalDate.parse(formattedMaturityDate, AppConstants.MATURITY_FORMATTER);
		return Timestamp.valueOf(formattedDate.atStartOfDay());
	}

	public static Object forLogging(OtdFedbackRequest fromDb) {
		return prettyJson(parseJson(fromDb, fromDb.getClass()));
	}

	public static JsonElement getResponse(HttpResponse fromCasa) throws ParseException, IOException {
		String convertedEntity = EntityUtils.toString(fromCasa.getEntity());
		return ProcessingUtils.parseJson(convertedEntity);
	}
}
