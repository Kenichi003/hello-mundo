package ph.com.metrobank.omni.mbs.otd.notification.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;

@Configuration
@ConfigurationProperties(prefix = "prop.otd")
public class OpeningFailureReasons { 	
	private static Logger LOGGER = LoggerFactory.getLogger(OpeningFailureReasons.class);

	@Value("${path.failureReasons}")
	private String path;

	@Value("${path.resources}")
	private String resourceFolder;

	private String insufficientFunds;
	private String insufficientFundsTitle;
	private String insufficientFundsSubtitle;
	
	private String inactiveAccount;
	private String inactiveAccountTitle;

	private String otherReasons;
	private String otherReasonsTitle;

	private List<String> inactiveAccountReason;
	private List<String> insufficientFundsReason;
	private List<String> otherReasonsReason;

	@PostConstruct
	public void updateFromFile() throws IOException {
		Path file = Paths.get(AppConstants.RELATIVE_PATH_BASE, resourceFolder, path);
		
		if(Files.exists(file)) {
			LOGGER.info("Attempting failure reasons update from file...");
	        try (InputStream input = new FileInputStream(file.toFile())) {
	            Properties prop = new Properties();
	            prop.load(input);
	            insufficientFunds = prop.getProperty("prop.otd.insufficientFunds");
	        	insufficientFundsTitle = prop.getProperty("prop.otd.insufficientFunds.title");
	        	insufficientFundsSubtitle = prop.getProperty("prop.otd.insufficientFunds.subTitle");
	        	insufficientFundsReason = new ArrayList<>();
	        	String iftReason = prop.getProperty("prop.otd.insufficientFunds.reason");
	        	String[] split = StringUtils.split(iftReason, ",");
	        	for(String entry : split) {
	        		entry = StringUtils.trim(entry);
	        		insufficientFundsReason.add(entry);
	        	}
	        	
	        	inactiveAccount = prop.getProperty("prop.otd.inactiveAccount");
	        	inactiveAccountTitle = prop.getProperty("prop.otd.inactiveAccount.title");
	        	inactiveAccountReason = new ArrayList<>();
	        	String reason = prop.getProperty("prop.otd.inactiveAccount.reason");
	        	inactiveAccountReason.add(reason);

	        	otherReasons = prop.getProperty("prop.otd.otherReasons");
	        	otherReasonsTitle = prop.getProperty("prop.otd.otherReasons.title");
	        	otherReasonsReason = new ArrayList<>();

//	            if(LOGGER.isDebugEnabled())	{
		        	LOGGER.info("inactive title: {}", inactiveAccountTitle);
		        	LOGGER.info("inactive reason: {}", reason);
		        	LOGGER.info("ift title: {}", insufficientFundsTitle);
		        	LOGGER.info("ift subtitle: {}", insufficientFundsSubtitle);
		        	LOGGER.info("ift reason: ", iftReason);
		        	LOGGER.info("OR title: {}", otherReasonsTitle);

		        	LOGGER.info(insufficientFunds);
		            LOGGER.info(inactiveAccount);
		            LOGGER.info(otherReasons);
//	            }
	        }
	        
			LOGGER.info("Update complete...");
		} else {
			LOGGER.info("failure reasons file not found.");
		}
	}

	public String getInsufficientFunds() {
		return insufficientFunds;
	}

	public void setInsufficientFunds(String insufficientFunds) {
		this.insufficientFunds = insufficientFunds;
	}

	public String getInactiveAccount() {
		return inactiveAccount;
	}

	public void setInactiveAccount(String inactiveAccount) {
		this.inactiveAccount = inactiveAccount;
	}

	public String getOtherReasons() {
		return otherReasons;
	}

	public void setOtherReasons(String others) {
		this.otherReasons = others;
	}

	public String getInsufficientFundsSubtitle() {
		return insufficientFundsSubtitle;
	}

	public void setInsufficientFundsSubtitle(String insufficientFundsSubtitle) {
		this.insufficientFundsSubtitle = insufficientFundsSubtitle;
	}

	public String getInsufficientFundsTitle() {
		return insufficientFundsTitle;
	}

	public void setInsufficientFundsTitle(String insufficientFundsTitle) {
		this.insufficientFundsTitle = insufficientFundsTitle;
	}

	public List<String> getInsufficientFundsReason() {
		return insufficientFundsReason;
	}

	public void setInsufficientFundsReason(List<String> insufficientFundsReason) {
		this.insufficientFundsReason = insufficientFundsReason;
	}

	public String getInactiveAccountTitle() {
		return inactiveAccountTitle;
	}

	public void setInactiveAccountTitle(String inactiveAccountTitle) {
		this.inactiveAccountTitle = inactiveAccountTitle;
	}

	public List<String> getInactiveAccountReason() {
		return inactiveAccountReason;
	}

	public void setInactiveAccountReason(List<String> inactiveAccountReason) {
		this.inactiveAccountReason = inactiveAccountReason;
	}

	public String getOtherReasonsTitle() {
		return otherReasonsTitle;
	}

	public void setOtherReasonsTitle(String otherReasonsTitle) {
		this.otherReasonsTitle = otherReasonsTitle;
	}

	public List<String> getOtherReason() {
		return otherReasonsReason;
	}

	public void setOtherReason(List<String> otherReason) {
		this.otherReasonsReason = otherReason;
	}

	public List<String> getOtherReasonsReason() {
		return otherReasonsReason;
	}

	public void setOtherReasonsReason(List<String> otherReasonsReason) {
		this.otherReasonsReason = otherReasonsReason;
	}
}