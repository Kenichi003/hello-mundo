package ph.com.metrobank.omni.mbs.otd.notification.exception;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import ph.com.metrobank.omni.mbs.otd.notification.dto.ErrorResponse;

@Component
public class GenericExceptionMapper implements ExceptionMapper<Throwable> {

	private static final Logger LOGGER = LoggerFactory.getLogger(GenericExceptionMapper.class);

	@Value("${app.name}")
	private String appName;

	@Value("${app.version}")
	private String appVersion;

	public Response toResponse(Throwable exception) {
		LOGGER.error("An error was encountered. exception={{}}", exception);
		ErrorResponse jsonResponse = new ErrorResponse(appName, appVersion);
		jsonResponse.setMessage(exception.getMessage());

		if (exception instanceof WebApplicationException) {
			WebApplicationException wae = (WebApplicationException) exception;
			jsonResponse.setCode(wae.getResponse().getStatus());
		} else {
			jsonResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		}

		return Response.status(jsonResponse.getCode()).entity(jsonResponse).type(MediaType.APPLICATION_JSON).build();
	}
}
