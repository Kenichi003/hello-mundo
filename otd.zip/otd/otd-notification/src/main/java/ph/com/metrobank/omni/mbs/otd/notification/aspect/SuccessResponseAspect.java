package ph.com.metrobank.omni.mbs.otd.notification.aspect;

import java.util.Collection;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ph.com.metrobank.omni.mbs.otd.notification.dto.SuccessResponse;

@Aspect
@Component
public class SuccessResponseAspect {

  private static final Logger LOGGER = LoggerFactory.getLogger(SuccessResponseAspect.class);

  @Value("${app.name}")
  private String appName;

  @Value("${app.version}")
  private String appVersion;

  @Around(value = "execution(* ph.com.metrobank.omni.mbs.otd.notification.endpoint..*.*(..))")
  public Object createSuccessResponse(ProceedingJoinPoint joinPoint) throws Throwable {

    LOGGER.info("Starting method execution for {}, details = {{}}",
        joinPoint.getSignature().getName(), joinPoint.getArgs());

    Object result = joinPoint.proceed();

    if (result instanceof Collection) {
      LOGGER.info("Finished execution of {}", joinPoint.getSignature().getName());
    } else {
      LOGGER.info("Finished execution of {}, response = {{}}", joinPoint.getSignature().getName(), result);
    }

    return new SuccessResponse(result, appName, appVersion);
  }

}
