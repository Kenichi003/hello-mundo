package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.io.Serializable;

public class MetaSuccessDto implements Serializable {	
	private static final long serialVersionUID = 1L;	
	private String tdAccountNumber;
	private String currency;
	private String principalAmount;
	private String interestRate;
	private String term;
	private String payoutOption;
	private String maturityDate;
	private String settlementAccount;	
	private String transactionDate;
	private String referenceId;
	
	
	public String getTdAccountNumber() {
		return tdAccountNumber;
	}
	public void setTdAccountNumber(String tdAccountNumber) {
		this.tdAccountNumber = tdAccountNumber;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPrincipalAmount() {
		return principalAmount;
	}
	public void setPrincipalAmount(String principalAmount) {
		this.principalAmount = principalAmount;
	}
	public String getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getPayoutOption() {
		return payoutOption;
	}
	public void setPayoutOption(String payoutOption) {
		this.payoutOption = payoutOption;
	}
	public String getMaturityDate() {
		return maturityDate;
	}
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}
	public String getSettlementAccount() {
		return settlementAccount;
	}
	public void setSettlementAccount(String settlementAccount) {
		this.settlementAccount = settlementAccount;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getReferenceId() {
		return referenceId;
	}
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	
	public MetaSuccessDto() {
		super();
	}
	
	
	public MetaSuccessDto(String tdAccountNumber, String currency, String principalAmount, String interestRate,
			String term, String payoutOption, String maturityDate, String settlementAccount, String transactionDate,
			String referenceId) {
		super();
		this.tdAccountNumber = tdAccountNumber;
		this.currency = currency;
		this.principalAmount = principalAmount;
		this.interestRate = interestRate;
		this.term = term;
		this.payoutOption = payoutOption;
		this.maturityDate = maturityDate;
		this.settlementAccount = settlementAccount;
		this.transactionDate = transactionDate;
		this.referenceId = referenceId;
	}
	@Override
	public String toString() {
		return "MetaSuccessDto [tdAccountNumber=" + tdAccountNumber + ", currency=" + currency + ", principalAmount="
				+ principalAmount + ", interestRate=" + interestRate + ", term=" + term + ", payoutOption="
				+ payoutOption + ", maturityDate=" + maturityDate + ", settlementAccount=" + settlementAccount
				+ ", transactionDate=" + transactionDate + ", referenceId=" + referenceId + "]";
	}


	
	
	
	
	
}
