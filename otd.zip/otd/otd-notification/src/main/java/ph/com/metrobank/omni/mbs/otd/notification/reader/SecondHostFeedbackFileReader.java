package ph.com.metrobank.omni.mbs.otd.notification.reader;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.HttpResponse;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.keycloak.representations.AccessTokenResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.github.ffpojo.file.reader.FileSystemFlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import ph.com.metrobank.omni.mbs.otd.notification.AppConstants;
import ph.com.metrobank.omni.mbs.otd.notification.config.OpeningFailureReasons;
import ph.com.metrobank.omni.mbs.otd.notification.dto.AutoEnrollAttempt;
import ph.com.metrobank.omni.mbs.otd.notification.dto.KafkaMessage;
import ph.com.metrobank.omni.mbs.otd.notification.dto.MetaFailedDto;
import ph.com.metrobank.omni.mbs.otd.notification.dto.MetaReasonFailedDto;
import ph.com.metrobank.omni.mbs.otd.notification.dto.MetaSuccessDto;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationBody;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationFilter;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationPayload;
import ph.com.metrobank.omni.mbs.otd.notification.dto.NotificationTemplateDto;
import ph.com.metrobank.omni.mbs.otd.notification.factory.HttpClientFactory;
import ph.com.metrobank.omni.mbs.otd.notification.factory.ThreadFactory;
import ph.com.metrobank.omni.mbs.otd.notification.model.OtdCustomer;
import ph.com.metrobank.omni.mbs.otd.notification.model.OtdFedbackRequest;
import ph.com.metrobank.omni.mbs.otd.notification.repository.webengine.CustomerRepository;
import ph.com.metrobank.omni.mbs.otd.notification.repository.webengine.OtdFedbackRequestRepository;
import ph.com.metrobank.omni.mbs.otd.notification.rest.JsonTypePost;
import ph.com.metrobank.omni.mbs.otd.notification.rest.PostCall;
import ph.com.metrobank.omni.mbs.otd.notification.service.KafkaSenderService;
import ph.com.metrobank.omni.mbs.otd.notification.util.ProcessingUtils;

@Component
public class SecondHostFeedbackFileReader {
	private static final Logger LOGGER = LoggerFactory.getLogger(SecondHostFeedbackFileReader.class);

	private static String accessToken;

	@Autowired
	private OtdFedbackRequestRepository requestRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private HttpClientFactory clientFactory;

	@Autowired
	private ThreadFactory threadFactory;
	
	@Autowired
	private KafkaSenderService kafka;

	@Autowired
	private Environment env;

	@Autowired
	private OpeningFailureReasons whyFailed;

	private String mbsNotificationTopic;

	private String autoEnrollUri;

	private FlatFileReaderDefinition ffDefinition;

	private String[] rolloverInstructions;

	private int batchSize;

	private CloseableHttpAsyncClient client;

	@PostConstruct
	private void initialize() throws Exception {
		mbsNotificationTopic = env.getProperty("topic.notification.mbs");
		autoEnrollUri = env.getProperty("uri.mbs.otd.autoEnroll");

		ffDefinition = new FlatFileReaderDefinition(OtdFedbackRequest.class);
		ffDefinition.setHeader(Header.class);
		ffDefinition.setTrailer(Trailer.class);
		rolloverInstructions = StringUtils.split(env.getProperty("value.rolloverInstructions"), ";");
		batchSize = env.getProperty("spring.jpa.properties.hibernate.jdbc.batch_size", Integer.class);
		
		client = clientFactory.createAsyncClient();
	}

	@PositionalRecord
	public static class Header {

		private String code;
		private String date;

		@PositionalField(initialPosition = 1, finalPosition = 1)
		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		@PositionalField(initialPosition = 2, finalPosition = 9)
		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}
	}

	@PositionalRecord
	public static class Trailer {

		private String code;
		private String total;

		@PositionalField(initialPosition = 1, finalPosition = 1)
		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		@PositionalField(initialPosition = 2, finalPosition = 11)
		public String getTotal() {
			return total;
		}

		public void setTotal(String total) {
			this.total = total;
		}
	}

	public void readFeedback(Path inputPath) throws Exception {
		if (Files.exists(inputPath)) {
			JsonObject access = obtainAccessObject();
			FlatFileReader ffReader = null;
			String reason = StringUtils.EMPTY;
			int reasonCode = -1;

			try {
				File inputFile = inputPath.toFile();
				ffReader = new FileSystemFlatFileReader(inputFile, ffDefinition);

				List<OtdFedbackRequest> updates = new LinkedList<>();
				List<PostCall> postCalls = new ArrayList<>();
				Map<String, NotificationTemplateDto> forKafka = new HashMap<>();

				for (Object record : ffReader) {					
					if(record instanceof OtdFedbackRequest) {					
						OtdFedbackRequest feedback = (OtdFedbackRequest) record;
						String referenceId = feedback.getReferenceId();
						LOGGER.info("OTD Transaction Reference I.D. = {}", referenceId);						
						Optional<OtdFedbackRequest> find = requestRepository.findByReferenceId(referenceId);					
						if(find.isPresent()) {							
							OtdFedbackRequest stored = find.get();
							String statusFlag = stored.getOpeningStatusFlag();
							if (!StringUtils.isEmpty(statusFlag)) {							
								LOGGER.info("Opening status flag: {{}}. This record has already been processed. Skipping...", statusFlag);
								continue;
							}

							feedback.setAccountName(stored.getAccountName());
							feedback.setId(stored.getId());
							feedback.setCustomerId(stored.getCustomerId());
							Timestamp now = Timestamp.valueOf(LocalDateTime.now());
							feedback.setCreated(stored.getCreated() == null ? now : stored.getCreated());
							feedback.setUpdated(now);
							feedback.setUpdatedBy(AppConstants.OTD_SERVICE);
							String date = feedback.getTransactionDateFromFile();
							if(!StringUtils.isBlank(date)) {
								LocalDate local = LocalDate.parse(date, AppConstants.FROM_HOST_FILE_FORMATTER);
								feedback.setTransactionDate(Timestamp.valueOf(ProcessingUtils.toLocalDateTime(local)));
								date = feedback.getMaturityDateFromFile();
								local = LocalDate.parse(date, AppConstants.FROM_HOST_FILE_FORMATTER);
								feedback.setMaturityDate(Timestamp.valueOf(ProcessingUtils.toLocalDateTime(local)));
							}

							updates.add(feedback);
							String otdAccountId = StringUtils.remove(feedback.getOtdAccountId(), AppConstants.DASH);
							String customerId = stored.getCustomerId();

							Optional<OtdCustomer> findCustomer = customerRepository.findById(Long.valueOf(customerId));
							if(findCustomer.isPresent()) {
								OtdCustomer customer = findCustomer.get();
								int length = StringUtils.length(otdAccountId);

								String maskedOtdAccountId = ProcessingUtils.append(AppConstants.OTD_ACCOUNT_PREFIX, StringUtils.substring(otdAccountId, length - 4, length));

								NotificationTemplateDto notification = new NotificationTemplateDto();
								NotificationFilter filter = notification.getFilter();

								filter.setId(customerId);
								filter.setEmail(customer.getEmail());
								filter.setMobile(customer.getMobile());
								boolean succeeded = StringUtils.equals(feedback.getOpeningStatusFlag(), AppConstants.ONE); 
								NotificationBody notificationBody = notification.getBody();
								NotificationPayload payload = notification.getPayload();

								BigDecimal computedRate = BigDecimal.ZERO;
								String terms = StringUtils.EMPTY;

								String code;
								if(succeeded) {
									code = AppConstants.OTD_ACCOUNT_OPENING_SUCCESS_TEMPLATE_KEY;
									payload.addEmailToken(AppConstants.TRANSACTION_REFEFERENCE_NUMBER, feedback.getReferenceId());
									payload.addEmailToken(AppConstants.TD_ACCOUNT_NUMBER, maskedOtdAccountId);

									String name = feedback.getAccountName();
									payload.addEmailToken(AppConstants.ACCOUNT_NAME, name == null || StringUtils.isBlank(name) ? AppConstants.VALUED_CLIENT : name);
									payload.addEmailToken(AppConstants.TD_ACCOUNT_NAME, feedback.getOtdAccountName());
									payload.addEmailToken(AppConstants.CURRENCY_PARAMETER, StringUtils.equals(feedback.getCurrencyCode(), AppConstants.PESO_CODE) ? AppConstants.PESO : AppConstants.USD_UPPERCASE);						
									payload.addEmailToken(AppConstants.PRINCIPAL_AMOUNT, AppConstants.TWO_DECIMAL_FORMATTER.format(NumberUtils.createBigDecimal(feedback.getPlacementAmount()).divide(AppConstants.PLACEMENT_AMOUNT_REDUCER)));											
									String baseRate = ProcessingUtils.insertIntoString(feedback.getBaseRate(), AppConstants.DOT, 3);
									String addOnRate = ProcessingUtils.insertIntoString(feedback.getAddOnRate(), AppConstants.DOT, 3);
									computedRate = NumberUtils.createBigDecimal(baseRate).add(NumberUtils.createBigDecimal(addOnRate));
									payload.addEmailToken(AppConstants.INTEREST_RATE, ProcessingUtils.append(AppConstants.THREE_DECIMAL_FORMATTER.format(computedRate), "%"));
									payload.addEmailToken(AppConstants.TRANSACTION_DATE_PARAMETER, feedback.getTransactionDateFromFile());
									payload.addEmailToken(AppConstants.MATURITY_DATE, feedback.getMaturityDateFromFile());
									payload.addEmailToken(AppConstants.SETTLEMENT_ACCOUNT_PARAMETER, feedback.getAccountId());
									payload.addEmailToken(AppConstants.PAYOUT, rolloverInstructions[NumberUtils.createInteger(feedback.getRolloverInstruction())]);
									payload.addSmsToken(AppConstants.TRANSACTION_REFEFERENCE_NUMBER, feedback.getReferenceId());
									String tenorValue = feedback.getTenor();
									Byte tenor = Byte.valueOf(tenorValue);
									if(tenor == 1) {
										terms = ProcessingUtils.append(String.valueOf(tenor), AppConstants.SPACE, AppConstants.MONTH);
									} else {
										terms = ProcessingUtils.append(String.valueOf(tenor), AppConstants.SPACE, AppConstants.MONTHS);
									}

									payload.addEmailToken(AppConstants.TERM, terms);
									notification.setSucceeded();
								} else {						
									code = AppConstants.OTD_ACCOUNT_OPENING_FAILURE_TEMPLATE_KEY;
									String name = feedback.getAccountName();
									payload.addEmailToken(AppConstants.ACCOUNT_NAME, name == null || StringUtils.isBlank(name) ? AppConstants.VALUED_CLIENT : name);
									payload.addEmailToken(AppConstants.TRANSACTION_REFEFERENCE_ID, feedback.getReferenceId());
									payload.addEmailToken(AppConstants.CURRENCY_PARAMETER, StringUtils.equals(feedback.getCurrencyCode(), AppConstants.PESO_CODE) ? AppConstants.PHP_UPPERCASE : AppConstants.USD_UPPERCASE);
									payload.addEmailToken(AppConstants.PRINCIPAL_AMOUNT, AppConstants.TWO_DECIMAL_FORMATTER.format(NumberUtils.createBigDecimal(feedback.getPlacementAmount()).divide(AppConstants.PLACEMENT_AMOUNT_REDUCER)));
									payload.addEmailToken(AppConstants.TRANSACTION_DATE_PARAMETER, AppConstants.MATURITY_FORMATTER.format(feedback.getCreated().toLocalDateTime()));
									payload.addEmailToken(AppConstants.SETTLEMENT_ACCOUNT_PARAMETER, feedback.getAccountId());
									payload.addSmsToken(AppConstants.TRANSACTION_REFEFERENCE_ID, feedback.getReferenceId());


									switch(StringUtils.trim(feedback.getRemarks())) {
									case AppConstants.INVALID_DETAILS:
									case AppConstants.ACCOUNT_NOT_IN_MEMO:
									case AppConstants.ACCOUNT_NOT_ACTIVE:
										reason = whyFailed.getInactiveAccount();
										reasonCode = 0;
										break;
									case AppConstants.INSUFFICIENT_FUNDS:
										reason = whyFailed.getInsufficientFunds();
										reasonCode = 1;
										break;
									default:
										reason = whyFailed.getOtherReasons();
										reasonCode = 2;
									}

									payload.addEmailToken(AppConstants.REASON, reason);
									notification.setFailed();
								}

								notificationBody.setEmailCode(code);
								notificationBody.setSmsCode(code);
								notificationBody.setNotificationCode(code);

								payload.setReferenceNo(feedback.getReferenceId());
								if(succeeded) {
									notification.setTitle(AppConstants.OTD_ACCOUNT_OPENING_SUCCESS_TITLE);
									payload.setMeta(metaSuccess(StringUtils.EMPTY, 
											StringUtils.equals(feedback.getCurrencyCode(), AppConstants.PESO_CODE) ? AppConstants.PHP.toUpperCase() : AppConstants.DOLLAR.toUpperCase(), 
													AppConstants.TWO_DECIMAL_FORMATTER.format(NumberUtils.createBigDecimal(feedback.getPlacementAmount()).divide(AppConstants.PLACEMENT_AMOUNT_REDUCER)),
													ProcessingUtils.append(AppConstants.THREE_DECIMAL_FORMATTER.format(computedRate), AppConstants.PERCENT), 
													terms,
													rolloverInstructions[NumberUtils.createInteger(feedback.getRolloverInstruction())],
													feedback.getMaturityDateFromFile(), 
													feedback.getAccountId(), feedback.getTransactionDateFromFile(), feedback.getReferenceId()));

									forKafka.put(otdAccountId, notification);

									AutoEnrollAttempt attempt = new AutoEnrollAttempt();
									attempt.setAccountNo(otdAccountId);
									attempt.setCustomerId(customerId);
									attempt.setCif(customer.getCif());

									JsonTypePost forPost = new JsonTypePost(autoEnrollUri, Optional.ofNullable(ProcessingUtils.toJson(attempt, AutoEnrollAttempt.class)), access);
									PostCall postCall = new PostCall(client, otdAccountId, forPost);
									postCalls.add(postCall);
								} else {
									notification.setTitle(AppConstants.OTD_ACCOUNT_OPENING_FAILURE_TITLE);						
									MetaFailedDto metaFailed = new MetaFailedDto();
									metaFailed.setCurrency(StringUtils.equals(feedback.getCurrencyCode(), AppConstants.PESO_CODE) ? AppConstants.PHP.toUpperCase() : AppConstants.DOLLAR.toUpperCase());
									metaFailed.setPrincipalAmount(AppConstants.TWO_DECIMAL_FORMATTER.format(NumberUtils.createBigDecimal(feedback.getPlacementAmount()).divide(AppConstants.PLACEMENT_AMOUNT_REDUCER)));
									metaFailed.setSettlementAccount(feedback.getAccountId());
									metaFailed.setTransactionDate(AppConstants.MATURITY_FORMATTER.format(feedback.getCreated().toLocalDateTime()));
									metaFailed.setReferenceId(feedback.getReferenceId());
									metaFailed.setReasons(processReason(reasonCode));						
									payload.setMeta(metaFailed);						

									String convertedPayload = ProcessingUtils.toJson(notification, NotificationTemplateDto.class);
									KafkaMessage message = new KafkaMessage();
									message.setTopic(mbsNotificationTopic);
									LOGGER.info("\nFAILED OTD PAYLOAD:\n{}", ProcessingUtils.prettyJson(convertedPayload));
									message.setMessage(convertedPayload);
									kafka.send(message);
								}
							} else {
								LOGGER.info("No customer found with I.D. # {}", customerId);
							}
						} else {
							LOGGER.info("No OTD record found with reference # {}", referenceId);
						}
					} else if(record instanceof Header) { 					
						Header header = (Header) record;
						LOGGER.info("Header date: {}", header.getDate());
						//						LocalDate dateOnFile = LocalDate.parse(header.getDate(), AppConstants.SECOND_HOST_FEEDBACK_FILE_FORMATTER);
						//						Optional<OtdSuccessfulDispatchDetails> check = timeCheckRepository.findById((long) 1);
						//						if(check.isPresent()) {
						//							OtdSuccessfulDispatchDetails runStamp = check.get();
						//							if(dateOnFile.isEqual(runStamp.getUpdated().toLocalDateTime().toLocalDate()))
						//								return;
						//						}
					} 
				}

				LOGGER.info("Invoking auto-enrollment for verified accounts...");
				threadFactory.invokePosts(postCalls);
				LOGGER.info("Processing Casa responses and collating notifications...");
				for(PostCall call : postCalls) {	
					String requestId = call.getRequestId();
					LOGGER.info("OTD # {}, begin.", requestId);

					HttpResponse fromCasa = call.getResponse();
					if(fromCasa == null) {
						LOGGER.error("Casa returned no response.");
						continue;
					}

					JsonElement casaResponse = ProcessingUtils.getResponse(fromCasa);
					LOGGER.info("Casa record: {}", ProcessingUtils.prettyJson(casaResponse));
					JsonObject casa = casaResponse.getAsJsonObject();
					NotificationTemplateDto notification = forKafka.get(call.getRequestId());

					JsonElement check = casa.get(AppConstants.DATA_PARAMETER);
					NotificationPayload payload = notification.getPayload();

					if(check.isJsonObject()) {
						JsonObject data = check.getAsJsonObject();
						if(data.has(AppConstants.ID_PARAMETER)) {
							String id = data.get(AppConstants.ID_PARAMETER).getAsString();
							payload.setSourceAccountId(id);
						} else {
							LOGGER.error("\nNo ID returned for OTD # {}. \nCasa response is:\n {}", requestId, ProcessingUtils.prettyJson(check));
						}
					} else {
						LOGGER.error("\nUnexpected auto-enrollment response returned for OTD # {}. \nCasa response is:\n {}", requestId, ProcessingUtils.prettyJson(check));
					}

					payload.setTransactionType(AppConstants.TIME_DEPOSIT_TYPE);
					payload.setType(AppConstants.TIME_DEPOSIT_TYPE);

					MetaSuccessDto msd = (MetaSuccessDto) payload.getMeta();														
					msd.setTdAccountNumber(requestId);

					String convertedPayload = ProcessingUtils.toJson(notification, NotificationTemplateDto.class);
					KafkaMessage message = new KafkaMessage();
					message.setTopic(mbsNotificationTopic);
					message.setMessage(convertedPayload);

					LOGGER.info("\nSUCCESSFUL OTD PAYLOAD:\n{}", ProcessingUtils.prettyJson(convertedPayload));										
					kafka.send(message);
					LOGGER.info("Notification handed off via Kafka.\nEnd of processing for OTD # {}.", requestId);
				}

				LOGGER.info("Saving updated OTD requests. Processed count is {} vs. {} records.", postCalls.size(), updates.size());
				save(updates);
				postCalls.clear();
				forKafka.clear();
			} catch(Exception e) {
				LOGGER.error("Error during processing of 2nd host feedback file:\n", e);
				throw e;
			} finally {
				if(ffReader != null)
					ffReader.close();
			}
		} else {
			LOGGER.error("{}: File not found!", inputPath.toString());
			throw new ResourceNotFoundException();
		}
	}

	private void save(List<OtdFedbackRequest> updates) {
		int count = updates.size();
		List<OtdFedbackRequest> batch = new ArrayList<>();
 		for (int i = 0; i < count; i++) {
 			batch.add(updates.get(i));
			if (i % batchSize == 0 && i > 0) {
				requestRepository.saveAll(batch);
				batch.clear();
			}
		}

		if (batch.size() > 0) {
			requestRepository.saveAll(batch);
			batch.clear();
		}
	}

	private MetaSuccessDto metaSuccess(String tdAccountNo, String currency, String principalAmount, String interestRate, String term,
			String payoutOption, String maturityDate, String settlementAccount, String transactionDate,
			String referenceId) {
		return new MetaSuccessDto(tdAccountNo, currency, principalAmount, interestRate, term, payoutOption, maturityDate, settlementAccount, transactionDate, referenceId);
	}

	//added by randy.bautista 02-10-2019
	//NOTE: CHANGING ANY HTML CODE IN "FAILURE-REASON.OTD" FILE, MAY AFFECT IN THIS METHOD..
	private MetaReasonFailedDto processReason(int code) {		
		MetaReasonFailedDto metaReason = new MetaReasonFailedDto();
		switch(code) {
		case 0:
			metaReason.setTitle(whyFailed.getInactiveAccountTitle());
			metaReason.setSubtitle(StringUtils.EMPTY);
			metaReason.setData(whyFailed.getInactiveAccountReason());
			break;

		case 1:
			metaReason.setTitle(whyFailed.getInsufficientFundsTitle());
			metaReason.setSubtitle(whyFailed.getInsufficientFundsSubtitle());
			metaReason.setData(whyFailed.getInsufficientFundsReason());
			break;

		default:
			metaReason.setTitle(whyFailed.getOtherReasonsTitle());
			metaReason.setSubtitle(StringUtils.EMPTY);
			metaReason.setData(whyFailed.getOtherReasonsReason());
		}

		return metaReason;
	}

	private String authServer;
	private String authServerRealm;
	private String authServerClientId;
	private String authServerClientSecret;
	private String tokenValidityInSeconds;
	private String authUrl;

	private long lastGenerationTime;

	protected boolean injectAccessToken;
	protected boolean securityEnabled;

	@PostConstruct
	private void setupRealm() {
		authServer = env.getProperty("auth.server.url");
		authServerRealm = env.getProperty("auth.server.realm");
		authServerClientId = env.getProperty("auth.server.client-id");
		authServerClientSecret = env.getProperty("auth.server.client-secret");
		tokenValidityInSeconds = env.getProperty("auth.token.validity.seconds");
		authUrl = ProcessingUtils.append(authServer, "/realms/", authServerRealm, "/protocol/openid-connect/token");
	}

	private JsonObject obtainAccessObject() {
		JsonObject accessObject = new JsonObject();
		accessObject.addProperty(AppConstants.AUTHORIZATION_PARAMETER, obtainAccessToken());
		accessObject.addProperty(AppConstants.X_DEVICE_ID, StringUtils.EMPTY);
		accessObject.addProperty(AppConstants.X_FORWARDED_FOR, StringUtils.EMPTY);
		accessObject.addProperty(AppConstants.X_OS, StringUtils.EMPTY);
		return accessObject;
	}

	private String obtainAccessToken() {
		if (!isTokenValid()) {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

			MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
			map.add("grant_type", "client_credentials");
			map.add("client_id", authServerClientId);
			map.add("client_secret", authServerClientSecret);

			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
			ResponseEntity<AccessTokenResponse> response = new RestTemplate().postForEntity(authUrl, request, AccessTokenResponse.class);

			accessToken = ProcessingUtils.append(AppConstants.BEARER, response.getBody().getToken());
		}

		return accessToken;
	}

	private boolean isTokenValid() {
		long now = System.nanoTime();

		if (lastGenerationTime == 0L) {
			lastGenerationTime = now;
			return false;
		}

		try {
			long validity = Long.parseLong(tokenValidityInSeconds);
			long elapsedTime = now - lastGenerationTime;
			long elapsedTimeInSeconds = TimeUnit.SECONDS.convert(elapsedTime, TimeUnit.NANOSECONDS);

			return elapsedTimeInSeconds < validity;
		} catch (NumberFormatException | NullPointerException e) {
			return false;
		}

	}
}