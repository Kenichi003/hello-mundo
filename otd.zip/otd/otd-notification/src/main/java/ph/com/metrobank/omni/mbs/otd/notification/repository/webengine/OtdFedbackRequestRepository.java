package ph.com.metrobank.omni.mbs.otd.notification.repository.webengine;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ph.com.metrobank.omni.mbs.otd.notification.model.OtdFedbackRequest;

public interface OtdFedbackRequestRepository extends JpaRepository<OtdFedbackRequest, Long> {

  @Override
  Optional<OtdFedbackRequest> findById(Long id);

  Optional<OtdFedbackRequest> findByReferenceId(String id);
  
  @Query(value = "SELECT * from OTD_REQUESTS r where r.created >= :stamp", nativeQuery=true)
  List<OtdFedbackRequest> findByCreated(@Param("stamp") String stamp);

  @Query(value = "SELECT * from OTD_REQUESTS r where r.updated >= :stamp", nativeQuery=true)
  List<OtdFedbackRequest> findByUpdated(@Param("stamp") String stamp);

//  @Query(value = "DELETE from OTD_REQUESTS r where r.created = :stamp")
  void deleteByCreated(@Param("stamp") Date stamp);

  Optional<OtdFedbackRequest> findByAccountId(String accountId);
  Optional<OtdFedbackRequest> findByOtdAccountId(String otdAccountId);
}
