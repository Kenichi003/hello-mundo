package ph.com.metrobank.omni.mbs.otd.notification.dto;

import java.util.HashMap;
import java.util.Map;

public class NotificationPayload {
	private Map<String, String> smsTokens = new HashMap<>();
	private Map<String, String> emailTokens = new HashMap<>();
	private Map<String, String> notificationTitleTokens = new HashMap<>();
	private Map<String, String> notificationBodyTokens = new HashMap<>();
	private String referenceNo;
	private String sourceAccountId;
	protected String type = "TIME_DEPOSIT";
	protected String transactionType = "TIME_DEPOSIT";
	protected String transactionStatus;
	protected String status;
	protected Object meta;

	public NotificationPayload() {
	}
	
	public void addSmsToken(String key, String value) {
		smsTokens.put(key, value);
	}
	
	public void addEmailToken(String key, String value) {
		emailTokens.put(key, value);
	}
	
	public void addNotificationTitleToken(String key, String value) {
		notificationTitleTokens.put(key, value);
	}
	
	public void addNotificationBodyToken(String key, String value) {
		notificationBodyTokens.put(key, value);
	}
	
	public String getReferenceNo() {
		return referenceNo;
	}
	
	public void setReferenceNo(String reference) {
		referenceNo = reference;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Object getMeta() {
		return meta;
	}

	public void setMeta(Object meta) {
		this.meta = meta;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getSourceAccountId() {
		return sourceAccountId;
	}

	public void setSourceAccountId(String sourceAccountId) {
		this.sourceAccountId = sourceAccountId;
	}
}
