package ph.com.metrobank.omni.mbs.otd.notification.rest;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class GetCall implements Callable<HttpResponse> {
	private static final Logger LOGGER = LoggerFactory.getLogger(GetCall.class);

	private String id;

	private CloseableHttpAsyncClient client;
	private HttpContext context;

	private HttpGet request;
	private HttpResponse response;

	public GetCall(CloseableHttpAsyncClient client, String id, HttpGet req){
		this.id = id;
		this.client = client;
		context = HttpClientContext.create();
		this.request = req;
	}

	public HttpResponse getResponse() {
		return response;
	}

	public String getRequestId() {
		return id;
	}


	@Override
	public HttpResponse call() throws InterruptedException, ExecutionException, TimeoutException {
    	MDC.put("job-id", id);
    	try {
    		Future<HttpResponse> future = client.execute(request, context, null);
    		if(future != null) {
    			response = future.get(30000, TimeUnit.MILLISECONDS);
    		} else {
    			LOGGER.info("{}: Request timeout.", id);
    		}

    		return response;
    	} finally {
    	    MDC.remove("job-id");
    	}
	}
}