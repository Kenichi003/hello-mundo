package ph.com.metrobank.omni.mbs.otd.notification.exception;

import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.core.Response;

public class AccessException extends NotAuthorizedException {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  public AccessException(String message) {
    super(message);
  }

  public AccessException(String message, Throwable e) {
    super(message, e);
  }
  
  public AccessException(Response response) {
	    super(response);
 }
}
