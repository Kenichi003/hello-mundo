package ph.com.metrobank.omni.mbs.otd.notification.config;

import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import liquibase.integration.spring.SpringLiquibase;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "ph.com.metrobank.omni.mbs.otd.notification.repository.webengine",
    entityManagerFactoryRef = "webengineEntityManager",
    transactionManagerRef = "webengineTransactionManager")
public class WebEngineConfig {

  @Bean
  @Primary
  @ConfigurationProperties("webengine.datasource")
  public DataSourceProperties webEngineDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean
  @Primary
  @ConfigurationProperties("webengine.datasource")
  public DataSource webengineDataSource() {
    return webEngineDataSourceProperties().initializeDataSourceBuilder().build();
  }

  @Bean
  @ConfigurationProperties(prefix = "webengine.datasource.liquibase")
  public LiquibaseProperties webengineLiquibaseProperties() {
    return new LiquibaseProperties();
  }

  @Bean(name = "liquibase")
  public SpringLiquibase webengineLiquibase() {
    return springLiquibase(webengineDataSource(), webengineLiquibaseProperties());
  }

  @PersistenceContext(unitName = "webengine")
  @Primary
  @Bean(name = "webengineEntityManager")
  public LocalContainerEntityManagerFactoryBean webengineEntityManagerFactory(
      EntityManagerFactoryBuilder builder) {
    return builder.dataSource(webengineDataSource()).packages("ph.com.metrobank.omni.mbs.otd.notification.model")
        .persistenceUnit("webengine").build();
  }

  @Bean(name = "webengineTransactionManager")
  @Primary
  public PlatformTransactionManager transactionManager(EntityManagerFactoryBuilder builder) {
    JpaTransactionManager tm = new JpaTransactionManager();
    tm.setEntityManagerFactory(webengineEntityManagerFactory(builder).getObject());
    tm.setDataSource(webengineDataSource());
    return tm;
  }

  private static SpringLiquibase springLiquibase(DataSource dataSource,
      LiquibaseProperties properties) {
    SpringLiquibase liquibase = new SpringLiquibase();
    liquibase.setDataSource(dataSource);
    liquibase.setChangeLog(properties.getChangeLog());
    liquibase.setContexts(properties.getContexts());
    liquibase.setDefaultSchema(properties.getDefaultSchema());
    liquibase.setDropFirst(properties.isDropFirst());
    liquibase.setShouldRun(properties.isEnabled());
    liquibase.setLabels(properties.getLabels());
    liquibase.setChangeLogParameters(properties.getParameters());
    liquibase.setRollbackFile(properties.getRollbackFile());
    return liquibase;
  }
}
